# Data Store

One Spring Boot library for **in-memory reference data** close to the executor JVM, or behind a REST API.
Datasets are declared in YAML: flat files, `JdbcClient` and `RestClient` sources, eager or lazy, with
reusable templates. They're held in a Spring `CacheManager` (in-memory: `simple` by default, Caffeine optional)
and reached through one singleton facade from plain Java, Flink or Spark. Python goes over REST.

```
           DataStore.get()  → DataStoreOperations
    ┌──────────────────┼───────────────────────┐
 embedded           delegate                remote ──HTTP──► DataStoreController (same library, web app)
 CachingDataStore   AbstractDelegatingStore  RemoteDataStore        ▲
 Spring Cache +     (your prebuilt library,                         └── Python: datastore.get_client()
 ReferenceDao       no cache)
 FlatFileDao · JdbcDao · RestDao · your @Repository
```

| Project | What |
|---|---|
| `datastore-lib` | the library (about 16 classes) |
| `refdata-example` | sample implementation: `application.yml` with 6 datasets, models, one custom DAO, tests for all 3 modes. The same jar runs embedded or as the server. |
| `clients/python` | stdlib-only remote client |

Build: `gradle build` (Java 17+, Gradle 8; run `gradle wrapper` once).

## API

```java
DataStoreOperations store = DataStore.init(Map.of("asOf", "2026-10-03"), 4);   // load args, parallelism
Customer c          = DataStore.get().get("customers", "C001", Customer.class);
Map<String, Price> p = DataStore.get().getAll("prices", isins, Price.class);   // misses: one batch call
DataStore.get().put("risk-scores", "C001", score);                              // write-through
DataStore.get().load("customers", Map.of("asOf", "2026-10-02"));               // reload with new args
DataStore.get().reload("fx-rates");                                             // same args as last load
DataStore.destroy();                                                            // clean everything
```

`DataStoreOperations`: `get`, `getAll`, `put`, `putAll`, `remove`, `initialize(args, parallelism)`,
`load(dataset, args)`, `reload(dataset)`, `datasets()`, `destroy()`.

**Load arguments**, resolved in this order:

1. arguments passed to the call
2. arguments given to `initialize` / `DataStore.init`
3. `datastore.default-args` in the YAML

Each dataset remembers the arguments it was last loaded with. `reload` and lazy key lookups reuse them.

**Facade options:** `DataStore.init(properties, args, parallelism, sources...)`.

- `properties` override everything, e.g. `datastore.mode=remote` in Flink job parameters.
- `sources` adds your Spring classes (DAO beans, DataSources). You can also set `datastore.boot.sources`.
- The facade never reconfigures the host's logging, so Flink and Spark log4j settings are left alone.

## YAML

```yaml
spring:
  cache.type: simple          # in-memory maps; 'caffeine' later without touching datastore.*

datastore:
  mode: ${DATASTORE_MODE:embedded}       # embedded | delegate | remote
  init-parallelism: 4
  default-args:
    asOf: ${BUSINESS_DATE:}               # ${ENV} / ${sys.prop:default}: resolved by Spring at startup

  templates:                              # reusable; datasets override any field
    pipe-file:
      file: { separator: "|", header: true, skip-trailer-lines: 1, null-value: "NULL" }
    refdb:
      jdbc: { datasource: oracleDataSource, fetch-size: 5000 }
    pricing-api:
      rest: { client: pricingRestClient, base-url: "${PRICING_URL}", headers: { X-Api-Key: "${PRICING_KEY}" } }

  datasets:                               # kebab-case names (Boot strips '_' from map keys)
    customers:
      template: pipe-file
      type: com.yourco.refdata.model.Customer    # or omit / 'map' for raw rows
      key: [customer_id]                          # composite: [book, isin] -> "B1|US123"
      file: { path: "${REFDATA_DIR}/customers_{asOf}.dat" }   # {arg}: filled at each load
    fx-rates:
      template: refdb
      key: [ccy_pair]
      jdbc:
        sql: "select ccy_pair, rate from fx_rate where as_of = :asOf"            # :arg = bound parameter
        get-sql: "select ccy_pair, rate from fx_rate where as_of = :asOf and ccy_pair = :key"
    prices:
      template: pricing-api
      preload: false                                       # lazy
      key: [isin]
      rest: { get-path: "/prices/{key}?asOf={asOf}", batch-path: "/prices/lookup?asOf={asOf}" }
    risk-scores:
      template: refdb
      writable: true
      key: [customer_id]
      jdbc:
        sql: "select * from risk_score"
        upsert-sql: "merge into risk_score ... values (:customer_id, :score, :computed_by)"
        delete-sql: "delete from risk_score where customer_id = :key"
    trade-limits:
      dao: tradeLimitDao                                   # any bean implementing ReferenceDao
      preload: false
```

### Sources

**`file`**: delimited flat files.

| Option | Default | |
|---|---|---|
| `path` | | `file:`/`classpath:`/plain path; `{args}`; globs (`*.dat`, sorted); `.gz` |
| `separator` | `,` | any string: `\|`, `\t`, `~\|~` |
| `header` / `columns` | `true` / | read names from the first data row, or give them (`header: false`) |
| `skip-header-lines` / `skip-trailer-lines` | 0 / 0 | banner lines before the header; trailer lines per file |
| `comment-prefix` | | skip lines starting with it (blank lines are always skipped) |
| `quote` | `"` | `""` escapes; `quote: ""` disables |
| `trim`, `null-value`, `charset`, `strict` | true, `""`, UTF-8, true | `strict`: fail on a column-count mismatch |

**`jdbc`** uses `JdbcClient`:

| Statement | Used for |
|---|---|
| `sql` | bulk load |
| `get-sql` (`:key`, `:key1`..) | lazy lookup of one key |
| `get-all-sql` (`:keys`) | lazy batch lookup |
| `upsert-sql` (value fields as `:snake_case` and `:camelCase`) | write-back |
| `delete-sql` | write-back delete |

- **Parameters:** load arguments are available in every statement.
- **Data source:** set `datasource: <bean>` when you have several.

**`rest`** uses `RestClient`:

| Option | Used for |
|---|---|
| `all-path` | bulk load |
| `get-path` | lazy lookup (404 = not found) |
| `batch-path` | lazy batch: POST the keys; the response is `{key: item}` or `[items]` |
| `put-path` / `delete-path` | write-back |
| `items-path` | JSON pointer to the item array, e.g. `/data` |

- **Client:** `client: <bean>` reuses an existing `RestClient` (its auth and interceptors).
- **`base-url` / `headers`:** applied on top.

**Combining sources:** a dataset with `file` plus `jdbc` (or `rest`) bulk-loads from the file and serves misses and writes from the second source.

**Row mapping:** columns become record fields via Jackson. `customer_id`, `CUSTOMER_ID` and `Customer Id` all map to `customerId`, and strings are converted to numbers, dates and booleans.

## Behaviour

- **`initialize`** loads every `preload: true` dataset in parallel (`init-parallelism`, or the argument). With `fail-fast: true`, any failure aborts initialization.
- **Load and reload** fetch into a buffer first, then put the new values and evict keys that are gone. Readers never see an empty dataset, and a failed load keeps the old data.
- **Cache misses** go to the DAO's key lookup:
  - concurrent misses on one key cause a single source call
  - `getAll` misses are fetched in one batch call
  - "not found" is not cached
- **Writes** require `writable: true`. They go to the source first when the DAO can save; otherwise they stay in memory only.
- **`destroy()`** clears every dataset, forgets arguments and closes DAOs. `DataStore.destroy()` also closes the Spring context and resets the singleton.
- **Cache provider:** with `spring.cache.type: simple` nothing is evicted, so lazy datasets grow with every key requested. For large, open-ended key spaces use `caffeine` with a size limit.

## Delegate mode

```java
@Component
class LegacyRefDataStore extends AbstractDelegatingDataStore {
    private final LegacyRefDataService legacy;
    protected Object fetch(String dataset, String key) { return legacy.lookup(dataset, key); }
    // override getAll / put / load ... when you map them
}
```
Set `datastore.mode: delegate`. The facade, the REST API and the Python client then all go through your class.

## Server (remote mode)

Add `spring-boot-starter-web` to the implementation project and run it (`java -jar refdata-example.jar`).

- **Startup:** it preloads, then serves the REST API.
- **Clients:** executors use `datastore.mode=remote` plus `datastore.remote.url`; Python uses `get_client(url)`.

| Endpoint | |
|---|---|
| `GET /api/v1/datasets` | `DatasetInfo` list (size, args, status, load time, error) |
| `GET /api/v1/datasets/{ds}/entry?key=` | one value (404 `NOT_FOUND`) |
| `POST /api/v1/datasets/{ds}/lookup` | `["k1","k2"]` → `{k: v}` |
| `PUT /api/v1/datasets/{ds}/entry?key=` / `/entries` | write |
| `DELETE /api/v1/datasets/{ds}/entry?key=` | `{"removed": true}` |
| `POST /api/v1/initialize` | `{"args": {...}, "parallelism": 4}` |
| `POST /api/v1/datasets/{ds}/load` / `/reload` | body = args |
| `POST /api/v1/destroy` | only with `datastore.server.allow-destroy: true` |

Errors are returned as `{"code","message"}`, using the same codes as `DataStoreException` and the Python `DataStoreError`.
