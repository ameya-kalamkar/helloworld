package com.yourco.datastore.dao;

import com.yourco.datastore.DataStoreException;

import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.function.BiConsumer;

/**
 * The one DAO contract. Built-in implementations ({@link JdbcDao}, {@link RestDao}, {@link FlatFileDao})
 * are created from YAML; for anything else implement this as a Spring bean and reference it with
 * {@code dao: <beanName>}. Implement only what the source supports; the rest stays unsupported.
 *
 * <p>Every method receives the effective load arguments (call &gt; initialize &gt; default-args).</p>
 */
public interface ReferenceDao<V> {

    /** Bulk load for preload / reload: push every (key, value) into the sink. */
    default void findAll(Map<String, String> args, BiConsumer<String, V> sink) {
        throw DataStoreException.unsupported(getClass().getSimpleName() + " has no bulk load");
    }

    /** Lazy load of one key on a cache miss; return null when the source has no such key. */
    default V findById(String key, Map<String, String> args) {
        throw DataStoreException.unsupported(getClass().getSimpleName() + " has no key lookup");
    }

    /** Lazy batch load for {@code getAll} misses. Default: one {@link #findById} per key. */
    default Map<String, V> findAllById(Collection<String> keys, Map<String, String> args) {
        Map<String, V> out = new LinkedHashMap<>();
        for (String key : keys) {
            V v = findById(key, args);
            if (v != null) {
                out.put(key, v);
            }
        }
        return out;
    }

    /** Write-back (writable datasets). If unsupported, writes stay in memory only. */
    default void save(Map<String, V> values, Map<String, String> args) {
        throw DataStoreException.unsupported(getClass().getSimpleName() + " has no save");
    }

    default void delete(String key, Map<String, String> args) {
        throw DataStoreException.unsupported(getClass().getSimpleName() + " has no delete");
    }

    /** Release resources; called by destroy(). */
    default void close() {
    }

    /** Shown in DatasetInfo.source. */
    default String describe() {
        return "dao:" + getClass().getSimpleName();
    }
}
