package com.yourco.datastore.config;

import com.yourco.datastore.DataStoreException;
import org.springframework.boot.context.properties.ConfigurationProperties;

import java.time.Duration;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * {@code datastore.*} configuration. {@code ${ENV}} / {@code ${sys.prop:default}} placeholders are resolved by
 * Spring at startup; {@code {arg}} placeholders (paths, URLs) and {@code :arg} SQL parameters at each load.
 *
 * <p>Dataset names are map keys: use kebab-case ({@code fx-rates}). Spring Boot strips {@code _} from
 * map keys unless written as {@code "[fx_rates]"}.</p>
 */
@ConfigurationProperties("datastore")
public class DataStoreProperties {

    /** embedded | delegate | remote */
    private String mode = "embedded";
    /** Load preload datasets when the Spring context starts (the facade turns this off and calls initialize itself). */
    private boolean preloadOnStartup = true;
    /** Datasets loaded concurrently by initialize() unless a parallelism is passed. */
    private int initParallelism = Math.max(1, Math.min(4, Runtime.getRuntime().availableProcessors()));
    /** Abort initialize() when any preload dataset fails. */
    private boolean failFast = true;
    /** Lowest-precedence load arguments. */
    private Map<String, String> defaultArgs = new LinkedHashMap<>();
    /** Reusable partial dataset configs, referenced with {@code template:}. */
    private Map<String, DatasetSpec> templates = new LinkedHashMap<>();
    private Map<String, DatasetSpec> datasets = new LinkedHashMap<>();
    private Remote remote = new Remote();
    private Server server = new Server();

    /** Datasets with their template merged in and defaults applied. */
    public Map<String, DatasetSpec> resolvedDatasets() {
        Map<String, DatasetSpec> out = new LinkedHashMap<>();
        datasets.forEach((name, spec) -> {
            DatasetSpec merged = spec;
            if (spec.getTemplate() != null) {
                DatasetSpec template = templates.get(spec.getTemplate());
                if (template == null) {
                    throw DataStoreException.config("Dataset '" + name + "' uses unknown template '" + spec.getTemplate() + "'");
                }
                merged = spec.overlay(template);
            }
            out.put(name, merged.withDefaults());
        });
        return out;
    }

    // ---- nested specs -----------------------------------------------------------------------

    public static class DatasetSpec {
        private String template;
        /** Value class, or "map" (default) for raw rows. */
        private String type;
        private Boolean preload;
        private Boolean writable;
        /** Key column(s); composite keys are joined with '|'. */
        private List<String> key;
        /** Bean name of a custom ReferenceDao (instead of file/jdbc/rest). */
        private String dao;
        private FileSpec file;
        private JdbcSpec jdbc;
        private RestSpec rest;

        /** This spec's non-null values on top of {@code base}. */
        DatasetSpec overlay(DatasetSpec base) {
            DatasetSpec m = new DatasetSpec();
            m.template = template;
            m.type = pick(type, base.type);
            m.preload = pick(preload, base.preload);
            m.writable = pick(writable, base.writable);
            m.key = pick(key, base.key);
            m.dao = pick(dao, base.dao);
            m.file = file == null ? base.file : base.file == null ? file : file.overlay(base.file);
            m.jdbc = jdbc == null ? base.jdbc : base.jdbc == null ? jdbc : jdbc.overlay(base.jdbc);
            m.rest = rest == null ? base.rest : base.rest == null ? rest : rest.overlay(base.rest);
            return m;
        }

        DatasetSpec withDefaults() {
            DatasetSpec d = overlay(new DatasetSpec());
            d.type = pick(d.type, "map");
            d.preload = pick(d.preload, Boolean.TRUE);
            d.writable = pick(d.writable, Boolean.FALSE);
            d.key = pick(d.key, List.of());
            if (d.file != null) {
                d.file = d.file.overlay(FileSpec.defaults());
            }
            if (d.jdbc != null) {
                d.jdbc = d.jdbc.overlay(JdbcSpec.defaults());
            }
            return d;
        }

        public String getTemplate() { return template; }
        public void setTemplate(String template) { this.template = template; }
        public String getType() { return type; }
        public void setType(String type) { this.type = type; }
        public Boolean getPreload() { return preload; }
        public void setPreload(Boolean preload) { this.preload = preload; }
        public Boolean getWritable() { return writable; }
        public void setWritable(Boolean writable) { this.writable = writable; }
        public List<String> getKey() { return key; }
        public void setKey(List<String> key) { this.key = key == null ? null : new ArrayList<>(key); }
        public String getDao() { return dao; }
        public void setDao(String dao) { this.dao = dao; }
        public FileSpec getFile() { return file; }
        public void setFile(FileSpec file) { this.file = file; }
        public JdbcSpec getJdbc() { return jdbc; }
        public void setJdbc(JdbcSpec jdbc) { this.jdbc = jdbc; }
        public RestSpec getRest() { return rest; }
        public void setRest(RestSpec rest) { this.rest = rest; }
    }

    /** Delimited flat file(s). */
    public static class FileSpec {
        /** file:/..., classpath:..., or a plain path; supports {args}, globs and .gz. */
        private String path;
        private String separator;
        /** First data line holds column names. */
        private Boolean header;
        /** Column names when header is false (or to override the header). */
        private List<String> columns;
        /** Banner lines before the header / data. */
        private Integer skipHeaderLines;
        /** Trailer lines at the end of each file. */
        private Integer skipTrailerLines;
        private String commentPrefix;
        /** Quote character ("" disables quoting). */
        private String quote;
        private Boolean trim;
        /** Token treated as null (e.g. "", "NULL", "\\N"). */
        private String nullValue;
        private String charset;
        /** Fail on rows whose column count differs from the header. */
        private Boolean strict;

        static FileSpec defaults() {
            FileSpec f = new FileSpec();
            f.separator = ",";
            f.header = true;
            f.skipHeaderLines = 0;
            f.skipTrailerLines = 0;
            f.quote = "\"";
            f.trim = true;
            f.nullValue = "";
            f.charset = "UTF-8";
            f.strict = true;
            return f;
        }

        FileSpec overlay(FileSpec b) {
            FileSpec m = new FileSpec();
            m.path = pick(path, b.path);
            m.separator = pick(separator, b.separator);
            m.header = pick(header, b.header);
            m.columns = pick(columns, b.columns);
            m.skipHeaderLines = pick(skipHeaderLines, b.skipHeaderLines);
            m.skipTrailerLines = pick(skipTrailerLines, b.skipTrailerLines);
            m.commentPrefix = pick(commentPrefix, b.commentPrefix);
            m.quote = pick(quote, b.quote);
            m.trim = pick(trim, b.trim);
            m.nullValue = pick(nullValue, b.nullValue);
            m.charset = pick(charset, b.charset);
            m.strict = pick(strict, b.strict);
            return m;
        }

        public String getPath() { return path; }
        public void setPath(String path) { this.path = path; }
        public String getSeparator() { return separator; }
        public void setSeparator(String separator) { this.separator = separator; }
        public Boolean getHeader() { return header; }
        public void setHeader(Boolean header) { this.header = header; }
        public List<String> getColumns() { return columns; }
        public void setColumns(List<String> columns) { this.columns = columns == null ? null : new ArrayList<>(columns); }
        public Integer getSkipHeaderLines() { return skipHeaderLines; }
        public void setSkipHeaderLines(Integer skipHeaderLines) { this.skipHeaderLines = skipHeaderLines; }
        public Integer getSkipTrailerLines() { return skipTrailerLines; }
        public void setSkipTrailerLines(Integer skipTrailerLines) { this.skipTrailerLines = skipTrailerLines; }
        public String getCommentPrefix() { return commentPrefix; }
        public void setCommentPrefix(String commentPrefix) { this.commentPrefix = commentPrefix; }
        public String getQuote() { return quote; }
        public void setQuote(String quote) { this.quote = quote; }
        public Boolean getTrim() { return trim; }
        public void setTrim(Boolean trim) { this.trim = trim; }
        public String getNullValue() { return nullValue; }
        public void setNullValue(String nullValue) { this.nullValue = nullValue; }
        public String getCharset() { return charset; }
        public void setCharset(String charset) { this.charset = charset; }
        public Boolean getStrict() { return strict; }
        public void setStrict(Boolean strict) { this.strict = strict; }
    }

    /** SQL via JdbcClient. All statements take :named parameters (load args, :key, :keys, value fields). */
    public static class JdbcSpec {
        /** DataSource bean name; default: the single DataSource. */
        private String datasource;
        /** Bulk load (preload / reload). */
        private String sql;
        /** Lazy single-key load; parameter :key (composite parts :key1, :key2 ...). */
        private String getSql;
        /** Lazy batch load; parameter :keys (list). */
        private String getAllSql;
        /** Write-back; parameters: value fields (snake_case and camelCase), :key and load args. */
        private String upsertSql;
        private String deleteSql;
        private Integer fetchSize;

        static JdbcSpec defaults() {
            JdbcSpec j = new JdbcSpec();
            j.fetchSize = 1000;
            return j;
        }

        JdbcSpec overlay(JdbcSpec b) {
            JdbcSpec m = new JdbcSpec();
            m.datasource = pick(datasource, b.datasource);
            m.sql = pick(sql, b.sql);
            m.getSql = pick(getSql, b.getSql);
            m.getAllSql = pick(getAllSql, b.getAllSql);
            m.upsertSql = pick(upsertSql, b.upsertSql);
            m.deleteSql = pick(deleteSql, b.deleteSql);
            m.fetchSize = pick(fetchSize, b.fetchSize);
            return m;
        }

        public String getDatasource() { return datasource; }
        public void setDatasource(String datasource) { this.datasource = datasource; }
        public String getSql() { return sql; }
        public void setSql(String sql) { this.sql = sql; }
        public String getGetSql() { return getSql; }
        public void setGetSql(String getSql) { this.getSql = getSql; }
        public String getGetAllSql() { return getAllSql; }
        public void setGetAllSql(String getAllSql) { this.getAllSql = getAllSql; }
        public String getUpsertSql() { return upsertSql; }
        public void setUpsertSql(String upsertSql) { this.upsertSql = upsertSql; }
        public String getDeleteSql() { return deleteSql; }
        public void setDeleteSql(String deleteSql) { this.deleteSql = deleteSql; }
        public Integer getFetchSize() { return fetchSize; }
        public void setFetchSize(Integer fetchSize) { this.fetchSize = fetchSize; }
    }

    /** HTTP via RestClient. Paths are URI templates with {key} and {args}. */
    public static class RestSpec {
        /** RestClient bean name (reuses its interceptors / auth); optional. */
        private String client;
        private String baseUrl;
        private Map<String, String> headers;
        /** Bulk load (GET): JSON array, or object with items at items-path. */
        private String allPath;
        /** Lazy single key (GET {key}); 404 = not found. */
        private String getPath;
        /** Lazy batch (POST JSON array of keys): returns {key: value} or an array of items. */
        private String batchPath;
        /** Write-back (PUT {key}, body = value). */
        private String putPath;
        private String deletePath;
        /** JSON pointer to the item array in bulk/batch responses, e.g. /data. */
        private String itemsPath;

        RestSpec overlay(RestSpec b) {
            RestSpec m = new RestSpec();
            m.client = pick(client, b.client);
            m.baseUrl = pick(baseUrl, b.baseUrl);
            Map<String, String> h = new LinkedHashMap<>();
            if (b.headers != null) {
                h.putAll(b.headers);
            }
            if (headers != null) {
                h.putAll(headers);
            }
            m.headers = h;
            m.allPath = pick(allPath, b.allPath);
            m.getPath = pick(getPath, b.getPath);
            m.batchPath = pick(batchPath, b.batchPath);
            m.putPath = pick(putPath, b.putPath);
            m.deletePath = pick(deletePath, b.deletePath);
            m.itemsPath = pick(itemsPath, b.itemsPath);
            return m;
        }

        public String getClient() { return client; }
        public void setClient(String client) { this.client = client; }
        public String getBaseUrl() { return baseUrl; }
        public void setBaseUrl(String baseUrl) { this.baseUrl = baseUrl; }
        public Map<String, String> getHeaders() { return headers; }
        public void setHeaders(Map<String, String> headers) { this.headers = headers; }
        public String getAllPath() { return allPath; }
        public void setAllPath(String allPath) { this.allPath = allPath; }
        public String getGetPath() { return getPath; }
        public void setGetPath(String getPath) { this.getPath = getPath; }
        public String getBatchPath() { return batchPath; }
        public void setBatchPath(String batchPath) { this.batchPath = batchPath; }
        public String getPutPath() { return putPath; }
        public void setPutPath(String putPath) { this.putPath = putPath; }
        public String getDeletePath() { return deletePath; }
        public void setDeletePath(String deletePath) { this.deletePath = deletePath; }
        public String getItemsPath() { return itemsPath; }
        public void setItemsPath(String itemsPath) { this.itemsPath = itemsPath; }
    }

    public static class Remote {
        /** Base URL of the data store server, e.g. http://refdata:8085 */
        private String url;
        private Duration connectTimeout = Duration.ofSeconds(5);
        private Duration requestTimeout = Duration.ofSeconds(30);
        /** Retries for reads only. */
        private int maxRetries = 2;
        private Map<String, String> headers = new LinkedHashMap<>();

        public String getUrl() { return url; }
        public void setUrl(String url) { this.url = url; }
        public Duration getConnectTimeout() { return connectTimeout; }
        public void setConnectTimeout(Duration connectTimeout) { this.connectTimeout = connectTimeout; }
        public Duration getRequestTimeout() { return requestTimeout; }
        public void setRequestTimeout(Duration requestTimeout) { this.requestTimeout = requestTimeout; }
        public int getMaxRetries() { return maxRetries; }
        public void setMaxRetries(int maxRetries) { this.maxRetries = maxRetries; }
        public Map<String, String> getHeaders() { return headers; }
        public void setHeaders(Map<String, String> headers) { this.headers = headers; }
    }

    public static class Server {
        /** Expose the REST API when running as a web application. */
        private boolean enabled = true;
        /** Allow POST /destroy over HTTP (off by default). */
        private boolean allowDestroy = false;

        public boolean isEnabled() { return enabled; }
        public void setEnabled(boolean enabled) { this.enabled = enabled; }
        public boolean isAllowDestroy() { return allowDestroy; }
        public void setAllowDestroy(boolean allowDestroy) { this.allowDestroy = allowDestroy; }
    }

    private static <T> T pick(T value, T fallback) {
        return value != null ? value : fallback;
    }

    // ---- top-level accessors ------------------------------------------------------------------

    public String getMode() { return mode; }
    public void setMode(String mode) { this.mode = mode; }
    public boolean isPreloadOnStartup() { return preloadOnStartup; }
    public void setPreloadOnStartup(boolean preloadOnStartup) { this.preloadOnStartup = preloadOnStartup; }
    public int getInitParallelism() { return initParallelism; }
    public void setInitParallelism(int initParallelism) { this.initParallelism = initParallelism; }
    public boolean isFailFast() { return failFast; }
    public void setFailFast(boolean failFast) { this.failFast = failFast; }
    public Map<String, String> getDefaultArgs() { return defaultArgs; }
    public void setDefaultArgs(Map<String, String> defaultArgs) { this.defaultArgs = defaultArgs; }
    public Map<String, DatasetSpec> getTemplates() { return templates; }
    public void setTemplates(Map<String, DatasetSpec> templates) { this.templates = templates; }
    public Map<String, DatasetSpec> getDatasets() { return datasets; }
    public void setDatasets(Map<String, DatasetSpec> datasets) { this.datasets = datasets; }
    public Remote getRemote() { return remote; }
    public void setRemote(Remote remote) { this.remote = remote; }
    public Server getServer() { return server; }
    public void setServer(Server server) { this.server = server; }
}
