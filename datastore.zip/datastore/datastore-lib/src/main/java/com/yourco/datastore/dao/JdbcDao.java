package com.yourco.datastore.dao;

import com.yourco.datastore.DataStoreException;
import com.yourco.datastore.config.DataStoreProperties.JdbcSpec;
import org.springframework.jdbc.core.ColumnMapRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowCallbackHandler;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.JdbcClient;

import javax.sql.DataSource;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.function.BiConsumer;

/**
 * SQL source via Spring's {@link JdbcClient}. Statements use :named parameters filled from the load
 * arguments ({@code :asOf}), the key ({@code :key}, {@code :key1..n}), the key list ({@code :keys}) and,
 * for upserts, the value's fields.
 */
public class JdbcDao<V> implements ReferenceDao<V> {

    private static final RowMapper<Map<String, Object>> ROW = new ColumnMapRowMapper();

    private final String dataset;
    private final Class<V> type;
    private final List<String> keyColumns;
    private final JdbcSpec spec;
    private final JdbcClient jdbc;
    private final NamedParameterJdbcTemplate named;

    public JdbcDao(String dataset, Class<V> type, List<String> keyColumns, JdbcSpec spec, DataSource dataSource) {
        this.dataset = dataset;
        this.type = type;
        this.keyColumns = keyColumns;
        this.spec = spec;
        JdbcTemplate template = new JdbcTemplate(dataSource);
        template.setFetchSize(spec.getFetchSize());
        this.named = new NamedParameterJdbcTemplate(template);
        this.jdbc = JdbcClient.create(named);
    }

    @Override
    public void findAll(Map<String, String> args, BiConsumer<String, V> sink) {
        String sql = require(spec.getSql(), "jdbc.sql (bulk load)");
        int[] rowNum = {0};
        jdbc.sql(sql).params(RowConverter.params(args)).query((RowCallbackHandler) rs -> {
            Map<String, Object> row = ROW.mapRow(rs, rowNum[0]++);
            sink.accept(RowConverter.key(row, keyColumns, dataset), RowConverter.fromRow(row, type));
        });
    }

    @Override
    public V findById(String key, Map<String, String> args) {
        String sql = require(spec.getGetSql(), "jdbc.get-sql (lazy lookup)");
        Map<String, Object> params = RowConverter.params(args);
        RowConverter.addKeyParams(params, key);
        List<Map<String, Object>> rows = jdbc.sql(sql).params(params).query(ROW).list();
        return rows.isEmpty() ? null : RowConverter.fromRow(rows.get(0), type);
    }

    @Override
    public Map<String, V> findAllById(Collection<String> keys, Map<String, String> args) {
        if (spec.getGetAllSql() == null) {
            return ReferenceDao.super.findAllById(keys, args);
        }
        Map<String, V> out = new LinkedHashMap<>();
        for (Map<String, Object> row : jdbc.sql(spec.getGetAllSql()).params(RowConverter.params(args, keys)).query(ROW).list()) {
            out.put(RowConverter.key(row, keyColumns, dataset), RowConverter.fromRow(row, type));
        }
        return out;
    }

    @Override
    public void save(Map<String, V> values, Map<String, String> args) {
        String sql = require(spec.getUpsertSql(), "jdbc.upsert-sql (write-back)");
        SqlParameterSource[] batch = new SqlParameterSource[values.size()];
        int i = 0;
        for (Map.Entry<String, V> e : values.entrySet()) {
            Map<String, Object> params = RowConverter.params(args);
            params.putAll(RowConverter.toParams(e.getValue()));
            RowConverter.addKeyParams(params, e.getKey());
            batch[i++] = new MapSqlParameterSource(params);
        }
        named.batchUpdate(sql, batch);
    }

    @Override
    public void delete(String key, Map<String, String> args) {
        String sql = require(spec.getDeleteSql(), "jdbc.delete-sql");
        Map<String, Object> params = RowConverter.params(args);
        RowConverter.addKeyParams(params, key);
        jdbc.sql(sql).params(params).update();
    }

    private String require(String sql, String what) {
        if (sql == null || sql.isBlank()) {
            throw DataStoreException.unsupported("Dataset '" + dataset + "' has no " + what);
        }
        return sql;
    }

    @Override
    public String describe() {
        return "jdbc:" + (spec.getDatasource() == null ? "default" : spec.getDatasource());
    }
}
