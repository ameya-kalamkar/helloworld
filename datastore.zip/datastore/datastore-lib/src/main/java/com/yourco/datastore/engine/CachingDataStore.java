package com.yourco.datastore.engine;

import com.yourco.datastore.DataStoreException;
import com.yourco.datastore.DataStoreException.Code;
import com.yourco.datastore.DataStoreOperations;
import com.yourco.datastore.DatasetInfo;
import com.yourco.datastore.DatasetInfo.Status;
import com.yourco.datastore.config.DataStoreProperties;
import com.yourco.datastore.config.DataStoreProperties.DatasetSpec;
import com.yourco.datastore.dao.ReferenceDao;
import com.yourco.datastore.dao.RowConverter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.SmartInitializingSingleton;
import org.springframework.cache.Cache;
import org.springframework.cache.CacheManager;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Embedded mode: every dataset is one Spring {@link Cache} (always in memory: simple by default, Caffeine
 * etc. via {@code spring.cache.type}) filled by its {@link ReferenceDao}.
 * <ul>
 *   <li>preload datasets are bulk-loaded by {@link #initialize}; a (re)load buffers the new data, then puts
 *       it and evicts keys that disappeared, so readers never see an empty dataset and a failed load keeps
 *       the old data</li>
 *   <li>misses fall back to the DAO's key lookup (lazy); concurrent misses on one key cause one source call;
 *       not-found results are not cached</li>
 *   <li>writes go to the DAO first (write-through) when it can save, then to the cache</li>
 * </ul>
 */
public class CachingDataStore implements DataStoreOperations, SmartInitializingSingleton, DisposableBean {

    private static final Logger log = LoggerFactory.getLogger(CachingDataStore.class);

    private final DataStoreProperties properties;
    private final Map<String, Holder<?>> datasets = new LinkedHashMap<>();
    private volatile Map<String, String> globalArgs = Map.of();

    public CachingDataStore(DataStoreProperties properties, CacheManager cacheManager,
                            Map<String, DatasetSpec> specs, Map<String, ReferenceDao<?>> daos,
                            Map<String, Class<?>> types) {
        this.properties = properties;
        specs.forEach((name, spec) -> {
            Cache cache = cacheManager.getCache(name);
            if (cache == null) {
                throw DataStoreException.config("CacheManager " + cacheManager.getClass().getSimpleName()
                        + " has no cache '" + name + "' (if spring.cache.cache-names is set, list every dataset there)");
            }
            datasets.put(name, new Holder<>(name, spec, cast(daos.get(name)), types.get(name), cache));
        });
    }

    @SuppressWarnings("unchecked")
    private static <V> ReferenceDao<V> cast(ReferenceDao<?> dao) {
        return (ReferenceDao<V>) dao;
    }

    /** Server / plain Boot apps: preload on startup (the DataStore facade disables this and calls initialize itself). */
    @Override
    public void afterSingletonsInstantiated() {
        if (properties.isPreloadOnStartup()) {
            initialize(Map.of(), 0);
        }
    }

    @Override
    public void destroy() {
        for (Holder<?> h : datasets.values()) {
            synchronized (h.lock) {
                h.cache.clear();
                h.keys.clear();
                h.args = Map.of();
                h.status = Status.NOT_LOADED;
                h.loadedAt = 0;
                h.lastError = null;
            }
            try {
                h.dao.close();
            } catch (RuntimeException e) {
                log.warn("Closing DAO of '{}' failed", h.name, e);
            }
        }
        globalArgs = Map.of();
        log.info("Data store destroyed: all datasets cleared");
    }

    // ---- reads ----------------------------------------------------------------------------------

    @Override
    public <V> V get(String dataset, String key, Class<V> type) {
        Holder<?> h = holder(dataset);
        if (key == null) {
            return null;
        }
        Cache.ValueWrapper hit = h.cache.get(key);
        if (hit != null) {
            return RowConverter.convert(hit.get(), type);
        }
        return RowConverter.convert(h.loadOne(key), type);
    }

    @Override
    public <V> Map<String, V> getAll(String dataset, Collection<String> keys, Class<V> type) {
        Holder<?> h = holder(dataset);
        Map<String, V> out = new LinkedHashMap<>();
        List<String> misses = new ArrayList<>();
        for (String key : keys) {
            if (key == null) {
                continue;
            }
            Cache.ValueWrapper hit = h.cache.get(key);
            if (hit != null) {
                out.put(key, RowConverter.convert(hit.get(), type));
            } else {
                misses.add(key);
            }
        }
        if (!misses.isEmpty()) {
            h.loadMany(misses).forEach((k, v) -> out.put(k, RowConverter.convert(v, type)));
        }
        return out;
    }

    // ---- writes ---------------------------------------------------------------------------------

    @Override
    public <V> void put(String dataset, String key, V value) {
        putAll(dataset, Collections.singletonMap(key, value));
    }

    @Override
    public <V> void putAll(String dataset, Map<String, V> values) {
        holder(dataset).write(values);
    }

    @Override
    public boolean remove(String dataset, String key) {
        return holder(dataset).remove(key);
    }

    // ---- lifecycle ------------------------------------------------------------------------------

    @Override
    public void initialize(Map<String, String> args, int parallelism) {
        globalArgs = args == null ? Map.of() : Map.copyOf(args);
        List<Holder<?>> preload = datasets.values().stream().filter(h -> h.spec.getPreload()).toList();
        int threads = Math.max(1, Math.min(preload.size(), parallelism > 0 ? parallelism : properties.getInitParallelism()));
        long start = System.nanoTime();

        AtomicInteger n = new AtomicInteger();
        ClassLoader tccl = Thread.currentThread().getContextClassLoader();
        ExecutorService pool = Executors.newFixedThreadPool(threads, r -> {
            Thread t = new Thread(r, "datastore-init-" + n.incrementAndGet());
            t.setDaemon(true);
            t.setContextClassLoader(tccl);
            return t;
        });
        List<String> failures = new ArrayList<>();
        try {
            List<Future<?>> futures = new ArrayList<>();
            for (Holder<?> h : preload) {
                futures.add(pool.submit(() -> h.load(effectiveArgs(null))));
            }
            for (int i = 0; i < futures.size(); i++) {
                try {
                    futures.get(i).get();
                } catch (ExecutionException e) {
                    failures.add(preload.get(i).name + ": " + e.getCause().getMessage());
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    throw new DataStoreException(Code.LOAD_FAILED, "Interrupted during initialize", e);
                }
            }
        } finally {
            pool.shutdownNow();
        }
        if (!failures.isEmpty()) {
            if (properties.isFailFast()) {
                throw new DataStoreException(Code.LOAD_FAILED, "Failed to load " + failures);
            }
            log.error("Datasets failed to load (fail-fast off): {}", failures);
        }
        log.info("Data store initialized: {} preload dataset(s), {} thread(s), {} ms, args={}",
                preload.size(), threads, (System.nanoTime() - start) / 1_000_000, globalArgs);
    }

    @Override
    public DatasetInfo load(String dataset, Map<String, String> args) {
        Holder<?> h = holder(dataset);
        h.load(effectiveArgs(args));
        return h.info();
    }

    @Override
    public DatasetInfo reload(String dataset) {
        Holder<?> h = holder(dataset);
        h.load(h.args.isEmpty() ? effectiveArgs(null) : h.args);
        return h.info();
    }

    @Override
    public List<DatasetInfo> datasets() {
        List<DatasetInfo> out = new ArrayList<>();
        datasets.values().forEach(h -> out.add(h.info()));
        return out;
    }

    /** Java type of a dataset (used by the REST controller to convert request bodies). */
    public Class<?> typeOf(String dataset) {
        return holder(dataset).type;
    }

    private Map<String, String> effectiveArgs(Map<String, String> callArgs) {
        Map<String, String> merged = new HashMap<>(properties.getDefaultArgs());
        merged.values().removeIf(v -> v == null || v.isBlank());
        merged.putAll(globalArgs);
        if (callArgs != null) {
            merged.putAll(callArgs);
        }
        return Map.copyOf(merged);
    }

    private Holder<?> holder(String dataset) {
        Holder<?> h = dataset == null ? null : datasets.get(dataset);
        if (h == null) {
            throw DataStoreException.unknownDataset(dataset);
        }
        return h;
    }

    // ---- one dataset ----------------------------------------------------------------------------

    private final class Holder<V> {
        final String name;
        final DatasetSpec spec;
        final ReferenceDao<V> dao;
        final Class<V> type;
        final Cache cache;
        final Set<String> keys = ConcurrentHashMap.newKeySet();         // keys held (Cache cannot list them)
        final Map<String, CompletableFuture<V>> inFlight = new ConcurrentHashMap<>();
        final Object lock = new Object();                                // writers + load swap; readers never lock

        volatile Map<String, String> args = Map.of();
        volatile Status status = Status.NOT_LOADED;
        volatile long loadedAt;
        volatile long loadMillis;
        volatile String lastError;
        volatile boolean lazyUnsupported;
        volatile boolean saveUnsupported;

        @SuppressWarnings("unchecked")
        Holder(String name, DatasetSpec spec, ReferenceDao<V> dao, Class<?> type, Cache cache) {
            this.name = name;
            this.spec = spec;
            this.dao = dao;
            this.type = (Class<V>) type;
            this.cache = cache;
        }

        /** Lazy single-key load, coalesced per key. */
        V loadOne(String key) {
            if (lazyUnsupported) {
                return null;
            }
            CompletableFuture<V> mine = new CompletableFuture<>();
            CompletableFuture<V> existing = inFlight.putIfAbsent(key, mine);
            if (existing != null) {
                return join(existing);
            }
            try {
                V value = dao.findById(key, currentArgs());
                if (value != null) {
                    store(key, value);
                }
                mine.complete(value);
                return value;
            } catch (DataStoreException e) {
                if (e.code() == Code.UNSUPPORTED) {
                    lazyUnsupported = true;
                    mine.complete(null);
                    return null;
                }
                mine.completeExceptionally(e);
                throw e;
            } catch (RuntimeException e) {
                mine.completeExceptionally(e);
                throw new DataStoreException(Code.LOAD_FAILED, "Lazy load of '" + name + "' key '" + key + "' failed: " + e.getMessage(), e);
            } finally {
                inFlight.remove(key, mine);
            }
        }

        /** Lazy batch load for getAll misses: one source call. */
        Map<String, V> loadMany(List<String> misses) {
            if (lazyUnsupported) {
                return Map.of();
            }
            if (misses.size() == 1) {
                V v = loadOne(misses.get(0));
                return v == null ? Map.of() : Map.of(misses.get(0), v);
            }
            try {
                Map<String, V> found = dao.findAllById(misses, currentArgs());
                found.forEach(this::store);
                return found;
            } catch (DataStoreException e) {
                if (e.code() == Code.UNSUPPORTED) {
                    lazyUnsupported = true;
                    return Map.of();
                }
                throw e;
            } catch (RuntimeException e) {
                throw new DataStoreException(Code.LOAD_FAILED, "Lazy batch load of '" + name + "' failed: " + e.getMessage(), e);
            }
        }

        /** Bulk (re)load: buffer, then put new + evict stale under the lock. */
        void load(Map<String, String> loadArgs) {
            long start = System.nanoTime();
            status = Status.LOADING;
            Map<String, V> fresh = new HashMap<>();
            try {
                dao.findAll(loadArgs, (key, value) -> {
                    if (key == null || value == null) {
                        throw new DataStoreException(Code.LOAD_FAILED, "Dataset '" + name + "': source returned a null key or value");
                    }
                    fresh.put(key, value);
                });
            } catch (DataStoreException e) {
                if (e.code() == Code.UNSUPPORTED && !spec.getPreload()) {
                    resetLazy(loadArgs, start);                   // lazy-only dataset: load = clear + new args
                    return;
                }
                fail(start, e);
                throw e;
            } catch (RuntimeException e) {
                fail(start, e);
                throw new DataStoreException(Code.LOAD_FAILED, "Loading '" + name + "' failed: " + e.getMessage(), e);
            }
            synchronized (lock) {
                fresh.forEach(cache::put);
                for (String old : keys) {
                    if (!fresh.containsKey(old)) {
                        cache.evict(old);
                    }
                }
                keys.retainAll(fresh.keySet());
                keys.addAll(fresh.keySet());
                args = loadArgs;
            }
            done(start);
            log.info("Loaded '{}': {} entries from {} in {} ms, args={}", name, fresh.size(), dao.describe(), loadMillis, loadArgs);
        }

        void write(Map<String, ? extends Object> values) {
            if (!spec.getWritable()) {
                throw DataStoreException.readOnly(name);
            }
            Map<String, V> typed = new LinkedHashMap<>();
            values.forEach((k, v) -> {
                if (k == null || k.isEmpty() || v == null) {
                    throw new DataStoreException(Code.INVALID_REQUEST, "Dataset '" + name + "': null key or value");
                }
                typed.put(k, RowConverter.convert(v, type));
            });
            synchronized (lock) {
                if (!saveUnsupported) {
                    try {
                        dao.save(typed, currentArgs());
                    } catch (DataStoreException e) {
                        if (e.code() != Code.UNSUPPORTED) {
                            throw e;
                        }
                        saveUnsupported = true;                    // memory-only from now on
                    } catch (RuntimeException e) {
                        throw new DataStoreException(Code.INTERNAL, "Write-back to '" + name + "' failed: " + e.getMessage(), e);
                    }
                }
                typed.forEach(this::store);
            }
        }

        boolean remove(String key) {
            if (!spec.getWritable()) {
                throw DataStoreException.readOnly(name);
            }
            synchronized (lock) {
                boolean present = keys.contains(key) || cache.get(key) != null;
                if (present && !saveUnsupported) {
                    try {
                        dao.delete(key, currentArgs());
                    } catch (DataStoreException e) {
                        if (e.code() != Code.UNSUPPORTED) {
                            throw e;
                        }
                    }
                }
                cache.evict(key);
                keys.remove(key);
                return present;
            }
        }

        private void store(String key, V value) {
            cache.put(key, value);
            keys.add(key);
        }

        private Map<String, String> currentArgs() {
            return args.isEmpty() ? effectiveArgs(null) : args;
        }

        private void resetLazy(Map<String, String> loadArgs, long start) {
            synchronized (lock) {
                cache.clear();
                keys.clear();
                args = loadArgs;
            }
            done(start);
        }

        private void done(long start) {
            loadMillis = (System.nanoTime() - start) / 1_000_000;
            loadedAt = System.currentTimeMillis();
            lastError = null;
            status = Status.READY;
        }

        private void fail(long start, Exception e) {
            loadMillis = (System.nanoTime() - start) / 1_000_000;
            lastError = String.valueOf(e.getMessage());
            status = Status.FAILED;
            log.error("Loading '{}' from {} failed", name, dao.describe(), e);
        }

        private V join(CompletableFuture<V> f) {
            try {
                return f.join();
            } catch (java.util.concurrent.CompletionException e) {
                Throwable c = e.getCause();
                throw c instanceof DataStoreException d ? d
                        : new DataStoreException(Code.LOAD_FAILED, "Lazy load of '" + name + "' failed: " + c.getMessage(), c);
            }
        }

        DatasetInfo info() {
            return new DatasetInfo(name, type.getName(), dao.describe(), spec.getPreload(), spec.getWritable(),
                    status, keys.size(), args, loadedAt, loadMillis, lastError);
        }
    }
}
