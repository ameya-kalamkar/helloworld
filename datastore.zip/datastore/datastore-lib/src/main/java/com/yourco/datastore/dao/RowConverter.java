package com.yourco.datastore.dao;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.MapperFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.json.JsonMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.yourco.datastore.DataStoreException;

import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.StringJoiner;

/**
 * Shared conversions: source rows (column name to value) into the dataset type, value objects into SQL
 * parameters, and key building. Column names are normalised to snake_case, so {@code customer_id},
 * {@code CUSTOMER_ID}, {@code customerId} and {@code "Customer Id"} all bind to the record component
 * {@code customerId}; strings are coerced to numbers / dates / booleans.
 */
public final class RowConverter {

    public static final String KEY_SEPARATOR = "|";

    /** Rows -> typed values (snake_case naming, lenient coercion). */
    private static final ObjectMapper ROWS = JsonMapper.builder()
            .addModule(new JavaTimeModule())
            .propertyNamingStrategy(PropertyNamingStrategies.SNAKE_CASE)
            .enable(MapperFeature.ACCEPT_CASE_INSENSITIVE_PROPERTIES)
            .disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES)
            .enable(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT)
            .build();

    /** Plain Java naming: value objects <-> maps, type conversion of already-typed values. */
    private static final ObjectMapper PLAIN = JsonMapper.builder()
            .addModule(new JavaTimeModule())
            .disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES)
            .build();

    private RowConverter() {
    }

    /** Converts a raw row; a Map target returns the row itself. */
    @SuppressWarnings("unchecked")
    public static <V> V fromRow(Map<String, Object> row, Class<V> type) {
        if (Map.class.isAssignableFrom(type)) {
            return (V) row;
        }
        Map<String, Object> normalised = new LinkedHashMap<>(row.size() * 2);
        row.forEach((k, v) -> normalised.put(snake(k), v));
        try {
            return ROWS.convertValue(normalised, type);
        } catch (IllegalArgumentException e) {
            throw new DataStoreException(DataStoreException.Code.LOAD_FAILED,
                    "Cannot map row to " + type.getName() + ": " + e.getMessage(), e);
        }
    }

    /** Converts an already-typed value to another type (e.g. Map dataset read as a record); identity if compatible. */
    public static <V> V convert(Object value, Class<V> type) {
        if (value == null || type.isInstance(value)) {
            return type.cast(value);
        }
        try {
            return PLAIN.convertValue(value, type);
        } catch (IllegalArgumentException e) {
            throw new DataStoreException(DataStoreException.Code.INVALID_REQUEST,
                    "Cannot convert " + value.getClass().getName() + " to " + type.getName() + ": " + e.getMessage(), e);
        }
    }

    /** Value fields as SQL parameters under both camelCase and snake_case names. */
    @SuppressWarnings("unchecked")
    public static Map<String, Object> toParams(Object value) {
        Map<String, Object> fields = value instanceof Map<?, ?> m
                ? new LinkedHashMap<>((Map<String, Object>) m)
                : PLAIN.convertValue(value, Map.class);
        Map<String, Object> params = new LinkedHashMap<>();
        fields.forEach((k, v) -> {
            params.put(k, v);
            params.putIfAbsent(snake(k), v);
        });
        return params;
    }

    /** Builds the key from the key columns of a row (composite keys joined with '|'). */
    public static String key(Map<String, Object> row, List<String> keyColumns, String dataset) {
        if (keyColumns.isEmpty()) {
            throw DataStoreException.config("Dataset '" + dataset + "' needs 'key' column(s)");
        }
        if (keyColumns.size() == 1) {
            return keyPart(lookup(row, keyColumns.get(0), dataset));
        }
        StringJoiner joiner = new StringJoiner(KEY_SEPARATOR);
        for (String col : keyColumns) {
            joiner.add(keyPart(lookup(row, col, dataset)));
        }
        return joiner.toString();
    }

    /** Joins key parts the same way datasets build composite keys. */
    public static String key(Object... parts) {
        StringJoiner joiner = new StringJoiner(KEY_SEPARATOR);
        for (Object p : parts) {
            joiner.add(keyPart(p));
        }
        return joiner.toString();
    }

    /** Adds :key and, for composite keys, :key1, :key2 ... to SQL / URI parameters. */
    public static void addKeyParams(Map<String, Object> params, String key) {
        params.put("key", key);
        String[] parts = key.split("\\|", -1);
        if (parts.length > 1) {
            for (int i = 0; i < parts.length; i++) {
                params.put("key" + (i + 1), parts[i]);
            }
        }
    }

    public static Map<String, Object> params(Map<String, String> args) {
        return new LinkedHashMap<>(args);
    }

    public static Map<String, Object> params(Map<String, String> args, Collection<String> keys) {
        Map<String, Object> p = params(args);
        p.put("keys", keys);
        return p;
    }

    private static Object lookup(Map<String, Object> row, String column, String dataset) {
        if (row.containsKey(column)) {
            return row.get(column);
        }
        String wanted = snake(column);
        for (Map.Entry<String, Object> e : row.entrySet()) {
            if (snake(e.getKey()).equals(wanted)) {
                return e.getValue();
            }
        }
        throw new DataStoreException(DataStoreException.Code.LOAD_FAILED,
                "Dataset '" + dataset + "': key column '" + column + "' not in row " + row.keySet());
    }

    private static String keyPart(Object v) {
        return v == null ? "" : v.toString().trim();
    }

    /** customerId / Customer Id / CUSTOMER-ID -> customer_id */
    static String snake(String name) {
        StringBuilder sb = new StringBuilder(name.length() + 4);
        char prev = 0;
        for (int i = 0; i < name.length(); i++) {
            char c = name.charAt(i);
            if (c == ' ' || c == '-' || c == '.') {
                c = '_';
            }
            if (Character.isUpperCase(c) && i > 0 && Character.isLowerCase(prev)) {
                sb.append('_');
            }
            sb.append(Character.toLowerCase(c));
            prev = c;
        }
        return sb.toString().replaceAll("_+", "_").toLowerCase(Locale.ROOT);
    }
}
