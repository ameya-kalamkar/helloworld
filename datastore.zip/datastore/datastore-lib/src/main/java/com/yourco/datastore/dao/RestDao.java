package com.yourco.datastore.dao;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.yourco.datastore.DataStoreException;
import com.yourco.datastore.config.DataStoreProperties.RestSpec;
import org.springframework.http.MediaType;
import org.springframework.web.client.RestClient;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.function.BiConsumer;

/**
 * HTTP source via Spring's {@link RestClient}. Paths are URI templates expanded (and encoded) with the
 * load arguments and {@code {key}}. Responses are JSON: an array of items, an object holding the array at
 * {@code items-path}, or (batch only) an object of {@code key -> item}.
 */
public class RestDao<V> implements ReferenceDao<V> {

    private static final ObjectMapper JSON = new ObjectMapper();

    private final String dataset;
    private final Class<V> type;
    private final List<String> keyColumns;
    private final RestSpec spec;
    private final RestClient client;

    public RestDao(String dataset, Class<V> type, List<String> keyColumns, RestSpec spec, RestClient base) {
        this.dataset = dataset;
        this.type = type;
        this.keyColumns = keyColumns;
        this.spec = spec;
        RestClient.Builder builder = base != null ? base.mutate() : RestClient.builder();
        if (spec.getBaseUrl() != null) {
            builder.baseUrl(spec.getBaseUrl());
        }
        if (spec.getHeaders() != null) {
            builder.defaultHeaders(h -> spec.getHeaders().forEach(h::set));
        }
        this.client = builder.build();
    }

    @Override
    public void findAll(Map<String, String> args, BiConsumer<String, V> sink) {
        String path = require(spec.getAllPath(), "rest.all-path (bulk load)");
        JsonNode body = client.get().uri(path, vars(args, null)).retrieve().body(JsonNode.class);
        for (JsonNode item : items(body)) {
            Map<String, Object> row = toRow(item);
            sink.accept(RowConverter.key(row, keyColumns, dataset), RowConverter.fromRow(row, type));
        }
    }

    @Override
    public V findById(String key, Map<String, String> args) {
        String path = require(spec.getGetPath(), "rest.get-path (lazy lookup)");
        JsonNode body = client.get().uri(path, vars(args, key)).exchange((req, res) -> {
            if (res.getStatusCode().value() == 404) {
                return null;
            }
            if (res.getStatusCode().isError()) {
                throw new DataStoreException(DataStoreException.Code.LOAD_FAILED,
                        "Dataset '" + dataset + "': GET " + req.getURI() + " returned " + res.getStatusCode());
            }
            return res.bodyTo(JsonNode.class);
        });
        return body == null || body.isNull() ? null : RowConverter.fromRow(toRow(body), type);
    }

    @Override
    public Map<String, V> findAllById(Collection<String> keys, Map<String, String> args) {
        if (spec.getBatchPath() == null) {
            return ReferenceDao.super.findAllById(keys, args);
        }
        JsonNode body = client.post().uri(spec.getBatchPath(), vars(args, null))
                .contentType(MediaType.APPLICATION_JSON).body(keys).retrieve().body(JsonNode.class);
        Map<String, V> out = new LinkedHashMap<>();
        if (body != null && body.isObject() && spec.getItemsPath() == null) {     // {key: item}
            Iterator<Map.Entry<String, JsonNode>> it = body.fields();
            while (it.hasNext()) {
                Map.Entry<String, JsonNode> e = it.next();
                if (!e.getValue().isNull()) {
                    out.put(e.getKey(), RowConverter.fromRow(toRow(e.getValue()), type));
                }
            }
        } else {                                                                  // [item, ...]
            for (JsonNode item : items(body)) {
                Map<String, Object> row = toRow(item);
                out.put(RowConverter.key(row, keyColumns, dataset), RowConverter.fromRow(row, type));
            }
        }
        return out;
    }

    @Override
    public void save(Map<String, V> values, Map<String, String> args) {
        String path = require(spec.getPutPath(), "rest.put-path (write-back)");
        values.forEach((key, value) -> client.put().uri(path, vars(args, key))
                .contentType(MediaType.APPLICATION_JSON).body(value).retrieve().toBodilessEntity());
    }

    @Override
    public void delete(String key, Map<String, String> args) {
        String path = require(spec.getDeletePath(), "rest.delete-path");
        client.delete().uri(path, vars(args, key)).retrieve().toBodilessEntity();
    }

    private Map<String, Object> vars(Map<String, String> args, String key) {
        Map<String, Object> vars = RowConverter.params(args);
        if (key != null) {
            RowConverter.addKeyParams(vars, key);
        }
        return vars;
    }

    private List<JsonNode> items(JsonNode body) {
        JsonNode node = body;
        if (node != null && spec.getItemsPath() != null) {
            node = node.at(spec.getItemsPath());
        }
        List<JsonNode> out = new ArrayList<>();
        if (node == null || node.isMissingNode() || node.isNull()) {
            return out;
        }
        if (!node.isArray()) {
            throw new DataStoreException(DataStoreException.Code.LOAD_FAILED,
                    "Dataset '" + dataset + "': expected a JSON array" + (spec.getItemsPath() == null ? " (set rest.items-path?)" : " at " + spec.getItemsPath()));
        }
        node.forEach(out::add);
        return out;
    }

    @SuppressWarnings("unchecked")
    private static Map<String, Object> toRow(JsonNode node) {
        return JSON.convertValue(node, LinkedHashMap.class);
    }

    private String require(String path, String what) {
        if (path == null || path.isBlank()) {
            throw DataStoreException.unsupported("Dataset '" + dataset + "' has no " + what);
        }
        return path;
    }

    @Override
    public String describe() {
        return "rest:" + (spec.getBaseUrl() != null ? spec.getBaseUrl() : spec.getClient());
    }
}
