package com.yourco.datastore.engine;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JavaType;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.json.JsonMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.yourco.datastore.DataStoreException;
import com.yourco.datastore.DataStoreException.Code;
import com.yourco.datastore.DataStoreOperations;
import com.yourco.datastore.DatasetInfo;
import com.yourco.datastore.config.DataStoreProperties;

import java.io.IOException;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Remote mode: the same operations over HTTP to a data store running as a web app (JDK HttpClient + Jackson). */
public class RemoteDataStore implements DataStoreOperations {

    static final String API = "/api/v1";

    private final String baseUrl;
    private final DataStoreProperties.Remote config;
    private final HttpClient http;
    private final ObjectMapper json = JsonMapper.builder()
            .addModule(new JavaTimeModule())
            .disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES)
            .build();

    public RemoteDataStore(DataStoreProperties.Remote config) {
        if (config.getUrl() == null || config.getUrl().isBlank()) {
            throw DataStoreException.config("datastore.remote.url is required in remote mode");
        }
        this.config = config;
        this.baseUrl = config.getUrl().replaceAll("/+$", "");
        this.http = HttpClient.newBuilder().version(HttpClient.Version.HTTP_1_1)
                .connectTimeout(config.getConnectTimeout()).build();
    }

    @Override
    public <V> V get(String dataset, String key, Class<V> type) {
        try {
            return convert(send(request(ds(dataset) + "/entry?key=" + enc(key)).GET(), true), type);
        } catch (DataStoreException e) {
            if (e.code() == Code.NOT_FOUND) {
                return null;
            }
            throw e;
        }
    }

    @Override
    public <V> Map<String, V> getAll(String dataset, Collection<String> keys, Class<V> type) {
        if (keys.isEmpty()) {
            return Map.of();
        }
        JavaType mapType = json.getTypeFactory().constructMapType(LinkedHashMap.class, String.class, type);
        return json.convertValue(send(post(ds(dataset) + "/lookup", keys), true), mapType);
    }

    @Override
    public <V> void put(String dataset, String key, V value) {
        send(request(ds(dataset) + "/entry?key=" + enc(key)).header("Content-Type", "application/json").PUT(body(value)), false);
    }

    @Override
    public <V> void putAll(String dataset, Map<String, V> values) {
        if (!values.isEmpty()) {
            send(request(ds(dataset) + "/entries").header("Content-Type", "application/json").PUT(body(values)), false);
        }
    }

    @Override
    public boolean remove(String dataset, String key) {
        return send(request(ds(dataset) + "/entry?key=" + enc(key)).DELETE(), false).path("removed").asBoolean();
    }

    @Override
    public void initialize(Map<String, String> args, int parallelism) {
        Map<String, Object> body = new LinkedHashMap<>();
        body.put("args", args == null ? Map.of() : args);
        body.put("parallelism", parallelism);
        send(post(API + "/initialize", body), false);
    }

    @Override
    public DatasetInfo load(String dataset, Map<String, String> args) {
        return json.convertValue(send(post(ds(dataset) + "/load", args == null ? Map.of() : args), false), DatasetInfo.class);
    }

    @Override
    public DatasetInfo reload(String dataset) {
        return json.convertValue(send(post(ds(dataset) + "/reload", Map.of()), false), DatasetInfo.class);
    }

    @Override
    public List<DatasetInfo> datasets() {
        return json.convertValue(send(request(API + "/datasets").GET(), true),
                json.getTypeFactory().constructCollectionType(List.class, DatasetInfo.class));
    }

    /** Asks the server to destroy (needs datastore.server.allow-destroy=true there). */
    @Override
    public void destroy() {
        send(post(API + "/destroy", Map.of()), false);
    }

    // ---- HTTP -------------------------------------------------------------------------------

    private static String ds(String dataset) {
        if (dataset == null || !dataset.matches("[A-Za-z0-9_.\\-]+")) {
            throw new DataStoreException(Code.INVALID_REQUEST, "Invalid dataset name '" + dataset + "'");
        }
        return API + "/datasets/" + dataset;
    }

    private static String enc(String key) {
        if (key == null) {
            throw new DataStoreException(Code.INVALID_REQUEST, "Key must not be null");
        }
        return URLEncoder.encode(key, StandardCharsets.UTF_8);
    }

    private HttpRequest.Builder request(String path) {
        HttpRequest.Builder b = HttpRequest.newBuilder(URI.create(baseUrl + path))
                .timeout(config.getRequestTimeout())
                .header("Accept", "application/json");
        config.getHeaders().forEach(b::header);
        return b;
    }

    private HttpRequest.Builder post(String path, Object body) {
        return request(path).header("Content-Type", "application/json").POST(body(body));
    }

    private HttpRequest.BodyPublisher body(Object body) {
        try {
            return HttpRequest.BodyPublishers.ofByteArray(json.writeValueAsBytes(body));
        } catch (IOException e) {
            throw new DataStoreException(Code.INVALID_REQUEST, "Cannot serialise request: " + e.getMessage(), e);
        }
    }

    private JsonNode send(HttpRequest.Builder builder, boolean idempotent) {
        HttpRequest request = builder.build();
        int attempts = idempotent ? config.getMaxRetries() + 1 : 1;
        Exception last = null;
        for (int attempt = 1; attempt <= attempts; attempt++) {
            try {
                HttpResponse<byte[]> res = http.send(request, HttpResponse.BodyHandlers.ofByteArray());
                if (res.statusCode() / 100 == 2) {
                    return res.body().length == 0 ? json.getNodeFactory().nullNode() : json.readTree(res.body());
                }
                DataStoreException error = error(res);
                if (res.statusCode() < 500 || attempt == attempts) {
                    throw error;
                }
                last = error;
            } catch (IOException e) {
                last = e;
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                throw new DataStoreException(Code.REMOTE_FAILURE, "Interrupted calling " + request.uri(), e);
            }
            sleep(attempt);
        }
        if (last instanceof DataStoreException d) {
            throw d;
        }
        throw new DataStoreException(Code.REMOTE_FAILURE, "Data store unreachable at " + request.uri() + ": " + last, last);
    }

    private DataStoreException error(HttpResponse<byte[]> res) {
        Code code = res.statusCode() == 404 ? Code.NOT_FOUND : Code.REMOTE_FAILURE;
        String message = "HTTP " + res.statusCode();
        try {
            JsonNode node = json.readTree(res.body());
            if (node.hasNonNull("code")) {
                code = Code.valueOf(node.get("code").asText());
            }
            if (node.hasNonNull("message")) {
                message = node.get("message").asText();
            }
        } catch (IOException | IllegalArgumentException ignored) {
            // non-JSON body (proxy / load balancer)
        }
        return new DataStoreException(code, message);
    }

    private <V> V convert(JsonNode node, Class<V> type) {
        try {
            return node == null || node.isNull() ? null : json.treeToValue(node, type);
        } catch (IOException | IllegalArgumentException e) {
            throw new DataStoreException(Code.INVALID_REQUEST, "Cannot convert response to " + type.getName(), e);
        }
    }

    private static void sleep(int attempt) {
        try {
            Thread.sleep(Math.min(2000L, 100L << (attempt - 1)));
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
}
