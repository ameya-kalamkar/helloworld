package com.yourco.datastore.web;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.yourco.datastore.DataStoreException;
import com.yourco.datastore.DataStoreException.Code;
import com.yourco.datastore.DataStoreOperations;
import com.yourco.datastore.DatasetInfo;
import com.yourco.datastore.config.DataStoreProperties;
import com.yourco.datastore.engine.CachingDataStore;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.autoconfigure.condition.ConditionalOnWebApplication;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * REST API over {@link DataStoreOperations}; active only in a servlet web application. Used by
 * {@code RemoteDataStore} and the Python client. Errors: {@code {"code": "...", "message": "..."}}.
 */
@RestController
@RequestMapping("/api/v1")
@ConditionalOnWebApplication(type = ConditionalOnWebApplication.Type.SERVLET)
@ConditionalOnProperty(prefix = "datastore.server", name = "enabled", matchIfMissing = true)
public class DataStoreController {

    private final DataStoreOperations store;
    private final DataStoreProperties properties;
    private final ObjectMapper json;

    public DataStoreController(DataStoreOperations store, DataStoreProperties properties, ObjectProvider<ObjectMapper> json) {
        this.store = store;
        this.properties = properties;
        this.json = json.getIfAvailable(ObjectMapper::new);
    }

    public record InitRequest(Map<String, String> args, Integer parallelism) {
    }

    public record ErrorBody(String code, String message) {
    }

    @GetMapping("/datasets")
    public List<DatasetInfo> datasets() {
        return store.datasets();
    }

    @GetMapping("/datasets/{dataset}/entry")
    public Object get(@PathVariable String dataset, @RequestParam String key) {
        Object value = store.get(dataset, key, Object.class);
        if (value == null) {
            throw new DataStoreException(Code.NOT_FOUND, "Key '" + key + "' not found in '" + dataset + "'");
        }
        return value;
    }

    @PostMapping("/datasets/{dataset}/lookup")
    public Map<String, Object> lookup(@PathVariable String dataset, @RequestBody List<String> keys) {
        return store.getAll(dataset, keys, Object.class);
    }

    @PutMapping("/datasets/{dataset}/entry")
    public ResponseEntity<Void> put(@PathVariable String dataset, @RequestParam String key, @RequestBody JsonNode body) {
        store.put(dataset, key, toValue(dataset, body));
        return ResponseEntity.noContent().build();
    }

    @PutMapping("/datasets/{dataset}/entries")
    public ResponseEntity<Void> putAll(@PathVariable String dataset, @RequestBody Map<String, JsonNode> body) {
        Map<String, Object> values = new LinkedHashMap<>();
        body.forEach((k, v) -> values.put(k, toValue(dataset, v)));
        store.putAll(dataset, values);
        return ResponseEntity.noContent().build();
    }

    @DeleteMapping("/datasets/{dataset}/entry")
    public Map<String, Boolean> remove(@PathVariable String dataset, @RequestParam String key) {
        return Map.of("removed", store.remove(dataset, key));
    }

    @PostMapping("/initialize")
    public List<DatasetInfo> initialize(@RequestBody(required = false) InitRequest request) {
        Map<String, String> args = request == null || request.args() == null ? Map.of() : request.args();
        int parallelism = request == null || request.parallelism() == null ? 0 : request.parallelism();
        store.initialize(args, parallelism);
        return store.datasets();
    }

    @PostMapping("/datasets/{dataset}/load")
    public DatasetInfo load(@PathVariable String dataset, @RequestBody(required = false) Map<String, String> args) {
        return store.load(dataset, args == null ? Map.of() : args);
    }

    @PostMapping("/datasets/{dataset}/reload")
    public DatasetInfo reload(@PathVariable String dataset) {
        return store.reload(dataset);
    }

    @PostMapping("/destroy")
    public ResponseEntity<Void> destroy() {
        if (!properties.getServer().isAllowDestroy()) {
            throw DataStoreException.unsupported("destroy over HTTP is disabled (datastore.server.allow-destroy)");
        }
        store.destroy();
        return ResponseEntity.noContent().build();
    }

    private Object toValue(String dataset, JsonNode node) {
        if (node == null || node.isNull()) {
            throw new DataStoreException(Code.INVALID_REQUEST, "Body must be a JSON value");
        }
        Class<?> type = store instanceof CachingDataStore c ? c.typeOf(dataset) : Map.class;
        try {
            return json.treeToValue(node, type);
        } catch (JsonProcessingException | IllegalArgumentException e) {
            throw new DataStoreException(Code.INVALID_REQUEST, "Body does not match " + type.getName() + ": " + e.getMessage(), e);
        }
    }

    // ---- errors ----------------------------------------------------------------------------------

    @ExceptionHandler(DataStoreException.class)
    public ResponseEntity<ErrorBody> handle(DataStoreException e) {
        HttpStatus status = switch (e.code()) {
            case UNKNOWN_DATASET, NOT_FOUND -> HttpStatus.NOT_FOUND;
            case READ_ONLY, UNSUPPORTED -> HttpStatus.CONFLICT;
            case INVALID_REQUEST -> HttpStatus.BAD_REQUEST;
            case NOT_INITIALIZED -> HttpStatus.SERVICE_UNAVAILABLE;
            default -> HttpStatus.INTERNAL_SERVER_ERROR;
        };
        return ResponseEntity.status(status).body(new ErrorBody(e.code().name(), e.getMessage()));
    }

    @ExceptionHandler({MissingServletRequestParameterException.class, HttpMessageNotReadableException.class})
    public ResponseEntity<ErrorBody> badRequest(Exception e) {
        return ResponseEntity.badRequest().body(new ErrorBody(Code.INVALID_REQUEST.name(), e.getMessage()));
    }
}
