package com.yourco.datastore.config;

import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.cache.interceptor.CacheAspectSupport;

/**
 * Turns on Spring caching (unless the application already did) so Spring Boot's own cache
 * auto-configuration builds the {@code CacheManager} from {@code spring.cache.type}: simple (default
 * without other providers), caffeine, jcache, redis, ... The data store only depends on the
 * {@code CacheManager} interface.
 */
@AutoConfiguration(beforeName = "org.springframework.boot.autoconfigure.cache.CacheAutoConfiguration")
@ConditionalOnMissingBean(CacheAspectSupport.class)
@EnableCaching
public class DataStoreCacheAutoConfiguration {
}
