package com.yourco.datastore.engine;

import com.yourco.datastore.DataStoreException;
import com.yourco.datastore.DataStoreOperations;
import com.yourco.datastore.DatasetInfo;

import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Delegate mode ({@code datastore.mode: delegate}): no Spring Cache, no DAOs. Subclass this as a Spring
 * bean and map each call onto your prebuilt service/library. Only {@link #get} is mandatory; everything
 * else has a sensible default (batch = loop, writes unsupported, lifecycle = no-op) you can override.
 *
 * <pre>{@code
 * @Component
 * class LegacyRefDataStore extends AbstractDelegatingDataStore {
 *     private final LegacyRefDataService legacy;
 *     protected Object fetch(String dataset, String key) { return legacy.lookup(dataset, key); }
 * }
 * }</pre>
 */
public abstract class AbstractDelegatingDataStore implements DataStoreOperations {

    /** Map a single lookup to the delegate; return null when absent. */
    protected abstract Object fetch(String dataset, String key);

    @Override
    public <V> V get(String dataset, String key, Class<V> type) {
        return com.yourco.datastore.dao.RowConverter.convert(fetch(dataset, key), type);
    }

    /** Override if the delegate has a batch call. */
    @Override
    public <V> Map<String, V> getAll(String dataset, Collection<String> keys, Class<V> type) {
        Map<String, V> out = new LinkedHashMap<>();
        for (String key : keys) {
            V v = get(dataset, key, type);
            if (v != null) {
                out.put(key, v);
            }
        }
        return out;
    }

    @Override
    public <V> void put(String dataset, String key, V value) {
        throw DataStoreException.unsupported("put is not mapped for the delegate");
    }

    @Override
    public <V> void putAll(String dataset, Map<String, V> values) {
        values.forEach((k, v) -> put(dataset, k, v));
    }

    @Override
    public boolean remove(String dataset, String key) {
        throw DataStoreException.unsupported("remove is not mapped for the delegate");
    }

    @Override
    public void initialize(Map<String, String> args, int parallelism) {
        // the delegate manages its own data
    }

    @Override
    public DatasetInfo load(String dataset, Map<String, String> args) {
        throw DataStoreException.unsupported("load is not mapped for the delegate");
    }

    @Override
    public DatasetInfo reload(String dataset) {
        throw DataStoreException.unsupported("reload is not mapped for the delegate");
    }

    @Override
    public List<DatasetInfo> datasets() {
        return List.of();
    }

    @Override
    public void destroy() {
        // nothing held here
    }
}
