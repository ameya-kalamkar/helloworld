package com.yourco.datastore;

/** The single exception type of the library; {@link Code} is stable across Java, HTTP and Python. */
public class DataStoreException extends RuntimeException {

    private static final long serialVersionUID = 1L;

    public enum Code {
        UNKNOWN_DATASET, NOT_FOUND, READ_ONLY, INVALID_REQUEST, UNSUPPORTED,
        LOAD_FAILED, CONFIG_ERROR, NOT_INITIALIZED, REMOTE_FAILURE, INTERNAL
    }

    private final Code code;

    public DataStoreException(Code code, String message) {
        this(code, message, null);
    }

    public DataStoreException(Code code, String message, Throwable cause) {
        super(message, cause);
        this.code = code;
    }

    public Code code() {
        return code;
    }

    public static DataStoreException unknownDataset(String name) {
        return new DataStoreException(Code.UNKNOWN_DATASET, "Unknown dataset '" + name + "'");
    }

    public static DataStoreException readOnly(String name) {
        return new DataStoreException(Code.READ_ONLY, "Dataset '" + name + "' is not writable");
    }

    public static DataStoreException unsupported(String what) {
        return new DataStoreException(Code.UNSUPPORTED, what);
    }

    public static DataStoreException config(String message) {
        return new DataStoreException(Code.CONFIG_ERROR, message);
    }

    @Override
    public String toString() {
        return "DataStoreException[" + code + "]: " + getMessage();
    }
}
