package com.yourco.datastore;

import com.yourco.datastore.engine.RemoteDataStore;
import org.springframework.boot.Banner;
import org.springframework.boot.SpringBootConfiguration;
import org.springframework.boot.WebApplicationType;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.core.env.MapPropertySource;
import org.springframework.core.io.DefaultResourceLoader;
import org.springframework.util.ClassUtils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Singleton entry point for executors (plain Java, Flink, Spark): boots a small non-web Spring context
 * once per JVM (per classloader), returns the configured {@link DataStoreOperations} and preloads.
 *
 * <pre>{@code
 * DataStoreOperations store = DataStore.init(Map.of("asOf", "2026-10-03"), 4);   // args, parallelism
 * Customer c = DataStore.get().get("customers", "C001", Customer.class);
 * DataStore.destroy();                                                            // clean everything
 * }</pre>
 *
 * Configuration comes from the usual Spring Boot sources (application.yml on the classpath, environment
 * variables, -D system properties) plus the {@code properties} map passed to {@link #init}, which wins.
 * Extra Spring sources (your DAO beans, DataSources ...) come from the {@code sources} argument or
 * {@code datastore.boot.sources} (comma separated class names).
 */
public final class DataStore {

    private static final Object LOCK = new Object();
    private static volatile DataStore instance;

    private final ConfigurableApplicationContext context;
    private final DataStoreOperations operations;

    private DataStore(ConfigurableApplicationContext context, DataStoreOperations operations) {
        this.context = context;
        this.operations = operations;
    }

    /** The store, initialising it with default arguments on first use. */
    public static DataStoreOperations get() {
        DataStore s = instance;
        return s != null ? s.operations : init(Map.of(), Map.of(), 0);
    }

    public static DataStoreOperations init(Map<String, String> args) {
        return init(Map.of(), args, 0);
    }

    public static DataStoreOperations init(Map<String, String> args, int parallelism) {
        return init(Map.of(), args, parallelism);
    }

    /**
     * Boots the store once per JVM and preloads with {@code args}; later calls return the same instance
     * (use {@code get().initialize(args)} to reload everything with new arguments).
     *
     * @param properties  highest-precedence config, e.g. {@code datastore.mode=remote}
     * @param args        load arguments for preload datasets
     * @param parallelism datasets loaded concurrently ({@code <= 0}: datastore.init-parallelism)
     * @param sources     extra Spring configuration / application classes
     */
    public static DataStoreOperations init(Map<String, String> properties, Map<String, String> args,
                                           int parallelism, Class<?>... sources) {
        DataStore s = instance;
        if (s != null) {
            return s.operations;
        }
        synchronized (LOCK) {
            if (instance == null) {
                instance = boot(properties, args, parallelism, sources);
            }
            return instance.operations;
        }
    }

    public static boolean isInitialized() {
        return instance != null;
    }

    /** Destroys the store (clears all data, closes DAOs), closes the Spring context and resets the singleton. */
    public static void destroy() {
        synchronized (LOCK) {
            DataStore s = instance;
            instance = null;
            if (s != null) {
                try {
                    s.operations.destroy();
                } finally {
                    if (s.context != null) {
                        s.context.close();
                    }
                }
            }
        }
    }

    /** A bean from the embedded context (e.g. one of your DAOs or services). */
    public static <T> T bean(Class<T> type) {
        DataStore s = instance;
        if (s == null || s.context == null) {
            throw new DataStoreException(DataStoreException.Code.NOT_INITIALIZED, "DataStore is not initialised");
        }
        return s.context.getBean(type);
    }

    // ---- bootstrap ------------------------------------------------------------------------------

    private static DataStore boot(Map<String, String> properties, Map<String, String> args, int parallelism, Class<?>[] sources) {
        ClassLoader cl = Thread.currentThread().getContextClassLoader();
        if (cl == null) {
            cl = DataStore.class.getClassLoader();
        }
        // never let Spring Boot reconfigure the host's (Flink / Spark) logging
        if (System.getProperty("org.springframework.boot.logging.LoggingSystem") == null) {
            System.setProperty("org.springframework.boot.logging.LoggingSystem", "none");
        }

        Map<String, Object> props = new HashMap<>(properties);
        props.put("datastore.preload-on-startup", "false");      // the facade preloads with the given args

        Set<Class<?>> allSources = new LinkedHashSet<>();
        allSources.add(Boot.class);
        allSources.addAll(List.of(sources));
        allSources.addAll(sourcesFromProperty(properties.get("datastore.boot.sources"), cl));
        allSources.addAll(sourcesFromProperty(System.getProperty("datastore.boot.sources"), cl));

        ConfigurableApplicationContext ctx = new SpringApplicationBuilder()
                .sources(allSources.toArray(Class<?>[]::new))
                .web(WebApplicationType.NONE)
                .bannerMode(Banner.Mode.OFF)
                .logStartupInfo(false)
                .resourceLoader(new DefaultResourceLoader(cl))
                .initializers(c -> c.getEnvironment().getPropertySources().addFirst(new MapPropertySource("datastore-init", props)))
                .run();
        try {
            DataStoreOperations ops = ctx.getBean(DataStoreOperations.class);
            if (!(ops instanceof RemoteDataStore)) {               // the server owns loading in remote mode
                ops.initialize(args == null ? Map.of() : args, parallelism);
            }
            return new DataStore(ctx, ops);
        } catch (RuntimeException e) {
            ctx.close();
            throw e;
        }
    }

    private static List<Class<?>> sourcesFromProperty(String value, ClassLoader cl) {
        List<Class<?>> out = new ArrayList<>();
        if (value == null || value.isBlank()) {
            return out;
        }
        for (String name : value.split(",")) {
            if (!name.isBlank()) {
                try {
                    out.add(ClassUtils.forName(name.trim(), cl));
                } catch (ClassNotFoundException | LinkageError e) {
                    throw DataStoreException.config("datastore.boot.sources: class " + name.trim() + " not found");
                }
            }
        }
        return out;
    }

    /** Minimal Boot configuration: auto-configuration only (cache manager, DataSource, the data store). */
    @SpringBootConfiguration
    @EnableAutoConfiguration
    static class Boot {
    }
}
