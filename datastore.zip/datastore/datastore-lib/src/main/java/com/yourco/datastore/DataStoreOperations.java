package com.yourco.datastore;

import java.util.Collection;
import java.util.List;
import java.util.Map;

/**
 * The one data-store contract, identical in every mode:
 * embedded ({@link com.yourco.datastore.engine.CachingDataStore}),
 * delegate ({@link com.yourco.datastore.engine.AbstractDelegatingDataStore}) and
 * remote ({@link com.yourco.datastore.engine.RemoteDataStore}).
 *
 * <p><b>Load arguments</b> ({@code args}) fill {@code {name}} placeholders in file paths / URLs and
 * {@code :name} parameters in SQL. Precedence: arguments passed to the call &gt; arguments given to
 * {@link #initialize} &gt; {@code datastore.default-args} in YAML. Each dataset remembers the arguments
 * it was last loaded with; {@link #reload} and lazy key lookups reuse them.</p>
 */
public interface DataStoreOperations {

    // ---- read -------------------------------------------------------------------------------

    /** Value for the key, converted to {@code type}; {@code null} if neither cached nor found in the source. */
    <V> V get(String dataset, String key, Class<V> type);

    /** Batch lookup: cached keys are served from memory, misses are fetched in one source call. Missing keys are omitted. */
    <V> Map<String, V> getAll(String dataset, Collection<String> keys, Class<V> type);

    // ---- write (datasets with writable: true) -------------------------------------------------

    /** Write-through when the dataset's DAO can save, otherwise memory only. */
    <V> void put(String dataset, String key, V value);

    <V> void putAll(String dataset, Map<String, V> values);

    /** @return true if the key was present */
    boolean remove(String dataset, String key);

    // ---- lifecycle ----------------------------------------------------------------------------

    /**
     * Loads every {@code preload: true} dataset with the given global arguments.
     *
     * @param parallelism number of datasets loaded concurrently; {@code <= 0} uses
     *                    {@code datastore.init-parallelism}
     */
    void initialize(Map<String, String> args, int parallelism);

    default void initialize(Map<String, String> args) {
        initialize(args, 0);
    }

    /** (Re)loads one dataset with these arguments (merged over the global/default ones). */
    DatasetInfo load(String dataset, Map<String, String> args);

    /** Reloads one dataset with the arguments it was last loaded with. */
    DatasetInfo reload(String dataset);

    List<DatasetInfo> datasets();

    /** Cleans everything: clears all data, forgets arguments, releases DAO resources. */
    void destroy();
}
