package com.yourco.datastore.dao;

import com.yourco.datastore.DataStoreException;
import com.yourco.datastore.config.DataStoreProperties.FileSpec;
import org.springframework.core.io.Resource;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import org.springframework.core.io.support.ResourcePatternResolver;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.Charset;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Deque;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.function.BiConsumer;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.GZIPInputStream;

/**
 * Delimited flat files: configurable separator (any string), header row or explicit columns, banner and
 * trailer lines, comments, quoting, trimming, null token, charset, globs ({@code *.dat}) and {@code .gz}.
 * Bulk load only.
 */
public class FlatFileDao<V> implements ReferenceDao<V> {

    private static final Pattern ARG = Pattern.compile("\\{([A-Za-z0-9_.-]+)}");

    private final String dataset;
    private final Class<V> type;
    private final List<String> keyColumns;
    private final FileSpec spec;
    private final ResourcePatternResolver resolver;

    public FlatFileDao(String dataset, Class<V> type, List<String> keyColumns, FileSpec spec, ClassLoader classLoader) {
        if (spec.getPath() == null || spec.getPath().isBlank()) {
            throw DataStoreException.config("Dataset '" + dataset + "': file.path is required");
        }
        if (!Boolean.TRUE.equals(spec.getHeader()) && (spec.getColumns() == null || spec.getColumns().isEmpty())) {
            throw DataStoreException.config("Dataset '" + dataset + "': header=false needs file.columns");
        }
        this.dataset = dataset;
        this.type = type;
        this.keyColumns = keyColumns;
        this.spec = spec;
        this.resolver = new PathMatchingResourcePatternResolver(classLoader);
    }

    @Override
    public void findAll(Map<String, String> args, BiConsumer<String, V> sink) {
        String location = resolvePath(spec.getPath(), args);
        Resource[] resources;
        try {
            resources = resolver.getResources(location);
        } catch (IOException e) {
            throw loadFailed("cannot resolve " + location, e);
        }
        List<Resource> files = new ArrayList<>(Arrays.asList(resources));
        files.removeIf(r -> !r.exists());
        if (files.isEmpty()) {
            throw loadFailed("no file matches " + location, null);
        }
        files.sort(Comparator.comparing(r -> String.valueOf(r.getFilename())));
        for (Resource file : files) {
            readFile(file, sink);
        }
    }

    /** Fills {arg} placeholders; plain paths become file: locations. */
    String resolvePath(String path, Map<String, String> args) {
        Matcher m = ARG.matcher(path);
        StringBuilder sb = new StringBuilder();
        while (m.find()) {
            String value = args.get(m.group(1));
            if (value == null) {
                throw new DataStoreException(DataStoreException.Code.INVALID_REQUEST,
                        "Dataset '" + dataset + "': missing load argument '" + m.group(1) + "' for path " + path);
            }
            m.appendReplacement(sb, Matcher.quoteReplacement(value));
        }
        m.appendTail(sb);
        String resolved = sb.toString();
        return resolved.contains(":") && !resolved.matches("^[A-Za-z]:[\\\\/].*") ? resolved : "file:" + resolved;
    }

    private void readFile(Resource file, BiConsumer<String, V> sink) {
        String name = String.valueOf(file.getFilename());
        try (InputStream raw = file.getInputStream();
             InputStream in = name.endsWith(".gz") ? new GZIPInputStream(raw) : raw;
             BufferedReader reader = new BufferedReader(new InputStreamReader(in, Charset.forName(spec.getCharset())))) {

            int trailer = spec.getSkipTrailerLines();
            Deque<String[]> pending = new ArrayDeque<>(trailer + 1);   // holds back the last N lines
            List<String> columns = Boolean.TRUE.equals(spec.getHeader()) ? null : normalise(spec.getColumns());
            int skip = spec.getSkipHeaderLines();
            String line;
            int lineNo = 0;
            while ((line = reader.readLine()) != null) {
                lineNo++;
                if (skip > 0) {
                    skip--;
                    continue;
                }
                if (line.isBlank() || (spec.getCommentPrefix() != null && line.startsWith(spec.getCommentPrefix()))) {
                    continue;
                }
                if (columns == null) {                                 // header row
                    List<String> header = normalise(Arrays.asList(split(line)));
                    columns = spec.getColumns() != null && !spec.getColumns().isEmpty() ? normalise(spec.getColumns()) : header;
                    continue;
                }
                pending.addLast(new String[]{String.valueOf(lineNo), line});
                if (pending.size() > trailer) {
                    String[] next = pending.removeFirst();
                    emit(columns, next[1], Integer.parseInt(next[0]), name, sink);
                }
            }
        } catch (IOException e) {
            throw loadFailed("cannot read " + name, e);
        }
    }

    private void emit(List<String> columns, String line, int lineNo, String file, BiConsumer<String, V> sink) {
        String[] values = split(line);
        if (values.length != columns.size() && Boolean.TRUE.equals(spec.getStrict())) {
            throw loadFailed(file + " line " + lineNo + ": expected " + columns.size() + " columns, got " + values.length, null);
        }
        Map<String, Object> row = new LinkedHashMap<>(columns.size() * 2);
        for (int i = 0; i < columns.size(); i++) {
            String v = i < values.length ? values[i] : null;
            if (v != null && Boolean.TRUE.equals(spec.getTrim())) {
                v = v.trim();
            }
            row.put(columns.get(i), v != null && v.equals(spec.getNullValue()) ? null : v);
        }
        sink.accept(RowConverter.key(row, keyColumns, dataset), RowConverter.fromRow(row, type));
    }

    /** Splits on the (multi-character) separator, honouring the quote character with "" escapes. */
    String[] split(String line) {
        String sep = spec.getSeparator();
        String quote = spec.getQuote();
        if (quote == null || quote.isEmpty() || line.indexOf(quote.charAt(0)) < 0) {
            return line.split(Pattern.quote(sep), -1);
        }
        char q = quote.charAt(0);
        List<String> out = new ArrayList<>();
        StringBuilder cur = new StringBuilder();
        boolean inQuotes = false;
        int i = 0;
        while (i < line.length()) {
            char c = line.charAt(i);
            if (inQuotes) {
                if (c == q && i + 1 < line.length() && line.charAt(i + 1) == q) {
                    cur.append(q);
                    i += 2;
                    continue;
                }
                if (c == q) {
                    inQuotes = false;
                } else {
                    cur.append(c);
                }
                i++;
            } else if (c == q) {
                inQuotes = true;
                i++;
            } else if (line.startsWith(sep, i)) {
                out.add(cur.toString());
                cur.setLength(0);
                i += sep.length();
            } else {
                cur.append(c);
                i++;
            }
        }
        out.add(cur.toString());
        return out.toArray(String[]::new);
    }

    private static List<String> normalise(List<String> names) {
        List<String> out = new ArrayList<>(names.size());
        for (String n : names) {
            out.add(n.trim().replace("﻿", ""));   // trim + strip a UTF-8 BOM on the first header
        }
        return out;
    }

    private DataStoreException loadFailed(String message, Throwable cause) {
        return new DataStoreException(DataStoreException.Code.LOAD_FAILED, "Dataset '" + dataset + "': " + message, cause);
    }

    @Override
    public String describe() {
        return "file:" + spec.getPath();
    }
}
