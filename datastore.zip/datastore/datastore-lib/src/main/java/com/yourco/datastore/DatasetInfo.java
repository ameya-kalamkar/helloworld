package com.yourco.datastore;

import java.util.Map;

/**
 * State of one dataset.
 *
 * @param name            dataset name
 * @param type            value class name ({@code java.util.Map} for {@code type: map})
 * @param source          file / jdbc / rest / dao:&lt;bean&gt; / delegate
 * @param preload         loaded on initialize
 * @param writable        accepts put / remove
 * @param status          NOT_LOADED, LOADING, READY, FAILED
 * @param size            keys currently held in memory
 * @param args            arguments of the last load
 * @param loadedAtEpochMs end of the last successful load (0 = never)
 * @param loadMillis      duration of the last load
 * @param lastError       last load error, or null
 */
public record DatasetInfo(
        String name,
        String type,
        String source,
        boolean preload,
        boolean writable,
        Status status,
        long size,
        Map<String, String> args,
        long loadedAtEpochMs,
        long loadMillis,
        String lastError) {

    public enum Status { NOT_LOADED, LOADING, READY, FAILED }
}
