package com.yourco.datastore.config;

import com.yourco.datastore.DataStoreException;
import com.yourco.datastore.config.DataStoreProperties.DatasetSpec;
import com.yourco.datastore.dao.FlatFileDao;
import com.yourco.datastore.dao.JdbcDao;
import com.yourco.datastore.dao.ReferenceDao;
import com.yourco.datastore.dao.RestDao;
import com.yourco.datastore.engine.CachingDataStore;
import com.yourco.datastore.engine.RemoteDataStore;
import com.yourco.datastore.web.DataStoreController;
import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.cache.CacheManager;
import org.springframework.cache.concurrent.ConcurrentMapCacheManager;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Import;
import org.springframework.util.ClassUtils;
import org.springframework.web.client.RestClient;

import javax.sql.DataSource;
import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.function.BiConsumer;

/**
 * Wires the data store from {@code datastore.*}:
 * <ul>
 *   <li>{@code mode: embedded} (default): one DAO per dataset (file / jdbc / rest / custom bean) behind a
 *       {@link CachingDataStore} on the application's {@link CacheManager}</li>
 *   <li>{@code mode: remote}: {@link RemoteDataStore}</li>
 *   <li>{@code mode: delegate}: nothing here; your {@code AbstractDelegatingDataStore} bean is the store</li>
 * </ul>
 * A source with a bulk part (file, jdbc.sql, rest.all-path) and a separate lazy part (jdbc.get-sql or
 * rest.get-path) is combined: bulk from the first, key lookups and writes from the second.
 */
@AutoConfiguration(afterName = {
        "org.springframework.boot.autoconfigure.cache.CacheAutoConfiguration",
        "org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration"})
@EnableConfigurationProperties(DataStoreProperties.class)
@Import(DataStoreController.class)
public class DataStoreAutoConfiguration {

    /** Fallback when no cache provider is configured: unbounded in-memory maps. */
    @Bean
    @ConditionalOnMissingBean(CacheManager.class)
    public CacheManager dataStoreCacheManager() {
        return new ConcurrentMapCacheManager();
    }

    @Bean
    @ConditionalOnProperty(prefix = "datastore", name = "mode", havingValue = "embedded", matchIfMissing = true)
    public CachingDataStore cachingDataStore(DataStoreProperties properties, CacheManager cacheManager,
                                             ConfigurableListableBeanFactory beanFactory) {
        Map<String, DatasetSpec> specs = properties.resolvedDatasets();
        Map<String, ReferenceDao<?>> daos = new LinkedHashMap<>();
        Map<String, Class<?>> types = new LinkedHashMap<>();
        ClassLoader cl = beanFactory.getBeanClassLoader();
        specs.forEach((name, spec) -> {
            Class<?> type = resolveType(name, spec.getType(), cl);
            types.put(name, type);
            daos.put(name, buildDao(name, spec, type, beanFactory, cl));
        });
        return new CachingDataStore(properties, cacheManager, specs, daos, types);
    }

    @Bean
    @ConditionalOnProperty(prefix = "datastore", name = "mode", havingValue = "remote")
    public RemoteDataStore remoteDataStore(DataStoreProperties properties) {
        return new RemoteDataStore(properties.getRemote());
    }

    // ---- DAO factory ----------------------------------------------------------------------------

    private static Class<?> resolveType(String dataset, String type, ClassLoader cl) {
        if (type == null || type.isBlank() || type.equalsIgnoreCase("map")) {
            return Map.class;
        }
        try {
            return ClassUtils.forName(type, cl);
        } catch (ClassNotFoundException | LinkageError e) {
            throw DataStoreException.config("Dataset '" + dataset + "': type " + type + " not on the classpath");
        }
    }

    @SuppressWarnings({"unchecked", "rawtypes"})
    private static ReferenceDao<?> buildDao(String name, DatasetSpec spec, Class<?> type,
                                            ConfigurableListableBeanFactory bf, ClassLoader cl) {
        if (spec.getDao() != null) {
            return bf.getBean(spec.getDao(), ReferenceDao.class);
        }
        List<ReferenceDao<?>> parts = new ArrayList<>();
        if (spec.getFile() != null) {
            parts.add(new FlatFileDao(name, type, spec.getKey(), spec.getFile(), cl));
        }
        if (spec.getJdbc() != null) {
            DataSource ds = spec.getJdbc().getDatasource() != null
                    ? bf.getBean(spec.getJdbc().getDatasource(), DataSource.class)
                    : bf.getBean(DataSource.class);
            parts.add(new JdbcDao(name, type, spec.getKey(), spec.getJdbc(), ds));
        }
        if (spec.getRest() != null) {
            RestClient client = spec.getRest().getClient() != null ? bf.getBean(spec.getRest().getClient(), RestClient.class) : null;
            parts.add(new RestDao(name, type, spec.getKey(), spec.getRest(), client));
        }
        if (parts.isEmpty()) {
            throw DataStoreException.config("Dataset '" + name + "' needs one of: file, jdbc, rest, dao");
        }
        return parts.size() == 1 ? parts.get(0) : new CombinedDao(parts.get(0), parts.get(1));
    }

    /** Bulk load from the first source; key lookups and writes from the second (e.g. file + jdbc). */
    private record CombinedDao<V>(ReferenceDao<V> bulk, ReferenceDao<V> lookup) implements ReferenceDao<V> {

        @Override
        public void findAll(Map<String, String> args, BiConsumer<String, V> sink) {
            bulk.findAll(args, sink);
        }

        @Override
        public V findById(String key, Map<String, String> args) {
            return lookup.findById(key, args);
        }

        @Override
        public Map<String, V> findAllById(Collection<String> keys, Map<String, String> args) {
            return lookup.findAllById(keys, args);
        }

        @Override
        public void save(Map<String, V> values, Map<String, String> args) {
            lookup.save(values, args);
        }

        @Override
        public void delete(String key, Map<String, String> args) {
            lookup.delete(key, args);
        }

        @Override
        public void close() {
            bulk.close();
            lookup.close();
        }

        @Override
        public String describe() {
            return bulk.describe() + " + " + lookup.describe();
        }
    }
}
