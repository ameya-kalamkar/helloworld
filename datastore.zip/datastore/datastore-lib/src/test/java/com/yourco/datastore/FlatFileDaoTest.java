package com.yourco.datastore;

import com.yourco.datastore.config.DataStoreProperties;
import com.yourco.datastore.config.DataStoreProperties.FileSpec;
import com.yourco.datastore.dao.FlatFileDao;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

class FlatFileDaoTest {

    public record Item(int id, String name, BigDecimal amount, String note) {
    }

    /** Builds a FileSpec through the same template/default merge the YAML goes through. */
    private static FileSpec spec(String yamlTemplateSep, Map<String, Object> overrides) {
        DataStoreProperties p = new DataStoreProperties();
        DataStoreProperties.DatasetSpec ds = new DataStoreProperties.DatasetSpec();
        FileSpec f = new FileSpec();
        f.setSeparator(yamlTemplateSep);
        overrides.forEach((k, v) -> {
            switch (k) {
                case "path" -> f.setPath((String) v);
                case "header" -> f.setHeader((Boolean) v);
                case "columns" -> f.setColumns(castList(v));
                case "skipHeaderLines" -> f.setSkipHeaderLines((Integer) v);
                case "skipTrailerLines" -> f.setSkipTrailerLines((Integer) v);
                case "commentPrefix" -> f.setCommentPrefix((String) v);
                case "nullValue" -> f.setNullValue((String) v);
                default -> throw new IllegalArgumentException(k);
            }
        });
        ds.setFile(f);
        p.getDatasets().put("t", ds);
        return p.resolvedDatasets().get("t").getFile();
    }

    @SuppressWarnings("unchecked")
    private static List<String> castList(Object v) {
        return (List<String>) v;
    }

    private static <V> Map<String, V> load(FlatFileDao<V> dao, Map<String, String> args) {
        Map<String, V> out = new LinkedHashMap<>();
        dao.findAll(args, out::put);
        return out;
    }

    @Test
    void multiCharSeparatorQuotesBannerTrailerCommentsNulls() {
        FileSpec f = spec("~|~", Map.of("path", "classpath:files/multi.dat", "skipHeaderLines", 1,
                "skipTrailerLines", 1, "commentPrefix", "#", "nullValue", "NULL"));
        Map<String, Item> rows = load(new FlatFileDao<>("t", Item.class, List.of("id"), f, getClass().getClassLoader()), Map.of());

        assertThat(rows).containsOnlyKeys("1", "2", "3");
        assertThat(rows.get("1").name()).isEqualTo("Smith, John");
        assertThat(rows.get("1").note()).isNull();
        assertThat(rows.get("2").name()).isEqualTo("Quote \"Q\" Ltd");
        assertThat(rows.get("3").amount()).isEqualByComparingTo("3");
    }

    @Test
    void noHeaderGlobAndArgsAsMaps() {
        FileSpec f = spec(",", Map.of("path", "classpath:files/{prefix}_*.csv", "header", false,
                "columns", List.of("code", "label", "rank")));
        Map<String, Map<String, Object>> rows = load(new FlatFileDao<>("t", castMap(), List.of("code"), f, getClass().getClassLoader()),
                Map.of("prefix", "part"));
        assertThat(rows).containsOnlyKeys("A", "B", "C");
        assertThat(rows.get("C")).containsEntry("label", "Gamma");
    }

    @Test
    void gzipAndMissingArgument() {
        FileSpec gz = spec(",", Map.of("path", "classpath:files/zipped.csv.gz"));
        assertThat(load(new FlatFileDao<>("t", castMap(), List.of("k"), gz, getClass().getClassLoader()), Map.of()))
                .containsOnlyKeys("z");

        FileSpec missing = spec(",", Map.of("path", "classpath:files/{asOf}.csv"));
        assertThatThrownBy(() -> load(new FlatFileDao<>("t", castMap(), List.of("k"), missing, getClass().getClassLoader()), Map.of()))
                .isInstanceOfSatisfying(DataStoreException.class, e -> assertThat(e.code()).isEqualTo(DataStoreException.Code.INVALID_REQUEST));
    }

    @SuppressWarnings({"unchecked", "rawtypes"})
    private static Class<Map<String, Object>> castMap() {
        return (Class) Map.class;
    }
}
