package com.yourco.datastore;

import com.yourco.datastore.config.DataStoreProperties;
import com.yourco.datastore.config.DataStoreProperties.DatasetSpec;
import org.junit.jupiter.api.Test;
import org.springframework.boot.context.properties.bind.Binder;
import org.springframework.boot.context.properties.source.MapConfigurationPropertySource;

import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;

class DataStorePropertiesTest {

    @Test
    void templatesMergeAndDefaultsApply() {
        Map<String, String> yaml = Map.of(
                "datastore.templates.pipe.file.separator", "|",
                "datastore.templates.pipe.file.skip-trailer-lines", "1",
                "datastore.templates.pipe.preload", "false",
                "datastore.datasets.customers.template", "pipe",
                "datastore.datasets.customers.key[0]", "customer_id",
                "datastore.datasets.customers.file.path", "/data/c_{asOf}.dat",
                "datastore.datasets.customers.file.separator", "~",
                "datastore.datasets.customers.preload", "true");
        DataStoreProperties p = new Binder(new MapConfigurationPropertySource(yaml))
                .bind("datastore", DataStoreProperties.class).get();

        DatasetSpec c = p.resolvedDatasets().get("customers");
        assertThat(c.getFile().getSeparator()).isEqualTo("~");          // dataset overrides template
        assertThat(c.getFile().getSkipTrailerLines()).isEqualTo(1);     // inherited from template
        assertThat(c.getFile().getHeader()).isTrue();                   // library default
        assertThat(c.getFile().getCharset()).isEqualTo("UTF-8");
        assertThat(c.getPreload()).isTrue();
        assertThat(c.getType()).isEqualTo("map");
        assertThat(c.getKey()).containsExactly("customer_id");
    }
}
