package com.yourco.refdata;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;

import java.io.IOException;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;

/** Fake pricing REST API on :18090 for the lazy 'prices' dataset (started once per test JVM). */
final class PricingStub {

    static final AtomicInteger GETS = new AtomicInteger();
    static final AtomicInteger BATCHES = new AtomicInteger();
    private static final Map<String, String> PRICES = Map.of(
            "US0378331005", "{\"isin\":\"US0378331005\",\"price\":227.48,\"currency\":\"USD\"}",
            "CA7800871021", "{\"isin\":\"CA7800871021\",\"price\":171.15,\"currency\":\"CAD\"}",
            "GB0005405286", "{\"isin\":\"GB0005405286\",\"price\":6.87,\"currency\":\"GBP\"}");
    private static HttpServer server;

    static synchronized void start() throws IOException {
        if (server != null) {
            return;
        }
        server = HttpServer.create(new InetSocketAddress("127.0.0.1", 18090), 0);
        server.createContext("/prices/", PricingStub::handle);
        server.start();
    }

    private static void handle(HttpExchange ex) throws IOException {
        if (!"demo-key".equals(ex.getRequestHeaders().getFirst("X-Api-Key"))) {
            send(ex, 401, "{}");
            return;
        }
        String path = ex.getRequestURI().getPath();
        if (path.equals("/prices/lookup") && ex.getRequestMethod().equals("POST")) {
            BATCHES.incrementAndGet();
            String body = new String(ex.getRequestBody().readAllBytes(), StandardCharsets.UTF_8);
            StringBuilder out = new StringBuilder("{");
            PRICES.forEach((isin, json) -> {
                if (body.contains("\"" + isin + "\"")) {
                    out.append(out.length() > 1 ? "," : "").append('"').append(isin).append("\":").append(json);
                }
            });
            send(ex, 200, out.append('}').toString());
            return;
        }
        GETS.incrementAndGet();
        String json = PRICES.get(path.substring("/prices/".length()));
        send(ex, json == null ? 404 : 200, json == null ? "{\"error\":\"unknown isin\"}" : json);
    }

    private static void send(HttpExchange ex, int status, String body) throws IOException {
        byte[] bytes = body.getBytes(StandardCharsets.UTF_8);
        ex.getResponseHeaders().add("Content-Type", "application/json");
        ex.sendResponseHeaders(status, bytes.length);
        try (OutputStream os = ex.getResponseBody()) {
            os.write(bytes);
        }
    }

    private PricingStub() {
    }
}
