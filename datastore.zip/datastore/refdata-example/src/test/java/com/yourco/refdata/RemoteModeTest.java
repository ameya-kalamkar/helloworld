package com.yourco.refdata;

import com.yourco.datastore.DataStore;
import com.yourco.datastore.DataStoreOperations;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.server.LocalServerPort;

import java.util.Map;

/** Boots the example as the server (preloads on startup) and runs the contract through the remote client. */
@SpringBootTest(classes = RefDataApplication.class, webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
class RemoteModeTest extends AbstractDataStoreContractTest {

    @LocalServerPort
    int port;

    @BeforeAll
    static void stub() throws Exception {
        PricingStub.start();
    }

    @BeforeEach
    void connect() {
        if (!DataStore.isInitialized()) {
            DataStore.init(Map.of("datastore.mode", "remote", "datastore.remote.url", "http://localhost:" + port), Map.of(), 0);
        }
    }

    @AfterAll
    static void stop() {
        DataStore.destroy();      // remote: closes the client context (server destroy is disabled by default)
    }

    @Override
    protected DataStoreOperations store() {
        return DataStore.get();
    }
}
