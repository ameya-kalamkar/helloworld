package com.yourco.refdata;

import com.yourco.datastore.DataStore;
import com.yourco.datastore.DataStoreOperations;
import com.yourco.refdata.dao.TradeLimitDao;
import com.yourco.refdata.model.Customer;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;

/** Executor-style usage: the facade boots the store in this JVM and preloads with arguments. */
class EmbeddedModeTest extends AbstractDataStoreContractTest {

    @BeforeAll
    static void start() throws Exception {
        PricingStub.start();
        DataStore.destroy();
        DataStore.init(Map.of("datastore.mode", "embedded"), Map.of("asOf", "2026-10-02"), 3, RefDataApplication.class);
    }

    @AfterAll
    static void stop() {
        DataStore.destroy();
    }

    @Override
    protected DataStoreOperations store() {
        return DataStore.get();
    }

    @Test
    void customDaoBeanIsReachable() {
        store().get("trade-limits", "RATES-EU", Object.class);
        assertThat(DataStore.bean(TradeLimitDao.class).calls()).isPositive();
    }

    @Test
    void destroyCleansEverythingAndInitializeRestores() {
        store().destroy();
        assertThat(store().datasets()).allSatisfy(i -> assertThat(i.size()).isZero());
        store().initialize(Map.of("asOf", "2026-10-02"), 2);
        assertThat(store().get("customers", "C001", Customer.class)).isNotNull();
    }
}
