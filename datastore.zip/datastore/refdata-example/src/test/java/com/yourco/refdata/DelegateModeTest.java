package com.yourco.refdata;

import com.yourco.datastore.DataStore;
import com.yourco.datastore.DataStoreException;
import com.yourco.datastore.engine.AbstractDelegatingDataStore;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;

import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

/** Delegate mode: no cache, no DAOs; calls go to a prebuilt service through the abstract delegate. */
class DelegateModeTest {

    /** Stand-in for your existing library. */
    static final Map<String, Map<String, Object>> LEGACY = Map.of(
            "countries", Map.of("CA", Map.of("code", "CA", "name", "Canada"), "IN", Map.of("code", "IN", "name", "India")));

    /** Registered as a source class (not @Component, so other tests' component scans don't pick it up). */
    static class LegacyDelegate extends AbstractDelegatingDataStore {
        @Override
        protected Object fetch(String dataset, String key) {
            Map<String, Object> table = LEGACY.get(dataset);
            return table == null ? null : table.get(key);
        }
    }

    public record Country(String code, String name) {
    }

    @AfterEach
    void stop() {
        DataStore.destroy();
    }

    @Test
    void callsAreMappedToTheDelegate() {
        DataStore.destroy();
        var store = DataStore.init(Map.of("datastore.mode", "delegate"), Map.of(), 0, LegacyDelegate.class);
        assertThat(store.get("countries", "CA", Country.class).name()).isEqualTo("Canada");
        assertThat(store.getAll("countries", java.util.List.of("CA", "IN", "XX"), Country.class)).hasSize(2);
        assertThatThrownBy(() -> store.put("countries", "FR", new Country("FR", "France")))
                .isInstanceOfSatisfying(DataStoreException.class, e -> assertThat(e.code()).isEqualTo(DataStoreException.Code.UNSUPPORTED));
    }
}
