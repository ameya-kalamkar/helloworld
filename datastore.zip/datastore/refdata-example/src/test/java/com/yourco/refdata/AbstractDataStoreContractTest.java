package com.yourco.refdata;

import com.yourco.datastore.DataStoreException;
import com.yourco.datastore.DataStoreException.Code;
import com.yourco.datastore.DataStoreOperations;
import com.yourco.datastore.DatasetInfo;
import com.yourco.refdata.model.Customer;
import com.yourco.refdata.model.FxRate;
import com.yourco.refdata.model.Price;
import com.yourco.refdata.model.RiskScore;
import com.yourco.refdata.model.TradeLimit;
import org.junit.jupiter.api.Test;

import java.util.List;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

/** One behavioural contract run against embedded and remote mode. */
abstract class AbstractDataStoreContractTest {

    protected abstract DataStoreOperations store();

    private DatasetInfo info(String name) {
        return store().datasets().stream().filter(i -> i.name().equals(name)).findFirst().orElseThrow();
    }

    @Test
    void pipeFileWithHeaderTrailerAndNullToken() {
        Customer c = store().get("customers", "C002", Customer.class);
        assertThat(c.name()).isEqualTo("Maple Leaf Foods");
        assertThat(c.rmCode()).isNull();                                  // "NULL" token
        assertThat(info("customers").size()).isEqualTo(4);                // trailer line not loaded
        assertThat(info("customers").args()).containsEntry("asOf", "2026-10-02");
    }

    @Test
    void csvWithoutHeaderAsMap() {
        Map<?, ?> branch = store().get("branches", "TOR01", Map.class);
        assertThat(branch.get("name")).isEqualTo("Toronto, King St");
        assertThat(branch.get("province")).isEqualTo("ON");
    }

    @Test
    void jdbcBulkWithNamedArgAndLazyFallback() {
        assertThat(store().get("fx-rates", "EUR/USD", FxRate.class).rate()).isEqualByComparingTo("1.0842");
        assertThat(store().get("fx-rates", "JPY/USD", FxRate.class)).isNull();            // lazy lookup, not in DB
    }

    @Test
    void lazyRestSingleAndBatch() {
        int gets = PricingStub.GETS.get();
        Price p = store().get("prices", "US0378331005", Price.class);
        assertThat(p.price()).isEqualByComparingTo("227.48");
        store().get("prices", "US0378331005", Price.class);                                // cached now
        assertThat(PricingStub.GETS.get() - gets).isEqualTo(1);

        int batches = PricingStub.BATCHES.get();
        Map<String, Price> many = store().getAll("prices", List.of("US0378331005", "CA7800871021", "GB0005405286", "XX0000000000"), Price.class);
        assertThat(many).containsOnlyKeys("US0378331005", "CA7800871021", "GB0005405286");
        assertThat(PricingStub.BATCHES.get() - batches).isEqualTo(1);                       // one call for all misses
    }

    @Test
    void customLazyDao() {
        assertThat(store().get("trade-limits", "FX-SPOT", TradeLimit.class).limit()).isEqualTo(50_000_000L);
        assertThat(store().get("trade-limits", "UNKNOWN", TradeLimit.class)).isNull();
    }

    @Test
    void writeThroughSurvivesReload() {
        String key = "WT-" + getClass().getSimpleName();
        store().put("risk-scores", key, new RiskScore(key, 0.42, "test"));
        assertThat(store().get("risk-scores", key, RiskScore.class).score()).isEqualTo(0.42);

        store().reload("risk-scores");                                     // re-read from the DB
        assertThat(store().get("risk-scores", key, RiskScore.class)).isNotNull();

        assertThat(store().remove("risk-scores", key)).isTrue();
        store().reload("risk-scores");
        assertThat(store().get("risk-scores", key, RiskScore.class)).isNull();
    }

    @Test
    void loadWithArgumentsThenReload() {
        try {
            DatasetInfo next = store().load("customers", Map.of("asOf", "2026-10-03"));
            assertThat(next.size()).isEqualTo(5);
            assertThat(store().get("customers", "C001", Customer.class).creditLimit()).isEqualTo(2_750_000d);

            assertThat(store().reload("customers").args()).containsEntry("asOf", "2026-10-03");   // reload keeps args
            assertThat(store().load("fx-rates", Map.of("asOf", "2026-10-03")).size()).isEqualTo(4);
            assertThat(store().get("fx-rates", "EUR/USD", FxRate.class).rate()).isEqualByComparingTo("1.0877");
        } finally {
            store().load("customers", Map.of("asOf", "2026-10-02"));
            store().load("fx-rates", Map.of("asOf", "2026-10-02"));
        }
        assertThat(store().get("customers", "C005", Customer.class)).isNull();                    // stale key evicted
    }

    @Test
    void errorsAreTyped() {
        assertThatThrownBy(() -> store().put("customers", "C9", new Customer("C9", "x", "SME", 1, "USD", null)))
                .isInstanceOfSatisfying(DataStoreException.class, e -> assertThat(e.code()).isEqualTo(Code.READ_ONLY));
        assertThatThrownBy(() -> store().get("no-such-dataset", "k", Map.class))
                .isInstanceOfSatisfying(DataStoreException.class, e -> assertThat(e.code()).isEqualTo(Code.UNKNOWN_DATASET));
    }

    @Test
    void catalog() {
        assertThat(store().datasets()).extracting(DatasetInfo::name)
                .contains("customers", "branches", "fx-rates", "prices", "risk-scores", "trade-limits");
        assertThat(info("prices").preload()).isFalse();
        assertThat(info("risk-scores").writable()).isTrue();
    }
}
