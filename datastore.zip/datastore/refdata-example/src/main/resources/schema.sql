-- idempotent: several Spring contexts may share this in-memory DB in one test JVM
create table if not exists fx_rate (
    as_of    date          not null,
    ccy_pair varchar(7)    not null,
    rate     decimal(18,8) not null,
    primary key (as_of, ccy_pair)
);
create table if not exists risk_score (
    customer_id varchar(16) primary key,
    score       double precision not null,
    computed_by varchar(64) not null
);
