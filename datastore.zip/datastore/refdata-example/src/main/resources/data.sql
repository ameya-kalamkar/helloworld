merge into fx_rate (as_of, ccy_pair, rate) key (as_of, ccy_pair) values
    (date '2026-10-02', 'USD/USD', 1.0),
    (date '2026-10-02', 'CAD/USD', 0.73150000),
    (date '2026-10-02', 'EUR/USD', 1.08420000),
    (date '2026-10-02', 'GBP/USD', 1.27010000),
    (date '2026-10-03', 'USD/USD', 1.0),
    (date '2026-10-03', 'CAD/USD', 0.73010000),
    (date '2026-10-03', 'EUR/USD', 1.08770000),
    (date '2026-10-03', 'GBP/USD', 1.26800000);
