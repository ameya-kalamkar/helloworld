package com.yourco.refdata.model;

public record TradeLimit(String book, long limit, String currency) {
}
