package com.yourco.refdata.model;

public record RiskScore(String customerId, double score, String computedBy) {
}
