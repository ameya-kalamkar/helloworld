package com.yourco.refdata.dao;

import com.yourco.datastore.dao.ReferenceDao;
import com.yourco.refdata.model.TradeLimit;
import org.springframework.stereotype.Repository;

import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Custom DAO for a source with no built-in support (stands in for a call into an existing library).
 * Referenced from YAML with {@code dao: tradeLimitDao}; lazy only (findById).
 */
@Repository("tradeLimitDao")
public class TradeLimitDao implements ReferenceDao<TradeLimit> {

    private static final Map<String, TradeLimit> LEGACY = Map.of(
            "FX-SPOT", new TradeLimit("FX-SPOT", 50_000_000L, "USD"),
            "RATES-EU", new TradeLimit("RATES-EU", 120_000_000L, "EUR"));

    private final AtomicInteger calls = new AtomicInteger();

    @Override
    public TradeLimit findById(String key, Map<String, String> args) {
        calls.incrementAndGet();
        return LEGACY.get(key);
    }

    public int calls() {
        return calls.get();
    }

    @Override
    public String describe() {
        return "dao:tradeLimitDao (legacy limits service)";
    }
}
