package com.yourco.refdata;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Runs this reference-data project as the remote data store server (REST API on :8085).
 * The same jar is used embedded by executors through {@code DataStore.init(...)}.
 */
@SpringBootApplication
public class RefDataApplication {

    public static void main(String[] args) {
        SpringApplication.run(RefDataApplication.class, args);
    }
}
