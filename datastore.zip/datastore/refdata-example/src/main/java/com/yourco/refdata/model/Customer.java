package com.yourco.refdata.model;

public record Customer(String customerId, String name, String segment, double creditLimit, String currency, String rmCode) {
}
