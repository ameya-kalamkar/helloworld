package com.yourco.refdata.model;

import java.math.BigDecimal;

public record Price(String isin, BigDecimal price, String currency) {
}
