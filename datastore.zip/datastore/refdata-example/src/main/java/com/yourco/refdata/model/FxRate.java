package com.yourco.refdata.model;

import java.math.BigDecimal;

public record FxRate(String ccyPair, BigDecimal rate) {
}
