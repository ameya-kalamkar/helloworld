"""Python client against a stub of the Data Store REST API (no Java needed)."""
import json
import threading
import unittest
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlparse

from datastore import DataStoreClient, DataStoreError, get_client, reset_client

DATA = {"customers": {"C001": {"customerId": "C001", "name": "Northwind"}, "a/b|c": {"customerId": "x"}}}
LOADS = []


class Stub(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def _send(self, status, body=None):
        raw = b"" if body is None else json.dumps(body).encode()
        self.send_response(status)
        self.send_header("Content-Length", str(len(raw)))
        self.end_headers()
        self.wfile.write(raw)

    def _body(self):
        n = int(self.headers.get("Content-Length") or 0)
        return json.loads(self.rfile.read(n)) if n else None

    def _route(self):
        u = urlparse(self.path)
        parts = u.path.split("/")
        key = parse_qs(u.query).get("key", [None])[0]
        if u.path == "/api/v1/initialize":
            return self._send(200, [{"name": "customers", "args": self._body()["args"]}])
        ds, op = (parts[4] if len(parts) > 4 else None), (parts[5] if len(parts) > 5 else None)
        if ds not in DATA:
            return self._send(404, {"code": "UNKNOWN_DATASET", "message": ds})
        t = DATA[ds]
        if op == "entry" and self.command == "GET":
            return self._send(200, t[key]) if key in t else self._send(404, {"code": "NOT_FOUND", "message": key})
        if op == "entry" and self.command == "PUT":
            t[key] = self._body()
            return self._send(204)
        if op == "entry" and self.command == "DELETE":
            return self._send(200, {"removed": t.pop(key, None) is not None})
        if op == "lookup":
            return self._send(200, {k: t[k] for k in self._body() if k in t})
        if op == "load":
            body = self._body()
            LOADS.append(body)
            return self._send(200, {"name": ds, "args": body})
        return self._send(400, {"code": "INVALID_REQUEST", "message": "?"})

    do_GET = do_POST = do_PUT = do_DELETE = _route


class ClientTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.server = ThreadingHTTPServer(("127.0.0.1", 0), Stub)
        threading.Thread(target=cls.server.serve_forever, daemon=True).start()
        cls.c = DataStoreClient(f"http://127.0.0.1:{cls.server.server_address[1]}", max_retries=0)

    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown()

    def test_reads_and_encoding(self):
        self.assertEqual(self.c.get("customers", "C001")["name"], "Northwind")
        self.assertIsNone(self.c.get("customers", "NOPE"))
        self.assertEqual(self.c.get("customers", "a/b|c")["customerId"], "x")
        self.assertEqual(set(self.c.get_all("customers", ["C001", "NOPE"])), {"C001"})

    def test_writes(self):
        self.c.put("customers", "C9", {"customerId": "C9"})
        self.assertEqual(self.c.get("customers", "C9"), {"customerId": "C9"})
        self.assertTrue(self.c.remove("customers", "C9"))

    def test_lifecycle_with_args(self):
        self.assertEqual(self.c.load("customers", {"asOf": "2026-10-03"})["args"], {"asOf": "2026-10-03"})
        self.assertEqual(self.c.initialize({"asOf": "2026-10-02"}, 4)[0]["args"], {"asOf": "2026-10-02"})

    def test_errors(self):
        with self.assertRaises(DataStoreError) as ctx:
            self.c.get("missing", "x")
        self.assertEqual(ctx.exception.code, "UNKNOWN_DATASET")
        with self.assertRaises(DataStoreError) as ctx:
            DataStoreClient("http://127.0.0.1:1", timeout=1, max_retries=0).datasets()
        self.assertEqual(ctx.exception.code, "REMOTE_FAILURE")

    def test_singleton(self):
        reset_client()
        self.assertIs(get_client(self.c.base_url), get_client())
        reset_client()


if __name__ == "__main__":
    unittest.main()
