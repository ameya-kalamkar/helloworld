"""Remote client for the Data Store server (standard library only; works on any Python / PySpark worker).

    from datastore import get_client
    ds = get_client()                                      # DATASTORE_URL env var, or get_client("http://host:8085")
    ds.get("customers", "C001")                            # dict or None
    ds.get_all("prices", ["US0378331005", "CA7800871021"]) # one call; missing keys omitted
    ds.put("risk-scores", "C001", {"customerId": "C001", "score": 0.4, "computedBy": "py"})
    ds.load("customers", {"asOf": "2026-10-03"})           # reload one dataset with arguments
"""
from __future__ import annotations

import json
import os
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
from typing import Any, Dict, Iterable, List, Optional

_API = "/api/v1"


class DataStoreError(Exception):
    """Same error codes as the Java DataStoreException (UNKNOWN_DATASET, READ_ONLY, ...)."""

    def __init__(self, code: str, message: str, status: Optional[int] = None):
        super().__init__(f"[{code}] {message}")
        self.code, self.message, self.status = code, message, status


class DataStoreClient:
    def __init__(self, base_url: str, timeout: float = 30.0, headers: Optional[Dict[str, str]] = None,
                 max_retries: int = 2):
        if not base_url:
            raise DataStoreError("CONFIG_ERROR", "base_url is required (or set DATASTORE_URL)")
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self.headers = dict(headers or {})
        self.max_retries = max(0, max_retries)

    # ---- reads ---------------------------------------------------------------------------------
    def get(self, dataset: str, key: str) -> Optional[Any]:
        try:
            return self._call("GET", f"{self._ds(dataset)}/entry?key={_q(key)}")
        except DataStoreError as e:
            if e.code == "NOT_FOUND":
                return None
            raise

    def get_all(self, dataset: str, keys: Iterable[str]) -> Dict[str, Any]:
        keys = list(keys)
        return self._call("POST", f"{self._ds(dataset)}/lookup", keys) if keys else {}

    # ---- writes (never retried) ----------------------------------------------------------------
    def put(self, dataset: str, key: str, value: Any) -> None:
        self._call("PUT", f"{self._ds(dataset)}/entry?key={_q(key)}", value, idempotent=False)

    def put_all(self, dataset: str, values: Dict[str, Any]) -> None:
        if values:
            self._call("PUT", f"{self._ds(dataset)}/entries", values, idempotent=False)

    def remove(self, dataset: str, key: str) -> bool:
        res = self._call("DELETE", f"{self._ds(dataset)}/entry?key={_q(key)}", idempotent=False)
        return bool(res and res.get("removed"))

    # ---- lifecycle -----------------------------------------------------------------------------
    def initialize(self, args: Optional[Dict[str, str]] = None, parallelism: int = 0) -> List[Dict[str, Any]]:
        return self._call("POST", f"{_API}/initialize", {"args": args or {}, "parallelism": parallelism}, idempotent=False)

    def load(self, dataset: str, args: Optional[Dict[str, str]] = None) -> Dict[str, Any]:
        return self._call("POST", f"{self._ds(dataset)}/load", args or {}, idempotent=False)

    def reload(self, dataset: str) -> Dict[str, Any]:
        return self._call("POST", f"{self._ds(dataset)}/reload", {}, idempotent=False)

    def datasets(self) -> List[Dict[str, Any]]:
        return self._call("GET", f"{_API}/datasets")

    def destroy(self) -> None:
        """Server must allow it: datastore.server.allow-destroy=true."""
        self._call("POST", f"{_API}/destroy", {}, idempotent=False)

    # ---- plumbing ------------------------------------------------------------------------------
    @staticmethod
    def _ds(dataset: str) -> str:
        if not dataset or not all(c.isalnum() or c in "_.-" for c in dataset):
            raise DataStoreError("INVALID_REQUEST", f"Invalid dataset name '{dataset}'")
        return f"{_API}/datasets/{dataset}"

    def _call(self, method: str, path: str, body: Any = None, idempotent: bool = True) -> Any:
        data = None if body is None else json.dumps(body).encode("utf-8")
        headers = {"Accept": "application/json", **self.headers}
        if data is not None:
            headers["Content-Type"] = "application/json"
        attempts = self.max_retries + 1 if idempotent else 1
        last: Optional[Exception] = None
        for attempt in range(1, attempts + 1):
            req = urllib.request.Request(self.base_url + path, data=data, headers=headers, method=method)
            try:
                with urllib.request.urlopen(req, timeout=self.timeout) as resp:
                    raw = resp.read()
                    return json.loads(raw) if raw else None
            except urllib.error.HTTPError as e:
                err = _to_error(e)
                if e.code < 500 or attempt == attempts:
                    raise err from None
                last = err
            except (urllib.error.URLError, TimeoutError, ConnectionError) as e:
                last = e
                if attempt == attempts:
                    break
            time.sleep(min(2.0, 0.1 * (2 ** (attempt - 1))))
        if isinstance(last, DataStoreError):
            raise last
        raise DataStoreError("REMOTE_FAILURE", f"Data store unreachable at {self.base_url}: {last}")


def _q(key: str) -> str:
    if key is None:
        raise DataStoreError("INVALID_REQUEST", "Key must not be None")
    return urllib.parse.quote(str(key), safe="")


def _to_error(e: "urllib.error.HTTPError") -> DataStoreError:
    code, message = ("NOT_FOUND" if e.code == 404 else "REMOTE_FAILURE"), f"HTTP {e.code}"
    try:
        payload = json.loads(e.read() or b"{}")
        code, message = payload.get("code", code), payload.get("message", message)
    except (ValueError, OSError):
        pass
    return DataStoreError(code, message, e.code)


_lock = threading.Lock()
_instance: Optional[DataStoreClient] = None


def get_client(base_url: Optional[str] = None, **kwargs: Any) -> DataStoreClient:
    """One client per Python process (e.g. per PySpark worker), mirroring the Java DataStore singleton."""
    global _instance
    if _instance is None:
        with _lock:
            if _instance is None:
                _instance = DataStoreClient(base_url or os.environ.get("DATASTORE_URL", ""), **kwargs)
    return _instance


def reset_client() -> None:
    global _instance
    with _lock:
        _instance = None
