# reference-data

Pre-built reference data DAOs (40 datasets; 4 in this sample) on Spring Cache, served two ways with the
same API:

* **reference-data-client**: library for consumer apps (many instances). Per dataset, `EMBEDDED` (loader bean
  in this JVM) or `DELEGATE` (through **reference-data-bridge** to the server).
* **reference-data-server**: the delegate. Every dataset runs locally (Spring cache + loader bean), holds
  the heavy data, and answers clients through the bridge.
* **reference-data-bridge**: all client <-> server communication behind `BridgeClient` / `BridgeServer`.
  Two transports: `grpc` (gRPC/protobuf) and `websocket` (Kryo frames over WebSocket). The server can run both at
  once; each client picks one with `delegate.transport`. Client and server code never sees which.

A team can give its own reference data the same behaviour by extending `ReferenceRepository` and
implementing `ReferenceLoader`; the sample consumer's `desk` dataset shows how (including nested values).

Stack: Java 17, Spring Framework 7.0.9 (server on Spring Boot 4.0.8), Jackson 3 (`tools.jackson`), gRPC 1.84, Kryo 5.6,
Spring WebSocket (server) / JDK `java.net.http.WebSocket` (client),
Lombok, SLF4J (the libraries log through `slf4j-api` only; the app picks the backend).

```
consumer app (many)                                   reference-data-server
holidayRepository.findAllByKeys(keys)
  └ client Spring cache (client policy)
      hit  → return
      miss → DELEGATE ── bridge: FindByKeys ───▶ holiday repository
             (EMBEDDED: loader bean, local)       └ server Spring cache (server policy)
                                                     hit → return; miss → loader bean → source
client preload ──────── bridge: FindAll ─────▶ (warm: SERVING only after server preload)
```

## Classes

| Module | Classes |
|---|---|
| core (shared) | `ReferenceRepository` (abstract DAO + cache-policy engine), `ReferenceLoader` (interface), `CachePolicy`, `ReferenceDataConfig` (config model, inheritance, validation), `RowValues`, `JsonSupport`, loaders `JdbcReferenceLoader` / `RestReferenceLoader` / `CsvReferenceLoader`; JSON Schemas in `schema/` |
| bridge | `BridgeClient`, `BridgeServer` (+ `Handler`): transport-neutral. `grpc`: `GrpcBridgeClient`, `GrpcBridgeServer`, `RowCodec`, `reference_data_bridge.proto`. `websocket`: `WebSocketBridgeClient`, `WebSocketBridgeServer`, `KryoCodec` |
| client | `ReferenceDataClient`, `ReferenceDataClientConfiguration`, pre-built DAOs in `client.datasets` (no transport code) |
| server | `ReferenceDataServer`, `ReferenceDataService` (the bridge `Handler`), `PrebuiltLoaders`, `IgniteCacheManager` (optional) |

## DAO API

| Method | Returns |
|---|---|
| `findByKey(key)` | `List<T>` (a key can have many rows); empty if not found |
| `findAllByKeys(keys)` | `Map<K, List<T>>` in request order, missing keys absent; misses loaded in one call |
| `findAll()` | `List<T>`, every row |
| `existsByKey(key)` | `boolean` |

```java
// pre-built (shipped in the client)                       // your own reference data
public class HolidayRepository                             public class DeskRepository
        extends ReferenceRepository<Holiday, String> {             extends ReferenceRepository<Desk, String> {
    public record Holiday(String calendarCode,                 public record Desk(String deskId, String name, String region) {}
                          LocalDate holidayDate,               public DeskRepository() { super("desk", Desk.class); }
                          String description) {}           }
    public HolidayRepository() { super("holiday", Holiday.class); }
}                                                          public class DeskLoader implements ReferenceLoader { ... }
```

Rows map to records by column name (`calendar_code` → `calendarCode`), or pass your own row mapper.
Composite keys: a record key, joined as `USNY|2026-12-25`.

Row values may be nested: a column can hold a map/record (→ nested record or `Map`), a list/array/SQL ARRAY
(→ `List`), or `byte[]`, recursively. `RowValues` normalises them to one JSON-like shape so EMBEDDED and DELEGATE
return identical rows, and both transports carry them losslessly: gRPC as recursive protobuf `Value`s (`list_value`,
`map_value`, `bytes_value`), WebSocket as tagged Kryo values (BigDecimal as unscaled bytes + scale). Not supported: cycles, polymorphic types, arbitrary object graphs (anything else becomes `toString()`).

```java
public record Desk(String deskId, String name, String region, Person head, List<String> books) {}
```

## Cache policies (Spring Cache, per dataset)

| Policy | Read |
|---|---|
| `CACHE_FIRST` | `cache.get(key, loader)`: miss → loader → cached; not-found cached too (`cache-not-found`) |
| `SOURCE_ONLY` | Spring `NoOpCache`: every call reaches the loader; same API |
| `CACHE_ONLY` | cache only, miss = not found; needs `preload` |

## Config (JSON by default; `.yml`/`.yaml` also accepted)

Each side has its own file and root element: **`reference-data-client`** in `reference-data-client.json`,
**`reference-data-server`** in `reference-data-server.json`. Next to the root only `"$schema"` is allowed; a file with
the other side's root fails with a clear message. `mode` (client), `policy`, `preload`, `cache-not-found`,
`cache-manager`, `key-separator` are set at the top and overridden per dataset. `repository`, `loader`,
`cache-manager` are **bean names in the application context**. `${NAME:default}` reads env vars / system properties
(and the Spring `Environment`), per value after parsing. JSON may contain `//` comments.

The sample files show every option with its default. Full reference:

| Key | Side | Default | Rule |
|---|---|---|---|
| `mode` | client (top, dataset) | `EMBEDDED` | `EMBEDDED` / `DELEGATE`; rejected on the server |
| `policy` | both (top, dataset) | `CACHE_FIRST` | `CACHE_ONLY` needs `preload: true`; `SOURCE_ONLY` + `preload` rejected |
| `preload` | both (top, dataset) | `false` | |
| `cache-not-found` | both (top, dataset) | `true` | |
| `cache-manager` | both (top, dataset) | `referenceDataCacheManager` | bean name; bean must be a `CacheManager` |
| `key-separator` | both (top, dataset) | `\|` | not empty |
| `preload-parallelism` | both (top) | `4` | 1..1024 |
| `datasets` | both | | at least one; names `[A-Za-z0-9][A-Za-z0-9._-]*` |
| `datasets.x.repository` | client | | required, valid bean name, unique; rejected on the server |
| `datasets.x.loader` | both | | server: required; client: required for EMBEDDED, ignored (warning) for DELEGATE; bean must be a `ReferenceLoader` |
| `datasets.x.cache-name` | both | dataset name | not blank; two datasets may not share a cache |
| `delegate` | client | | required if any dataset is DELEGATE; rejected on the server |
| `delegate.transport` | client | `grpc` | `grpc` or `websocket` |
| `delegate.target` | client | | required. grpc: `dns:///reference-data-server:9090` (one target). websocket: `ws://host:9091/reference-data` or `wss://...`, several comma-separated (round-robin); scheme must match the transport |
| `delegate.deadline` / `find-all-deadline` / `ready-timeout` | client | `2s` / `10m` / `5m` | positive duration: `500ms`, `2s`, `10m`, `1h`, `1d`, `PT2S` |
| `delegate.plaintext` | client | `true` | grpc only (websocket: `ws://` vs `wss://`) |
| `delegate.max-message-size-mb` | client | `64` | 1..2047 |
| `delegate.max-keys-per-call` | client | `5000` | 1..1000000 |
| `delegate.find-all-window` | client | `4` | websocket only; 1..1024 FindAll chunks in flight |
| `bridge` | server | gRPC on 9090 | `grpc` and/or `websocket` endpoint, at least one; rejected on the client |
| `bridge.{grpc,websocket}.port` | server | `9090` / `9091` | 1..65535; the two must differ |
| `bridge.{grpc,websocket}.max-message-size-mb` | server | `64` | 1..2047 |
| `bridge.{grpc,websocket}.find-all-chunk-keys` | server | `500` | 1..1000000 |
| `bridge.{grpc,websocket}.worker-threads` | server | `16` | 1..1024 |
| `bridge.websocket.path` | server | `/reference-data` | starts with `/`; websocket only |
| `bridge.websocket.send-buffer-mb` / `send-timeout` | server | `64` / `30s` | a client that stops reading is disconnected beyond these; websocket only |

**Validation** happens twice:
* **At startup** (authoritative): unknown keys, wrong types, unresolved placeholders, every rule above, missing or
  wrong-typed beans, shared caches, and (client) datasets the server doesn't serve. All problems are reported at
  once, each with its path, e.g. `reference-data-client.delegate.max-keys-per-call: 0 is outside 1..1000000`.
* **In the IDE**: `reference-data-core/src/main/resources/schema/reference-data-{client,server}.schema.json`
  (JSON Schema 2020-12, also inside the core jar under `schema/`) give autocomplete, defaults and the same rules.
  Point `"$schema"` at them (the samples use a relative path). Rules needing inheritance or beans stay startup-only;
  values written as `${...}` are accepted by the schema and checked after resolution. IntelliJ: comments in `.json`
  need the file mapped as JSON5 (or drop the comments).

**Client** `reference-data-client.json` (location override: `REFERENCE_DATA_CLIENT_CONFIG`):

```jsonc
{
  "$schema": "…/schema/reference-data-client.schema.json",
  "reference-data-client": {
    "mode": "${REFDATA_MODE:DELEGATE}",
    "policy": "CACHE_FIRST",
    "delegate": { "transport": "grpc", "target": "${REFDATA_SERVER:dns:///reference-data-server:9090}",
                  "deadline": "2s", "max-keys-per-call": 5000 },
    "datasets": {
      "currency": { "repository": "currencyRepository", "policy": "CACHE_ONLY", "preload": true },
      "holiday":  { "repository": "holidayRepository" },
      "desk":     { "repository": "deskRepository", "mode": "EMBEDDED", "loader": "deskLoader" }
    }
  }
}
```

A pre-built DAO named in the config becomes a bean automatically; your own DAOs and loaders are your beans.

| App | Start |
|---|---|
| Spring (Boot or not) | `@Import(ReferenceDataClientConfiguration.class)`; inject `HolidayRepository` |
| No Spring (Flink/Spark) | `ReferenceDataClient.init()` (own beans: `init(null, Map.of("deskRepository", new DeskRepository(), ...))`), then `client.repository(HolidayRepository.class)` |

Startup: validate, connect, wait for the server's health check, check `ListDatasets`, bind each DAO, preload
(`DELEGATE`: the server's `FindAll`).

**Server** `reference-data-server.json` (override: `REFERENCE_DATA_SERVER_CONFIG`):

```jsonc
{
  "$schema": "…/schema/reference-data-server.schema.json",
  "reference-data-server": {
    "preload": true,
    "bridge": {
      "grpc":      { "port": 9090 },
      "websocket": { "port": 9091, "path": "/reference-data" }       // Kryo over Spring WebSocket
    },
    "datasets": {
      "currency":   { "loader": "currencyLoader" },
      "instrument": { "loader": "instrumentLoader", "policy": "SOURCE_ONLY", "preload": false,
                      "cache-manager": "igniteCacheManager" }      // with ignite.enabled=true
    }
  }
}
```

## Bridge transports

Same operations on both (`Health`, `ListDatasets`, `FindByKeys`, chunked `FindAll` with flow control), same row
model, same error codes (`NOT_FOUND` unknown dataset, `UNAVAILABLE` preloading / source failed / connection lost,
`DEADLINE_EXCEEDED`, `INTERNAL`), so switching transport is a config change only.

| | `grpc` | `websocket` |
|---|---|---|
| Wire | HTTP/2, protobuf (`reference_data_bridge.proto`) | WebSocket binary messages, one Kryo frame each (`KryoCodec`, versioned, fixed class ids) |
| Server | grpc-java (Netty), own port | Spring WebSocket handler on the embedded servlet container (Tomcat), started only if `bridge.websocket` is set |
| Client | grpc-java channel, `round_robin` over DNS addresses | JDK `java.net.http.WebSocket` (no extra dependency, fine in Flink/Spark), one connection per URI, round-robin, reconnects on next call |
| FindAll flow control | gRPC `isReady` / on-ready | credits: `find-all-window` chunks ahead, one credit back per chunk consumed |
| Slow / dead client | HTTP/2 flow control | `send-buffer-mb` / `send-timeout` then disconnect |
| Readiness | gRPC health service | `Health` frame |
| Proxies / LBs | needs HTTP/2-aware L7 or L4 | any HTTP/1.1 proxy that allows WebSocket upgrade |

Calls are multiplexed on one connection by request id. Kryo is used with explicit serializers (no reflection, no
class names on the wire, registration required), so a peer cannot make the other side instantiate arbitrary classes.
Browser origins are refused (JVM clients send none). Use `wss://` (TLS on the servlet container) across untrusted
networks.

## Logging (SLF4J)

| Level | What |
|---|---|
| INFO | config file loaded, every dataset's effective settings, bindings, preload per dataset (keys, ms), bridge connect / SERVING, FindAll streams (keys, chunks, KB, ms) |
| DEBUG | every source/bridge load: keys requested, hits, misses, found, not found, latency; REST/JDBC/CSV call timings |
| TRACE | every cache hit, FindAll chunks, flow-control pauses |
| WARN/ERROR | load failures (dataset, operation, source, ms), cancelled streams, invalid configuration (full list) |

Logger names are the classes (`com.referencedata.*`): server `logging.level.com.referencedata` (env `REFDATA_LOG_LEVEL`),
sample consumer `simplelogger.properties`.

## Benchmark: Kryo vs protobuf, gRPC vs WebSocket

`reference-data-benchmark` measures Java-to-Java object transfer: serialization alone, then each transport with each
codec on localhost (unary latency, concurrent throughput, bulk preload stream). See `reference-data-benchmark/RESULTS.md`.

```bash
./gradlew :reference-data-benchmark:run --args='--objects 1000000 --threads 16'
```

## Run the sample

```bash
./gradlew :reference-data-server:bootRun                     # CSV sample data, gRPC :9090 + WebSocket :9091
REFDATA_TRANSPORT=websocket REFDATA_SERVER=ws://localhost:9091/reference-data \
  ./gradlew :reference-data-sample-consumer:run               # same consumer over Kryo/WebSocket
./gradlew :reference-data-sample-consumer:run                 # plain Spring consumer
./gradlew :reference-data-sample-consumer:runPlainJava        # no-Spring (Flink-style) consumer
```
