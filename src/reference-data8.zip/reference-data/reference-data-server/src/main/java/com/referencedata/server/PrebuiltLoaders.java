package com.referencedata.server;

import com.referencedata.core.ReferenceLoader;
import com.referencedata.core.loader.CsvReferenceLoader;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.List;

/**
 * Loader beans for the pre-built datasets (4 of the 40 shown, over sample CSV files so the server runs without a
 * database). The config refers to them by bean name. Real ones would typically be JDBC:
 *
 * <pre>{@code
 * @Bean ReferenceLoader currencyLoader(DataSource ds) {
 *     return new JdbcReferenceLoader(ds, JdbcReferenceLoader.Spec.builder()      // Lombok @Builder
 *             .keyColumns(List.of("ccy_code"))
 *             .sqlAll("select ccy_code, name, decimals from currency")
 *             .sqlByKeys("select ccy_code, name, decimals from currency where ccy_code in (:keys)")
 *             .build());
 * }
 * }</pre>
 */
@Configuration(proxyBeanMethods = false)
public class PrebuiltLoaders {

    @Bean
    ReferenceLoader currencyLoader() {
        return new CsvReferenceLoader("classpath:sample-data/currencies.csv", "|", List.of("ccy_code"));
    }

    @Bean
    ReferenceLoader countryLoader() {
        return new CsvReferenceLoader("classpath:sample-data/countries.csv", "|", List.of("country_code"));
    }

    @Bean
    ReferenceLoader holidayLoader() {
        return new CsvReferenceLoader("classpath:sample-data/holidays.csv", "|", List.of("calendar_code"));
    }

    @Bean
    ReferenceLoader instrumentLoader() {
        return new CsvReferenceLoader("classpath:sample-data/instruments.csv", "|", List.of("instrument_id"));
    }
}
