package com.referencedata.server;

import com.referencedata.bridge.BridgeServer;
import com.referencedata.core.ReferenceDataConfig;
import com.referencedata.core.ReferenceDataConfig.Resolved;
import com.referencedata.core.ReferenceLoader;
import com.referencedata.core.ReferenceRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cache.Cache;
import org.springframework.cache.CacheManager;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.function.Function;

/**
 * The server's datasets, exposed to clients through the bridge (transport-neutral). Each dataset is a plain-row
 * {@link ReferenceRepository} bound to its cache (from the named CacheManager bean) and loader bean, so every client
 * call is answered by the server's cache, reading through to the source according to the server's policy.
 */
@Slf4j
@Component
public class ReferenceDataService implements BridgeServer.Handler {

    private final Map<String, ReferenceRepository<Map<String, Object>, String>> repositories = new LinkedHashMap<>();

    public ReferenceDataService(ReferenceDataConfig.Settings config, ApplicationContext ctx) {
        List<String> errors = new ArrayList<>();
        config.validate(ReferenceDataConfig.Side.SERVER, errors);
        ReferenceDataConfig.failIfAny(ROOT, errors);

        Function<String, CacheManager> cacheManagers = n -> ctx.containsBean(n) && ctx.getBean(n) instanceof CacheManager cm ? cm : null;
        Map<String, Cache> caches = new LinkedHashMap<>();
        for (String name : config.datasets().keySet()) {
            Resolved r = config.resolve(name);
            ReferenceLoader loader = ctx.containsBean(r.loader()) && ctx.getBean(r.loader()) instanceof ReferenceLoader l ? l : null;
            if (loader == null) errors.add("datasets." + name + ".loader: no ReferenceLoader bean named '" + r.loader() + "'");
            log.info("  dataset '{}': loader={}, policy={}, preload={}, cache-manager={}, cache={}, cache-not-found={}",
                    name, r.loader(), r.policy(), r.preload(), r.cacheManager(), r.cacheName(), r.cacheNotFound());
            Cache cache = r.cache(cacheManagers, errors);
            caches.put(name, cache);
            if (loader != null && cache != null) {
                ReferenceRepository<Map<String, Object>, String> repo = ReferenceRepository.rows(name);
                repo.bind(r.binding(cache, loader, "loader=" + r.loader()));
                repositories.put(name, repo);
            }
        }
        ReferenceDataConfig.checkNoSharedCaches(caches, errors);
        ReferenceDataConfig.failIfAny(ROOT, errors);
        log.info("reference-data-server configured {} datasets", repositories.size());
    }

    private static final String ROOT = ReferenceDataConfig.Side.SERVER.root();

    /** The plain-row repository of a dataset, for server-side code. Unknown dataset: IllegalArgumentException. */
    public ReferenceRepository<Map<String, Object>, String> repository(String dataset) {
        ReferenceRepository<Map<String, Object>, String> r = repositories.get(dataset);
        if (r == null) throw new IllegalArgumentException("Unknown dataset '" + dataset + "'; this server serves " + repositories.keySet());
        return r;
    }

    @Override
    public Set<String> datasets() {
        return repositories.keySet();
    }

    @Override
    public Map<String, List<Map<String, Object>>> findByKeys(String dataset, Collection<String> keys) {
        return repository(dataset).findAllByKeys(keys);
    }

    @Override
    public Map<String, List<Map<String, Object>>> findAll(String dataset) {
        return repository(dataset).findAllGroupedByKey();
    }

    /** Loads every dataset with {@code preload}, in parallel. */
    void preloadAll(int parallelism) throws InterruptedException {
        long t0 = System.nanoTime();
        log.info("Preloading server datasets (parallelism {})", parallelism);
        ExecutorService pool = Executors.newFixedThreadPool(parallelism);
        try {
            Map<String, Future<Integer>> fs = new LinkedHashMap<>();
            repositories.forEach((name, repo) -> {
                if (repo.binding().preload()) fs.put(name, pool.submit(repo::preload));
            });
            List<String> failed = new ArrayList<>();
            long keys = 0;
            for (Map.Entry<String, Future<Integer>> e : fs.entrySet()) {
                try {
                    keys += e.getValue().get();
                } catch (ExecutionException ex) {
                    log.error("Preload of '{}' failed", e.getKey(), ex.getCause());
                    failed.add(e.getKey() + ": " + ex.getCause());
                }
            }
            if (!failed.isEmpty()) throw new IllegalStateException("Preload failed:\n  - " + String.join("\n  - ", failed));
            log.info("Server preload done: {} datasets, {} keys in {} ms", fs.size(), keys, (System.nanoTime() - t0) / 1_000_000);
        } finally {
            pool.shutdownNow();
        }
    }
}
