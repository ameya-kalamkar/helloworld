package com.referencedata.server;

import com.referencedata.bridge.BridgeServer;
import com.referencedata.bridge.websocket.WebSocketBridgeServer;
import com.referencedata.core.ReferenceDataConfig;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.WebApplicationType;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnWebApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.cache.CacheManager;
import org.springframework.cache.concurrent.ConcurrentMapCacheManager;
import org.springframework.context.SmartLifecycle;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.SimpleCommandLinePropertySource;
import org.springframework.core.env.StandardEnvironment;
import org.springframework.core.io.DefaultResourceLoader;
import org.springframework.web.socket.config.annotation.EnableWebSocket;
import org.springframework.web.socket.config.annotation.WebSocketConfigurer;
import org.springframework.web.socket.config.annotation.WebSocketHandlerRegistry;
import org.springframework.web.socket.server.standard.ServletServerContainerFactoryBean;

/**
 * reference-data-server, the delegate for clients in DELEGATE mode. Every dataset runs locally: the server's
 * Spring cache in front of a loader bean. Clients talk to it through reference-data-bridge: every transport under
 * {@code bridge} runs, gRPC ({@code bridge.grpc}) and/or Kryo over Spring WebSocket ({@code bridge.websocket}; the
 * embedded servlet container starts only then, on that port).
 * Config: {@code reference-data-server.json}; override with {@code reference-data.server.config} / env
 * {@code REFERENCE_DATA_SERVER_CONFIG}.
 * <p>
 * Startup: the bridge starts not-ready, datasets with {@code preload} load in parallel, then the bridge reports
 * SERVING and accepts lookups. Clients wait for that before their own preload.
 */
@Slf4j
@SpringBootApplication
public class ReferenceDataServer {

    public static final String DEFAULT_LOCATION = "classpath:reference-data-server.json";
    public static final String LOCATION_PROPERTY = "reference-data.server.config";

    /**
     * Reads the config first (placeholders from env vars, system properties and {@code --name=value} arguments), so
     * it decides whether a web server is needed: only for the websocket bridge, on {@code bridge.websocket.port}.
     */
    public static void main(String[] args) {
        StandardEnvironment env = new StandardEnvironment();
        env.getPropertySources().addFirst(new SimpleCommandLinePropertySource(args));
        String location = ReferenceDataConfig.location(env, LOCATION_PROPERTY, null, DEFAULT_LOCATION);
        ReferenceDataConfig.Settings config = ReferenceDataConfig.load(ReferenceDataConfig.Side.SERVER, location, env,
                new DefaultResourceLoader());
        ReferenceDataConfig.Endpoint ws = ReferenceDataConfig.Bridge.orDefault(config.bridge()).websocket();

        SpringApplicationBuilder app = new SpringApplicationBuilder(ReferenceDataServer.class)
                .initializers(ctx -> ctx.getBeanFactory().registerSingleton("referenceDataServerConfig", config));
        if (ws == null) {
            app.web(WebApplicationType.NONE);
        } else {
            app.web(WebApplicationType.SERVLET).properties("server.port=" + ws.portOrDefault(ReferenceDataConfig.WEBSOCKET));
        }
        app.run(args);
    }

    /** In-memory default for datasets that name no other {@code cache-manager}. */
    @Bean(ReferenceDataConfig.DEFAULT_CACHE_MANAGER)
    @ConditionalOnMissingBean(name = ReferenceDataConfig.DEFAULT_CACHE_MANAGER)
    CacheManager referenceDataCacheManager() {
        ConcurrentMapCacheManager cm = new ConcurrentMapCacheManager();
        cm.setAllowNullValues(false);
        return cm;
    }

    @Bean
    BridgeServer bridgeServer(ReferenceDataConfig.Settings config, ReferenceDataService service) {
        return BridgeServer.create(config.bridge(), service);
    }

    @Bean
    SmartLifecycle bridgeLifecycle(BridgeServer bridge) {
        return new SmartLifecycle() {
            private volatile boolean running;

            @Override
            public void start() {
                bridge.start();
                running = true;
            }

            @Override
            public void stop() {
                bridge.stop();
                running = false;
            }

            @Override
            public boolean isRunning() {
                return running;
            }
        };
    }

    /** Heats up the caches, then the bridge reports SERVING so clients may preload from us. */
    @Bean
    ApplicationRunner preloadThenServe(ReferenceDataConfig.Settings config, ReferenceDataService service, BridgeServer bridge) {
        return args -> {
            long t0 = System.nanoTime();
            service.preloadAll(config.preloadParallelismOrDefault());
            bridge.markServing();
            log.info("reference-data-server ready in {} ms, serving {}", (System.nanoTime() - t0) / 1_000_000, config.datasets().keySet());
        };
    }

    /** Spring WebSocket wiring for the websocket bridge; present only when the servlet container runs. */
    @Configuration(proxyBeanMethods = false)
    @EnableWebSocket
    @ConditionalOnWebApplication(type = ConditionalOnWebApplication.Type.SERVLET)
    @RequiredArgsConstructor
    static class WebSocketBridgeConfig implements WebSocketConfigurer {

        private final BridgeServer bridge;

        @Override
        public void registerWebSocketHandlers(WebSocketHandlerRegistry registry) {
            bridge.unwrap(WebSocketBridgeServer.class).ifPresent(ws -> {
                registry.addHandler(ws, ws.path());       // no allowed origins: browsers are refused, JVM clients send none
                log.info("WebSocket bridge registered at {}", ws.path());
            });
        }

        /** The servlet container's own limit on one inbound binary message (Tomcat default is 8 KB). */
        @Bean
        ServletServerContainerFactoryBean webSocketContainer() {
            ServletServerContainerFactoryBean c = new ServletServerContainerFactoryBean();
            bridge.unwrap(WebSocketBridgeServer.class).ifPresent(ws -> c.setMaxBinaryMessageBufferSize(ws.maxMessageBytes()));
            return c;
        }
    }
}
