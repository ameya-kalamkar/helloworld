package com.referencedata.server;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.ignite.Ignite;
import org.apache.ignite.IgniteCache;
import org.apache.ignite.Ignition;
import org.apache.ignite.cache.CacheMode;
import org.apache.ignite.configuration.CacheConfiguration;
import org.apache.ignite.configuration.IgniteConfiguration;
import org.apache.ignite.spi.discovery.tcp.TcpDiscoverySpi;
import org.apache.ignite.spi.discovery.tcp.ipfinder.vm.TcpDiscoveryVmIpFinder;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.cache.Cache;
import org.springframework.cache.CacheManager;
import org.springframework.cache.support.SimpleValueWrapper;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Callable;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Optional Spring {@link CacheManager} over Apache Ignite, so a server dataset can share one cache across server
 * nodes: start with {@code ignite.enabled=true} (env REFDATA_IGNITE_ENABLED) and set the dataset's
 * {@code "cache-manager": "igniteCacheManager"}. A small adapter instead of {@code ignite-spring}, which pins
 * older Spring versions. Run with the --add-opens flags in build.gradle.
 */
@Slf4j
@RequiredArgsConstructor
public class IgniteCacheManager implements CacheManager {

    private final Ignite ignite;
    private final CacheMode mode;
    private final int backups;
    private final Map<String, Cache> caches = new ConcurrentHashMap<>();

    @Override
    public Cache getCache(String name) {
        return caches.computeIfAbsent(name, n -> {
            CacheConfiguration<Object, Object> cfg = new CacheConfiguration<>(n).setCacheMode(mode);
            if (mode == CacheMode.PARTITIONED) cfg.setBackups(backups);
            log.info("Ignite cache '{}' ({}, backups={})", n, mode, mode == CacheMode.PARTITIONED ? backups : "n/a");
            return new SpringCache(ignite.getOrCreateCache(cfg));
        });
    }

    @Override
    public Collection<String> getCacheNames() {
        return caches.keySet();
    }

    @Configuration(proxyBeanMethods = false)
    @ConditionalOnProperty(name = "ignite.enabled", havingValue = "true")
    static class Config {

        @Bean(destroyMethod = "close")
        Ignite ignite(@Value("${ignite.instance-name:reference-data}") String name,
                      @Value("${ignite.discovery-addresses:127.0.0.1:47500..47509}") List<String> addresses) {
            log.info("Starting Ignite node '{}' (discovery {})", name, addresses);
            TcpDiscoveryVmIpFinder ipFinder = new TcpDiscoveryVmIpFinder();
            ipFinder.setAddresses(addresses);
            return Ignition.start(new IgniteConfiguration()
                    .setIgniteInstanceName(name)
                    .setDiscoverySpi(new TcpDiscoverySpi().setIpFinder(ipFinder))
                    .setPeerClassLoadingEnabled(false)
                    .setMetricsLogFrequency(0));
        }

        @Bean
        CacheManager igniteCacheManager(Ignite ignite,
                                        @Value("${ignite.cache-mode:PARTITIONED}") CacheMode mode,
                                        @Value("${ignite.backups:1}") int backups) {
            return new IgniteCacheManager(ignite, mode, backups);
        }
    }

    /** Spring Cache view of one Ignite cache. Values (lists of row maps) must be serializable. */
    @RequiredArgsConstructor
    static final class SpringCache implements Cache {
        private final IgniteCache<Object, Object> cache;
        private final Map<Object, Object> locks = new ConcurrentHashMap<>();

        @Override public String getName() { return cache.getName(); }
        @Override public Object getNativeCache() { return cache; }

        @Override
        public ValueWrapper get(Object key) {
            Object v = cache.get(key);
            return v == null ? null : new SimpleValueWrapper(v);
        }

        @Override
        @SuppressWarnings("unchecked")
        public <T> T get(Object key, Class<T> type) {
            Object v = cache.get(key);
            if (v != null && type != null && !type.isInstance(v)) {
                throw new IllegalStateException("Cached value is not of required type [" + type.getName() + "]: " + v);
            }
            return (T) v;
        }

        /** Loads once per key in this JVM; other nodes may load the same key concurrently (puts are idempotent). */
        @Override
        @SuppressWarnings("unchecked")
        public <T> T get(Object key, Callable<T> valueLoader) {
            Object v = cache.get(key);
            if (v != null) return (T) v;
            Object lock = locks.computeIfAbsent(key, k -> new Object());
            try {
                synchronized (lock) {
                    v = cache.get(key);
                    if (v != null) return (T) v;
                    T loaded;
                    try {
                        loaded = valueLoader.call();
                    } catch (Exception e) {
                        throw new ValueRetrievalException(key, valueLoader, e);
                    }
                    if (loaded != null) cache.put(key, loaded);
                    return loaded;
                }
            } finally {
                locks.remove(key, lock);
            }
        }

        @Override public void put(Object key, Object value) { if (value != null) cache.put(key, value); }
        @Override public void evict(Object key) { cache.remove(key); }
        @Override public void clear() { cache.clear(); }
    }
}
