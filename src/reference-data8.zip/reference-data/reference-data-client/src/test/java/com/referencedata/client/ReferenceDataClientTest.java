package com.referencedata.client;

import com.referencedata.bridge.BridgeClient;
import com.referencedata.client.datasets.CurrencyRepository;
import com.referencedata.client.datasets.HolidayRepository;
import com.referencedata.core.CachePolicy;
import com.referencedata.core.ReferenceDataConfig.Dataset;
import com.referencedata.core.ReferenceDataConfig.Delegate;
import com.referencedata.core.ReferenceDataConfig.Mode;
import com.referencedata.core.ReferenceDataConfig.Settings;
import com.referencedata.core.ReferenceLoader;
import com.referencedata.core.ReferenceRepository;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

class ReferenceDataClientTest {

    static final Map<String, List<Map<String, Object>>> DATA = Map.of(
            "USD", List.of(Map.of("ccy_code", "USD", "name", "US Dollar", "decimals", 2L)),
            "JPY", List.of(Map.of("ccy_code", "JPY", "name", "Yen", "decimals", 0L)));

    /** Fake reference-data-server recording calls. */
    static final class FakeServer implements BridgeClient {
        final Set<String> served;
        final List<String> calls = new ArrayList<>();
        boolean closed;

        FakeServer(Set<String> served) { this.served = served; }

        public void awaitReady() { calls.add("awaitReady"); }
        public Set<String> listDatasets() { calls.add("listDatasets"); return served; }
        public ReferenceLoader loader(String dataset) { return loader(dataset, calls); }
        public void close() { closed = true; }

        static ReferenceLoader loader(String dataset, List<String> calls) {
            return new ReferenceLoader() {
                public Map<String, List<Map<String, Object>>> loadAll() { calls.add("findAll:" + dataset); return new LinkedHashMap<>(DATA); }
                public List<Map<String, Object>> loadByKey(String k) { return loadByKeys(List.of(k)).getOrDefault(k, List.of()); }
                public Map<String, List<Map<String, Object>>> loadByKeys(Collection<String> keys) {
                    calls.add("findByKeys:" + dataset + keys);
                    Map<String, List<Map<String, Object>>> out = new HashMap<>();
                    for (String k : keys) if (DATA.containsKey(k)) out.put(k, DATA.get(k));
                    return out;
                }
            };
        }
    }

    /** A row-typed DAO so the test does not depend on Jackson mapping. */
    static final class CodeRepository extends ReferenceRepository<String, String> {
        CodeRepository(String dataset) { super(dataset, String.class, row -> (String) row.get("ccy_code")); }
    }

    static Delegate delegate() { return new Delegate("grpc", "dns:///localhost:9090", null, null, null, null, null, null, null); }

    static Dataset ds(String repo, Mode mode, String loader, CachePolicy policy, Boolean preload) {
        return new Dataset(repo, mode, loader, policy, preload, null, null, null, null);
    }

    static Settings settings(Mode mode, Delegate d, Map<String, Dataset> datasets) {
        return new Settings(mode, CachePolicy.CACHE_FIRST, null, null, null, null, null, d, null, datasets);
    }

    @Test
    void delegateDatasetsPreloadFromServerAndCacheMisses() {
        FakeServer server = new FakeServer(Set.of("currency", "holiday", "instrument"));
        Map<String, Dataset> d = new LinkedHashMap<>();
        d.put("currency", ds("ccyRepo", null, null, CachePolicy.CACHE_ONLY, true));
        d.put("holiday", ds("holRepo", null, null, null, null));
        CodeRepository ccy = new CodeRepository("currency");
        CodeRepository hol = new CodeRepository("holiday");
        Map<String, Object> beans = Map.of("ccyRepo", ccy, "holRepo", hol);
        try (ReferenceDataClient c = ReferenceDataClient.start(settings(Mode.DELEGATE, delegate(), d), beans::get, x -> server)) {
            assertEquals(List.of("awaitReady", "listDatasets"), server.calls);
            c.bindAll(beans::get);
            assertEquals("findAll:currency", server.calls.get(2));               // preload = server FindAll
            assertEquals(List.of("USD"), ccy.findByKey("USD"));
            assertEquals(List.of(), ccy.findByKey("EUR"));                       // CACHE_ONLY: no call
            hol.findByKey("JPY");
            hol.findByKey("JPY");
            assertEquals(4, server.calls.size());                                // cache first: one FindByKeys
            assertEquals(Set.of("currency", "holiday"), c.datasets());           // only what this app asked for
            assertTrue(c.repository("holRepo") == hol);
        }
        assertTrue(server.closed);
    }

    @Test
    void prebuiltDaosNeedNoBeansAndModeCanBeOverriddenPerDataset() {
        FakeServer server = new FakeServer(Set.of("holiday"));
        Map<String, Dataset> d = new LinkedHashMap<>();
        d.put("holiday", ds("holidayRepository", null, null, null, null));                       // pre-built, DELEGATE
        d.put("currency", ds("currencyRepository", Mode.EMBEDDED, "currencyLoader", null, null)); // pre-built, EMBEDDED
        List<String> localCalls = new ArrayList<>();
        Map<String, Object> beans = Map.of("currencyLoader", FakeServer.loader("local", localCalls));
        try (ReferenceDataClient c = ReferenceDataClient.start(settings(Mode.DELEGATE, delegate(), d), beans::get, x -> server)) {
            c.bindAll(beans::get);
            assertTrue(c.repository(HolidayRepository.class).isBound());
            assertTrue(c.repository(CurrencyRepository.class).isBound());
            assertEquals(List.of(), localCalls);
        }
    }

    @Test
    void embeddedOnlyClientNeedsNoServer() {
        Map<String, Dataset> d = Map.of("currency", ds("ccyRepo", null, "l", null, null));
        CodeRepository ccy = new CodeRepository("currency");
        Map<String, Object> beans = Map.of("ccyRepo", ccy, "l", FakeServer.loader("l", new ArrayList<>()));
        try (ReferenceDataClient c = ReferenceDataClient.start(settings(Mode.EMBEDDED, null, d), beans::get,
                x -> { throw new AssertionError("no server expected"); })) {
            c.bindAll(beans::get);
            assertEquals(List.of("USD"), ccy.findByKey("USD"));
        }
    }

    @Test
    void datasetMissingOnServerFailsAndClosesChannel() {
        FakeServer server = new FakeServer(Set.of("currency"));
        IllegalStateException e = assertThrows(IllegalStateException.class, () -> ReferenceDataClient.start(
                settings(Mode.DELEGATE, delegate(), Map.of("holdiay", ds("r", null, null, null, null))), n -> null, x -> server));
        assertTrue(e.getMessage().contains("holdiay"), e.getMessage());
        assertTrue(server.closed);
    }

    @Test
    void wrongBeansAreReportedTogether() {
        Map<String, Dataset> d = new LinkedHashMap<>();
        d.put("a", ds("aRepo", Mode.EMBEDDED, "nope", null, null));
        d.put("b", ds("bRepo", Mode.EMBEDDED, "l", null, null));
        Map<String, Object> beans = Map.of("l", FakeServer.loader("l", new ArrayList<>()));
        String m = assertThrows(IllegalStateException.class, () -> {
            Settings s = new Settings(Mode.EMBEDDED, null, null, null, "missingCm", null, null, null, null, d);
            ReferenceDataClient.start(s, beans::get, x -> null);
        }).getMessage();
        assertTrue(m.contains("Invalid reference-data-client configuration"), m);
        assertTrue(m.contains("datasets.a.loader: no ReferenceLoader bean named 'nope'"), m);
        assertTrue(m.contains("datasets.b.cache-manager: no CacheManager bean named 'missingCm'"), m);
    }

    @Test
    void bindChecksDatasetAndUnknownRepositoryFails() {
        Map<String, Dataset> d = Map.of("currency", ds("ccyRepo", Mode.EMBEDDED, "l", null, null));
        Map<String, Object> beans = Map.of("l", FakeServer.loader("l", new ArrayList<>()));
        try (ReferenceDataClient c = ReferenceDataClient.start(settings(Mode.EMBEDDED, null, d), beans::get, x -> null)) {
            assertFalse(c.bind("otherRepo", new CodeRepository("currency"), true));            // not configured: ignored
            assertThrows(IllegalStateException.class, () -> c.bind("ccyRepo", new CodeRepository("holiday"), true));
            assertEquals(Set.of("ccyRepo"), c.unboundRepositoryNames());
            assertThrows(IllegalStateException.class, () -> c.bindAll(n -> null));             // ccyRepo: no bean, not pre-built
        }
    }
}
