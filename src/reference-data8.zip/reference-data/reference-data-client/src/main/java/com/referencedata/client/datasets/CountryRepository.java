package com.referencedata.client.datasets;

import com.referencedata.core.ReferenceRepository;

/** Pre-built DAO for dataset {@code country}. */
public class CountryRepository extends ReferenceRepository<CountryRepository.Country, String> {

    public record Country(String countryCode, String name, String currency) {}

    public CountryRepository() {
        super("country", Country.class);
    }
}
