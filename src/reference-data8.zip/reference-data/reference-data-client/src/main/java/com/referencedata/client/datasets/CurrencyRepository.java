package com.referencedata.client.datasets;

import com.referencedata.core.ReferenceRepository;

/** Pre-built DAO for dataset {@code currency}. Enable with {@code "repository": "currencyRepository"}. */
public class CurrencyRepository extends ReferenceRepository<CurrencyRepository.Currency, String> {

    public record Currency(String ccyCode, String name, int decimals) {}

    public CurrencyRepository() {
        super("currency", Currency.class);
    }

    public int decimals(String ccy) {
        return findByKey(ccy).stream().findFirst().map(Currency::decimals).orElse(2);
    }
}
