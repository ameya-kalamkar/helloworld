package com.referencedata.client.datasets;

import com.referencedata.core.ReferenceRepository;

import java.time.LocalDate;

/** Pre-built DAO for dataset {@code holiday}: one calendar code, many holidays. */
public class HolidayRepository extends ReferenceRepository<HolidayRepository.Holiday, String> {

    public record Holiday(String calendarCode, LocalDate holidayDate, String description) {}

    public HolidayRepository() {
        super("holiday", Holiday.class);
    }

    public boolean isHoliday(String calendar, LocalDate day) {
        return findByKey(calendar).stream().anyMatch(h -> h.holidayDate().equals(day));
    }
}
