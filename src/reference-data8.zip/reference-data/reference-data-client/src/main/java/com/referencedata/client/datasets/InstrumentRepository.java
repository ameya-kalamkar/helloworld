package com.referencedata.client.datasets;

import com.referencedata.core.ReferenceRepository;

/** Pre-built DAO for dataset {@code instrument}, keyed by instrument id. */
public class InstrumentRepository extends ReferenceRepository<InstrumentRepository.Instrument, Long> {

    public record Instrument(long instrumentId, String symbol, String currency, int lotSize) {}

    public InstrumentRepository() {
        super("instrument", Instrument.class);
    }
}
