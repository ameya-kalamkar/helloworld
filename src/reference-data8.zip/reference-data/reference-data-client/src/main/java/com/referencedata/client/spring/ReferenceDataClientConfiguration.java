package com.referencedata.client.spring;

import com.referencedata.client.ReferenceDataClient;
import com.referencedata.core.ReferenceDataConfig;
import com.referencedata.core.ReferenceRepository;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.BeanFactoryAware;
import org.springframework.beans.factory.SmartInitializingSingleton;
import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.beans.factory.config.BeanPostProcessor;
import org.springframework.beans.factory.support.BeanDefinitionRegistry;
import org.springframework.beans.factory.support.RootBeanDefinition;
import org.springframework.context.EnvironmentAware;
import org.springframework.context.ResourceLoaderAware;
import org.springframework.context.annotation.ImportBeanDefinitionRegistrar;
import org.springframework.core.env.Environment;
import org.springframework.core.io.ResourceLoader;
import org.springframework.core.type.AnnotationMetadata;

import java.util.ArrayList;
import java.util.List;

/**
 * Spring (Boot or not): {@code @Import(ReferenceDataClientConfiguration.class)} on any {@code @Configuration}.
 * <ul>
 *   <li>Reads {@code reference-data-client.json} (or the {@code reference-data.client.config} location);
 *       {@code ${...}} resolve against this app's {@code Environment}.</li>
 *   <li>{@code repository}, {@code loader}, {@code cache-manager} names are looked up in this application context.
 *       A configured pre-built DAO ({@code currencyRepository}...) that is not already a bean is registered here.</li>
 *   <li>Every {@code ReferenceRepository} bean the config names is bound to its dataset as it is created, and
 *       preloaded if configured. Startup fails if a configured repository has no bean.</li>
 * </ul>
 */
@Slf4j
@Setter
public class ReferenceDataClientConfiguration implements ImportBeanDefinitionRegistrar, EnvironmentAware, ResourceLoaderAware {

    public static final String CLIENT_BEAN = "referenceDataClient";

    private Environment environment;        // set by Spring (EnvironmentAware)
    private ResourceLoader resourceLoader;  // set by Spring (ResourceLoaderAware)

    @Override
    public void registerBeanDefinitions(AnnotationMetadata importing, BeanDefinitionRegistry registry) {
        if (registry.containsBeanDefinition(CLIENT_BEAN)) return;
        if (!(registry instanceof BeanFactory bf)) throw new IllegalStateException("Unsupported registry " + registry.getClass());

        String location = ReferenceDataConfig.location(environment, ReferenceDataClient.LOCATION_PROPERTY, null,
                ReferenceDataClient.DEFAULT_LOCATION);
        ReferenceDataConfig.Settings settings = ReferenceDataConfig.load(ReferenceDataConfig.Side.CLIENT, location, environment, resourceLoader);

        // Pre-built DAOs named in the config become beans, unless the app already defines a bean with that name.
        settings.datasets().values().forEach(d -> {
            if (d.repository() != null && ReferenceDataClient.PREBUILT.containsKey(d.repository())
                    && !registry.containsBeanDefinition(d.repository())) {
                registry.registerBeanDefinition(d.repository(), new RootBeanDefinition(ReferenceDataClient.PREBUILT.get(d.repository())));
                log.debug("Registered pre-built bean '{}' ({})", d.repository(), ReferenceDataClient.PREBUILT.get(d.repository()).getSimpleName());
            }
        });

        RootBeanDefinition client = new RootBeanDefinition(ReferenceDataClient.class,
                () -> ReferenceDataClient.initShared(() -> ReferenceDataClient.start(settings,
                        name -> name != null && bf.containsBean(name) ? bf.getBean(name) : null)));
        client.setDestroyMethodName("close");
        registry.registerBeanDefinition(CLIENT_BEAN, client);

        RootBeanDefinition binder = new RootBeanDefinition(RepositoryBinder.class);
        binder.setRole(BeanDefinition.ROLE_INFRASTRUCTURE);
        registry.registerBeanDefinition(CLIENT_BEAN + ".binder", binder);
    }

    /** Binds each configured {@code ReferenceRepository} bean when Spring creates it; checks none is missing at the end. */
    @Setter
    static class RepositoryBinder implements BeanPostProcessor, SmartInitializingSingleton, BeanFactoryAware {
        private BeanFactory beanFactory;  // set by Spring (BeanFactoryAware)

        @Override
        public Object postProcessAfterInitialization(Object bean, String beanName) throws BeansException {
            if (bean instanceof ReferenceRepository<?, ?> repo && !repo.isBound()) {
                client().bind(beanName, repo, true);
            }
            return bean;
        }

        @Override
        public void afterSingletonsInstantiated() {
            ReferenceDataClient client = client();
            List<String> missing = new ArrayList<>();
            for (String name : client.unboundRepositoryNames()) {
                if (beanFactory.containsBean(name)) beanFactory.getBean(name); // lazy bean: create (and bind) now
                else missing.add(name);
            }
            if (!client.unboundRepositoryNames().isEmpty()) {
                log.error("Reference data repositories without a bean: {}", missing);
                throw new IllegalStateException("Reference data repositories without a bean: " + missing
                        + " (declare them, or use a pre-built name: " + ReferenceDataClient.PREBUILT.keySet() + ")");
            }
        }

        private ReferenceDataClient client() {
            return beanFactory.getBean(CLIENT_BEAN, ReferenceDataClient.class);
        }
    }
}
