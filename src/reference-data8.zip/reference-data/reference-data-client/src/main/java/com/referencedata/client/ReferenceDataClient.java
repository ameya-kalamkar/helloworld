package com.referencedata.client;

import com.referencedata.bridge.BridgeClient;
import com.referencedata.client.datasets.CountryRepository;
import com.referencedata.client.datasets.CurrencyRepository;
import com.referencedata.client.datasets.HolidayRepository;
import com.referencedata.client.datasets.InstrumentRepository;
import com.referencedata.core.ReferenceDataConfig;
import com.referencedata.core.ReferenceDataConfig.Mode;
import com.referencedata.core.ReferenceDataConfig.Resolved;
import com.referencedata.core.ReferenceDataConfig.Settings;
import com.referencedata.core.ReferenceLoader;
import com.referencedata.core.ReferenceRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cache.Cache;
import org.springframework.cache.CacheManager;
import org.springframework.cache.concurrent.ConcurrentMapCacheManager;
import org.springframework.core.env.StandardEnvironment;
import org.springframework.core.io.DefaultResourceLoader;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.function.Function;
import java.util.function.Supplier;

/**
 * The reference data client: one per JVM, configured from {@code reference-data-client.json} (or {@code .yml}).
 * Only the datasets listed there exist for this app.
 *
 * <pre>{@code
 * ReferenceDataClient client = ReferenceDataClient.init();          // no Spring (Flink, Spark, main)
 * HolidayRepository holidays = client.repository(HolidayRepository.class);
 * }</pre>
 * In Spring apps use {@code @Import(ReferenceDataClientConfiguration.class)}: same code, DAOs become beans.
 * <p>
 * Startup: validate config, connect to reference-data-server over the bridge if any dataset is DELEGATE, wait
 * until it is warm, check it serves our datasets, bind each configured DAO (a bean, or one of the {@link #PREBUILT} DAOs)
 * to its policy/cache/loader, and preload datasets with {@code preload} (DELEGATE: the server's {@code FindAll}).
 */
@Slf4j
public final class ReferenceDataClient implements AutoCloseable {

    public static final String DEFAULT_LOCATION = "classpath:reference-data-client.json";
    /** Config location override; also read from env var {@code REFERENCE_DATA_CLIENT_CONFIG}. */
    public static final String LOCATION_PROPERTY = "reference-data.client.config";

    /** The pre-built DAOs offered by the library, by bean name (4 of the 40 shown in this sample). */
    public static final Map<String, Class<? extends ReferenceRepository<?, ?>>> PREBUILT = Map.of(
            "currencyRepository", CurrencyRepository.class,
            "countryRepository", CountryRepository.class,
            "holidayRepository", HolidayRepository.class,
            "instrumentRepository", InstrumentRepository.class);

    private static volatile ReferenceDataClient instance;

    private final Settings settings;
    private final Map<String, Resolved> byRepository;                  // repository bean name -> dataset settings
    private final Map<String, ReferenceRepository.Binding> bindings;    // repository bean name -> binding
    private final Map<String, ReferenceRepository<?, ?>> bound = new ConcurrentHashMap<>();
    private final BridgeClient delegate;

    private ReferenceDataClient(Settings settings, Map<String, Resolved> byRepository,
                                Map<String, ReferenceRepository.Binding> bindings, BridgeClient delegate) {
        this.settings = settings;
        this.byRepository = Map.copyOf(byRepository);
        this.bindings = Map.copyOf(bindings);
        this.delegate = delegate;
    }

    // ------------------------------------------------------------------ init without Spring

    public static ReferenceDataClient init() {
        return init(null, Map.of());
    }

    public static ReferenceDataClient init(String location) {
        return init(location, Map.of());
    }

    /**
     * Without Spring, {@code beans} supplies what the config names: your own DAOs and loaders, custom cache managers
     * ({@code Map.of("deskRepository", new DeskRepository(), "deskLoader", loader)}). Pre-built DAOs need nothing.
     */
    public static ReferenceDataClient init(String location, Map<String, ?> beans) {
        return initShared(() -> {
            StandardEnvironment env = new StandardEnvironment(); // env vars + system properties
            String loc = ReferenceDataConfig.location(env, LOCATION_PROPERTY, location, DEFAULT_LOCATION);
            ReferenceDataClient c = start(ReferenceDataConfig.load(ReferenceDataConfig.Side.CLIENT, loc, env, new DefaultResourceLoader()), beans::get);
            try {
                c.bindAll(beans::get);
            } catch (RuntimeException e) {
                c.close();
                throw e;
            }
            return c;
        });
    }

    public static ReferenceDataClient get() {
        ReferenceDataClient c = instance;
        if (c == null) throw new IllegalStateException("ReferenceDataClient.init() has not been called");
        return c;
    }

    /** The JVM's client, created by {@code factory} if there is none yet. */
    public static ReferenceDataClient initShared(Supplier<ReferenceDataClient> factory) {
        ReferenceDataClient c = instance;
        if (c != null) return c;
        synchronized (ReferenceDataClient.class) {
            if (instance == null) instance = factory.get();
            return instance;
        }
    }

    // ------------------------------------------------------------------ startup

    /** Validates, connects and prepares bindings. {@code beans} resolves loader / cache-manager names (null if absent). */
    public static ReferenceDataClient start(Settings s, Function<String, Object> beans) {
        return start(s, beans, BridgeClient::connect);
    }

    static ReferenceDataClient start(Settings s, Function<String, Object> beans, Function<ReferenceDataConfig.Delegate, BridgeClient> connector) {
        long t0 = System.nanoTime();
        List<String> errors = new ArrayList<>();
        s.validate(ReferenceDataConfig.Side.CLIENT, errors);
        ReferenceDataConfig.failIfAny(ROOT, errors);

        boolean anyDelegate = s.datasets().keySet().stream().anyMatch(n -> s.resolve(n).mode() == Mode.DELEGATE);
        log.info("Starting reference data client: {} datasets {} ({})", s.datasets().size(), s.datasets().keySet(),
                anyDelegate ? "bridge " + s.delegate().transportOrDefault() + " -> " + s.delegate().target() : "all EMBEDDED, no server");
        BridgeClient conn = anyDelegate ? connector.apply(s.delegate()) : null;
        try {
            CacheManager builtIn = new ConcurrentMapCacheManager();
            Function<String, CacheManager> cacheManagers = name -> {
                Object bean = beans.apply(name);
                if (bean instanceof CacheManager cm) return cm;
                return bean == null && ReferenceDataConfig.DEFAULT_CACHE_MANAGER.equals(name) ? builtIn : null;
            };
            Map<String, Resolved> byRepository = new LinkedHashMap<>();
            Map<String, ReferenceRepository.Binding> bindings = new LinkedHashMap<>();
            Map<String, Cache> caches = new LinkedHashMap<>();
            for (String name : s.datasets().keySet()) {
                Resolved r = s.resolve(name);
                ReferenceLoader loader = null;
                String source;
                if (r.mode() == Mode.DELEGATE) {
                    loader = conn.loader(name);
                    source = "DELEGATE " + s.delegate().target();
                } else {
                    source = "EMBEDDED loader=" + r.loader();
                    Object bean = beans.apply(r.loader());
                    if (bean instanceof ReferenceLoader l) loader = l;
                    else if (bean == null) errors.add("datasets." + name + ".loader: no ReferenceLoader bean named '" + r.loader() + "'");
                    else errors.add("datasets." + name + ".loader: bean '" + r.loader() + "' is a " + bean.getClass().getName()
                                + ", not a ReferenceLoader");
                }
                log.info("  dataset '{}': repository={}, mode={}, policy={}, preload={}, cache-manager={}, cache={}{}",
                        name, r.repository(), r.mode(), r.policy(), r.preload(), r.cacheManager(), r.cacheName(),
                        r.mode() == Mode.EMBEDDED ? ", loader=" + r.loader() : "");
                Cache cache = r.cache(cacheManagers, errors);
                caches.put(name, cache);
                byRepository.put(r.repository(), r);
                if (cache != null && loader != null) bindings.put(r.repository(), r.binding(cache, loader, source));
            }
            ReferenceDataConfig.checkNoSharedCaches(caches, errors);
            ReferenceDataConfig.failIfAny(ROOT, errors);

            if (conn != null) {
                conn.awaitReady();
                Set<String> served = conn.listDatasets();
                List<String> missing = s.datasets().keySet().stream()
                        .filter(n -> s.resolve(n).mode() == Mode.DELEGATE && !served.contains(n)).toList();
                if (!missing.isEmpty()) {
                    log.error("reference-data-server does not serve {}; it serves {}", missing, served);
                    throw new IllegalStateException("reference-data-server does not serve " + missing + "; it serves " + served);
                }
            }
            log.info("Reference data client ready to bind in {} ms", (System.nanoTime() - t0) / 1_000_000);
            return new ReferenceDataClient(s, byRepository, bindings, conn);
        } catch (RuntimeException e) {
            if (conn != null) conn.close();
            throw e;
        }
    }

    private static final String ROOT = ReferenceDataConfig.Side.CLIENT.root();

    /** Without Spring: binds every configured DAO (from {@code beans}, else pre-built), then preloads in parallel. */
    void bindAll(Function<String, Object> beans) {
        List<String> errors = new ArrayList<>();
        for (String repoName : byRepository.keySet()) {
            Object bean = beans.apply(repoName);
            ReferenceRepository<?, ?> repo = bean instanceof ReferenceRepository<?, ?> r ? r : newPrebuilt(repoName);
            if (repo == null) {
                errors.add("datasets." + byRepository.get(repoName).dataset() + ".repository: no repository named '" + repoName
                        + "' (pass it in the beans map, or use a pre-built one: " + PREBUILT.keySet() + ")");
                continue;
            }
            if (bean == null) log.debug("Using pre-built {} for '{}'", repo.getClass().getSimpleName(), repoName);
            bind(repoName, repo, false);
        }
        ReferenceDataConfig.failIfAny(ROOT, errors);
        preloadAll();
    }

    /**
     * Binds a DAO that the config names {@code repoName}; returns false if no dataset refers to that name.
     * Used by the Spring configuration for every {@code ReferenceRepository} bean, and by {@link #bindAll}.
     */
    public boolean bind(String repoName, ReferenceRepository<?, ?> repo, boolean preloadNow) {
        Resolved r = byRepository.get(repoName);
        if (r == null) {
            log.debug("Repository bean '{}' ({}) is not in {}; left unbound", repoName, repo.dataset(), ROOT);
            return false;
        }
        if (!r.dataset().equals(repo.dataset())) {
            throw new IllegalStateException("Dataset '" + r.dataset() + "' names repository '" + repoName + "', but that bean is a "
                    + repo.getClass().getName() + " for dataset '" + repo.dataset() + "'");
        }
        synchronized (this) {
            if (bound.containsKey(repoName)) return true;
            repo.bind(bindings.get(repoName));
            bound.put(repoName, repo);
        }
        if (preloadNow && r.preload()) repo.preload();
        return true;
    }

    // ------------------------------------------------------------------ use

    /** The bound DAO of that class, e.g. {@code repository(HolidayRepository.class)}. */
    public <R extends ReferenceRepository<?, ?>> R repository(Class<R> type) {
        for (ReferenceRepository<?, ?> r : bound.values()) {
            if (type.isInstance(r)) return type.cast(r);
        }
        throw new IllegalStateException(type.getName() + " is not enabled for this client; enabled: " + bound.keySet());
    }

    public ReferenceRepository<?, ?> repository(String repoName) {
        ReferenceRepository<?, ?> r = bound.get(repoName);
        if (r == null) throw new IllegalStateException("'" + repoName + "' is not enabled for this client; enabled: " + bound.keySet());
        return r;
    }

    public Set<String> datasets() {
        return settings.datasets().keySet();
    }

    public Set<String> repositoryNames() {
        return byRepository.keySet();
    }

    public Set<String> unboundRepositoryNames() {
        Set<String> out = new LinkedHashSet<>(byRepository.keySet());
        out.removeAll(bound.keySet());
        return out;
    }

    @Override
    public void close() {
        synchronized (ReferenceDataClient.class) {
            if (instance == this) instance = null;
        }
        log.info("Closing reference data client ({} repositories bound)", bound.size());
        if (delegate != null) delegate.close();
    }

    /** A new instance of a pre-built DAO, or null if the name is not pre-built. */
    public static ReferenceRepository<?, ?> newPrebuilt(String repoName) {
        Class<? extends ReferenceRepository<?, ?>> type = PREBUILT.get(repoName);
        if (type == null) return null;
        try {
            return type.getDeclaredConstructor().newInstance();
        } catch (ReflectiveOperationException e) {
            throw new IllegalStateException("Cannot create " + type.getName(), e);
        }
    }

    private void preloadAll() {
        List<ReferenceRepository<?, ?>> todo = bound.entrySet().stream()
                .filter(e -> byRepository.get(e.getKey()).preload()).map(Map.Entry::getValue).toList();
        if (todo.isEmpty()) return;
        long t0 = System.nanoTime();
        log.info("Preloading {} datasets (parallelism {})", todo.size(), Math.min(todo.size(), settings.preloadParallelismOrDefault()));
        ExecutorService pool = Executors.newFixedThreadPool(Math.min(todo.size(), settings.preloadParallelismOrDefault()));
        try {
            List<Future<Integer>> fs = todo.stream().map(r -> pool.submit(r::preload)).toList();
            int keys = 0;
            for (Future<Integer> f : fs) keys += f.get();
            log.info("Preload done: {} datasets, {} keys in {} ms", todo.size(), keys, (System.nanoTime() - t0) / 1_000_000);
        } catch (ExecutionException e) {
            log.error("Preload failed", e.getCause());
            throw e.getCause() instanceof RuntimeException re ? re : new IllegalStateException(e.getCause());
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new IllegalStateException("Interrupted during preload", e);
        } finally {
            pool.shutdownNow();
        }
    }
}
