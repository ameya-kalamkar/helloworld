package com.referencedata.core;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;

import java.lang.reflect.Array;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.sql.SQLException;
import java.time.temporal.TemporalAccessor;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Normalizes source rows to a small, JSON-like set of types so a row read through the bridge equals the same row
 * read directly from the source (EMBEDDED and DELEGATE give identical results):
 * <ul>
 *   <li>top-level column names lower-cased (Oracle returns upper case); nested keys kept as they are</li>
 *   <li>integral numbers to {@link Long} (or {@link BigDecimal} beyond 64 bits); other numbers to {@link BigDecimal}</li>
 *   <li>dates and times to ISO-8601 strings; {@code Boolean}, {@code String} and {@code byte[]} kept</li>
 *   <li>nested {@code Map} to {@code Map<String, Object>}; {@code Collection}, arrays and {@code java.sql.Array} to
 *       {@code List<Object>}; records to {@code Map} of their components; all recursively</li>
 *   <li>anything else (enums, UUIDs, ...) to {@code toString()}</li>
 * </ul>
 * Rows therefore carry any JSON-shaped structure; the row type ({@code T}) gets nested records, lists and maps back
 * through Jackson. Cyclic structures are rejected.
 */
@NoArgsConstructor(access = AccessLevel.PRIVATE)
public final class RowValues {

    /** Deeper nesting than this is treated as a cycle. */
    public static final int MAX_DEPTH = 64;

    public static Map<String, Object> normalize(Map<String, ?> raw) {
        Map<String, Object> out = new LinkedHashMap<>(Math.max(4, raw.size() * 2));
        raw.forEach((k, v) -> out.put(k.toLowerCase(Locale.ROOT), normalizeValue(v, 1)));
        return out;
    }

    public static Object normalizeValue(Object v) {
        return normalizeValue(v, 0);
    }

    private static Object normalizeValue(Object v, int depth) {
        if (depth > MAX_DEPTH) throw new IllegalArgumentException("Row value nested deeper than " + MAX_DEPTH + " (cycle?)");
        if (v == null || v instanceof String || v instanceof Boolean || v instanceof Long) return v;
        if (v instanceof Integer || v instanceof Short || v instanceof Byte) return ((Number) v).longValue();
        if (v instanceof BigInteger bi) return bi.bitLength() < 64 ? (Object) bi.longValue() : new BigDecimal(bi);
        if (v instanceof BigDecimal bd) return normalizeDecimal(bd);
        if (v instanceof Double || v instanceof Float) {
            double d = ((Number) v).doubleValue();
            if (Double.isNaN(d) || Double.isInfinite(d)) return Double.toString(d);
            return normalizeDecimal(BigDecimal.valueOf(d));
        }
        if (v instanceof java.sql.Timestamp ts) return ts.toLocalDateTime().toString();
        if (v instanceof java.sql.Date d) return d.toLocalDate().toString();
        if (v instanceof java.sql.Time t) return t.toLocalTime().toString();
        if (v instanceof TemporalAccessor) return v.toString();
        if (v instanceof java.util.Date d) return d.toInstant().toString();
        if (v instanceof byte[] b) return b.clone();
        if (v instanceof Character || v instanceof Enum<?>) return v.toString();
        if (v instanceof Map<?, ?> m) {
            Map<String, Object> out = new LinkedHashMap<>(Math.max(4, m.size() * 2));
            m.forEach((k, x) -> out.put(String.valueOf(k), normalizeValue(x, depth + 1)));
            return Collections.unmodifiableMap(out);
        }
        if (v instanceof Collection<?> c) {
            List<Object> out = new ArrayList<>(c.size());
            for (Object x : c) out.add(normalizeValue(x, depth + 1));
            return Collections.unmodifiableList(out);
        }
        if (v.getClass().isArray()) {
            int n = Array.getLength(v);
            List<Object> out = new ArrayList<>(n);
            for (int i = 0; i < n; i++) out.add(normalizeValue(Array.get(v, i), depth + 1));
            return Collections.unmodifiableList(out);
        }
        if (v instanceof java.sql.Array a) {
            try {
                return normalizeValue(Arrays.asList((Object[]) a.getArray()), depth);
            } catch (SQLException e) {
                throw new IllegalStateException("Cannot read SQL array: " + e.getMessage(), e);
            }
        }
        if (v.getClass().isRecord()) {
            Map<String, Object> out = new LinkedHashMap<>();
            for (var c : v.getClass().getRecordComponents()) {
                try {
                    out.put(c.getName(), normalizeValue(c.getAccessor().invoke(v), depth + 1));
                } catch (ReflectiveOperationException e) {
                    throw new IllegalArgumentException("Cannot read " + v.getClass().getName() + "." + c.getName()
                            + " (make the record public)", e);
                }
            }
            return Collections.unmodifiableMap(out);
        }
        return v.toString();
    }

    private static Object normalizeDecimal(BigDecimal bd) {
        BigDecimal s = bd.signum() == 0 ? BigDecimal.ZERO : bd.stripTrailingZeros();
        if (s.scale() <= 0 && s.precision() - s.scale() < 19) return s.longValueExact();
        return s;
    }
}
