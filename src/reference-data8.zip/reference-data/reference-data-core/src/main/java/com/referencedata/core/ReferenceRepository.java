package com.referencedata.core;

import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cache.Cache;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.RecordComponent;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.StringJoiner;
import java.util.function.Function;
import java.util.function.Supplier;

/**
 * Extension point and engine: a read-only DAO for one dataset, in the Spring Data repository style.
 * The 40 pre-built DAOs extend it; so can a team's own reference data service:
 *
 * <pre>{@code
 * public class DeskRepository extends ReferenceRepository<DeskRepository.Desk, String> {
 *     public record Desk(String deskId, String name, String region) {}
 *     public DeskRepository() { super("desk", Desk.class); }
 * }
 * }</pre>
 * The client or server binds it at startup to the dataset's {@link Binding}: cache policy, Spring
 * {@link Cache} and {@link ReferenceLoader}. Rows are mapped to {@code T} once, on load, and cached as an
 * unmodifiable {@code List<T>} per key.
 *
 * <table>
 *   <caption>Cache policies</caption>
 *   <tr><td>CACHE_FIRST</td><td>{@code cache.get(key, loader)}; batch misses loaded in one {@code loadByKeys}</td></tr>
 *   <tr><td>SOURCE_ONLY</td><td>same code on a Spring {@code NoOpCache}: every call reaches the loader</td></tr>
 *   <tr><td>CACHE_ONLY</td><td>cache only, miss = not found; filled by preload</td></tr>
 * </table>
 *
 * @param <T> row type: a record/POJO (column {@code ccy_code} fills {@code ccyCode}) or {@code Map<String, Object>}
 * @param <K> key type: String, number, date, or a record of the key columns (joined with the key separator)
 */
@Slf4j
public abstract class ReferenceRepository<T, K> {

    /** What a repository is bound to; built from config by the client or server. */
    public record Binding(CachePolicy policy, Cache cache, ReferenceLoader loader, boolean preload,
                          boolean cacheNotFound, String keySeparator, String source) {}

    private final String dataset;
    private final Class<T> rowType;
    private final Function<Map<String, Object>, T> mapper;
    private final Object loadAllLock = new Object();
    private volatile Binding binding;
    private volatile Set<String> allKeys; // complete key set once loadAll has run

    /** Rows mapped to {@code rowType} by column name (Jackson). */
    protected ReferenceRepository(String dataset, Class<T> rowType) {
        this(dataset, rowType, JsonSupport.rowMapper(rowType));
    }

    protected ReferenceRepository(String dataset, Class<T> rowType, Function<Map<String, Object>, T> mapper) {
        this.dataset = Objects.requireNonNull(dataset, "dataset");
        this.rowType = Objects.requireNonNull(rowType, "rowType");
        this.mapper = Objects.requireNonNull(mapper, "mapper");
    }

    /** A repository of plain rows, without writing a class (used by the server). */
    @SuppressWarnings({"unchecked", "rawtypes"})
    public static ReferenceRepository<Map<String, Object>, String> rows(String dataset) {
        return new ReferenceRepository<>(dataset, (Class) Map.class, Function.identity()) {};
    }

    public final String dataset() {
        return dataset;
    }

    public final Class<T> rowType() {
        return rowType;
    }

    // ------------------------------------------------------------------ reader API

    /** Rows for one key; empty list if the key does not exist. */
    public List<T> findByKey(K key) {
        String k = encodeKey(key);
        Binding b = bound();
        if (b.policy() == CachePolicy.CACHE_ONLY) {
            List<T> v = cached(b, k);
            log.trace("{}.findByKey({}) [CACHE_ONLY] -> {} rows", dataset, k, v.size());
            return v;
        }
        if (!b.cacheNotFound()) return findAllByEncodedKeys(List.of(k)).getOrDefault(k, List.of());
        long t0 = System.nanoTime();
        boolean[] loaded = {false};
        try {
            List<T> v = b.cache().get(k, () -> {
                loaded[0] = true;
                return mapRows(b.loader().loadByKey(k));
            });
            List<T> out = v == null ? List.of() : v;
            if (loaded[0]) {
                log.debug("{}.findByKey({}) [{}] miss -> {} loaded {} rows in {} ms",
                        dataset, k, b.policy(), b.source(), out.size(), millis(t0));
            } else {
                log.trace("{}.findByKey({}) [{}] hit -> {} rows", dataset, k, b.policy(), out.size());
            }
            return out;
        } catch (Cache.ValueRetrievalException e) {
            log.warn("{}.findByKey({}) failed from {} after {} ms: {}", dataset, k, b.source(), millis(t0), e.getCause());
            throw new LoadException(dataset, "loadByKey", e.getCause() != null ? e.getCause() : e);
        }
    }

    /**
     * Rows for many keys, misses loaded in one call. Keys that do not exist are absent, so use
     * {@code getOrDefault(key, List.of())}. Iteration follows the order of {@code keys}.
     */
    public Map<K, List<T>> findAllByKeys(Collection<K> keys) {
        Objects.requireNonNull(keys, "keys");
        if (keys.isEmpty()) return Map.of();
        Map<K, String> encoded = new LinkedHashMap<>();
        for (K key : keys) encoded.computeIfAbsent(key, this::encodeKey);
        Map<String, List<T>> found = findAllByEncodedKeys(new LinkedHashSet<>(encoded.values()));
        Map<K, List<T>> out = new LinkedHashMap<>();
        encoded.forEach((key, k) -> {
            List<T> rows = found.get(k);
            if (rows != null) out.put(key, rows);
        });
        return Collections.unmodifiableMap(out);
    }

    /** Every row of the dataset. */
    public List<T> findAll() {
        List<T> out = new ArrayList<>();
        findAllGroupedByKey().values().forEach(out::addAll);
        return Collections.unmodifiableList(out);
    }

    public boolean existsByKey(K key) {
        return !findByKey(key).isEmpty();
    }

    /** Every row, grouped by encoded key (what the server streams to clients). */
    public Map<String, List<T>> findAllGroupedByKey() {
        Binding b = bound();
        if (b.policy() == CachePolicy.SOURCE_ONLY) {
            long t0 = System.nanoTime();
            Map<String, List<T>> out = new LinkedHashMap<>();
            load("loadAll", () -> b.loader().loadAll()).forEach((k, rows) -> {
                List<T> v = mapRows(rows);
                if (!v.isEmpty()) out.put(k, v);
            });
            log.debug("{}.findAll [SOURCE_ONLY] -> {} returned {} keys in {} ms", dataset, b.source(), out.size(), millis(t0));
            return Collections.unmodifiableMap(out);
        }
        Set<String> keys = allKeys;
        if (keys == null) {
            if (b.policy() == CachePolicy.CACHE_ONLY) {
                log.warn("{}.findAll on CACHE_ONLY dataset before preload; returning empty", dataset);
                return Map.of();
            }
            keys = loadAllIntoCache(b);
        }
        return findAllByEncodedKeys(keys);
    }

    // ------------------------------------------------------------------ lifecycle

    /** Binds this DAO to its dataset settings; done once by the client or server at startup. */
    public final synchronized void bind(Binding b) {
        if (binding != null) throw new IllegalStateException("Repository for '" + dataset + "' is already bound");
        binding = Objects.requireNonNull(b, "binding");
        log.info("Bound {} to dataset '{}': policy={}, source={}, cache={}, preload={}, cache-not-found={}, key-separator='{}'",
                getClass().getSimpleName(), dataset, b.policy(), b.source(), b.cache().getName(), b.preload(),
                b.cacheNotFound(), b.keySeparator());
    }

    public final boolean isBound() {
        return binding != null;
    }

    public final Binding binding() {
        return bound();
    }

    /** Loads the whole dataset into the cache; returns the key count (0 for SOURCE_ONLY). */
    public int preload() {
        Binding b = bound();
        return b.policy() == CachePolicy.SOURCE_ONLY ? 0 : loadAllIntoCache(b).size();
    }

    /** Clears the cache; the next read reloads (CACHE_ONLY: call {@link #preload()} again). */
    public void evictAll() {
        synchronized (loadAllLock) {
            bound().cache().clear();
            allKeys = null;
            log.info("{}: cache '{}' evicted", dataset, bound().cache().getName());
        }
    }

    /**
     * Turns a key into the cache/loader key. Strings pass through; records (composite keys) join their
     * components in declaration order with the key separator; anything else uses {@code toString()}.
     * Override for other encodings.
     */
    protected String encodeKey(K key) {
        if (key == null) throw new IllegalArgumentException("key must not be null");
        if (key instanceof String s) return s;
        if (!key.getClass().isRecord()) return key.toString();
        StringJoiner j = new StringJoiner(bound().keySeparator());
        for (RecordComponent c : key.getClass().getRecordComponents()) {
            try {
                Object v = c.getAccessor().invoke(key);
                if (v == null) throw new IllegalArgumentException("key component '" + c.getName() + "' must not be null");
                j.add(v.toString());
            } catch (IllegalAccessException | InvocationTargetException e) {
                throw new IllegalArgumentException("Cannot read key component '" + c.getName() + "' (make the record public)", e);
            }
        }
        return j.toString();
    }

    @Override
    public String toString() {
        Binding b = binding;
        return getClass().getSimpleName() + "[" + dataset + (b == null ? ", unbound" : ", " + b.policy() + ", " + b.source()) + "]";
    }

    // ------------------------------------------------------------------ internals

    private Map<String, List<T>> findAllByEncodedKeys(Collection<String> keys) {
        Binding b = bound();
        Map<String, List<T>> found = new LinkedHashMap<>();
        List<String> misses = new ArrayList<>();
        for (String k : keys) {
            Objects.requireNonNull(k, "keys must not contain null");
            Cache.ValueWrapper w = b.cache().get(k);
            if (w != null) {
                List<T> v = cast(w.get());
                if (v != null && !v.isEmpty()) found.put(k, v);
            } else {
                misses.add(k);
            }
        }
        if (misses.isEmpty() || b.policy() == CachePolicy.CACHE_ONLY) {
            log.trace("{}.findAllByKeys [{}] {} keys: {} found, {} missing (no load)",
                    dataset, b.policy(), keys.size(), found.size(), misses.size());
            return Collections.unmodifiableMap(found);
        }

        long t0 = System.nanoTime();
        int hits = found.size();
        Map<String, List<Map<String, Object>>> loaded = load("loadByKeys", () -> b.loader().loadByKeys(misses));
        int notFound = 0;
        for (String k : misses) {
            List<T> v = mapRows(loaded.get(k));
            if (!v.isEmpty() || b.cacheNotFound()) b.cache().put(k, v);
            if (!v.isEmpty()) found.put(k, v);
            else notFound++;
        }
        log.debug("{}.findAllByKeys [{}] {} keys: {} hits, {} misses -> {} in {} ms ({} found, {} not found)",
                dataset, b.policy(), keys.size(), hits, misses.size(), b.source(), millis(t0),
                misses.size() - notFound, notFound);
        Map<String, List<T>> ordered = new LinkedHashMap<>();
        for (String k : keys) {
            List<T> v = found.get(k);
            if (v != null) ordered.put(k, v);
        }
        return Collections.unmodifiableMap(ordered);
    }

    private Set<String> loadAllIntoCache(Binding b) {
        synchronized (loadAllLock) {
            if (allKeys != null) return allKeys;
            long t0 = System.nanoTime();
            Set<String> keys = new LinkedHashSet<>();
            load("loadAll", () -> b.loader().loadAll()).forEach((k, rows) -> {
                List<T> v = mapRows(rows);
                if (v.isEmpty()) return;
                b.cache().put(k, v);
                keys.add(k);
            });
            allKeys = Collections.unmodifiableSet(keys);
            log.info("Loaded dataset '{}' ({}, from {}) into cache '{}': {} keys in {} ms",
                    dataset, b.policy(), b.source(), b.cache().getName(), keys.size(), millis(t0));
            return allKeys;
        }
    }

    private List<T> cached(Binding b, String key) {
        Cache.ValueWrapper w = b.cache().get(key);
        List<T> v = w == null ? null : cast(w.get());
        return v == null ? List.of() : v;
    }

    private List<T> mapRows(List<Map<String, Object>> rows) {
        if (rows == null || rows.isEmpty()) return List.of();
        List<T> out = new ArrayList<>(rows.size());
        for (Map<String, Object> r : rows) out.add(mapper.apply(r));
        return Collections.unmodifiableList(out);
    }

    private <R> R load(String op, Supplier<R> call) {
        try {
            R r = call.get();
            if (r == null) throw new IllegalStateException("loader returned null");
            return r;
        } catch (LoadException e) {
            throw e;
        } catch (RuntimeException e) {
            log.warn("{}.{} failed from {}: {}", dataset, op, binding == null ? "?" : binding.source(), e.toString());
            throw new LoadException(dataset, op, e);
        }
    }

    private static long millis(long startNanos) {
        return (System.nanoTime() - startNanos) / 1_000_000;
    }

    private Binding bound() {
        Binding b = binding;
        if (b == null) {
            throw new IllegalStateException("Dataset '" + dataset + "' is not enabled: add it under reference-data-client.datasets"
                    + " with \"repository\" pointing to this repository's bean name");
        }
        return b;
    }

    @SuppressWarnings("unchecked")
    private static <V> List<V> cast(Object o) {
        return (List<V>) o;
    }

    /** The loader (source or delegate) failed. Nothing was cached for the keys involved. */
    @Getter
    public static class LoadException extends RuntimeException {
        private final String dataset;
        private final String operation;

        public LoadException(String dataset, String operation, Throwable cause) {
            super("Loading dataset '" + dataset + "' failed in " + operation + ": " + cause, cause);
            this.dataset = dataset;
            this.operation = operation;
        }
    }
}
