package com.referencedata.core.loader;

import com.referencedata.core.ReferenceLoader;
import com.referencedata.core.RowValues;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.io.DefaultResourceLoader;
import org.springframework.core.io.Resource;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UncheckedIOException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.StringJoiner;
import java.util.regex.Pattern;

/**
 * {@link ReferenceLoader} over a delimited flat file with a header row ({@code classpath:} or {@code file:}).
 * Values are strings (empty = null); the row type's Jackson mapping converts them ({@code "2"} to {@code int}).
 * The file is read on every load call, so use it with CACHE_FIRST/CACHE_ONLY + preload.
 * No quoting support: use a delimiter that does not occur in values.
 */
@Slf4j
public class CsvReferenceLoader implements ReferenceLoader {

    private final String location;
    private final String delimiter;
    private final List<String> keyColumns;
    private final String keySeparator;

    public CsvReferenceLoader(String location, String delimiter, List<String> keyColumns) {
        this(location, delimiter, keyColumns, "|");
    }

    public CsvReferenceLoader(String location, String delimiter, List<String> keyColumns, String keySeparator) {
        this.location = location;
        this.delimiter = delimiter;
        this.keyColumns = keyColumns.stream().map(c -> c.toLowerCase(Locale.ROOT)).toList();
        this.keySeparator = keySeparator;
        log.info("CSV loader: {} (delimiter '{}', key-columns {})", location, delimiter, this.keyColumns);
    }

    @Override
    public Map<String, List<Map<String, Object>>> loadAll() {
        long t0 = System.nanoTime();
        Resource r = new DefaultResourceLoader().getResource(location);
        Map<String, List<Map<String, Object>>> out = new LinkedHashMap<>();
        int rows = 0;
        try (BufferedReader in = new BufferedReader(new InputStreamReader(r.getInputStream(), StandardCharsets.UTF_8))) {
            String headerLine = in.readLine();
            if (headerLine == null) return out;
            String[] header = split(headerLine);
            for (int i = 0; i < header.length; i++) header[i] = header[i].toLowerCase(Locale.ROOT);
            for (String col : keyColumns) {
                if (!List.of(header).contains(col)) throw new IllegalStateException(location + " has no key column '" + col + "'");
            }
            String line;
            while ((line = in.readLine()) != null) {
                if (line.isBlank()) continue;
                String[] values = split(line);
                Map<String, Object> raw = new LinkedHashMap<>();
                for (int i = 0; i < header.length; i++) {
                    String v = i < values.length ? values[i].trim() : "";
                    raw.put(header[i], v.isEmpty() ? null : v);
                }
                Map<String, Object> row = RowValues.normalize(raw);
                out.computeIfAbsent(keyOf(row), k -> new ArrayList<>()).add(row);
                rows++;
            }
        } catch (IOException e) {
            log.warn("Cannot read {}: {}", location, e.toString());
            throw new UncheckedIOException("Cannot read " + location, e);
        }
        log.debug("Read {}: {} rows, {} keys in {} ms", location, rows, out.size(), (System.nanoTime() - t0) / 1_000_000);
        return out;
    }

    @Override
    public List<Map<String, Object>> loadByKey(String key) {
        return loadAll().getOrDefault(key, List.of());
    }

    @Override
    public Map<String, List<Map<String, Object>>> loadByKeys(Collection<String> keys) {
        Map<String, List<Map<String, Object>>> all = loadAll();
        Map<String, List<Map<String, Object>>> out = new LinkedHashMap<>();
        for (String k : keys) {
            List<Map<String, Object>> rows = all.get(k);
            if (rows != null) out.put(k, rows);
        }
        return out;
    }

    private String[] split(String line) {
        String[] parts = line.split(Pattern.quote(delimiter), -1);
        for (int i = 0; i < parts.length; i++) parts[i] = parts[i].trim();
        return parts;
    }

    private String keyOf(Map<String, Object> row) {
        StringJoiner j = new StringJoiner(keySeparator);
        keyColumns.forEach(c -> j.add(String.valueOf(row.get(c))));
        return j.toString();
    }
}
