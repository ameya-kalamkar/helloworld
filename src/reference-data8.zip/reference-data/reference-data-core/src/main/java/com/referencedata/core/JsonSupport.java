package com.referencedata.core;

import com.referencedata.core.ReferenceDataConfig.Settings;
import com.referencedata.core.ReferenceDataConfig.Side;
import lombok.AccessLevel;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.env.PropertyResolver;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import tools.jackson.core.JacksonException;
import tools.jackson.core.json.JsonReadFeature;
import tools.jackson.databind.DeserializationFeature;
import tools.jackson.databind.JavaType;
import tools.jackson.databind.JsonNode;
import tools.jackson.databind.MapperFeature;
import tools.jackson.databind.ObjectMapper;
import tools.jackson.databind.PropertyNamingStrategies;
import tools.jackson.databind.cfg.DateTimeFeature;
import tools.jackson.databind.json.JsonMapper;
import tools.jackson.databind.node.ArrayNode;
import tools.jackson.databind.node.ObjectNode;
import tools.jackson.databind.node.StringNode;
import tools.jackson.dataformat.yaml.YAMLMapper;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.function.Function;

/** All Jackson 3 use in one place: reading the config files and mapping rows to row types. */
@Slf4j
@NoArgsConstructor(access = AccessLevel.PRIVATE)
final class JsonSupport {

    /** Allowed next to the side's root element at the top of a config file. */
    static final String SCHEMA = "$schema";

    private static final ObjectMapper JSON_CONFIG = JsonMapper.builder()
            .enable(JsonReadFeature.ALLOW_JAVA_COMMENTS)          // "//" and "/* */" comments in the JSON config
            .propertyNamingStrategy(PropertyNamingStrategies.KEBAB_CASE)
            .enable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES)   // off by default in Jackson 3
            .enable(DeserializationFeature.FAIL_ON_NULL_FOR_PRIMITIVES)
            .enable(MapperFeature.ACCEPT_CASE_INSENSITIVE_ENUMS)
            .build();

    private static final ObjectMapper YAML_CONFIG = YAMLMapper.builder()
            .propertyNamingStrategy(PropertyNamingStrategies.KEBAB_CASE)
            .enable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES)
            .enable(DeserializationFeature.FAIL_ON_NULL_FOR_PRIMITIVES)
            .enable(MapperFeature.ACCEPT_CASE_INSENSITIVE_ENUMS)
            .build();

    /** Rows to row types. java.time is built into Jackson 3; nested maps/lists map to nested records/collections. */
    private static final ObjectMapper ROWS = JsonMapper.builder()
            .propertyNamingStrategy(PropertyNamingStrategies.SNAKE_CASE)   // column ccy_code -> property ccyCode
            .disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES)
            .disable(DeserializationFeature.FAIL_ON_NULL_FOR_PRIMITIVES)  // Jackson 3 default is on; null column -> 0/false
            .enable(DeserializationFeature.USE_BIG_DECIMAL_FOR_FLOATS)
            .disable(DateTimeFeature.ADJUST_DATES_TO_CONTEXT_TIME_ZONE)
            .build();

    /** Identity for {@code Map} row types; otherwise Jackson maps columns to properties ({@code @JsonProperty} to rename). */
    @SuppressWarnings("unchecked")
    static <T> Function<Map<String, Object>, T> rowMapper(Class<T> type) {
        if (Map.class.isAssignableFrom(type)) return row -> (T) row;
        JavaType t = ROWS.constructType(type);
        return row -> {
            try {
                return ROWS.convertValue(row, t);
            } catch (JacksonException e) {
                throw new IllegalStateException("Cannot map row to " + type.getName() + ": " + e.getOriginalMessage()
                        + " (columns " + row.keySet() + ")", e);
            }
        };
    }

    /**
     * Parses {@code location} for one side: comments allowed (JSON), {@code ${...}} resolved per string value, the
     * side's root element required, nothing else at the top except {@code "$schema"}, unknown keys rejected.
     */
    static Settings readConfig(Side side, String location, PropertyResolver env, ResourceLoader resources) {
        Resource r = resources.getResource(location);
        if (!r.exists()) throw new IllegalStateException("Reference data config not found: " + location);
        String lower = location.toLowerCase(Locale.ROOT);
        boolean yaml = lower.endsWith(".yml") || lower.endsWith(".yaml");
        ObjectMapper mapper = yaml ? YAML_CONFIG : JSON_CONFIG;
        log.debug("Reading {} config {} as {}", side.root(), location, yaml ? "YAML" : "JSON");

        JsonNode top;
        try (InputStream in = r.getInputStream()) {
            top = mapper.readTree(in);
        } catch (IOException | JacksonException e) {
            throw new IllegalStateException("Cannot parse " + location + ": " + e.getMessage(), e);
        }
        if (top == null || !top.isObject()) throw new IllegalStateException(location + " is empty or not an object");

        List<String> errors = new ArrayList<>();
        for (String name : ((ObjectNode) top).propertyNames()) {
            if (name.equals(side.root()) || name.equals(SCHEMA)) continue;
            boolean otherSide = false;
            for (Side other : Side.values()) otherSide |= other != side && name.equals(other.root());
            errors.add(otherSide
                    ? name + ": this is the other side's root; " + location + " is read as the " + side.root() + " config"
                    : name + ": unknown top-level element; expected '" + side.root() + "' (and optionally '" + SCHEMA + "')");
        }
        JsonNode body = top.get(side.root());
        if (body == null || body.isNull()) {
            errors.add(side.root() + ": required root element is missing");
        } else if (!body.isObject()) {
            errors.add(side.root() + ": must be an object");
        } else {
            resolvePlaceholders(body, side.root(), env, errors);
        }
        ReferenceDataConfig.failIfAny(location, errors);

        try {
            return mapper.treeToValue(body, Settings.class);
        } catch (JacksonException e) {
            throw new IllegalStateException("Invalid " + location + " at " + side.root() + pathOf(e) + ": "
                    + e.getOriginalMessage(), e);
        }
    }

    private static String pathOf(JacksonException e) {
        StringBuilder sb = new StringBuilder();
        for (JacksonException.Reference ref : e.getPath()) {
            if (ref.getPropertyName() != null) sb.append('.').append(ref.getPropertyName());
            else if (ref.getIndex() >= 0) sb.append('[').append(ref.getIndex()).append(']');
        }
        return sb.toString();
    }

    /** Resolves {@code ${...}} in every string value after parsing, so an env value cannot break the file's syntax. */
    private static void resolvePlaceholders(JsonNode node, String path, PropertyResolver env, List<String> errors) {
        if (node instanceof ObjectNode obj) {
            for (String name : new ArrayList<>(obj.propertyNames())) {
                JsonNode v = obj.get(name);
                String p = path + "." + name;
                if (v.isString()) obj.set(name, StringNode.valueOf(resolve(v.asString(), p, env, errors)));
                else resolvePlaceholders(v, p, env, errors);
            }
        } else if (node instanceof ArrayNode arr) {
            for (int i = 0; i < arr.size(); i++) {
                String p = path + "[" + i + "]";
                if (arr.get(i).isString()) arr.set(i, StringNode.valueOf(resolve(arr.get(i).asString(), p, env, errors)));
                else resolvePlaceholders(arr.get(i), p, env, errors);
            }
        }
    }

    private static String resolve(String text, String path, PropertyResolver env, List<String> errors) {
        if (!text.contains("${")) return text;
        try {
            String v = env.resolveRequiredPlaceholders(text);
            log.debug("{}: resolved placeholder {}", path, text);
            return v;
        } catch (IllegalArgumentException e) {
            errors.add(path + ": unresolved placeholder in '" + text + "' (" + e.getMessage() + ")");
            return text;
        }
    }
}
