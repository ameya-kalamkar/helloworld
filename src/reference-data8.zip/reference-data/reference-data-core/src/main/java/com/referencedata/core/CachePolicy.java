package com.referencedata.core;

/** How a dataset's DAO uses its Spring {@link org.springframework.cache.Cache}. Set per dataset. */
public enum CachePolicy {

    /** Cache first; on a miss read through the loader and cache the result. */
    CACHE_FIRST,

    /** Cache disabled: a Spring {@code NoOpCache} passes every call straight to the loader. Same API. */
    SOURCE_ONLY,

    /** Cache only: a miss is "not found", the loader is never called on reads. Requires {@code preload}. */
    CACHE_ONLY
}
