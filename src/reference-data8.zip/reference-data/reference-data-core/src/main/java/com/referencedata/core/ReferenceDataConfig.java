package com.referencedata.core;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cache.Cache;
import org.springframework.cache.CacheManager;
import org.springframework.cache.support.NoOpCache;
import org.springframework.core.env.PropertyResolver;
import org.springframework.core.io.ResourceLoader;

import java.time.Duration;
import java.time.format.DateTimeParseException;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.function.Function;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * The client and server config files ({@code .json}, or {@code .yml}/{@code .yaml}). Same settings model; each file
 * has its own root: {@code "reference-data-client"} or {@code "reference-data-server"} (plus an optional
 * {@code "$schema"} for IDE validation).
 *
 * <pre>
 * {
 *   "reference-data-client": {
 *     "mode": "${REFDATA_MODE:DELEGATE}",
 *     "policy": "CACHE_FIRST",
 *     "delegate": { "transport": "grpc", "target": "${REFDATA_SERVER:dns:///reference-data-server:9090}" },
 *     "datasets": { "currency": { "repository": "currencyRepository", "policy": "CACHE_ONLY", "preload": true } }
 *   }
 * }
 * </pre>
 * {@code mode} (client), {@code policy}, {@code preload}, {@code cache-not-found}, {@code cache-manager} and
 * {@code key-separator} are set at the top and overridden per dataset. {@code repository}, {@code loader} and
 * {@code cache-manager} are Spring bean names. {@code ${NAME:default}} resolves per value; JSON may contain comments;
 * unknown keys fail; {@link Settings#validate} reports every problem at once.
 */
@Slf4j
@NoArgsConstructor(access = AccessLevel.PRIVATE)
public final class ReferenceDataConfig {

    /** Bean name of the built-in in-memory cache manager used when none is configured. */
    public static final String DEFAULT_CACHE_MANAGER = "referenceDataCacheManager";

    /** Bridge transports: gRPC/protobuf, or WebSocket carrying Kryo-serialized frames. */
    public static final String GRPC = "grpc";
    public static final String WEBSOCKET = "websocket";
    public static final Set<String> TRANSPORTS = Set.of(GRPC, WEBSOCKET);

    private static final Pattern NAME = Pattern.compile("[A-Za-z0-9][A-Za-z0-9._-]*");
    private static final Pattern BEAN_NAME = Pattern.compile("[A-Za-z_$][A-Za-z0-9_$.#-]*");

    /** Where a client dataset's data comes from; the server is always local. */
    public enum Mode { EMBEDDED, DELEGATE }

    /** Which file is being read: decides the root element and which settings are allowed. */
    @RequiredArgsConstructor
    public enum Side {
        CLIENT("reference-data-client"),
        SERVER("reference-data-server");

        private final String root;

        /** The file's root element. */
        public String root() { return root; }
    }

    /**
     * Top-level values.
     *
     * @param preloadParallelism datasets preloaded at the same time, default 4
     * @param delegate           client only: bridge connection to reference-data-server
     * @param bridge             server only: bridge endpoint clients connect to
     */
    public record Settings(Mode mode,
                           CachePolicy policy,
                           Boolean preload,
                           Boolean cacheNotFound,
                           String cacheManager,
                           String keySeparator,
                           Integer preloadParallelism,
                           Delegate delegate,
                           Bridge bridge,
                           Map<String, Dataset> datasets) {

        public Settings {
            datasets = datasets == null ? Map.of() : Collections.unmodifiableMap(new LinkedHashMap<>(datasets));
        }

        public int preloadParallelismOrDefault() {
            return preloadParallelism == null ? 4 : preloadParallelism;
        }

        /** The dataset's effective settings: dataset value, else top-level value, else default. */
        public Resolved resolve(String name) {
            Dataset d = datasets.get(name);
            if (d == null) throw new IllegalArgumentException("Dataset '" + name + "' is not configured; configured: " + datasets.keySet());
            return new Resolved(name,
                    first(d.mode(), mode, Mode.EMBEDDED),
                    first(d.policy(), policy, CachePolicy.CACHE_FIRST),
                    first(d.preload(), preload, false),
                    first(d.cacheNotFound(), cacheNotFound, true),
                    first(d.cacheManager(), cacheManager, DEFAULT_CACHE_MANAGER),
                    first(d.cacheName(), null, name),
                    first(d.keySeparator(), keySeparator, "|"),
                    d.repository(),
                    d.loader());
        }

        /** Adds every configuration problem for this side to {@code errors} (nothing is thrown here). */
        public void validate(Side side, List<String> errors) {
            String r = side.root();
            if (datasets.isEmpty()) errors.add(r + ".datasets: at least one dataset is required");
            if (keySeparator != null && keySeparator.isEmpty()) errors.add(r + ".key-separator: must not be empty");
            if (preloadParallelism != null && preloadParallelism < 1) errors.add(r + ".preload-parallelism: must be >= 1");
            if (cacheManager != null && cacheManager.isBlank()) errors.add(r + ".cache-manager: must not be blank");

            if (side == Side.SERVER) {
                if (mode != null) errors.add(r + ".mode: client-only; the server always runs its loaders locally");
                if (delegate != null) errors.add(r + ".delegate: client-only; the server uses 'bridge'");
                validateBridge(r, bridge, errors);
            } else if (bridge != null) {
                errors.add(r + ".bridge: server-only; the client uses 'delegate'");
            }

            boolean anyDelegate = false;
            Map<String, String> repos = new LinkedHashMap<>();
            for (Map.Entry<String, Dataset> e : datasets.entrySet()) {
                String name = e.getKey();
                Dataset d = e.getValue();
                String p = r + ".datasets." + name;
                if (d == null) {
                    errors.add(p + ": must be an object");
                    continue;
                }
                if (!NAME.matcher(name).matches()) errors.add(p + ": dataset name must match " + NAME.pattern());
                Resolved res = resolve(name);
                blankOrBean(p + ".loader", d.loader(), errors);
                blankOrBean(p + ".cache-manager", d.cacheManager(), errors);
                if (d.cacheName() != null && d.cacheName().isBlank()) errors.add(p + ".cache-name: must not be blank");
                if (d.keySeparator() != null && d.keySeparator().isEmpty()) errors.add(p + ".key-separator: must not be empty");

                if (side == Side.SERVER) {
                    if (d.mode() != null) errors.add(p + ".mode: client-only");
                    if (d.repository() != null) errors.add(p + ".repository: client-only");
                    if (d.loader() == null) errors.add(p + ".loader: a ReferenceLoader bean name is required");
                } else {
                    if (d.repository() == null) {
                        errors.add(p + ".repository: the DAO bean name is required");
                    } else {
                        blankOrBean(p + ".repository", d.repository(), errors);
                        String other = repos.putIfAbsent(d.repository(), name);
                        if (other != null) errors.add(p + ".repository: '" + d.repository() + "' is already used by dataset " + other);
                    }
                    if (res.mode() == Mode.EMBEDDED && d.loader() == null) {
                        errors.add(p + ".loader: EMBEDDED mode needs a ReferenceLoader bean name");
                    }
                    if (res.mode() == Mode.DELEGATE && d.loader() != null) {
                        log.warn("{}.loader '{}' is ignored: the dataset is DELEGATE (served by reference-data-server)", p, d.loader());
                    }
                    anyDelegate |= res.mode() == Mode.DELEGATE;
                }
                if (res.policy() == CachePolicy.CACHE_ONLY && !res.preload()) {
                    errors.add(p + ": CACHE_ONLY needs preload: true (nothing else ever fills the cache)");
                }
                if (res.policy() == CachePolicy.SOURCE_ONLY && res.preload()) {
                    errors.add(p + ": preload has no effect with SOURCE_ONLY (the cache is disabled)");
                }
            }
            if (side == Side.CLIENT) {
                if (anyDelegate && delegate == null) {
                    errors.add(r + ".delegate: required because at least one dataset is DELEGATE");
                } else if (delegate != null) {
                    validateDelegate(r, delegate, anyDelegate, errors);
                }
            }
        }

        private static void validateDelegate(String r, Delegate d, boolean required, List<String> errors) {
            String p = r + ".delegate";
            if (d.target() == null || d.target().isBlank()) {
                if (required) errors.add(p + ".target: required, e.g. dns:///reference-data-server:9090");
            }
            String transport = d.transportOrDefault();
            if (!TRANSPORTS.contains(transport)) {
                errors.add(p + ".transport: '" + d.transport() + "' is not one of " + TRANSPORTS);
            } else if (d.target() != null && !d.target().isBlank()) {
                for (String t : d.targets()) {
                    boolean ws = t.startsWith("ws://") || t.startsWith("wss://");
                    if (transport.equals(WEBSOCKET) && !ws) {
                        errors.add(p + ".target: '" + t + "' must be ws://host:port/path or wss://... for the websocket transport");
                    } else if (transport.equals(GRPC) && ws) {
                        errors.add(p + ".target: '" + t + "' is a WebSocket URI; use \"transport\": \"websocket\" or a gRPC target (dns:///host:port)");
                    } else if (transport.equals(WEBSOCKET)) {
                        try {
                            java.net.URI u = new java.net.URI(t);
                            if (u.getHost() == null) errors.add(p + ".target: '" + t + "' has no host");
                        } catch (java.net.URISyntaxException e) {
                            errors.add(p + ".target: '" + t + "' is not a valid URI: " + e.getMessage());
                        }
                    }
                }
                if (transport.equals(GRPC) && d.targets().size() > 1) {
                    errors.add(p + ".target: gRPC takes one target (use dns:/// for several addresses)");
                }
                if (transport.equals(WEBSOCKET) && d.plaintext() != null) {
                    log.warn("{}.plaintext is ignored for websocket: ws:// is plain, wss:// is TLS", p);
                }
            }
            positiveDuration(p + ".deadline", d.deadline(), errors);
            positiveDuration(p + ".find-all-deadline", d.findAllDeadline(), errors);
            positiveDuration(p + ".ready-timeout", d.readyTimeout(), errors);
            range(p + ".max-message-size-mb", d.maxMessageSizeMb(), 1, 2047, errors);
            range(p + ".max-keys-per-call", d.maxKeysPerCall(), 1, 1_000_000, errors);
            range(p + ".find-all-window", d.findAllWindow(), 1, 1024, errors);
        }

        private static void validateBridge(String r, Bridge b, List<String> errors) {
            String p = r + ".bridge";
            if (b == null) return;                                   // default: gRPC on 9090
            if (b.grpc() == null && b.websocket() == null) {
                errors.add(p + ": configure at least one of 'grpc', 'websocket' (or leave 'bridge' out for gRPC on 9090)");
                return;
            }
            if (b.grpc() != null) validateEndpoint(p + ".grpc", b.grpc(), false, errors);
            if (b.websocket() != null) validateEndpoint(p + ".websocket", b.websocket(), true, errors);
            if (b.grpc() != null && b.websocket() != null
                    && b.grpc().portOrDefault(GRPC) == b.websocket().portOrDefault(WEBSOCKET)) {
                errors.add(p + ": grpc and websocket cannot share port " + b.grpc().portOrDefault(GRPC));
            }
        }

        private static void validateEndpoint(String p, Endpoint e, boolean websocket, List<String> errors) {
            range(p + ".port", e.port(), 1, 65_535, errors);
            range(p + ".max-message-size-mb", e.maxMessageSizeMb(), 1, 2047, errors);
            range(p + ".find-all-chunk-keys", e.findAllChunkKeys(), 1, 1_000_000, errors);
            range(p + ".worker-threads", e.workerThreads(), 1, 1024, errors);
            if (websocket) {
                if (e.path() != null && !e.path().matches("/[A-Za-z0-9._~/-]*")) {
                    errors.add(p + ".path: '" + e.path() + "' must start with / (e.g. /reference-data)");
                }
                range(p + ".send-buffer-mb", e.sendBufferMb(), 1, 2047, errors);
                positiveDuration(p + ".send-timeout", e.sendTimeout(), errors);
            } else {
                if (e.path() != null) errors.add(p + ".path: websocket only");
                if (e.sendBufferMb() != null) errors.add(p + ".send-buffer-mb: websocket only");
                if (e.sendTimeout() != null) errors.add(p + ".send-timeout: websocket only");
            }
        }

        private static void blankOrBean(String path, String value, List<String> errors) {
            if (value == null) return;
            if (value.isBlank()) errors.add(path + ": must not be blank");
            else if (!BEAN_NAME.matcher(value).matches()) errors.add(path + ": '" + value + "' is not a valid bean name");
        }

        private static void range(String path, Integer value, int min, int max, List<String> errors) {
            if (value != null && (value < min || value > max)) errors.add(path + ": " + value + " is outside " + min + ".." + max);
        }

        private static void positiveDuration(String path, String value, List<String> errors) {
            if (value == null) return;
            try {
                Duration d = duration(value, null);
                if (d.isNegative() || d.isZero()) errors.add(path + ": must be positive");
            } catch (DateTimeParseException | ArithmeticException e) {
                errors.add(path + ": '" + value + "' is not a duration (e.g. 500ms, 2s, 10m, 1h, PT2S)");
            }
        }
    }

    /**
     * Client only: the bridge connection to reference-data-server.
     *
     * @param transport       {@code grpc} (default) or {@code websocket} (Kryo frames over WebSocket)
     * @param target          gRPC: {@code dns:///reference-data-server:9090} (round-robin over all server addresses);
     *                        websocket: {@code ws://reference-data-server:9091/reference-data}, or several URIs separated
     *                        by commas (one connection each, round-robin per call); {@code wss://} for TLS
     * @param deadline        per FindByKeys call, default 2s
     * @param findAllDeadline per FindAll stream (preload, findAll), default 10m
     * @param readyTimeout    how long startup waits for the server to report it is warm, default 5m
     * @param plaintext       gRPC only: no TLS, default true (websocket: the URI scheme decides)
     * @param maxKeysPerCall  findAllByKeys misses are sent in calls of this many keys, default 5000
     * @param findAllWindow   websocket only: FindAll chunks the server may send ahead of this client, default 4
     */
    public record Delegate(String transport, String target, String deadline, String findAllDeadline, String readyTimeout,
                           Boolean plaintext, Integer maxMessageSizeMb, Integer maxKeysPerCall, Integer findAllWindow) {
        public String transportOrDefault() { return normalizeTransport(transport); }
        public List<String> targets() {
            return target == null ? List.of() : java.util.Arrays.stream(target.split(",")).map(String::trim).filter(t -> !t.isEmpty()).toList();
        }
        public Duration deadlineOrDefault() { return duration(deadline, Duration.ofSeconds(2)); }
        public Duration findAllDeadlineOrDefault() { return duration(findAllDeadline, Duration.ofMinutes(10)); }
        public Duration readyTimeoutOrDefault() { return duration(readyTimeout, Duration.ofMinutes(5)); }
        public boolean plaintextOrDefault() { return plaintext == null || plaintext; }
        public int maxMessageSizeMbOrDefault() { return maxMessageSizeMb == null ? 64 : maxMessageSizeMb; }
        public int maxKeysPerCallOrDefault() { return maxKeysPerCall == null ? 5000 : maxKeysPerCall; }
        public int findAllWindowOrDefault() { return findAllWindow == null ? 4 : findAllWindow; }
    }

    /**
     * Server only: the bridge endpoints clients connect to, one per transport; both may run at once so clients can
     * use either. Without a {@code bridge} section the server runs gRPC on 9090.
     */
    public record Bridge(Endpoint grpc, Endpoint websocket) {
        /** Configured endpoints by transport name, gRPC default when none. */
        public Map<String, Endpoint> endpoints() {
            Map<String, Endpoint> out = new LinkedHashMap<>();
            if (grpc != null) out.put(GRPC, grpc);
            if (websocket != null) out.put(WEBSOCKET, websocket);
            if (out.isEmpty()) out.put(GRPC, new Endpoint(null, null, null, null, null, null, null));
            return out;
        }

        public static Bridge orDefault(Bridge b) {
            return b != null ? b : new Bridge(null, null);
        }
    }

    /**
     * One server bridge endpoint.
     *
     * @param port             default 9090 (grpc) / 9091 (websocket)
     * @param path             websocket only: handshake path, default {@code /reference-data}
     * @param findAllChunkKeys keys per FindAll message (also capped at about 1 MB), default 500
     * @param workerThreads    threads answering requests (lookups may wait on the source), default 16
     * @param sendBufferMb     websocket only: per-connection outbound buffer before the connection is closed, default 64
     * @param sendTimeout      websocket only: longest a single send may block before the connection is closed, default 30s
     */
    public record Endpoint(Integer port, String path, Integer maxMessageSizeMb, Integer findAllChunkKeys,
                           Integer workerThreads, Integer sendBufferMb, String sendTimeout) {
        public int portOrDefault(String transport) { return port != null ? port : WEBSOCKET.equals(transport) ? 9091 : 9090; }
        public String pathOrDefault() { return path == null ? "/reference-data" : path; }
        public int maxMessageSizeMbOrDefault() { return maxMessageSizeMb == null ? 64 : maxMessageSizeMb; }
        public int findAllChunkKeysOrDefault() { return findAllChunkKeys == null ? 500 : findAllChunkKeys; }
        public int workerThreadsOrDefault() { return workerThreads == null ? 16 : workerThreads; }
        public int sendBufferMbOrDefault() { return sendBufferMb == null ? 64 : sendBufferMb; }
        public Duration sendTimeoutOrDefault() { return duration(sendTimeout, Duration.ofSeconds(30)); }
    }

    /**
     * One dataset; every field overrides the top-level value of the same name.
     *
     * @param repository client: bean name of the DAO, e.g. {@code currencyRepository}
     * @param loader     bean name of the {@link ReferenceLoader}; server always, client in EMBEDDED mode
     */
    public record Dataset(String repository, Mode mode, String loader, CachePolicy policy, Boolean preload,
                          Boolean cacheNotFound, String cacheManager, String cacheName, String keySeparator) {}

    /** A dataset's effective settings after inheritance. */
    public record Resolved(String dataset, Mode mode, CachePolicy policy, boolean preload, boolean cacheNotFound,
                           String cacheManager, String cacheName, String keySeparator, String repository, String loader) {

        /** The dataset's Spring cache: a pass-through {@code NoOpCache} for SOURCE_ONLY, else from the named cache manager. */
        public Cache cache(Function<String, CacheManager> cacheManagers, List<String> errors) {
            if (policy == CachePolicy.SOURCE_ONLY) return new NoOpCache(cacheName);
            CacheManager cm = cacheManagers.apply(cacheManager);
            if (cm == null) {
                errors.add("datasets." + dataset + ".cache-manager: no CacheManager bean named '" + cacheManager + "'");
                return null;
            }
            Cache c = cm.getCache(cacheName);
            if (c == null) errors.add("datasets." + dataset + ".cache-name: cache manager '" + cacheManager + "' has no cache '" + cacheName + "'");
            return c;
        }

        public ReferenceRepository.Binding binding(Cache cache, ReferenceLoader loader, String source) {
            return new ReferenceRepository.Binding(policy, cache, loader, preload, cacheNotFound, keySeparator, source);
        }
    }

    // ------------------------------------------------------------------ loading

    /**
     * Reads the config for one side: JSON by default, YAML for {@code .yml}/{@code .yaml}. The file must have that
     * side's root element. {@code ${...}} resolve against {@code env}. Does not validate; call {@link Settings#validate}.
     */
    public static Settings load(Side side, String location, PropertyResolver env, ResourceLoader resources) {
        Settings s = JsonSupport.readConfig(side, location, env, resources);
        log.info("Loaded {} config from {}: {} datasets {}", side.root(), location, s.datasets().size(), s.datasets().keySet());
        return s;
    }

    /** {@code explicit}, else the value of {@code property} (also as an env var, e.g. REFERENCE_DATA_CLIENT_CONFIG), else {@code fallback}. */
    public static String location(PropertyResolver env, String property, String explicit, String fallback) {
        if (explicit != null && !explicit.isBlank()) return explicit;
        String configured = env.getProperty(property);
        return configured != null && !configured.isBlank() ? configured : fallback;
    }

    /** Adds an error for every pair of datasets that would share one Spring cache. */
    public static void checkNoSharedCaches(Map<String, Cache> cachesByDataset, List<String> errors) {
        Map<String, String> owners = new LinkedHashMap<>();
        cachesByDataset.forEach((name, c) -> {
            if (c == null || c instanceof NoOpCache) return;
            String id = System.identityHashCode(c.getNativeCache()) + ":" + c.getName();
            String owner = owners.putIfAbsent(id, name);
            if (owner != null) errors.add("datasets." + name + ".cache-name: shares Spring cache '" + c.getName() + "' with dataset " + owner);
        });
    }

    public static void failIfAny(String what, List<String> errors) {
        if (!errors.isEmpty()) {
            log.error("Invalid {} configuration ({} problems):\n  - {}", what, errors.size(), String.join("\n  - ", errors));
            throw new IllegalStateException("Invalid " + what + " configuration:\n  - " + String.join("\n  - ", errors));
        }
    }

    private static final Pattern DURATION = Pattern.compile("(\\d+)\\s*(ms|s|m|h|d)");

    /** {@code 500ms}, {@code 2s}, {@code 10m}, {@code 1h}, {@code 1d} or ISO-8601 ({@code PT2S}). */
    public static Duration duration(String text, Duration fallback) {
        if (text == null || text.isBlank()) return fallback;
        String t = text.trim();
        Matcher m = DURATION.matcher(t);
        if (!m.matches()) return Duration.parse(t);
        long n = Long.parseLong(m.group(1));
        return switch (m.group(2)) {
            case "ms" -> Duration.ofMillis(n);
            case "s" -> Duration.ofSeconds(n);
            case "m" -> Duration.ofMinutes(n);
            case "h" -> Duration.ofHours(n);
            default -> Duration.ofDays(n);
        };
    }

    private static String normalizeTransport(String transport) {
        return transport == null || transport.isBlank() ? "grpc" : transport.trim().toLowerCase(Locale.ROOT);
    }

    @SafeVarargs
    private static <T> T first(T... values) {
        for (T v : values) if (v != null) return v;
        return null;
    }
}
