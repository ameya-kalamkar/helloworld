package com.referencedata.core;

import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Extension point: loads one dataset from wherever it really lives (JDBC, REST, gRPC, files...),
 * like JCache's / Caffeine's {@code CacheLoader}. The cache calls it on a miss (read-through) and for preload.
 * <p>
 * Rows are maps of column name to value, normalised with {@link RowValues#normalize(Map)}. A key can have
 * several rows. Keys that do not exist are simply absent from results. Implementations must be thread-safe.
 * Declare implementations as Spring beans; the config refers to them by bean name ({@code "loader": "deskLoader"}).
 */
public interface ReferenceLoader {

    /** Every key of the dataset with its rows. Used for preload and {@code findAll}. */
    Map<String, List<Map<String, Object>>> loadAll();

    /** Rows for one key; empty list if the key does not exist. */
    List<Map<String, Object>> loadByKey(String key);

    /** Rows for many keys. Override to load in one round trip; the default calls {@link #loadByKey} per key. */
    default Map<String, List<Map<String, Object>>> loadByKeys(Collection<String> keys) {
        Map<String, List<Map<String, Object>>> out = new LinkedHashMap<>();
        for (String k : keys) {
            List<Map<String, Object>> rows = loadByKey(k);
            if (rows != null && !rows.isEmpty()) out.put(k, rows);
        }
        return out;
    }
}
