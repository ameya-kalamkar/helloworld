package com.referencedata.core.loader;

import com.referencedata.core.ReferenceLoader;
import com.referencedata.core.RowValues;
import lombok.Builder;
import lombok.extern.slf4j.Slf4j;
import org.springframework.jdbc.core.ColumnMapRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.simple.JdbcClient;

import javax.sql.DataSource;
import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.StringJoiner;
import java.util.stream.Stream;

/**
 * {@link ReferenceLoader} over plain SQL with Spring {@link JdbcClient}. No JPA. Rows are grouped by key; SQL arrays
 * become lists (see {@link RowValues}).
 */
@Slf4j
public class JdbcReferenceLoader implements ReferenceLoader {

    private final JdbcClient bulk;   // large fetch size for loadAll
    private final JdbcClient point;  // default fetch size for point loads
    private final Spec spec;
    private final List<String> keyCols;
    private final ColumnMapRowMapper mapper = new ColumnMapRowMapper();

    public JdbcReferenceLoader(DataSource dataSource, Spec spec) {
        this.spec = spec;
        this.keyCols = spec.keyColumns().stream().map(c -> c.toLowerCase(Locale.ROOT)).toList();

        JdbcTemplate bulkTemplate = new JdbcTemplate(dataSource);
        bulkTemplate.setFetchSize(spec.fetchSize());
        bulkTemplate.setQueryTimeout(spec.queryTimeoutSec());
        this.bulk = JdbcClient.create(bulkTemplate);

        JdbcTemplate pointTemplate = new JdbcTemplate(dataSource);
        pointTemplate.setQueryTimeout(spec.queryTimeoutSec());
        this.point = JdbcClient.create(pointTemplate);
        log.info("JDBC loader: key-columns={}, sql-by-keys={}, sql-by-key={}, key-batch-size={}, fetch-size={}, timeout={}s",
                keyCols, spec.sqlByKeys() != null, spec.sqlByKey() != null, spec.keyBatchSize(), spec.fetchSize(),
                spec.queryTimeoutSec());
    }

    @Override
    public Map<String, List<Map<String, Object>>> loadAll() {
        long t0 = System.nanoTime();
        Map<String, List<Map<String, Object>>> out = new LinkedHashMap<>();
        int[] count = {0};
        try (Stream<Map<String, Object>> rows = bulk.sql(spec.sqlAll()).query(mapper).stream()) {
            rows.forEach(raw -> {
                add(out, RowValues.normalize(raw));
                count[0]++;
            });
        }
        log.debug("sql-all: {} rows, {} keys in {} ms", count[0], out.size(), (System.nanoTime() - t0) / 1_000_000);
        return out;
    }

    @Override
    public List<Map<String, Object>> loadByKey(String key) {
        if (spec.sqlByKey() != null) {
            List<Map<String, Object>> out = new ArrayList<>();
            point.sql(spec.sqlByKey()).param("key", key).query(mapper).list()
                    .forEach(raw -> out.add(RowValues.normalize(raw)));
            return out;
        }
        return loadByKeys(List.of(key)).getOrDefault(key, List.of());
    }

    @Override
    public Map<String, List<Map<String, Object>>> loadByKeys(Collection<String> keys) {
        if (spec.sqlByKeys() == null) {
            if (spec.sqlByKey() == null) {
                throw new UnsupportedOperationException("No jdbc.sql-by-keys or sql-by-key configured; use CACHE_ONLY with preload");
            }
            return ReferenceLoader.super.loadByKeys(keys);
        }
        long t0 = System.nanoTime();
        Map<String, List<Map<String, Object>>> out = new LinkedHashMap<>();
        List<String> all = new ArrayList<>(keys);
        int queries = 0;
        for (int i = 0; i < all.size(); i += spec.keyBatchSize()) {
            List<String> chunk = all.subList(i, Math.min(all.size(), i + spec.keyBatchSize()));
            point.sql(spec.sqlByKeys()).param("keys", chunk).query(mapper).list()
                    .forEach(raw -> add(out, RowValues.normalize(raw)));
            queries++;
        }
        log.debug("sql-by-keys: {} keys in {} queries -> {} found in {} ms",
                all.size(), queries, out.size(), (System.nanoTime() - t0) / 1_000_000);
        return out;
    }

    private void add(Map<String, List<Map<String, Object>>> out, Map<String, Object> row) {
        out.computeIfAbsent(keyOf(row), k -> new ArrayList<>()).add(row);
    }

    private String keyOf(Map<String, Object> row) {
        if (keyCols.size() == 1) return String.valueOf(row.get(keyCols.get(0)));
        StringJoiner j = new StringJoiner(spec.keySeparator());
        keyCols.forEach(c -> j.add(String.valueOf(row.get(c))));
        return j.toString();
    }

    /**
     * Definition of a JDBC-backed loader. A key may have several rows.
     *
     * <pre>
     * jdbc:
     *   key-columns: [calendar_code]
     *   sql-all: select * from holiday order by calendar_code
     *   sql-by-keys: select * from holiday where calendar_code in (:keys)
     * </pre>
     *
     * @param keyColumns      one or more columns; composite keys are joined with {@code keySeparator}
     * @param sqlAll          full load, used by preload and findAll
     * @param sqlByKeys       point load with {@code :keys} (single key column only); without it, misses fall back to
     *                        {@code sqlByKey} per key, or fail if neither is set
     * @param sqlByKey        point load with {@code :key}; works for composite keys if you split the key yourself
     * @param keySeparator    separator for composite keys, default {@code |}
     * @param keyBatchSize    max keys per IN list, default 900 (stays under Oracle's 1000 limit)
     * @param fetchSize       JDBC fetch size for the full load, default 5000
     * @param queryTimeoutSec statement timeout, default 30
     */
    @Builder
    public record Spec(List<String> keyColumns,
                       String sqlAll,
                       String sqlByKeys,
                       String sqlByKey,
                       String keySeparator,
                       Integer keyBatchSize,
                       Integer fetchSize,
                       Integer queryTimeoutSec) {

        public Spec {
            if (keyColumns == null || keyColumns.isEmpty()) throw new IllegalArgumentException("jdbc.key-columns is required");
            if (sqlAll == null || sqlAll.isBlank()) throw new IllegalArgumentException("jdbc.sql-all is required");
            keyColumns = List.copyOf(keyColumns);
            keySeparator = keySeparator == null ? "|" : keySeparator;
            keyBatchSize = keyBatchSize == null ? 900 : keyBatchSize;
            fetchSize = fetchSize == null ? 5000 : fetchSize;
            queryTimeoutSec = queryTimeoutSec == null ? 30 : queryTimeoutSec;
            if (sqlByKeys != null && keyColumns.size() > 1) {
                throw new IllegalArgumentException("sql-by-keys supports a single key column; use sql-by-key or a custom ReferenceLoader");
            }
        }
    }
}
