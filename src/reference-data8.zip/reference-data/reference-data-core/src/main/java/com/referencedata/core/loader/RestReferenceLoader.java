package com.referencedata.core.loader;

import com.referencedata.core.ReferenceLoader;
import com.referencedata.core.RowValues;
import lombok.Builder;
import lombok.extern.slf4j.Slf4j;
import tools.jackson.core.JacksonException;
import tools.jackson.core.type.TypeReference;
import tools.jackson.databind.DeserializationFeature;
import tools.jackson.databind.ObjectMapper;
import tools.jackson.databind.json.JsonMapper;

import java.io.IOException;
import java.io.UncheckedIOException;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.StringJoiner;

/**
 * {@link ReferenceLoader} over a REST/JSON API using the JDK HttpClient and Jackson 3. Nested JSON objects and arrays
 * in rows are kept (as maps and lists). See {@link Spec}.
 */
@Slf4j
public class RestReferenceLoader implements ReferenceLoader {

    private static final TypeReference<List<Map<String, Object>>> ROWS = new TypeReference<>() {};

    private final Spec spec;
    private final List<String> keyCols;
    private final HttpClient http;
    private final ObjectMapper mapper = JsonMapper.builder()
            .enable(DeserializationFeature.USE_BIG_DECIMAL_FOR_FLOATS)
            .enable(DeserializationFeature.USE_LONG_FOR_INTS)
            .build();

    public RestReferenceLoader(Spec spec) {
        this.spec = spec;
        this.keyCols = spec.keyColumns().stream().map(c -> c.toLowerCase(Locale.ROOT)).toList();
        this.http = HttpClient.newBuilder().connectTimeout(spec.connectTimeout()).build();
        log.info("REST loader: key-columns={}, all-url={}, by-key-url={}, by-keys-url={}, headers={}",
                keyCols, spec.allUrl(), spec.byKeyUrl(), spec.byKeysUrl(), spec.headers().keySet());
    }

    @Override
    public Map<String, List<Map<String, Object>>> loadAll() {
        if (spec.allUrl() == null) throw new UnsupportedOperationException("rest.all-url is not configured");
        return group(send(get(spec.allUrl())));
    }

    @Override
    public List<Map<String, Object>> loadByKey(String key) {
        if (spec.byKeyUrl() == null) return loadByKeys(List.of(key)).getOrDefault(key, List.of());
        String url = spec.byKeyUrl().replace("{key}", URLEncoder.encode(key, StandardCharsets.UTF_8).replace("+", "%20"));
        List<Map<String, Object>> rows = send(get(url));
        List<Map<String, Object>> out = new ArrayList<>(rows.size());
        for (Map<String, Object> r : rows) out.add(RowValues.normalize(r));
        return out;
    }

    @Override
    public Map<String, List<Map<String, Object>>> loadByKeys(Collection<String> keys) {
        if (spec.byKeysUrl() == null) return ReferenceLoader.super.loadByKeys(keys);
        HttpRequest.Builder b = HttpRequest.newBuilder(URI.create(spec.byKeysUrl()))
                .timeout(spec.requestTimeout())
                .header("Content-Type", "application/json")
                .POST(HttpRequest.BodyPublishers.ofByteArray(mapper.writeValueAsBytes(List.copyOf(keys))));
        return group(send(headers(b)));
    }

    private HttpRequest get(String url) {
        return headers(HttpRequest.newBuilder(URI.create(url)).timeout(spec.requestTimeout()).GET());
    }

    private HttpRequest headers(HttpRequest.Builder b) {
        b.header("Accept", "application/json");
        spec.headers().forEach(b::header);
        return b.build();
    }

    private List<Map<String, Object>> send(HttpRequest req) {
        long t0 = System.nanoTime();
        try {
            HttpResponse<byte[]> resp = http.send(req, HttpResponse.BodyHandlers.ofByteArray());
            long ms = (System.nanoTime() - t0) / 1_000_000;
            if (resp.statusCode() == 404) {
                log.debug("{} {} -> 404 (not found) in {} ms", req.method(), req.uri(), ms);
                return List.of();
            }
            if (resp.statusCode() / 100 != 2) {
                String body = new String(resp.body(), StandardCharsets.UTF_8);
                log.warn("{} {} -> HTTP {} in {} ms", req.method(), req.uri(), resp.statusCode(), ms);
                throw new IllegalStateException("HTTP " + resp.statusCode() + " from " + req.uri() + ": "
                        + body.substring(0, Math.min(300, body.length())));
            }
            List<Map<String, Object>> rows = mapper.readValue(resp.body(), ROWS);
            log.debug("{} {} -> {} rows, {} bytes in {} ms", req.method(), req.uri(), rows.size(), resp.body().length, ms);
            return rows;
        } catch (JacksonException e) {
            throw new IllegalStateException("REST response from " + req.uri() + " is not a JSON array of rows: "
                    + e.getOriginalMessage(), e);
        } catch (IOException e) {
            log.warn("{} {} failed after {} ms: {}", req.method(), req.uri(), (System.nanoTime() - t0) / 1_000_000, e.toString());
            throw new UncheckedIOException("REST call to " + req.uri() + " failed: " + e.getMessage(), e);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new IllegalStateException("Interrupted calling " + req.uri(), e);
        }
    }

    private Map<String, List<Map<String, Object>>> group(List<Map<String, Object>> rows) {
        Map<String, List<Map<String, Object>>> out = new LinkedHashMap<>();
        for (Map<String, Object> raw : rows) {
            Map<String, Object> row = RowValues.normalize(raw);
            out.computeIfAbsent(keyOf(row), k -> new ArrayList<>()).add(row);
        }
        return out;
    }

    private String keyOf(Map<String, Object> row) {
        if (keyCols.size() == 1) return String.valueOf(row.get(keyCols.get(0)));
        StringJoiner j = new StringJoiner(spec.keySeparator());
        keyCols.forEach(c -> j.add(String.valueOf(row.get(c))));
        return j.toString();
    }

    /**
     * Definition of a REST-backed loader. Each endpoint returns a JSON array of row objects;
     * rows are grouped by the key columns.
     *
     * <pre>
     * rest:
     *   key-columns: [instrument_id]
     *   all-url: https://instruments.internal/api/instruments
     *   by-key-url: https://instruments.internal/api/instruments/{key}
     *   by-keys-url: https://instruments.internal/api/instruments/search   # POST ["k1","k2"], optional
     *   headers: { Authorization: "Bearer ${INSTRUMENT_TOKEN}" }
     * </pre>
     *
     * @param byKeyUrl  GET with {@code {key}} substituted (URL-encoded); 404 means not found
     * @param byKeysUrl optional POST of a JSON array of keys, returning rows for all of them
     */
    @Builder
    public record Spec(List<String> keyColumns,
                       String allUrl,
                       String byKeyUrl,
                       String byKeysUrl,
                       Map<String, String> headers,
                       String keySeparator,
                       Duration connectTimeout,
                       Duration requestTimeout) {

        public Spec {
            if (keyColumns == null || keyColumns.isEmpty()) throw new IllegalArgumentException("rest.key-columns is required");
            if (allUrl == null && byKeyUrl == null) throw new IllegalArgumentException("rest needs all-url and/or by-key-url");
            keyColumns = List.copyOf(keyColumns);
            headers = headers == null ? Map.of() : Map.copyOf(headers);
            keySeparator = keySeparator == null ? "|" : keySeparator;
            connectTimeout = connectTimeout == null ? Duration.ofSeconds(5) : connectTimeout;
            requestTimeout = requestTimeout == null ? Duration.ofSeconds(30) : requestTimeout;
        }
    }
}
