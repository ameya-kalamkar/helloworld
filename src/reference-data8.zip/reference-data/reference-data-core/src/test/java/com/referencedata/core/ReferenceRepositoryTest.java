package com.referencedata.core;

import com.referencedata.core.ReferenceDataConfig.Dataset;
import com.referencedata.core.ReferenceDataConfig.Mode;
import com.referencedata.core.ReferenceDataConfig.Settings;
import com.referencedata.core.loader.CsvReferenceLoader;
import org.junit.jupiter.api.Test;
import org.springframework.cache.CacheManager;
import org.springframework.cache.concurrent.ConcurrentMapCacheManager;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

class ReferenceRepositoryTest {

    /** Loader over a fixed map that counts calls. */
    static final class CountingLoader implements ReferenceLoader {
        final Map<String, List<Map<String, Object>>> data;
        final AtomicInteger all = new AtomicInteger(), one = new AtomicInteger(), many = new AtomicInteger();
        volatile Collection<String> lastKeys;
        volatile RuntimeException failWith;

        CountingLoader(Map<String, List<Map<String, Object>>> data) { this.data = data; }

        public Map<String, List<Map<String, Object>>> loadAll() { fail(); all.incrementAndGet(); return new LinkedHashMap<>(data); }
        public List<Map<String, Object>> loadByKey(String k) { fail(); one.incrementAndGet(); return data.getOrDefault(k, List.of()); }
        public Map<String, List<Map<String, Object>>> loadByKeys(Collection<String> keys) {
            fail(); many.incrementAndGet(); lastKeys = List.copyOf(keys);
            Map<String, List<Map<String, Object>>> out = new LinkedHashMap<>();
            for (String k : keys) if (data.containsKey(k)) out.put(k, data.get(k));
            return out;
        }
        private void fail() { if (failWith != null) throw failWith; }
    }

    static Map<String, List<Map<String, Object>>> data() {
        Map<String, List<Map<String, Object>>> d = new LinkedHashMap<>();
        d.put("USD", List.of(Map.of("ccy_code", "USD", "decimals", 2L)));
        d.put("JPY", List.of(Map.of("ccy_code", "JPY", "decimals", 0L)));
        d.put("USNY", List.of(Map.of("d", "2026-11-26"), Map.of("d", "2026-12-25")));
        d.put("A|1", List.of(Map.of("d", "composite")));
        return d;
    }

    public record CompositeKey(String a, int b) {}

    /** Custom DAO, as a consumer would write one (here with a hand-written row mapper). */
    static final class CcyRepository extends ReferenceRepository<String, Object> {
        CcyRepository() { super("ccy", String.class, row -> String.valueOf(row.getOrDefault("ccy_code", row.get("d")))); }
    }

    static ReferenceRepository<Map<String, Object>, String> rows(CachePolicy policy, boolean preload, boolean cacheNotFound, ReferenceLoader l) {
        ReferenceRepository<Map<String, Object>, String> r = ReferenceRepository.rows("ds");
        CacheManager cm = new ConcurrentMapCacheManager();
        r.bind(new ReferenceRepository.Binding(policy, policy == CachePolicy.SOURCE_ONLY
                ? new org.springframework.cache.support.NoOpCache("ds") : cm.getCache("ds"), l, preload, cacheNotFound, "|", "test"));
        return r;
    }

    @Test
    void cacheFirstReadsThroughOnceAndCachesNotFound() {
        CountingLoader l = new CountingLoader(data());
        var r = rows(CachePolicy.CACHE_FIRST, false, true, l);
        assertEquals(1, r.findByKey("USD").size());
        r.findByKey("USD");
        assertEquals(1, l.one.get());
        assertEquals(List.of(), r.findByKey("XXX"));
        r.findByKey("XXX");
        assertEquals(2, l.one.get());
    }

    @Test
    void notFoundIsRetriedWhenCacheNotFoundIsOff() {
        CountingLoader l = new CountingLoader(data());
        var r = rows(CachePolicy.CACHE_FIRST, false, false, l);
        r.findByKey("XXX");
        r.findByKey("XXX");
        assertEquals(2, l.many.get());
    }

    @Test
    void batchLoadsAllMissesInOneCallInRequestOrder() {
        CountingLoader l = new CountingLoader(data());
        var r = rows(CachePolicy.CACHE_FIRST, false, true, l);
        r.findByKey("JPY");
        Map<String, List<Map<String, Object>>> got = r.findAllByKeys(List.of("USNY", "JPY", "XXX", "USD", "USNY"));
        assertEquals(List.of("USNY", "JPY", "USD"), List.copyOf(got.keySet()));
        assertEquals(1, l.many.get());
        assertEquals(List.of("USNY", "XXX", "USD"), l.lastKeys);
        r.findAllByKeys(List.of("USNY", "XXX", "USD"));
        assertEquals(1, l.many.get());
    }

    @Test
    void sourceOnlyAlwaysCallsTheLoader() {
        CountingLoader l = new CountingLoader(data());
        var r = rows(CachePolicy.SOURCE_ONLY, false, true, l);
        r.findByKey("USD");
        r.findByKey("USD");
        assertEquals(2, l.one.get());
        assertEquals(5, r.findAll().size());
        r.findAll();
        assertEquals(2, l.all.get());
        assertEquals(0, r.preload());
    }

    @Test
    void cacheOnlyServesPreloadAndNeverReadsThrough() {
        CountingLoader l = new CountingLoader(data());
        var r = rows(CachePolicy.CACHE_ONLY, true, true, l);
        assertEquals(List.of(), r.findAll());              // before preload: empty
        assertEquals(4, r.preload());
        assertEquals(1, r.findByKey("USD").size());
        assertEquals(List.of(), r.findByKey("XXX"));
        assertEquals(List.of("USD"), List.copyOf(r.findAllByKeys(List.of("XXX", "USD")).keySet()));
        assertEquals(List.of("USD", "JPY", "USNY", "A|1"), List.copyOf(r.findAllGroupedByKey().keySet()));
        assertEquals(0, l.one.get() + l.many.get());
    }

    @Test
    void findAllOnCacheFirstLoadsOnceThenServesFromCache() {
        CountingLoader l = new CountingLoader(data());
        var r = rows(CachePolicy.CACHE_FIRST, false, true, l);
        assertEquals(5, r.findAll().size());
        assertEquals(5, r.findAll().size());
        assertEquals(1, l.all.get());
        r.findByKey("USNY");
        assertEquals(0, l.one.get());
    }

    @Test
    void loaderFailureIsWrappedAndNotCached() {
        CountingLoader l = new CountingLoader(data());
        var r = rows(CachePolicy.CACHE_FIRST, false, true, l);
        l.failWith = new IllegalStateException("db down");
        assertThrows(ReferenceRepository.LoadException.class, () -> r.findByKey("USD"));
        assertThrows(ReferenceRepository.LoadException.class, () -> r.findAllByKeys(List.of("USD")));
        l.failWith = null;
        assertEquals(1, r.findByKey("USD").size());
    }

    @Test
    void customDaoWithMapperAndCompositeKey() {
        CcyRepository r = new CcyRepository();
        assertThrows(IllegalStateException.class, () -> r.findByKey("USD"));     // not enabled yet
        r.bind(new ReferenceRepository.Binding(CachePolicy.CACHE_FIRST, new ConcurrentMapCacheManager().getCache("ccy"),
                new CountingLoader(data()), false, true, "|", "test"));
        assertEquals(List.of("USD"), r.findByKey("USD"));
        assertEquals(List.of("composite"), r.findByKey(new CompositeKey("A", 1)));
        assertThrows(IllegalStateException.class, () -> r.bind(r.binding()));   // bind once
    }

    @Test
    void configInheritsDatasetThenTopThenDefault() {
        Map<String, Dataset> ds = new LinkedHashMap<>();
        ds.put("a", new Dataset("aRepository", null, null, null, null, null, null, null, null));
        ds.put("b", new Dataset("bRepository", Mode.EMBEDDED, "bLoader", CachePolicy.CACHE_FIRST, false, false, "dsCm", "bCache", "#"));
        Settings s = new Settings(Mode.DELEGATE, CachePolicy.SOURCE_ONLY, true, null, "topCm", null, null, null, null, ds);
        var a = s.resolve("a");
        assertEquals(Mode.DELEGATE, a.mode());
        assertEquals(CachePolicy.SOURCE_ONLY, a.policy());
        assertTrue(a.preload());
        assertEquals("topCm", a.cacheManager());
        assertEquals("a", a.cacheName());
        var b = s.resolve("b");
        assertEquals(new ReferenceDataConfig.Resolved("b", Mode.EMBEDDED, CachePolicy.CACHE_FIRST, false, false, "dsCm", "bCache", "#",
                "bRepository", "bLoader"), b);
        Settings none = new Settings(null, null, null, null, null, null, null, null, null, Map.of("c", new Dataset("c", null, "l", null, null, null, null, null, null)));
        assertEquals(ReferenceDataConfig.DEFAULT_CACHE_MANAGER, none.resolve("c").cacheManager());
        assertEquals(Mode.EMBEDDED, none.resolve("c").mode());
    }

    @Test
    void validationReportsEveryProblemPerSide() {
        Map<String, Dataset> ds = new LinkedHashMap<>();
        ds.put("x", new Dataset(null, null, null, CachePolicy.CACHE_ONLY, false, null, null, null, null));
        ds.put("y", new Dataset("rep", Mode.DELEGATE, null, CachePolicy.SOURCE_ONLY, true, null, null, null, null));
        ds.put("z", new Dataset("rep", null, "bad name!", null, null, null, " ", null, ""));
        ds.put("bad name", new Dataset("other", null, "l", null, null, null, null, null, null));
        List<String> client = new ArrayList<>();
        new Settings(Mode.EMBEDDED, null, null, null, null, null, 0, null, new ReferenceDataConfig.Bridge(null, null), ds)
                .validate(ReferenceDataConfig.Side.CLIENT, client);
        String c = String.join("\n", client);
        assertTrue(c.contains("reference-data-client.bridge: server-only"), c);
        assertTrue(c.contains("reference-data-client.preload-parallelism: must be >= 1"), c);
        assertTrue(c.contains("reference-data-client.datasets.x.repository: the DAO bean name is required"), c);
        assertTrue(c.contains("reference-data-client.datasets.x.loader: EMBEDDED mode needs"), c);
        assertTrue(c.contains("reference-data-client.datasets.x: CACHE_ONLY needs preload"), c);
        assertTrue(c.contains("reference-data-client.datasets.y: preload has no effect with SOURCE_ONLY"), c);
        assertTrue(c.contains("reference-data-client.delegate: required because at least one dataset is DELEGATE"), c);
        assertTrue(c.contains("reference-data-client.datasets.z.repository: 'rep' is already used by dataset y"), c);
        assertTrue(c.contains("reference-data-client.datasets.z.loader: 'bad name!' is not a valid bean name"), c);
        assertTrue(c.contains("reference-data-client.datasets.z.cache-manager: must not be blank"), c);
        assertTrue(c.contains("reference-data-client.datasets.z.key-separator: must not be empty"), c);
        assertTrue(c.contains("reference-data-client.datasets.bad name: dataset name must match"), c);

        List<String> server = new ArrayList<>();
        new Settings(Mode.DELEGATE, null, null, null, null, null, null,
                new ReferenceDataConfig.Delegate(null, "t", null, null, null, null, null, null, null),
                new ReferenceDataConfig.Bridge(
                        new ReferenceDataConfig.Endpoint(70_000, "/x", 0, 0, null, 5, null),
                        new ReferenceDataConfig.Endpoint(null, "no-slash", null, null, 0, 0, "never")),
                Map.of("s", new Dataset("rep", Mode.EMBEDDED, null, null, null, null, null, null, null)))
                .validate(ReferenceDataConfig.Side.SERVER, server);
        String sv = String.join("\n", server);
        assertTrue(sv.contains("reference-data-server.mode: client-only"), sv);
        assertTrue(sv.contains("reference-data-server.delegate: client-only"), sv);
        assertTrue(sv.contains("reference-data-server.bridge.grpc.port: 70000 is outside 1..65535"), sv);
        assertTrue(sv.contains("reference-data-server.bridge.grpc.max-message-size-mb: 0 is outside 1..2047"), sv);
        assertTrue(sv.contains("reference-data-server.bridge.grpc.find-all-chunk-keys: 0 is outside 1..1000000"), sv);
        assertTrue(sv.contains("reference-data-server.bridge.grpc.path: websocket only"), sv);
        assertTrue(sv.contains("reference-data-server.bridge.grpc.send-buffer-mb: websocket only"), sv);
        assertTrue(sv.contains("reference-data-server.bridge.websocket.path: 'no-slash' must start with /"), sv);
        assertTrue(sv.contains("reference-data-server.bridge.websocket.worker-threads: 0 is outside 1..1024"), sv);
        assertTrue(sv.contains("reference-data-server.bridge.websocket.send-buffer-mb: 0 is outside 1..2047"), sv);
        assertTrue(sv.contains("reference-data-server.bridge.websocket.send-timeout: 'never' is not a duration"), sv);
        assertTrue(sv.contains("reference-data-server.datasets.s.mode: client-only"), sv);
        assertTrue(sv.contains("reference-data-server.datasets.s.repository: client-only"), sv);
        assertTrue(sv.contains("reference-data-server.datasets.s.loader: a ReferenceLoader bean name is required"), sv);
        assertEquals(14, server.size(), sv);

        List<String> clash = new ArrayList<>();
        ReferenceDataConfig.Endpoint p9000 = new ReferenceDataConfig.Endpoint(9000, null, null, null, null, null, null);
        new Settings(null, null, null, null, null, null, null, null,
                new ReferenceDataConfig.Bridge(p9000, new ReferenceDataConfig.Endpoint(9000, "/rd", null, null, null, null, null)),
                Map.of("s", new Dataset(null, null, "l", null, null, null, null, null, null)))
                .validate(ReferenceDataConfig.Side.SERVER, clash);
        assertEquals(List.of("reference-data-server.bridge: grpc and websocket cannot share port 9000"), clash);
        assertEquals(List.of("grpc", "websocket"), List.copyOf(new ReferenceDataConfig.Bridge(p9000, p9000).endpoints().keySet()));
        assertEquals(9090, ReferenceDataConfig.Bridge.orDefault(null).endpoints().get("grpc").portOrDefault("grpc"));
    }

    @Test
    void delegateSettingsAreRangeChecked() {
        List<String> errors = new ArrayList<>();
        new Settings(Mode.DELEGATE, null, null, null, null, null, null,
                new ReferenceDataConfig.Delegate("grpc", " ", "soon", "0s", "-PT1S", true, 4096, 0, 0),
                null, Map.of("a", new Dataset("r", null, null, null, null, null, null, null, null)))
                .validate(ReferenceDataConfig.Side.CLIENT, errors);
        String e = String.join("\n", errors);
        assertTrue(e.contains("reference-data-client.delegate.target: required"), e);
        assertTrue(e.contains("reference-data-client.delegate.deadline: 'soon' is not a duration"), e);
        assertTrue(e.contains("reference-data-client.delegate.find-all-deadline: must be positive"), e);
        assertTrue(e.contains("reference-data-client.delegate.ready-timeout: must be positive"), e);
        assertTrue(e.contains("reference-data-client.delegate.max-message-size-mb: 4096 is outside 1..2047"), e);
        assertTrue(e.contains("reference-data-client.delegate.max-keys-per-call: 0 is outside 1..1000000"), e);
        assertTrue(e.contains("reference-data-client.delegate.find-all-window: 0 is outside 1..1024"), e);
        assertEquals(7, errors.size(), e);

        List<String> ok = new ArrayList<>();
        new Settings(Mode.DELEGATE, null, null, null, null, null, null,
                new ReferenceDataConfig.Delegate(null, "dns:///s:9090", "500ms", "10m", "PT2M", null, 64, 5000, null),
                null, Map.of("a", new Dataset("r", null, null, null, null, null, null, null, null)))
                .validate(ReferenceDataConfig.Side.CLIENT, ok);
        assertEquals(List.of(), ok);
        assertEquals("reference-data-client", ReferenceDataConfig.Side.CLIENT.root());

        // transport must match the target
        List<String> ws = new ArrayList<>();
        Map<String, Dataset> one = Map.of("a", new Dataset("r", null, null, null, null, null, null, null, null));
        new Settings(Mode.DELEGATE, null, null, null, null, null, null,
                new ReferenceDataConfig.Delegate("websocket", "ws://a:9091/reference-data, dns:///b:9090", null, null, null, null, null, null, 8),
                null, one).validate(ReferenceDataConfig.Side.CLIENT, ws);
        assertEquals(List.of("reference-data-client.delegate.target: 'dns:///b:9090' must be ws://host:port/path or wss://... for the websocket transport"), ws);
        List<String> grpc = new ArrayList<>();
        new Settings(Mode.DELEGATE, null, null, null, null, null, null,
                new ReferenceDataConfig.Delegate("GRPC", "ws://a:9091/x", null, null, null, null, null, null, null),
                null, one).validate(ReferenceDataConfig.Side.CLIENT, grpc);
        assertTrue(grpc.get(0).contains("is a WebSocket URI"), grpc.toString());
        List<String> okWs = new ArrayList<>();
        ReferenceDataConfig.Delegate twoServers = new ReferenceDataConfig.Delegate("websocket",
                "ws://a:9091/reference-data,wss://b:443/reference-data", null, null, null, null, null, null, null);
        new Settings(Mode.DELEGATE, null, null, null, null, null, null, twoServers, null, one)
                .validate(ReferenceDataConfig.Side.CLIENT, okWs);
        assertEquals(List.of(), okWs);
        assertEquals(List.of("ws://a:9091/reference-data", "wss://b:443/reference-data"), twoServers.targets());
        assertEquals(4, twoServers.findAllWindowOrDefault());
        assertEquals("reference-data-server", ReferenceDataConfig.Side.SERVER.root());
    }

    public record Point(int x, java.math.BigDecimal y) {}

    @Test
    void rowValuesNormaliseNestedStructures() {
        Map<String, Object> raw = new LinkedHashMap<>();
        raw.put("ID", 7);
        raw.put("Price", 1.50d);
        raw.put("tags", new String[] {"a", "b"});
        raw.put("blob", new byte[] {1, 2});
        raw.put("when", java.time.LocalDate.of(2026, 12, 25));
        raw.put("nested", Map.of("count", (short) 3, "list", List.of(1, List.of(2L))));
        raw.put("point", new Point(1, new java.math.BigDecimal("2.500")));
        raw.put("none", null);
        Map<String, Object> row = RowValues.normalize(raw);
        assertEquals(List.of("id", "price", "tags", "blob", "when", "nested", "point", "none"), List.copyOf(row.keySet()));
        assertEquals(7L, row.get("id"));
        assertEquals(new java.math.BigDecimal("1.5"), row.get("price"));
        assertEquals(List.of("a", "b"), row.get("tags"));
        assertTrue(java.util.Arrays.equals(new byte[] {1, 2}, (byte[]) row.get("blob")));
        assertEquals("2026-12-25", row.get("when"));
        assertEquals(Map.of("count", 3L, "list", List.of(1L, List.of(2L))), row.get("nested"));
        assertEquals(Map.of("x", 1L, "y", new java.math.BigDecimal("2.5")), row.get("point"));
        assertTrue(row.containsKey("none") && row.get("none") == null);

        List<Object> cycle = new ArrayList<>();
        cycle.add(cycle);
        assertThrows(IllegalArgumentException.class, () -> RowValues.normalizeValue(cycle));
    }

    @Test
    void durationsAndSharedCaches() {
        assertEquals(java.time.Duration.ofMillis(500), ReferenceDataConfig.duration("500ms", null));
        assertEquals(java.time.Duration.ofMinutes(10), ReferenceDataConfig.duration("10m", null));
        assertEquals(java.time.Duration.ofSeconds(3), ReferenceDataConfig.duration("PT3S", null));
        CacheManager cm = new ConcurrentMapCacheManager();
        List<String> errors = new ArrayList<>();
        ReferenceDataConfig.checkNoSharedCaches(Map.of("p", cm.getCache("same")), errors);
        Map<String, org.springframework.cache.Cache> two = new LinkedHashMap<>();
        two.put("p", cm.getCache("same"));
        two.put("q", cm.getCache("same"));
        ReferenceDataConfig.checkNoSharedCaches(two, errors);
        assertEquals(List.of("datasets.q.cache-name: shares Spring cache 'same' with dataset p"), errors);
    }

    @Test
    void csvLoaderGroupsRowsByKey() throws Exception {
        Path f = Files.createTempFile("holidays", ".csv");
        Files.writeString(f, "Calendar_Code|holiday_date|description\nUSNY|2026-11-26|Thanksgiving\nUSNY|2026-12-25|Christmas\nCATO|2026-10-12|\n");
        CsvReferenceLoader l = new CsvReferenceLoader(f.toUri().toString(), "|", List.of("calendar_code"));
        Map<String, List<Map<String, Object>>> all = l.loadAll();
        assertEquals(List.of("USNY", "CATO"), List.copyOf(all.keySet()));
        assertEquals(2, all.get("USNY").size());
        assertTrue(all.get("CATO").get(0).containsKey("description") && all.get("CATO").get(0).get("description") == null);
        assertEquals(1, l.loadByKeys(List.of("CATO", "XXXX")).size());
    }
}
