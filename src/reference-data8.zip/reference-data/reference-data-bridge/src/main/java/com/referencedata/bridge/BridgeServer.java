package com.referencedata.bridge;

import com.referencedata.bridge.grpc.GrpcBridgeServer;
import com.referencedata.bridge.websocket.WebSocketBridgeServer;
import com.referencedata.core.ReferenceDataConfig;
import com.referencedata.core.ReferenceDataConfig.Endpoint;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;

/**
 * Server side of the bridge. reference-data-server implements {@link Handler} (its datasets) and the bridge
 * exposes it over every transport configured under the server's {@code bridge}: {@code grpc} (gRPC/protobuf) and/or
 * {@code websocket} (Kryo frames over Spring WebSocket), at the same time, so clients may use either.
 * Until {@link #markServing()} the server reports not-ready and rejects lookups, so clients never preload from a
 * half-warm cache.
 */
public interface BridgeServer {

    void start();

    /** Call after the server's own preload: health turns SERVING and lookups are accepted. */
    void markServing();

    void stop();

    /** What the server serves. Unknown dataset: {@link IllegalArgumentException}; source failure: a LoadException. */
    interface Handler {

        Set<String> datasets();

        /** Rows of the keys that exist; absent keys are omitted. */
        Map<String, List<Map<String, Object>>> findByKeys(String dataset, Collection<String> keys);

        /** The whole dataset, key to rows. */
        Map<String, List<Map<String, Object>>> findAll(String dataset);
    }

    /** This server, or a part of it, as {@code type} (e.g. the WebSocket handler Spring must register). */
    default <T> Optional<T> unwrap(Class<T> type) {
        return type.isInstance(this) ? Optional.of(type.cast(this)) : Optional.empty();
    }

    /** One server per configured transport, started, marked SERVING and stopped together. */
    static BridgeServer create(ReferenceDataConfig.Bridge config, Handler handler) {
        List<BridgeServer> parts = new ArrayList<>();
        ReferenceDataConfig.Bridge.orDefault(config).endpoints().forEach((transport, endpoint) ->
                parts.add(create(transport, endpoint, handler)));
        if (parts.size() == 1) return parts.get(0);
        return new BridgeServer() {
            @Override public void start() { parts.forEach(BridgeServer::start); }
            @Override public void markServing() { parts.forEach(BridgeServer::markServing); }
            @Override public void stop() { parts.forEach(BridgeServer::stop); }

            @Override
            public <T> Optional<T> unwrap(Class<T> type) {
                return parts.stream().map(p -> p.unwrap(type)).flatMap(Optional::stream).findFirst();
            }
        };
    }

    private static BridgeServer create(String transport, Endpoint endpoint, Handler handler) {
        return switch (transport) {
            case ReferenceDataConfig.GRPC -> new GrpcBridgeServer(endpoint, handler);
            case ReferenceDataConfig.WEBSOCKET -> new WebSocketBridgeServer(endpoint, handler);
            default -> throw new IllegalArgumentException("Unknown bridge transport '" + transport + "' (supported: "
                    + ReferenceDataConfig.TRANSPORTS + ")");
        };
    }
}
