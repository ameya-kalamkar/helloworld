package com.referencedata.bridge.grpc;

import com.referencedata.bridge.BridgeServer;
import com.referencedata.bridge.grpc.v1.FindAllRequest;
import com.referencedata.bridge.grpc.v1.FindByKeysRequest;
import com.referencedata.bridge.grpc.v1.FindByKeysResponse;
import com.referencedata.bridge.grpc.v1.KeyRows;
import com.referencedata.bridge.grpc.v1.KeyRowsChunk;
import com.referencedata.bridge.grpc.v1.ListDatasetsRequest;
import com.referencedata.bridge.grpc.v1.ListDatasetsResponse;
import com.referencedata.bridge.grpc.v1.ReferenceDataBridgeGrpc;
import com.referencedata.core.ReferenceDataConfig;
import com.referencedata.core.ReferenceRepository;
import io.grpc.Server;
import io.grpc.ServerBuilder;
import io.grpc.Status;
import io.grpc.health.v1.HealthCheckResponse.ServingStatus;
import io.grpc.protobuf.services.HealthStatusManager;
import io.grpc.stub.ServerCallStreamObserver;
import io.grpc.stub.StreamObserver;
import lombok.extern.slf4j.Slf4j;

import java.io.IOException;
import java.io.UncheckedIOException;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * gRPC implementation of {@link BridgeServer}.
 * <ul>
 *   <li>Health: NOT_SERVING from start until {@link #markServing()}; lookups before that get UNAVAILABLE.</li>
 *   <li>{@code FindAll}: chunks of up to {@code find-all-chunk-keys} keys (and about 1 MB) per message, sent only
 *       while the client can receive ({@code isReady()} + on-ready handler), so a slow client never makes the
 *       server buffer the whole dataset.</li>
 *   <li>Errors: unknown dataset NOT_FOUND, source failure UNAVAILABLE, anything else INTERNAL.</li>
 * </ul>
 */
@Slf4j
public final class GrpcBridgeServer implements BridgeServer {

    private static final int MAX_CHUNK_BYTES = 1024 * 1024;

    private final ReferenceDataConfig.Endpoint cfg;
    private final int port;
    private java.util.concurrent.ExecutorService workers;
    private final Handler handler;
    private final HealthStatusManager health = new HealthStatusManager();
    private final AtomicBoolean serving = new AtomicBoolean();
    private Server server;

    public GrpcBridgeServer(ReferenceDataConfig.Endpoint cfg, Handler handler) {
        this.cfg = cfg;
        this.port = cfg.portOrDefault(ReferenceDataConfig.GRPC);
        this.handler = handler;
        health.setStatus(HealthStatusManager.SERVICE_NAME_ALL_SERVICES, ServingStatus.NOT_SERVING);
    }

    @Override
    public synchronized void start() {
        try {
            java.util.concurrent.atomic.AtomicInteger n = new java.util.concurrent.atomic.AtomicInteger();
            workers = java.util.concurrent.Executors.newFixedThreadPool(cfg.workerThreadsOrDefault(), r -> {
                Thread t = new Thread(r, "refdata-grpc-" + n.incrementAndGet());
                t.setDaemon(true);
                return t;
            });
            server = ServerBuilder.forPort(port)
                    .executor(workers)
                    .addService(new Service())
                    .addService(health.getHealthService())
                    .maxInboundMessageSize(cfg.maxMessageSizeMbOrDefault() * 1024 * 1024)
                    .build()
                    .start();
            log.info("Bridge server (gRPC) on port {} (max-message-size={}MB, find-all-chunk-keys={}, worker-threads={}): "
                    + "NOT_SERVING until preload completes", port, cfg.maxMessageSizeMbOrDefault(), cfg.findAllChunkKeysOrDefault(),
                    cfg.workerThreadsOrDefault());
        } catch (IOException e) {
            throw new UncheckedIOException("Cannot start gRPC bridge on port " + port, e);
        }
    }

    @Override
    public void markServing() {
        serving.set(true);
        health.setStatus(HealthStatusManager.SERVICE_NAME_ALL_SERVICES, ServingStatus.SERVING);
        log.info("Bridge server (gRPC) on port {} is SERVING", port);
    }

    @Override
    public synchronized void stop() {
        if (server == null) return;
        log.info("Stopping bridge server (gRPC) on port {}", port);
        health.enterTerminalState();
        server.shutdown();
        try {
            if (!server.awaitTermination(10, TimeUnit.SECONDS)) server.shutdownNow();
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            server.shutdownNow();
        }
        server = null;
        if (workers != null) workers.shutdownNow();
        workers = null;
    }

    private final class Service extends ReferenceDataBridgeGrpc.ReferenceDataBridgeImplBase {

        @Override
        public void findByKeys(FindByKeysRequest req, StreamObserver<FindByKeysResponse> out) {
            if (!checkServing(out)) return;
            long t0 = System.nanoTime();
            try {
                FindByKeysResponse.Builder b = FindByKeysResponse.newBuilder();
                handler.findByKeys(req.getDataset(), req.getKeysList()).forEach((k, rows) -> b.addEntries(RowCodec.toProto(k, rows)));
                FindByKeysResponse resp = b.build();
                out.onNext(resp);
                out.onCompleted();
                log.debug("FindByKeys {}: {} keys -> {} found, {} bytes in {} ms", req.getDataset(), req.getKeysCount(),
                        resp.getEntriesCount(), resp.getSerializedSize(), (System.nanoTime() - t0) / 1_000_000);
            } catch (RuntimeException e) {
                out.onError(toStatus(e, req.getDataset()));
            }
        }

        @Override
        public void findAll(FindAllRequest req, StreamObserver<KeyRowsChunk> out) {
            if (!checkServing(out)) return;
            Map<String, List<Map<String, Object>>> all;
            try {
                all = handler.findAll(req.getDataset());
            } catch (RuntimeException e) {
                out.onError(toStatus(e, req.getDataset()));
                return;
            }
            log.info("FindAll {}: streaming {} keys", req.getDataset(), all.size());
            new ChunkSender(req.getDataset(), all.entrySet().iterator(), (ServerCallStreamObserver<KeyRowsChunk>) out,
                    cfg.findAllChunkKeysOrDefault()).start();
        }

        @Override
        public void listDatasets(ListDatasetsRequest req, StreamObserver<ListDatasetsResponse> out) {
            out.onNext(ListDatasetsResponse.newBuilder().addAllDatasets(handler.datasets()).build());
            out.onCompleted();
            log.debug("ListDatasets -> {}", handler.datasets());
        }

        private boolean checkServing(StreamObserver<?> out) {
            if (serving.get()) return true;
            log.debug("Rejected request: still preloading");
            out.onError(Status.UNAVAILABLE.withDescription("reference-data-server is still preloading").asRuntimeException());
            return false;
        }
    }

    /** Sends chunks only while the client can take them; resumes from the on-ready callback (manual flow control). */
    private static final class ChunkSender implements Runnable {
        private final String dataset;
        private final long startNanos = System.nanoTime();
        private int chunksSent;
        private long bytesSent;
        private int pauses;
        private final Iterator<Map.Entry<String, List<Map<String, Object>>>> entries;
        private final ServerCallStreamObserver<KeyRowsChunk> call;
        private final int chunkKeys;
        private boolean finished;

        ChunkSender(String dataset, Iterator<Map.Entry<String, List<Map<String, Object>>>> entries,
                    ServerCallStreamObserver<KeyRowsChunk> call, int chunkKeys) {
            this.dataset = dataset;
            this.entries = entries;
            this.call = call;
            this.chunkKeys = Math.max(1, chunkKeys);
        }

        void start() {
            call.setOnCancelHandler(() -> {
                synchronized (this) {
                    if (!finished) log.warn("FindAll {} cancelled by client after {} chunks", dataset, chunksSent);
                    finished = true;
                }
            });
            call.setOnReadyHandler(this); // must be set before the service method returns
            run();
        }

        @Override
        public synchronized void run() {
            if (finished) return;
            try {
                while (call.isReady()) {
                    if (!entries.hasNext()) {
                        finished = true;
                        call.onCompleted();
                        log.info("FindAll {}: sent {} chunks ({} KB) in {} ms, paused {} times for a slow client",
                                dataset, chunksSent, bytesSent / 1024, (System.nanoTime() - startNanos) / 1_000_000, pauses);
                        return;
                    }
                    KeyRowsChunk.Builder chunk = KeyRowsChunk.newBuilder();
                    int bytes = 0;
                    while (entries.hasNext() && chunk.getEntriesCount() < chunkKeys && bytes < MAX_CHUNK_BYTES) {
                        Map.Entry<String, List<Map<String, Object>>> e = entries.next();
                        KeyRows kr = RowCodec.toProto(e.getKey(), e.getValue());
                        bytes += kr.getSerializedSize();
                        chunk.addEntries(kr);
                    }
                    call.onNext(chunk.build());
                    chunksSent++;
                    bytesSent += bytes;
                }
                // not ready: the on-ready handler calls run() again when the client has room
                pauses++;
                log.trace("FindAll {}: client not ready after {} chunks, pausing", dataset, chunksSent);
            } catch (RuntimeException e) {
                finished = true;
                log.error("FindAll {} failed after {} chunks", dataset, chunksSent, e);
                call.onError(Status.INTERNAL.withDescription("FindAll failed: " + e).withCause(e).asRuntimeException());
            }
        }
    }

    private static RuntimeException toStatus(RuntimeException e, String dataset) {
        if (e instanceof IllegalArgumentException) {
            log.warn("Request for unknown dataset '{}': {}", dataset, e.getMessage());
            return Status.NOT_FOUND.withDescription(e.getMessage()).asRuntimeException();
        }
        if (e instanceof ReferenceRepository.LoadException) {
            log.warn("Source load failed for {}: {}", dataset, e.getMessage());
            return Status.UNAVAILABLE.withDescription(e.getMessage()).withCause(e).asRuntimeException();
        }
        log.error("Request for {} failed", dataset, e);
        return Status.INTERNAL.withDescription(e.toString()).withCause(e).asRuntimeException();
    }
}
