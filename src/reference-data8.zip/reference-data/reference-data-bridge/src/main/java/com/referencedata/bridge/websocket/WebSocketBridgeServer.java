package com.referencedata.bridge.websocket;

import com.referencedata.bridge.BridgeServer;
import com.referencedata.bridge.websocket.KryoCodec.Cancel;
import com.referencedata.bridge.websocket.KryoCodec.Code;
import com.referencedata.bridge.websocket.KryoCodec.Credit;
import com.referencedata.bridge.websocket.KryoCodec.Datasets;
import com.referencedata.bridge.websocket.KryoCodec.Failure;
import com.referencedata.bridge.websocket.KryoCodec.FindAll;
import com.referencedata.bridge.websocket.KryoCodec.FindByKeys;
import com.referencedata.bridge.websocket.KryoCodec.Frame;
import com.referencedata.bridge.websocket.KryoCodec.Health;
import com.referencedata.bridge.websocket.KryoCodec.ListDatasets;
import com.referencedata.bridge.websocket.KryoCodec.Rows;
import com.referencedata.bridge.websocket.KryoCodec.Status;
import com.referencedata.core.ReferenceDataConfig;
import com.referencedata.core.ReferenceRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.socket.BinaryMessage;
import org.springframework.web.socket.CloseStatus;
import org.springframework.web.socket.WebSocketSession;
import org.springframework.web.socket.handler.BinaryWebSocketHandler;
import org.springframework.web.socket.handler.ConcurrentWebSocketSessionDecorator;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * WebSocket + Kryo implementation of {@link BridgeServer}, as a Spring {@link BinaryWebSocketHandler}: the server
 * application registers it at {@link #path()} (Spring WebSocket on the embedded servlet container), and this class
 * handles the protocol.
 * <ul>
 *   <li>Health: {@code Status(serving=false)} until {@link #markServing()}; lookups before that get UNAVAILABLE.</li>
 *   <li>Requests run on {@code worker-threads}, never on the container's I/O threads (a lookup may wait on the source).</li>
 *   <li>Each session is wrapped in a {@link ConcurrentWebSocketSessionDecorator}: sends are thread-safe, and a client
 *       that stops reading is disconnected after {@code send-timeout} or {@code send-buffer-mb}.</li>
 *   <li>{@code FindAll}: chunks of up to {@code find-all-chunk-keys} keys (and about 1 MB), sent only while the client
 *       has credit (initial {@code window}, plus one per chunk it consumed).</li>
 *   <li>Errors: unknown dataset NOT_FOUND, source failure UNAVAILABLE, bad frame BAD_REQUEST, anything else INTERNAL.</li>
 * </ul>
 */
@Slf4j
public final class WebSocketBridgeServer extends BinaryWebSocketHandler implements BridgeServer {

    private final ReferenceDataConfig.Endpoint cfg;
    private final Handler handler;
    private final int maxBytes;
    private final AtomicBoolean serving = new AtomicBoolean();
    private final Map<String, Peer> peers = new ConcurrentHashMap<>();
    private volatile ExecutorService workers;

    public WebSocketBridgeServer(ReferenceDataConfig.Endpoint cfg, Handler handler) {
        this.cfg = cfg;
        this.handler = handler;
        this.maxBytes = cfg.maxMessageSizeMbOrDefault() * 1024 * 1024;
    }

    /** Handshake path to register this handler at, e.g. {@code /reference-data}. */
    public String path() {
        return cfg.pathOrDefault();
    }

    public int port() {
        return cfg.portOrDefault(ReferenceDataConfig.WEBSOCKET);
    }

    /** Largest inbound message; the servlet WebSocket container must allow it too. */
    public int maxMessageBytes() {
        return maxBytes;
    }

    // ------------------------------------------------------------------ BridgeServer

    @Override
    public synchronized void start() {
        if (workers != null) return;
        AtomicInteger n = new AtomicInteger();
        workers = Executors.newFixedThreadPool(cfg.workerThreadsOrDefault(), r -> {
            Thread t = new Thread(r, "refdata-ws-" + n.incrementAndGet());
            t.setDaemon(true);
            return t;
        });
        log.info("Bridge server (WebSocket/Kryo) on port {} path {} (max-message-size={}MB, find-all-chunk-keys={}, "
                        + "worker-threads={}, send-buffer={}MB, send-timeout={}): NOT_SERVING until preload completes",
                port(), path(), cfg.maxMessageSizeMbOrDefault(), cfg.findAllChunkKeysOrDefault(), cfg.workerThreadsOrDefault(),
                cfg.sendBufferMbOrDefault(), cfg.sendTimeoutOrDefault());
    }

    @Override
    public void markServing() {
        serving.set(true);
        log.info("Bridge server (WebSocket/Kryo) on port {} path {} is SERVING", port(), path());
    }

    @Override
    public synchronized void stop() {
        if (workers == null) return;
        log.info("Stopping bridge server (WebSocket/Kryo): closing {} connections", peers.size());
        serving.set(false);
        new ArrayList<>(peers.values()).forEach(p -> p.close(CloseStatus.GOING_AWAY));
        workers.shutdown();
        try {
            if (!workers.awaitTermination(10, TimeUnit.SECONDS)) workers.shutdownNow();
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            workers.shutdownNow();
        }
        workers = null;
    }

    // ------------------------------------------------------------------ Spring WebSocket callbacks

    @Override
    public void afterConnectionEstablished(WebSocketSession session) {
        session.setBinaryMessageSizeLimit(maxBytes);
        WebSocketSession concurrent = new ConcurrentWebSocketSessionDecorator(session,
                (int) cfg.sendTimeoutOrDefault().toMillis(), cfg.sendBufferMbOrDefault() * 1024 * 1024);
        peers.put(session.getId(), new Peer(concurrent));
        log.info("Client connected: {} from {} ({} connections)", session.getId(), session.getRemoteAddress(), peers.size());
    }

    @Override
    protected void handleBinaryMessage(WebSocketSession session, BinaryMessage message) {
        Peer peer = peers.get(session.getId());
        if (peer == null) return;
        Frame f;
        try {
            f = KryoCodec.decode(message.getPayload());
        } catch (RuntimeException e) {
            log.warn("Bad frame from {}: {}", session.getId(), e.getMessage());
            peer.send(new Failure(0, Code.BAD_REQUEST, e.getMessage()));
            return;
        }
        log.trace("{} <- {}", session.getId(), f.getClass().getSimpleName());
        if (f instanceof Health h) {
            peer.send(new Status(h.id(), serving.get()));
        } else if (f instanceof ListDatasets l) {
            peer.send(new Datasets(l.id(), List.copyOf(handler.datasets())));
            log.debug("ListDatasets -> {}", handler.datasets());
        } else if (f instanceof Credit c) {
            Stream s = peer.streams.get(c.id());
            if (s != null) s.credit(c.chunks());
        } else if (f instanceof Cancel c) {
            Stream s = peer.streams.remove(c.id());
            if (s != null) s.cancel("cancelled by client");
        } else if (!serving.get()) {
            log.debug("Rejected request from {}: still preloading", session.getId());
            peer.send(new Failure(f.id(), Code.UNAVAILABLE, "reference-data-server is still preloading"));
        } else if (f instanceof FindByKeys r) {
            submit(peer, r.id(), () -> findByKeys(peer, r));
        } else if (f instanceof FindAll r) {
            submit(peer, r.id(), () -> findAll(peer, r));
        } else {
            peer.send(new Failure(f.id(), Code.BAD_REQUEST, "Unexpected frame " + f.getClass().getSimpleName()));
        }
    }

    @Override
    public void afterConnectionClosed(WebSocketSession session, CloseStatus status) {
        Peer p = peers.remove(session.getId());
        if (p != null) {
            p.streams.values().forEach(s -> s.cancel("connection closed"));
            log.info("Client disconnected: {} ({}), {} connections left", session.getId(), status, peers.size());
        }
    }

    @Override
    public void handleTransportError(WebSocketSession session, Throwable exception) {
        log.warn("Transport error on {}: {}", session.getId(), exception.toString());
    }

    // ------------------------------------------------------------------ requests

    private void findByKeys(Peer peer, FindByKeys r) {
        long t0 = System.nanoTime();
        Map<String, List<Map<String, Object>>> rows = handler.findByKeys(r.dataset(), r.keys());
        byte[] bytes = KryoCodec.encode(new Rows(r.id(), rows, true), maxBytes);
        peer.sendBytes(bytes);
        log.debug("FindByKeys {}: {} keys -> {} found, {} bytes in {} ms", r.dataset(), r.keys().size(), rows.size(),
                bytes.length, (System.nanoTime() - t0) / 1_000_000);
    }

    private void findAll(Peer peer, FindAll r) {
        Map<String, List<Map<String, Object>>> all = handler.findAll(r.dataset());
        log.info("FindAll {}: streaming {} keys to {}", r.dataset(), all.size(), peer.session.getId());
        Stream s = new Stream(peer, r.id(), r.dataset(), all.entrySet().iterator(), Math.max(1, r.window()));
        peer.streams.put(r.id(), s);
        s.pump();
    }

    private void submit(Peer peer, long id, Runnable work) {
        try {
            workers.execute(() -> {
                try {
                    work.run();
                } catch (RuntimeException e) {
                    peer.send(toFailure(id, e));
                }
            });
        } catch (RejectedExecutionException | NullPointerException e) {
            peer.send(new Failure(id, Code.UNAVAILABLE, "reference-data-server is stopping"));
        }
    }

    private static Failure toFailure(long id, RuntimeException e) {
        if (e instanceof IllegalArgumentException) {
            log.warn("Request for unknown dataset: {}", e.getMessage());
            return new Failure(id, Code.NOT_FOUND, e.getMessage());
        }
        if (e instanceof ReferenceRepository.LoadException le) {
            log.warn("Source load failed for {}: {}", le.getDataset(), e.getMessage());
            return new Failure(id, Code.UNAVAILABLE, e.getMessage());
        }
        log.error("Request {} failed", id, e);
        return new Failure(id, Code.INTERNAL, e.toString());
    }

    // ------------------------------------------------------------------ per connection

    /** One client connection: thread-safe sends and its open FindAll streams. */
    private final class Peer {
        private final WebSocketSession session;
        private final Map<Long, Stream> streams = new ConcurrentHashMap<>();

        Peer(WebSocketSession session) {
            this.session = session;
        }

        void send(Frame f) {
            sendBytes(KryoCodec.encode(f, maxBytes));
        }

        void sendBytes(byte[] bytes) {
            try {
                session.sendMessage(new BinaryMessage(bytes));
            } catch (IOException | RuntimeException e) {
                // ConcurrentWebSocketSessionDecorator throws when send-timeout / send-buffer-mb is exceeded
                log.warn("Send to {} failed ({} bytes): {}; closing", session.getId(), bytes.length, e.toString());
                close(CloseStatus.SESSION_NOT_RELIABLE);
            }
        }

        void close(CloseStatus status) {
            try {
                session.close(status);
            } catch (IOException e) {
                log.debug("Close of {} failed: {}", session.getId(), e.toString());
            }
        }
    }

    /** One FindAll: sends chunks while the client has credit; credit and pump may arrive on different threads. */
    private final class Stream {
        private final Peer peer;
        private final long id;
        private final String dataset;
        private final Iterator<Map.Entry<String, List<Map<String, Object>>>> entries;
        private final long startNanos = System.nanoTime();
        private int credit;
        private int chunksSent;
        private long bytesSent;
        private int pauses;
        private boolean finished;

        Stream(Peer peer, long id, String dataset, Iterator<Map.Entry<String, List<Map<String, Object>>>> entries, int window) {
            this.peer = peer;
            this.id = id;
            this.dataset = dataset;
            this.entries = entries;
            this.credit = window;
        }

        void credit(int n) {
            synchronized (this) {
                if (finished) return;
                credit += n;
            }
            try {
                workers.execute(this::pump);       // encode off the container thread
            } catch (RejectedExecutionException | NullPointerException e) {
                cancel("server stopping");
            }
        }

        synchronized void pump() {
            try {
                while (!finished && credit > 0) {
                    byte[] chunk = KryoCodec.encodeChunk(id, entries, cfg.findAllChunkKeysOrDefault(), KryoCodec.MAX_CHUNK_BYTES, maxBytes);
                    peer.sendBytes(chunk);
                    credit--;
                    chunksSent++;
                    bytesSent += chunk.length;
                    if (!entries.hasNext()) {
                        finished = true;
                        peer.streams.remove(id);
                        log.info("FindAll {}: sent {} chunks ({} KB) in {} ms, paused {} times for a slow client",
                                dataset, chunksSent, bytesSent / 1024, (System.nanoTime() - startNanos) / 1_000_000, pauses);
                    }
                }
                if (!finished) {
                    pauses++;
                    log.trace("FindAll {}: no credit after {} chunks, pausing", dataset, chunksSent);
                }
            } catch (RuntimeException e) {
                finished = true;
                peer.streams.remove(id);
                log.error("FindAll {} failed after {} chunks", dataset, chunksSent, e);
                peer.send(new Failure(id, Code.INTERNAL, "FindAll failed: " + e));
            }
        }

        synchronized void cancel(String why) {
            if (finished) return;
            finished = true;
            log.warn("FindAll {} stopped after {} chunks: {}", dataset, chunksSent, why);
        }
    }
}
