package com.referencedata.bridge.grpc;

import com.google.protobuf.ByteString;
import com.referencedata.bridge.grpc.v1.Column;
import com.referencedata.bridge.grpc.v1.KeyRows;
import com.referencedata.bridge.grpc.v1.ListValue;
import com.referencedata.bridge.grpc.v1.MapValue;
import com.referencedata.bridge.grpc.v1.Row;
import com.referencedata.bridge.grpc.v1.Value;
import com.referencedata.core.RowValues;
import lombok.AccessLevel;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Converts normalised rows (see {@link RowValues}: String, Long, BigDecimal, Double, Boolean, byte[], null, and nested
 * Map / List of those) to and from protobuf, losslessly and recursively. Decimals travel as text so BigDecimal scale
 * and precision survive; maps keep their entry order.
 */
@NoArgsConstructor(access = AccessLevel.PRIVATE)
final class RowCodec {

    static KeyRows toProto(String key, List<Map<String, Object>> rows) {
        KeyRows.Builder b = KeyRows.newBuilder().setKey(key);
        for (Map<String, Object> row : rows) b.addRows(toProto(row));
        return b.build();
    }

    static Row toProto(Map<String, Object> row) {
        Row.Builder b = Row.newBuilder();
        row.forEach((name, v) -> b.addColumns(column(name, v, 0)));
        return b.build();
    }

    static List<Map<String, Object>> fromProto(KeyRows kr) {
        List<Map<String, Object>> out = new ArrayList<>(kr.getRowsCount());
        for (Row r : kr.getRowsList()) out.add(fromProto(r));
        return out;
    }

    static Map<String, Object> fromProto(Row row) {
        return fromColumns(row.getColumnsList(), false);
    }

    static Value toValue(Object v) {
        return toValue(v, 0);
    }

    private static Column column(String name, Object v, int depth) {
        return Column.newBuilder().setName(name).setValue(toValue(v, depth + 1)).build();
    }

    private static Value toValue(Object v, int depth) {
        if (depth > RowValues.MAX_DEPTH) throw new IllegalArgumentException("Row value nested deeper than " + RowValues.MAX_DEPTH);
        Value.Builder b = Value.newBuilder();
        if (v == null) return b.setNullValue(true).build();
        if (v instanceof String s) return b.setText(s).build();
        if (v instanceof Long l) return b.setLongValue(l).build();
        if (v instanceof Integer || v instanceof Short || v instanceof Byte) return b.setLongValue(((Number) v).longValue()).build();
        if (v instanceof BigDecimal d) return b.setDecimal(d.toPlainString()).build();
        if (v instanceof Double || v instanceof Float) return b.setDoubleValue(((Number) v).doubleValue()).build();
        if (v instanceof Boolean flag) return b.setBoolValue(flag).build();
        if (v instanceof byte[] bytes) return b.setBytesValue(ByteString.copyFrom(bytes)).build();
        if (v instanceof Map<?, ?> m) {
            MapValue.Builder mb = MapValue.newBuilder();
            m.forEach((k, x) -> mb.addEntries(column(String.valueOf(k), x, depth)));
            return b.setMapValue(mb).build();
        }
        if (v instanceof Collection<?> c) {
            ListValue.Builder lb = ListValue.newBuilder();
            for (Object x : c) lb.addValues(toValue(x, depth + 1));
            return b.setListValue(lb).build();
        }
        // not normalised by the loader (arrays, records, java.time, ...): normalise, then encode
        Object n = RowValues.normalizeValue(v);
        if (n instanceof String s) return b.setText(s).build();
        return toValue(n, depth + 1);
    }

    static Object fromValue(Value v) {
        return switch (v.getKindCase()) {
            case NULL_VALUE, KIND_NOT_SET -> null;
            case TEXT -> v.getText();
            case LONG_VALUE -> v.getLongValue();
            case DECIMAL -> new BigDecimal(v.getDecimal());
            case DOUBLE_VALUE -> v.getDoubleValue();
            case BOOL_VALUE -> v.getBoolValue();
            case BYTES_VALUE -> v.getBytesValue().toByteArray();
            case LIST_VALUE -> {
                List<Object> out = new ArrayList<>(v.getListValue().getValuesCount());
                for (Value x : v.getListValue().getValuesList()) out.add(fromValue(x));
                yield Collections.unmodifiableList(out);
            }
            case MAP_VALUE -> fromColumns(v.getMapValue().getEntriesList(), true);
        };
    }

    private static Map<String, Object> fromColumns(List<Column> columns, boolean nested) {
        Map<String, Object> out = new LinkedHashMap<>(Math.max(4, columns.size() * 2));
        for (Column c : columns) out.put(c.getName(), fromValue(c.getValue()));
        return nested ? Collections.unmodifiableMap(out) : out;
    }
}
