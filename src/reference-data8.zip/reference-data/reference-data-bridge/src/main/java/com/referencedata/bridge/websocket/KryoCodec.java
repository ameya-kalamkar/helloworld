package com.referencedata.bridge.websocket;

import com.esotericsoftware.kryo.Kryo;
import com.esotericsoftware.kryo.KryoException;
import com.esotericsoftware.kryo.Serializer;
import com.esotericsoftware.kryo.io.Input;
import com.esotericsoftware.kryo.io.Output;
import com.esotericsoftware.kryo.util.Pool;
import com.referencedata.core.RowValues;
import lombok.AccessLevel;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Wire format of the WebSocket bridge: one Kryo-serialized {@link Frame} per binary WebSocket message.
 * <ul>
 *   <li>Every message starts with a protocol version byte, then the Kryo class id of the frame and its fields.</li>
 *   <li>Registration is required and ids are fixed, so client and server never exchange class names and a frame
 *       type the peer does not know fails fast.</li>
 *   <li>Row values use the same model as the gRPC bridge ({@link RowValues}): null, String, Long, BigDecimal (unscaled
 *       bytes + scale, exact), Double, Boolean, byte[], and nested List / Map of those, recursively. EMBEDDED, gRPC and
 *       WebSocket therefore return identical rows.</li>
 *   <li>Kryo instances are not thread-safe: a {@link Pool} hands one to each encode/decode.</li>
 * </ul>
 * Multiplexing: every request carries an id; responses carry the same id, so one connection serves concurrent calls.
 */
@NoArgsConstructor(access = AccessLevel.PRIVATE)
final class KryoCodec {

    static final int PROTOCOL_VERSION = 1;
    /** Soft cap on one FindAll chunk; a single key larger than this is still sent alone. */
    static final int MAX_CHUNK_BYTES = 1024 * 1024;

    // ------------------------------------------------------------------ frames

    /** Every message on the connection. Requests go client to server, responses server to client, matched by id. */
    sealed interface Frame permits Health, Status, ListDatasets, Datasets, FindByKeys, FindAll, Credit, Cancel, Rows, Failure {
        long id();
    }

    /** Request: is the server warm (SERVING)? */
    record Health(long id) implements Frame {}

    /** Response to {@link Health}. */
    record Status(long id, boolean serving) implements Frame {}

    record ListDatasets(long id) implements Frame {}

    record Datasets(long id, List<String> names) implements Frame {}

    /** Answered by one {@link Rows} with {@code last = true}. */
    record FindByKeys(long id, String dataset, List<String> keys) implements Frame {}

    /**
     * Answered by {@link Rows} chunks; the last has {@code last = true}. The server sends at most {@code window}
     * chunks ahead; the client returns one {@link Credit} per chunk it has consumed (flow control).
     */
    record FindAll(long id, String dataset, int window) implements Frame {}

    record Credit(long id, int chunks) implements Frame {}

    /** Client gave up on a call (deadline): the server stops streaming it. */
    record Cancel(long id) implements Frame {}

    /** Key to rows; keys not found are absent. */
    record Rows(long id, Map<String, List<Map<String, Object>>> entries, boolean last) implements Frame {}

    record Failure(long id, Code code, String message) implements Frame {}

    /** Same meaning as the gRPC status codes the gRPC bridge uses. */
    enum Code { NOT_FOUND, UNAVAILABLE, INTERNAL, BAD_REQUEST, DEADLINE_EXCEEDED }

    // ------------------------------------------------------------------ encode / decode

    private static final Pool<Kryo> KRYO = new Pool<>(true, false, 64) {
        @Override
        protected Kryo create() {
            Kryo k = new Kryo();
            k.setRegistrationRequired(true);
            k.setReferences(false);
            FrameSerializer s = new FrameSerializer();
            int id = 100;                                    // fixed ids: part of the protocol, never reorder
            for (Class<?> c : List.of(Health.class, Status.class, ListDatasets.class, Datasets.class, FindByKeys.class,
                    FindAll.class, Credit.class, Cancel.class, Rows.class, Failure.class)) {
                k.register(c, s, id++);
            }
            return k;
        }
    };

    static byte[] encode(Frame f, int maxBytes) {
        Kryo k = KRYO.obtain();
        try (Output out = new Output(Math.min(4096, maxBytes), maxBytes)) {
            out.writeByte(PROTOCOL_VERSION);
            k.writeClassAndObject(out, f);
            return out.toBytes();
        } catch (KryoException e) {
            throw new IllegalStateException("Cannot encode " + f.getClass().getSimpleName() + " (limit " + maxBytes
                    + " bytes, see max-message-size-mb): " + e.getMessage(), e);
        } finally {
            KRYO.free(k);
        }
    }

    /**
     * One FindAll chunk straight from the dataset iterator: up to {@code maxKeys} keys and about {@code maxChunkBytes},
     * {@code last} set when the iterator is exhausted. Encodes as it goes, so no intermediate frame object.
     */
    static byte[] encodeChunk(long id, Iterator<Map.Entry<String, List<Map<String, Object>>>> entries, int maxKeys,
                              int maxChunkBytes, int maxBytes) {
        Kryo k = KRYO.obtain();
        try (Output out = new Output(Math.min(64 * 1024, maxBytes), maxBytes)) {
            out.writeByte(PROTOCOL_VERSION);
            k.writeClass(out, Rows.class);
            out.writeVarLong(id, true);
            FrameSerializer.writeEntries(out, entries, maxKeys, maxChunkBytes);
            out.writeBoolean(!entries.hasNext());
            return out.toBytes();
        } catch (KryoException e) {
            throw new IllegalStateException("Cannot encode FindAll chunk (limit " + maxBytes + " bytes): " + e.getMessage(), e);
        } finally {
            KRYO.free(k);
        }
    }

    static Frame decode(ByteBuffer buf) {
        byte[] b = new byte[buf.remaining()];
        buf.get(b);
        return decode(b);
    }

    static Frame decode(byte[] bytes) {
        Kryo k = KRYO.obtain();
        try (Input in = new Input(bytes)) {
            int version = in.readByte();
            if (version != PROTOCOL_VERSION) {
                throw new IllegalArgumentException("Unsupported bridge protocol version " + version + " (this side speaks "
                        + PROTOCOL_VERSION + ")");
            }
            Object o = k.readClassAndObject(in);
            if (!(o instanceof Frame f)) throw new IllegalArgumentException("Not a bridge frame: " + o);
            return f;
        } catch (KryoException e) {
            throw new IllegalArgumentException("Malformed bridge frame: " + e.getMessage(), e);
        } finally {
            KRYO.free(k);
        }
    }

    // ------------------------------------------------------------------ Kryo serializer

    /** Explicit field-by-field serializer for every frame (no reflection, stable across JVM versions). */
    static final class FrameSerializer extends Serializer<Frame> {

        private static final int T_NULL = 0, T_STRING = 1, T_LONG = 2, T_DECIMAL = 3, T_DOUBLE = 4, T_TRUE = 5,
                T_FALSE = 6, T_BYTES = 7, T_LIST = 8, T_MAP = 9;

        FrameSerializer() {
            setImmutable(true);
        }

        @Override
        public void write(Kryo kryo, Output out, Frame f) {
            out.writeVarLong(f.id(), true);
            if (f instanceof Status s) {
                out.writeBoolean(s.serving());
            } else if (f instanceof Datasets d) {
                writeStrings(out, d.names());
            } else if (f instanceof FindByKeys r) {
                out.writeString(r.dataset());
                writeStrings(out, r.keys());
            } else if (f instanceof FindAll r) {
                out.writeString(r.dataset());
                out.writeVarInt(r.window(), true);
            } else if (f instanceof Credit c) {
                out.writeVarInt(c.chunks(), true);
            } else if (f instanceof Rows r) {
                writeEntries(out, r.entries().entrySet().iterator(), Integer.MAX_VALUE, Integer.MAX_VALUE);
                out.writeBoolean(r.last());
            } else if (f instanceof Failure e) {
                out.writeVarInt(e.code().ordinal(), true);
                out.writeString(e.message());
            }
            // Health, ListDatasets, Cancel: id only
        }

        @Override
        public Frame read(Kryo kryo, Input in, Class<? extends Frame> type) {
            long id = in.readVarLong(true);
            if (type == Health.class) return new Health(id);
            if (type == Status.class) return new Status(id, in.readBoolean());
            if (type == ListDatasets.class) return new ListDatasets(id);
            if (type == Datasets.class) return new Datasets(id, readStrings(in));
            if (type == FindByKeys.class) return new FindByKeys(id, in.readString(), readStrings(in));
            if (type == FindAll.class) return new FindAll(id, in.readString(), in.readVarInt(true));
            if (type == Credit.class) return new Credit(id, in.readVarInt(true));
            if (type == Cancel.class) return new Cancel(id);
            if (type == Rows.class) {
                Map<String, List<Map<String, Object>>> entries = readEntries(in);
                return new Rows(id, entries, in.readBoolean());
            }
            if (type == Failure.class) {
                int code = in.readVarInt(true);
                Code c = code < Code.values().length ? Code.values()[code] : Code.INTERNAL;
                return new Failure(id, c, in.readString());
            }
            throw new KryoException("Unknown frame type " + type);
        }

        /** Entries, each preceded by {@code true}; {@code false} ends the list (so chunks can be cut while writing). */
        static void writeEntries(Output out, Iterator<Map.Entry<String, List<Map<String, Object>>>> it, int maxKeys, int maxBytes) {
            int start = out.position();
            int n = 0;
            while (it.hasNext() && n < maxKeys && out.position() - start < maxBytes) {
                Map.Entry<String, List<Map<String, Object>>> e = it.next();
                out.writeBoolean(true);
                out.writeString(e.getKey());
                List<Map<String, Object>> rows = e.getValue();
                out.writeVarInt(rows.size(), true);
                for (Map<String, Object> row : rows) writeMap(out, row, 0);
                n++;
            }
            out.writeBoolean(false);
        }

        static Map<String, List<Map<String, Object>>> readEntries(Input in) {
            Map<String, List<Map<String, Object>>> out = new LinkedHashMap<>();
            while (in.readBoolean()) {
                String key = in.readString();
                int n = in.readVarInt(true);
                List<Map<String, Object>> rows = new ArrayList<>(n);
                for (int i = 0; i < n; i++) rows.add(readMap(in, 0, false));
                out.put(key, rows);
            }
            return out;
        }

        private static void writeStrings(Output out, List<String> values) {
            out.writeVarInt(values.size(), true);
            for (String v : values) out.writeString(v);
        }

        private static List<String> readStrings(Input in) {
            int n = in.readVarInt(true);
            List<String> out = new ArrayList<>(n);
            for (int i = 0; i < n; i++) out.add(in.readString());
            return out;
        }

        private static void writeMap(Output out, Map<?, ?> m, int depth) {
            out.writeVarInt(m.size(), true);
            for (Map.Entry<?, ?> e : m.entrySet()) {
                out.writeString(String.valueOf(e.getKey()));
                writeValue(out, e.getValue(), depth + 1);
            }
        }

        private static Map<String, Object> readMap(Input in, int depth, boolean nested) {
            int n = in.readVarInt(true);
            Map<String, Object> m = new LinkedHashMap<>(Math.max(4, n * 2));
            for (int i = 0; i < n; i++) m.put(in.readString(), readValue(in, depth + 1));
            return nested ? Collections.unmodifiableMap(m) : m;
        }

        private static void writeValue(Output out, Object v, int depth) {
            if (depth > RowValues.MAX_DEPTH) throw new KryoException("Row value nested deeper than " + RowValues.MAX_DEPTH);
            if (v == null) {
                out.writeByte(T_NULL);
            } else if (v instanceof String s) {
                out.writeByte(T_STRING);
                out.writeString(s);
            } else if (v instanceof Long || v instanceof Integer || v instanceof Short || v instanceof Byte) {
                out.writeByte(T_LONG);
                out.writeVarLong(((Number) v).longValue(), false);
            } else if (v instanceof BigDecimal d) {
                out.writeByte(T_DECIMAL);
                out.writeVarInt(d.scale(), false);
                byte[] unscaled = d.unscaledValue().toByteArray();
                out.writeVarInt(unscaled.length, true);
                out.writeBytes(unscaled);
            } else if (v instanceof Double || v instanceof Float) {
                out.writeByte(T_DOUBLE);
                out.writeDouble(((Number) v).doubleValue());
            } else if (v instanceof Boolean b) {
                out.writeByte(b ? T_TRUE : T_FALSE);
            } else if (v instanceof byte[] bytes) {
                out.writeByte(T_BYTES);
                out.writeVarInt(bytes.length, true);
                out.writeBytes(bytes);
            } else if (v instanceof Collection<?> c) {
                out.writeByte(T_LIST);
                out.writeVarInt(c.size(), true);
                for (Object x : c) writeValue(out, x, depth + 1);
            } else if (v instanceof Map<?, ?> m) {
                out.writeByte(T_MAP);
                writeMap(out, m, depth);
            } else {
                // not normalised by the loader (arrays, records, java.time, ...): normalise, then encode
                writeValue(out, RowValues.normalizeValue(v), depth + 1);
            }
        }

        private static Object readValue(Input in, int depth) {
            if (depth > RowValues.MAX_DEPTH) throw new KryoException("Row value nested deeper than " + RowValues.MAX_DEPTH);
            int tag = in.readByte();
            switch (tag) {
                case T_NULL: return null;
                case T_STRING: return in.readString();
                case T_LONG: return in.readVarLong(false);
                case T_DECIMAL: {
                    int scale = in.readVarInt(false);
                    byte[] unscaled = in.readBytes(in.readVarInt(true));
                    return new BigDecimal(new BigInteger(unscaled), scale);
                }
                case T_DOUBLE: return in.readDouble();
                case T_TRUE: return Boolean.TRUE;
                case T_FALSE: return Boolean.FALSE;
                case T_BYTES: return in.readBytes(in.readVarInt(true));
                case T_LIST: {
                    int n = in.readVarInt(true);
                    List<Object> l = new ArrayList<>(n);
                    for (int i = 0; i < n; i++) l.add(readValue(in, depth + 1));
                    return Collections.unmodifiableList(l);
                }
                case T_MAP: return readMap(in, depth, true);
                default: throw new KryoException("Unknown value tag " + tag);
            }
        }
    }
}
