package com.referencedata.bridge.grpc;

import com.referencedata.bridge.BridgeClient;
import com.referencedata.bridge.grpc.v1.FindAllRequest;
import com.referencedata.bridge.grpc.v1.FindByKeysRequest;
import com.referencedata.bridge.grpc.v1.FindByKeysResponse;
import com.referencedata.bridge.grpc.v1.KeyRows;
import com.referencedata.bridge.grpc.v1.KeyRowsChunk;
import com.referencedata.bridge.grpc.v1.ListDatasetsRequest;
import com.referencedata.bridge.grpc.v1.ReferenceDataBridgeGrpc;
import com.referencedata.core.ReferenceDataConfig;
import com.referencedata.core.ReferenceLoader;
import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;
import io.grpc.StatusRuntimeException;
import io.grpc.health.v1.HealthCheckRequest;
import io.grpc.health.v1.HealthCheckResponse;
import io.grpc.health.v1.HealthGrpc;
import lombok.extern.slf4j.Slf4j;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.TimeUnit;

/**
 * gRPC implementation of {@link BridgeClient}: one channel shared by every DELEGATE dataset of the client.
 * <ul>
 *   <li>{@code FindByKeys}: unary; misses are sent in calls of up to {@code max-keys-per-call} keys, each with
 *       its own {@code deadline}.</li>
 *   <li>{@code FindAll}: server-streaming in chunks of keys; the blocking iterator pulls one chunk at a time, so the
 *       server (which respects flow control) never runs ahead of this client.</li>
 * </ul>
 */
@Slf4j
public final class GrpcBridgeClient implements BridgeClient {

    private final ReferenceDataConfig.Delegate cfg;
    private final ManagedChannel channel;
    private final ReferenceDataBridgeGrpc.ReferenceDataBridgeBlockingStub stub;

    public GrpcBridgeClient(ReferenceDataConfig.Delegate cfg) {
        this.cfg = cfg;
        ManagedChannelBuilder<?> b = ManagedChannelBuilder.forTarget(cfg.target())
                .defaultLoadBalancingPolicy("round_robin")
                .maxInboundMessageSize(cfg.maxMessageSizeMbOrDefault() * 1024 * 1024);
        if (cfg.plaintextOrDefault()) b.usePlaintext(); else b.useTransportSecurity();
        this.channel = b.build();
        this.stub = ReferenceDataBridgeGrpc.newBlockingStub(channel);
        log.info("Bridge client (gRPC) -> {}: plaintext={}, deadline={}, find-all-deadline={}, max-keys-per-call={}, max-message-size={}MB",
                cfg.target(), cfg.plaintextOrDefault(), cfg.deadlineOrDefault(), cfg.findAllDeadlineOrDefault(),
                cfg.maxKeysPerCallOrDefault(), cfg.maxMessageSizeMbOrDefault());
    }

    /** Waits until the server's gRPC health check says SERVING, which it does only after its own preload. */
    @Override
    public void awaitReady() {
        long t0 = System.nanoTime();
        long deadline = t0 + cfg.readyTimeoutOrDefault().toNanos();
        HealthGrpc.HealthBlockingStub health = HealthGrpc.newBlockingStub(channel);
        String last = "no answer";
        while (true) {
            try {
                HealthCheckResponse r = health.withDeadlineAfter(2, TimeUnit.SECONDS)
                        .check(HealthCheckRequest.newBuilder().setService("").build());
                if (r.getStatus() == HealthCheckResponse.ServingStatus.SERVING) {
                    log.info("reference-data-server at {} is SERVING (waited {} ms)", cfg.target(), millis(t0));
                    return;
                }
                last = r.getStatus().name();
            } catch (StatusRuntimeException e) {
                last = e.getStatus().getCode().name();
            }
            if (System.nanoTime() > deadline) {
                throw new IllegalStateException("reference-data-server at " + cfg.target() + " not ready after "
                        + cfg.readyTimeoutOrDefault() + " (last: " + last + ")");
            }
            log.info("Waiting for reference-data-server at {} ({}, {} ms so far)", cfg.target(), last, millis(t0));
            try {
                Thread.sleep(1_000);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                throw new IllegalStateException("Interrupted while waiting for reference-data-server", e);
            }
        }
    }

    @Override
    public Set<String> listDatasets() {
        Set<String> served = new LinkedHashSet<>(stub.withDeadlineAfter(cfg.deadlineOrDefault().toMillis(), TimeUnit.MILLISECONDS)
                .listDatasets(ListDatasetsRequest.getDefaultInstance()).getDatasetsList());
        log.info("reference-data-server at {} serves {} datasets: {}", cfg.target(), served.size(), served);
        return served;
    }

    @Override
    public ReferenceLoader loader(String dataset) {
        return new ReferenceLoader() {
            @Override
            public Map<String, List<Map<String, Object>>> loadAll() {
                long t0 = System.nanoTime();
                Map<String, List<Map<String, Object>>> out = new LinkedHashMap<>();
                int chunkCount = 0;
                long bytes = 0;
                try {
                    Iterator<KeyRowsChunk> chunks = stub.withDeadlineAfter(cfg.findAllDeadlineOrDefault().toMillis(), TimeUnit.MILLISECONDS)
                            .findAll(FindAllRequest.newBuilder().setDataset(dataset).build());
                    while (chunks.hasNext()) {
                        KeyRowsChunk c = chunks.next();
                        chunkCount++;
                        bytes += c.getSerializedSize();
                        for (KeyRows kr : c.getEntriesList()) out.put(kr.getKey(), RowCodec.fromProto(kr));
                        log.trace("FindAll {}: chunk {} with {} keys", dataset, chunkCount, c.getEntriesCount());
                    }
                } catch (StatusRuntimeException e) {
                    log.warn("FindAll {} failed after {} chunks, {} ms: {}", dataset, chunkCount, millis(t0), e.getStatus());
                    throw e;
                }
                log.info("FindAll {}: {} keys in {} chunks ({} KB) in {} ms", dataset, out.size(), chunkCount, bytes / 1024, millis(t0));
                return out;
            }

            @Override
            public List<Map<String, Object>> loadByKey(String key) {
                return loadByKeys(List.of(key)).getOrDefault(key, List.of());
            }

            @Override
            public Map<String, List<Map<String, Object>>> loadByKeys(Collection<String> keys) {
                long t0 = System.nanoTime();
                Map<String, List<Map<String, Object>>> out = new LinkedHashMap<>();
                List<String> all = new ArrayList<>(keys);
                int chunk = cfg.maxKeysPerCallOrDefault();
                int calls = 0;
                for (int i = 0; i < all.size(); i += chunk) {
                    List<String> part = all.subList(i, Math.min(all.size(), i + chunk));
                    try {
                        FindByKeysResponse resp = stub.withDeadlineAfter(cfg.deadlineOrDefault().toMillis(), TimeUnit.MILLISECONDS)
                                .findByKeys(FindByKeysRequest.newBuilder().setDataset(dataset).addAllKeys(part).build());
                        for (KeyRows kr : resp.getEntriesList()) out.put(kr.getKey(), RowCodec.fromProto(kr));
                        calls++;
                    } catch (StatusRuntimeException e) {
                        log.warn("FindByKeys {} ({} keys, call {}) failed after {} ms: {}", dataset, part.size(), calls + 1,
                                millis(t0), e.getStatus());
                        throw e;
                    }
                }
                log.debug("FindByKeys {}: {} keys in {} calls -> {} found in {} ms", dataset, all.size(), calls, out.size(), millis(t0));
                return out;
            }

            @Override
            public String toString() {
                return "bridge:grpc[" + dataset + " @ " + cfg.target() + "]";
            }
        };
    }

    private static long millis(long startNanos) {
        return (System.nanoTime() - startNanos) / 1_000_000;
    }

    @Override
    public void close() {
        log.info("Closing bridge client to {}", cfg.target());
        channel.shutdown();
        try {
            if (!channel.awaitTermination(5, TimeUnit.SECONDS)) channel.shutdownNow();
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            channel.shutdownNow();
        }
    }
}
