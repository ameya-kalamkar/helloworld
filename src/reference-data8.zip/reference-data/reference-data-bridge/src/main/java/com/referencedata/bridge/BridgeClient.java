package com.referencedata.bridge;

import com.referencedata.bridge.grpc.GrpcBridgeClient;
import com.referencedata.bridge.websocket.WebSocketBridgeClient;
import com.referencedata.core.ReferenceDataConfig;
import com.referencedata.core.ReferenceLoader;

import java.util.Set;

/**
 * Client side of the bridge between reference-data-client and reference-data-server. Transport-neutral:
 * the client only sees this interface; {@code "transport"} in the client's {@code delegate} config picks the
 * implementation: {@code grpc} (gRPC/protobuf) or {@code websocket} (Kryo frames over the JDK WebSocket client).
 */
public interface BridgeClient extends AutoCloseable {

    /** Waits until the server reports it is warm (its own preload done), up to {@code delegate.ready-timeout}. */
    void awaitReady();

    /** Datasets the server serves. */
    Set<String> listDatasets();

    /** The loader a DELEGATE dataset uses: every call is answered by the server's repository for that dataset. */
    ReferenceLoader loader(String dataset);

    @Override
    void close();

    /** Connects with the transport named in the config. */
    static BridgeClient connect(ReferenceDataConfig.Delegate config) {
        String transport = config.transportOrDefault();
        return switch (transport) {
            case ReferenceDataConfig.GRPC -> new GrpcBridgeClient(config);
            case ReferenceDataConfig.WEBSOCKET -> new WebSocketBridgeClient(config);
            default -> throw new IllegalArgumentException("Unknown bridge transport '" + transport + "' (supported: "
                    + ReferenceDataConfig.TRANSPORTS + ")");
        };
    }
}
