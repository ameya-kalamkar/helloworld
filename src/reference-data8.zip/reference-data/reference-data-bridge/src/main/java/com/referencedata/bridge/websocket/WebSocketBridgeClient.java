package com.referencedata.bridge.websocket;

import com.referencedata.bridge.BridgeClient;
import com.referencedata.bridge.websocket.KryoCodec.Cancel;
import com.referencedata.bridge.websocket.KryoCodec.Code;
import com.referencedata.bridge.websocket.KryoCodec.Credit;
import com.referencedata.bridge.websocket.KryoCodec.Datasets;
import com.referencedata.bridge.websocket.KryoCodec.Failure;
import com.referencedata.bridge.websocket.KryoCodec.FindAll;
import com.referencedata.bridge.websocket.KryoCodec.FindByKeys;
import com.referencedata.bridge.websocket.KryoCodec.Frame;
import com.referencedata.bridge.websocket.KryoCodec.Health;
import com.referencedata.bridge.websocket.KryoCodec.ListDatasets;
import com.referencedata.bridge.websocket.KryoCodec.Rows;
import com.referencedata.bridge.websocket.KryoCodec.Status;
import com.referencedata.core.ReferenceDataConfig;
import com.referencedata.core.ReferenceLoader;
import lombok.extern.slf4j.Slf4j;

import java.io.ByteArrayOutputStream;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.WebSocket;
import java.nio.ByteBuffer;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionStage;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;

/**
 * WebSocket + Kryo implementation of {@link BridgeClient}, on the JDK's own {@code java.net.http.WebSocket}: no extra
 * dependency in the client (works the same in Spring apps and in Flink/Spark executors).
 * <ul>
 *   <li>One WebSocket per target URI ({@code target} may list several, comma-separated), shared by all DELEGATE
 *       datasets; calls are multiplexed by id and spread round-robin over the connections.</li>
 *   <li>A dropped connection fails its in-flight calls (UNAVAILABLE) and is reopened by the next call.</li>
 *   <li>{@code FindByKeys}: one request/response per {@code max-keys-per-call} keys, each with {@code deadline}.</li>
 *   <li>{@code FindAll}: chunks with credit-based flow control: the server sends at most {@code find-all-window}
 *       chunks ahead; one credit goes back per chunk decoded, so a slow client never makes the server buffer the
 *       whole dataset.</li>
 * </ul>
 */
@Slf4j
public final class WebSocketBridgeClient implements BridgeClient {

    private static final Duration CONNECT_TIMEOUT = Duration.ofSeconds(10);

    private final ReferenceDataConfig.Delegate cfg;
    private final HttpClient http;
    private final List<Connection> connections;
    private final AtomicLong ids = new AtomicLong();
    private final AtomicInteger next = new AtomicInteger();
    private final int maxBytes;

    public WebSocketBridgeClient(ReferenceDataConfig.Delegate cfg) {
        this.cfg = cfg;
        this.maxBytes = cfg.maxMessageSizeMbOrDefault() * 1024 * 1024;
        this.http = HttpClient.newBuilder().connectTimeout(CONNECT_TIMEOUT).build();
        List<Connection> cs = new ArrayList<>();
        for (String t : cfg.targets()) cs.add(new Connection(URI.create(t)));
        if (cs.isEmpty()) throw new IllegalArgumentException("delegate.target is required for the websocket bridge");
        this.connections = List.copyOf(cs);
        log.info("Bridge client (WebSocket/Kryo) -> {}: deadline={}, find-all-deadline={}, find-all-window={}, "
                        + "max-keys-per-call={}, max-message-size={}MB", cfg.targets(), cfg.deadlineOrDefault(),
                cfg.findAllDeadlineOrDefault(), cfg.findAllWindowOrDefault(), cfg.maxKeysPerCallOrDefault(),
                cfg.maxMessageSizeMbOrDefault());
    }

    // ------------------------------------------------------------------ BridgeClient

    /** Waits until at least one server reports SERVING (its own preload done). */
    @Override
    public void awaitReady() {
        long t0 = System.nanoTime();
        long deadline = t0 + cfg.readyTimeoutOrDefault().toNanos();
        String last = "no answer";
        while (true) {
            for (Connection c : connections) {
                try {
                    Frame f = c.call(new Health(ids.incrementAndGet()), Duration.ofSeconds(2));
                    if (f instanceof Status s && s.serving()) {
                        log.info("reference-data-server at {} is SERVING (waited {} ms)", c.uri, millis(t0));
                        return;
                    }
                    last = c.uri + ": NOT_SERVING";
                } catch (RuntimeException e) {
                    last = c.uri + ": " + e.getMessage();
                }
            }
            if (System.nanoTime() > deadline) {
                throw new IllegalStateException("reference-data-server at " + cfg.targets() + " not ready after "
                        + cfg.readyTimeoutOrDefault() + " (last: " + last + ")");
            }
            log.info("Waiting for reference-data-server ({}, {} ms so far)", last, millis(t0));
            sleep(1_000);
        }
    }

    @Override
    public Set<String> listDatasets() {
        Frame f = call(id -> new ListDatasets(id), cfg.deadlineOrDefault());
        Set<String> served = new LinkedHashSet<>(((Datasets) f).names());
        log.info("reference-data-server at {} serves {} datasets: {}", cfg.targets(), served.size(), served);
        return served;
    }

    @Override
    public ReferenceLoader loader(String dataset) {
        return new ReferenceLoader() {
            @Override
            public Map<String, List<Map<String, Object>>> loadAll() {
                return findAll(dataset);
            }

            @Override
            public List<Map<String, Object>> loadByKey(String key) {
                return loadByKeys(List.of(key)).getOrDefault(key, List.of());
            }

            @Override
            public Map<String, List<Map<String, Object>>> loadByKeys(Collection<String> keys) {
                return findByKeys(dataset, keys);
            }

            @Override
            public String toString() {
                return "bridge:websocket[" + dataset + " @ " + cfg.target() + "]";
            }
        };
    }

    @Override
    public void close() {
        log.info("Closing bridge client to {}", cfg.targets());
        connections.forEach(Connection::close);
    }

    // ------------------------------------------------------------------ calls

    private Map<String, List<Map<String, Object>>> findByKeys(String dataset, Collection<String> keys) {
        long t0 = System.nanoTime();
        Map<String, List<Map<String, Object>>> out = new LinkedHashMap<>();
        List<String> all = new ArrayList<>(keys);
        int chunk = cfg.maxKeysPerCallOrDefault();
        int calls = 0;
        for (int i = 0; i < all.size(); i += chunk) {
            List<String> part = List.copyOf(all.subList(i, Math.min(all.size(), i + chunk)));
            try {
                Rows r = (Rows) call(id -> new FindByKeys(id, dataset, part), cfg.deadlineOrDefault());
                out.putAll(r.entries());
                calls++;
            } catch (RuntimeException e) {
                log.warn("FindByKeys {} ({} keys, call {}) failed after {} ms: {}", dataset, part.size(), calls + 1, millis(t0), e.getMessage());
                throw e;
            }
        }
        log.debug("FindByKeys {}: {} keys in {} calls -> {} found in {} ms", dataset, all.size(), calls, out.size(), millis(t0));
        return out;
    }

    private Map<String, List<Map<String, Object>>> findAll(String dataset) {
        long t0 = System.nanoTime();
        long deadline = t0 + cfg.findAllDeadlineOrDefault().toNanos();
        Connection c = pick();
        long id = ids.incrementAndGet();
        BlockingQueue<Frame> q = c.register(id);
        Map<String, List<Map<String, Object>>> out = new LinkedHashMap<>();
        int chunks = 0;
        try {
            c.send(new FindAll(id, dataset, cfg.findAllWindowOrDefault()));
            while (true) {
                Frame f = poll(q, deadline);
                if (f == null) {
                    c.trySend(new Cancel(id));
                    throw failure(Code.DEADLINE_EXCEEDED, "FindAll " + dataset + " exceeded find-all-deadline "
                            + cfg.findAllDeadlineOrDefault() + " after " + chunks + " chunks");
                }
                if (f instanceof Failure e) throw failure(e.code(), e.message());
                Rows r = (Rows) f;
                out.putAll(r.entries());
                chunks++;
                log.trace("FindAll {}: chunk {} with {} keys", dataset, chunks, r.entries().size());
                if (r.last()) break;
                c.send(new Credit(id, 1));                      // consumed one chunk: the server may send one more
            }
        } catch (RuntimeException e) {
            log.warn("FindAll {} via {} failed after {} chunks, {} ms: {}", dataset, c.uri, chunks, millis(t0), e.getMessage());
            throw e;
        } finally {
            c.unregister(id);
        }
        log.info("FindAll {}: {} keys in {} chunks in {} ms via {}", dataset, out.size(), chunks, millis(t0), c.uri);
        return out;
    }

    /** One request, one response, on the next connection; a connection that cannot be opened is skipped. */
    private Frame call(java.util.function.LongFunction<Frame> request, Duration timeout) {
        Frame f = pick().call(request.apply(ids.incrementAndGet()), timeout);
        if (f instanceof Failure e) throw failure(e.code(), e.message());
        return f;
    }

    private Connection pick() {
        RuntimeException lastError = null;
        for (int i = 0; i < connections.size(); i++) {
            Connection c = connections.get(Math.floorMod(next.getAndIncrement(), connections.size()));
            try {
                c.open();
                return c;
            } catch (RuntimeException e) {
                lastError = e;
                log.debug("Skipping {}: {}", c.uri, e.getMessage());
            }
        }
        throw failure(Code.UNAVAILABLE, "no reference-data-server reachable at " + cfg.targets()
                + (lastError == null ? "" : ": " + lastError.getMessage()));
    }

    private static RuntimeException failure(Code code, String message) {
        return new IllegalStateException(code + ": " + message);
    }

    private static Frame poll(BlockingQueue<Frame> q, long deadlineNanos) {
        try {
            long wait = deadlineNanos - System.nanoTime();
            return wait <= 0 ? q.poll() : q.poll(wait, TimeUnit.NANOSECONDS);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new IllegalStateException("Interrupted waiting for reference-data-server", e);
        }
    }

    private static long millis(long startNanos) {
        return (System.nanoTime() - startNanos) / 1_000_000;
    }

    private static void sleep(long ms) {
        try {
            Thread.sleep(ms);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new IllegalStateException("Interrupted while waiting for reference-data-server", e);
        }
    }

    // ------------------------------------------------------------------ one WebSocket

    /** One WebSocket to one server: multiplexed calls, serialized sends, reassembly of fragmented messages. */
    private final class Connection implements WebSocket.Listener {
        private final URI uri;
        private final Map<Long, BlockingQueue<Frame>> pending = new ConcurrentHashMap<>();
        private volatile WebSocket ws;
        private volatile boolean closing;
        private CompletableFuture<?> sends = CompletableFuture.completedFuture(null);   // guarded by this
        private ByteArrayOutputStream partial;                                          // listener thread only

        Connection(URI uri) {
            this.uri = uri;
        }

        synchronized WebSocket open() {
            WebSocket w = ws;
            if (w != null && !w.isInputClosed() && !w.isOutputClosed()) return w;
            long t0 = System.nanoTime();
            try {
                w = http.newWebSocketBuilder().connectTimeout(CONNECT_TIMEOUT).buildAsync(uri, this)
                        .get(CONNECT_TIMEOUT.toMillis() + 1_000, TimeUnit.MILLISECONDS);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                throw new IllegalStateException("Interrupted connecting to " + uri, e);
            } catch (Exception e) {
                Throwable cause = e.getCause() != null ? e.getCause() : e;
                throw failure(Code.UNAVAILABLE, "cannot connect to " + uri + ": " + cause);
            }
            ws = w;
            sends = CompletableFuture.completedFuture(null);
            log.info("Connected to {} in {} ms", uri, millis(t0));
            return w;
        }

        BlockingQueue<Frame> register(long id) {
            BlockingQueue<Frame> q = new LinkedBlockingQueue<>();
            pending.put(id, q);
            return q;
        }

        void unregister(long id) {
            pending.remove(id);
        }

        Frame call(Frame request, Duration timeout) {
            open();
            BlockingQueue<Frame> q = register(request.id());
            try {
                send(request);
                Frame f = poll(q, System.nanoTime() + timeout.toNanos());
                if (f == null) {
                    trySend(new Cancel(request.id()));
                    throw failure(Code.DEADLINE_EXCEEDED, request.getClass().getSimpleName() + " to " + uri
                            + " exceeded " + timeout);
                }
                return f;
            } finally {
                unregister(request.id());
            }
        }

        /** The JDK WebSocket allows one outstanding send: chain them. */
        void send(Frame f) {
            byte[] bytes = KryoCodec.encode(f, maxBytes);
            WebSocket w = open();
            CompletableFuture<?> done;
            synchronized (this) {
                sends = sends.handle((x, e) -> null).thenCompose(x -> w.sendBinary(ByteBuffer.wrap(bytes), true));
                done = sends;
            }
            try {
                done.get(cfg.deadlineOrDefault().toMillis() + 5_000, TimeUnit.MILLISECONDS);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                throw new IllegalStateException("Interrupted sending to " + uri, e);
            } catch (Exception e) {
                w.abort();
                throw failure(Code.UNAVAILABLE, "send to " + uri + " failed: " + (e.getCause() != null ? e.getCause() : e));
            }
        }

        void trySend(Frame f) {
            try {
                send(f);
            } catch (RuntimeException e) {
                log.debug("Could not send {} to {}: {}", f, uri, e.getMessage());
            }
        }

        void close() {
            closing = true;
            WebSocket w = ws;
            if (w == null) return;
            try {
                w.sendClose(WebSocket.NORMAL_CLOSURE, "client closing").get(2, TimeUnit.SECONDS);
            } catch (Exception e) {
                w.abort();
            }
            failAll("client closed");
        }

        // ---- listener (JDK HttpClient thread)

        @Override
        public void onOpen(WebSocket w) {
            w.request(1);
        }

        @Override
        public CompletionStage<?> onBinary(WebSocket w, ByteBuffer data, boolean last) {
            if (partial == null) partial = new ByteArrayOutputStream(Math.max(256, data.remaining()));
            byte[] chunk = new byte[data.remaining()];
            data.get(chunk);
            partial.write(chunk, 0, chunk.length);
            if (partial.size() > maxBytes) {
                log.error("Message from {} exceeds max-message-size-mb {}; closing", uri, cfg.maxMessageSizeMbOrDefault());
                partial = null;
                w.abort();
                failAll("message larger than max-message-size-mb");
                return null;
            }
            if (last) {
                byte[] message = partial.toByteArray();
                partial = null;
                dispatch(message);
            }
            w.request(1);
            return null;
        }

        private void dispatch(byte[] message) {
            Frame f;
            try {
                f = KryoCodec.decode(message);
            } catch (RuntimeException e) {
                log.error("Undecodable message from {} ({} bytes): {}", uri, message.length, e.getMessage());
                return;
            }
            BlockingQueue<Frame> q = pending.get(f.id());
            if (q != null) q.add(f);
            else log.debug("Late {} from {} for call {} (already finished)", f.getClass().getSimpleName(), uri, f.id());
        }

        @Override
        public CompletionStage<?> onClose(WebSocket w, int statusCode, String reason) {
            if (closing) log.debug("Connection to {} closed: {} {}", uri, statusCode, reason);
            else log.warn("Connection to {} closed by server: {} {}", uri, statusCode, reason);
            failAll("connection closed: " + statusCode + " " + reason);
            return null;
        }

        @Override
        public void onError(WebSocket w, Throwable error) {
            if (!closing) log.warn("Connection to {} failed: {}", uri, error.toString());
            failAll("connection error: " + error);
        }

        private void failAll(String why) {
            pending.forEach((id, q) -> q.add(new Failure(id, Code.UNAVAILABLE, uri + " " + why)));
        }
    }
}
