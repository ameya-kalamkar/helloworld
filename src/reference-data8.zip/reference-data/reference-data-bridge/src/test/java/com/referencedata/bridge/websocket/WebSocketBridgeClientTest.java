package com.referencedata.bridge.websocket;

import com.referencedata.bridge.websocket.KryoCodec.Cancel;
import com.referencedata.bridge.websocket.KryoCodec.Code;
import com.referencedata.bridge.websocket.KryoCodec.Credit;
import com.referencedata.bridge.websocket.KryoCodec.Datasets;
import com.referencedata.bridge.websocket.KryoCodec.Failure;
import com.referencedata.bridge.websocket.KryoCodec.FindAll;
import com.referencedata.bridge.websocket.KryoCodec.FindByKeys;
import com.referencedata.bridge.websocket.KryoCodec.Frame;
import com.referencedata.bridge.websocket.KryoCodec.Health;
import com.referencedata.bridge.websocket.KryoCodec.ListDatasets;
import com.referencedata.bridge.websocket.KryoCodec.Rows;
import com.referencedata.bridge.websocket.KryoCodec.Status;
import com.referencedata.core.ReferenceDataConfig;
import com.referencedata.core.ReferenceLoader;
import org.junit.jupiter.api.Test;

import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.atomic.AtomicInteger;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * The real JDK WebSocket client against a minimal RFC 6455 server written here (no Spring, no network beyond
 * localhost) that speaks the Kryo frames like WebSocketBridgeServer: health, multiplexing, chunked FindAll with credit,
 * errors, deadlines and reconnect.
 */
class WebSocketBridgeClientTest {

    static final Map<String, List<Map<String, Object>>> CCY = new LinkedHashMap<>();
    static {
        for (String c : List.of("USD", "EUR", "JPY", "GBP", "CAD", "CHF", "AUD")) {
            CCY.put(c, List.of(Map.of("ccy_code", c, "decimals", c.equals("JPY") ? 0L : 2L, "tags", List.of("g10"))));
        }
    }

    /** Fake reference-data-server: answers like WebSocketBridgeServer and records what it received. */
    static final class FakeServer implements AutoCloseable {
        final ServerSocket socket = new ServerSocket(0);
        final List<Frame> received = Collections.synchronizedList(new ArrayList<>());
        final AtomicInteger notServingAnswers = new AtomicInteger(2);
        final List<Socket> connections = Collections.synchronizedList(new ArrayList<>());
        final Map<Long, Iterator<Map.Entry<String, List<Map<String, Object>>>>> streams = new java.util.concurrent.ConcurrentHashMap<>();

        FakeServer() throws IOException {
            Thread t = new Thread(() -> {
                while (!socket.isClosed()) {
                    try {
                        Socket s = socket.accept();
                        connections.add(s);
                        Thread c = new Thread(() -> serve(s));
                        c.setDaemon(true);
                        c.start();
                    } catch (IOException e) {
                        return;
                    }
                }
            });
            t.setDaemon(true);
            t.start();
        }

        String uri() {
            return "ws://localhost:" + socket.getLocalPort() + "/reference-data";
        }

        void dropConnections() throws IOException {
            for (Socket s : new ArrayList<>(connections)) s.close();
            connections.clear();
        }

        @Override
        public void close() throws IOException {
            socket.close();
            dropConnections();
        }

        private void serve(Socket s) {
            try (s) {
                InputStream in = s.getInputStream();
                OutputStream out = s.getOutputStream();
                handshake(in, out);
                DataInputStream din = new DataInputStream(in);
                ByteArrayOutputStream message = new ByteArrayOutputStream();
                while (true) {
                    int b0 = din.readUnsignedByte(), b1 = din.readUnsignedByte();
                    int opcode = b0 & 0x0F;
                    long len = b1 & 0x7F;
                    if (len == 126) len = din.readUnsignedShort();
                    else if (len == 127) len = din.readLong();
                    byte[] mask = new byte[4];
                    if ((b1 & 0x80) != 0) din.readFully(mask);
                    byte[] payload = new byte[(int) len];
                    din.readFully(payload);
                    for (int i = 0; i < payload.length; i++) payload[i] ^= mask[i % 4];
                    if (opcode == 8) {                                   // close
                        send(out, 8, payload);
                        return;
                    }
                    if (opcode == 9) {                                   // ping
                        send(out, 10, payload);
                        continue;
                    }
                    message.write(payload);
                    if ((b0 & 0x80) == 0) continue;                      // more fragments follow
                    Frame f = KryoCodec.decode(message.toByteArray());
                    message.reset();
                    received.add(f);
                    answer(f, out);
                }
            } catch (IOException e) {
                // connection dropped
            }
        }

        private void answer(Frame f, OutputStream out) throws IOException {
            if (f instanceof Health h) {
                reply(out, new Status(h.id(), notServingAnswers.getAndDecrement() <= 0));
            } else if (f instanceof ListDatasets l) {
                reply(out, new Datasets(l.id(), List.of("currency", "holiday")));
            } else if (f instanceof FindByKeys r) {
                if (r.dataset().equals("slow")) return;                  // never answers: client deadline
                if (!r.dataset().equals("currency")) {
                    reply(out, new Failure(r.id(), Code.NOT_FOUND, "Unknown dataset '" + r.dataset() + "'"));
                    return;
                }
                Map<String, List<Map<String, Object>>> found = new LinkedHashMap<>();
                for (String k : r.keys()) if (CCY.containsKey(k)) found.put(k, CCY.get(k));
                reply(out, new Rows(r.id(), found, true));
            } else if (f instanceof FindAll r) {
                streams.put(r.id(), CCY.entrySet().iterator());
                for (int i = 0; i < r.window(); i++) if (!sendChunk(out, r.id())) break;
            } else if (f instanceof Credit c) {
                for (int i = 0; i < c.chunks(); i++) if (!sendChunk(out, c.id())) break;
            }
        }

        private boolean sendChunk(OutputStream out, long id) throws IOException {
            Iterator<Map.Entry<String, List<Map<String, Object>>>> it = streams.get(id);
            if (it == null) return false;
            byte[] chunk = KryoCodec.encodeChunk(id, it, 2, KryoCodec.MAX_CHUNK_BYTES, 1 << 20);
            if (!it.hasNext()) streams.remove(id);
            send(out, 2, chunk);
            return it.hasNext();
        }

        private void reply(OutputStream out, Frame f) throws IOException {
            send(out, 2, KryoCodec.encode(f, 1 << 20));
        }

        private static synchronized void send(OutputStream out, int opcode, byte[] payload) throws IOException {
            synchronized (out) {
                out.write(0x80 | opcode);
                if (payload.length < 126) {
                    out.write(payload.length);
                } else if (payload.length < 65_536) {
                    out.write(126);
                    out.write(payload.length >>> 8);
                    out.write(payload.length & 0xFF);
                } else {
                    out.write(127);
                    for (int i = 7; i >= 0; i--) out.write((int) ((long) payload.length >>> (8 * i)) & 0xFF);
                }
                out.write(payload);
                out.flush();
            }
        }

        private static void handshake(InputStream in, OutputStream out) throws IOException {
            StringBuilder req = new StringBuilder();
            while (!req.toString().endsWith("\r\n\r\n")) {
                int c = in.read();
                if (c < 0) throw new IOException("closed during handshake");
                req.append((char) c);
            }
            String key = null;
            for (String line : req.toString().split("\r\n")) {
                if (line.toLowerCase().startsWith("sec-websocket-key:")) key = line.substring(18).trim();
            }
            try {
                String accept = Base64.getEncoder().encodeToString(MessageDigest.getInstance("SHA-1")
                        .digest((key + "258EAFA5-E914-47DA-95CA-C5AB0DC85B11").getBytes(StandardCharsets.US_ASCII)));
                out.write(("HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\n"
                        + "Sec-WebSocket-Accept: " + accept + "\r\n\r\n").getBytes(StandardCharsets.US_ASCII));
                out.flush();
            } catch (java.security.NoSuchAlgorithmException e) {
                throw new IOException(e);
            }
        }

        long count(Class<? extends Frame> type) {
            synchronized (received) {
                return received.stream().filter(type::isInstance).count();
            }
        }
    }

    /** Frames the client sent without waiting for an answer arrive asynchronously. */
    static void awaitCount(FakeServer server, Class<? extends Frame> type, long expected) throws InterruptedException {
        for (int i = 0; i < 50 && server.count(type) < expected; i++) Thread.sleep(20);
        assertEquals(expected, server.count(type), type.getSimpleName());
    }

    static ReferenceDataConfig.Delegate delegate(String target) {
        return new ReferenceDataConfig.Delegate("websocket", target, "1s", "10s", "20s", null, 64, 2, 2);
    }

    @Test
    void healthDatasetsLookupsAndChunkedFindAllWithCredit() throws Exception {
        try (FakeServer server = new FakeServer();
             WebSocketBridgeClient client = new WebSocketBridgeClient(delegate(server.uri()))) {
            client.awaitReady();                                          // NOT_SERVING twice, then SERVING
            assertEquals(3, server.count(Health.class));
            assertEquals(Set.of("currency", "holiday"), client.listDatasets());

            ReferenceLoader ccy = client.loader("currency");
            Map<String, List<Map<String, Object>>> some = ccy.loadByKeys(List.of("USD", "JPY", "XXX", "EUR", "GBP"));
            assertEquals(List.of("USD", "JPY", "EUR", "GBP"), List.copyOf(some.keySet()));
            assertEquals(0L, some.get("JPY").get(0).get("decimals"));
            assertEquals(List.of("g10"), some.get("USD").get(0).get("tags"));
            assertEquals(3, server.count(FindByKeys.class));              // 5 keys, max-keys-per-call 2

            Map<String, List<Map<String, Object>>> all = ccy.loadAll();   // 7 keys, 2 per chunk -> 4 chunks
            assertEquals(CCY, all);
            assertEquals(1, server.count(FindAll.class));
            awaitCount(server, Credit.class, 3);                          // one credit per non-last chunk
            FindAll fa = (FindAll) server.received.stream().filter(FindAll.class::isInstance).findFirst().orElseThrow();
            assertEquals(2, fa.window());
        }
    }

    @Test
    void errorsDeadlinesAndReconnect() throws Exception {
        try (FakeServer server = new FakeServer()) {
            server.notServingAnswers.set(0);
            try (WebSocketBridgeClient client = new WebSocketBridgeClient(delegate(server.uri()))) {
                client.awaitReady();
                IllegalStateException nf = assertThrows(IllegalStateException.class,
                        () -> client.loader("nope").loadByKey("USD"));
                assertTrue(nf.getMessage().startsWith("NOT_FOUND"), nf.getMessage());

                long t0 = System.nanoTime();
                IllegalStateException slow = assertThrows(IllegalStateException.class,
                        () -> client.loader("slow").loadByKey("USD"));
                assertTrue(slow.getMessage().startsWith("DEADLINE_EXCEEDED"), slow.getMessage());
                assertTrue((System.nanoTime() - t0) / 1_000_000 < 3_000);
                awaitCount(server, Cancel.class, 1);                      // server told to stop

                server.dropConnections();                                 // server side goes away
                Thread.sleep(300);
                assertEquals(List.of(Map.of("ccy_code", "EUR", "decimals", 2L, "tags", List.of("g10"))),
                        client.loader("currency").loadByKey("EUR"));      // reopened transparently
            }
        }
    }

    @Test
    void severalServersAreUsedRoundRobinAndADownOneIsSkipped() throws Exception {
        try (FakeServer a = new FakeServer(); FakeServer b = new FakeServer()) {
            a.notServingAnswers.set(0);
            b.notServingAnswers.set(0);
            String down = "ws://localhost:1/reference-data";
            try (WebSocketBridgeClient client = new WebSocketBridgeClient(delegate(a.uri() + "," + down + "," + b.uri()))) {
                client.awaitReady();
                for (int i = 0; i < 6; i++) client.loader("currency").loadByKey("USD");
                assertTrue(a.count(FindByKeys.class) >= 2 && b.count(FindByKeys.class) >= 2,
                        a.count(FindByKeys.class) + " / " + b.count(FindByKeys.class));
                assertEquals(6, a.count(FindByKeys.class) + b.count(FindByKeys.class));
            }
        }
    }
}
