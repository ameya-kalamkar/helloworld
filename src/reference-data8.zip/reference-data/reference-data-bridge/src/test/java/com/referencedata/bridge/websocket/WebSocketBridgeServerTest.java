package com.referencedata.bridge.websocket;

import com.referencedata.bridge.BridgeServer;
import com.referencedata.bridge.websocket.KryoCodec.Cancel;
import com.referencedata.bridge.websocket.KryoCodec.Code;
import com.referencedata.bridge.websocket.KryoCodec.Credit;
import com.referencedata.bridge.websocket.KryoCodec.Datasets;
import com.referencedata.bridge.websocket.KryoCodec.Failure;
import com.referencedata.bridge.websocket.KryoCodec.FindAll;
import com.referencedata.bridge.websocket.KryoCodec.FindByKeys;
import com.referencedata.bridge.websocket.KryoCodec.Frame;
import com.referencedata.bridge.websocket.KryoCodec.Health;
import com.referencedata.bridge.websocket.KryoCodec.ListDatasets;
import com.referencedata.bridge.websocket.KryoCodec.Rows;
import com.referencedata.bridge.websocket.KryoCodec.Status;
import com.referencedata.core.ReferenceDataConfig;
import com.referencedata.core.ReferenceRepository;
import org.junit.jupiter.api.Test;
import org.springframework.web.socket.BinaryMessage;
import org.springframework.web.socket.CloseStatus;
import org.springframework.web.socket.WebSocketSession;

import java.lang.reflect.Proxy;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

/** Drives the Spring WebSocket handler directly: readiness, lookups, error codes, FindAll credit, cancel. */
class WebSocketBridgeServerTest {

    static final Map<String, List<Map<String, Object>>> DATA = new LinkedHashMap<>();
    static {
        for (String k : List.of("A", "B", "C", "D", "E")) DATA.put(k, List.of(Map.of("k", k)));
    }

    static final BridgeServer.Handler HANDLER = new BridgeServer.Handler() {
        public Set<String> datasets() { return Set.of("ds", "broken"); }

        public Map<String, List<Map<String, Object>>> findByKeys(String dataset, Collection<String> keys) {
            check(dataset);
            Map<String, List<Map<String, Object>>> out = new LinkedHashMap<>();
            for (String k : keys) if (DATA.containsKey(k)) out.put(k, DATA.get(k));
            return out;
        }

        public Map<String, List<Map<String, Object>>> findAll(String dataset) {
            check(dataset);
            return DATA;
        }

        private void check(String dataset) {
            if (dataset.equals("broken")) throw new ReferenceRepository.LoadException(dataset, "loadByKeys", new IllegalStateException("db down"));
            if (!dataset.equals("ds")) throw new IllegalArgumentException("Unknown dataset '" + dataset + "'");
        }
    };

    /** A session that records what the server sends. */
    static WebSocketSession session(BlockingQueue<Frame> sent) {
        return (WebSocketSession) Proxy.newProxyInstance(WebSocketSession.class.getClassLoader(), new Class<?>[] {WebSocketSession.class},
                (proxy, m, args) -> switch (m.getName()) {
                    case "getId" -> "s1";
                    case "isOpen" -> true;
                    case "sendMessage" -> {
                        sent.add(KryoCodec.decode(((BinaryMessage) args[0]).getPayload()));
                        yield null;
                    }
                    case "getBinaryMessageSizeLimit", "getTextMessageSizeLimit" -> 0;
                    case "hashCode" -> System.identityHashCode(proxy);
                    case "equals" -> proxy == args[0];
                    case "toString" -> "session s1";
                    default -> null;
                });
    }

    static void send(WebSocketBridgeServer server, WebSocketSession s, Frame f) throws Exception {
        server.handleMessage(s, new BinaryMessage(KryoCodec.encode(f, 1 << 20)));
    }

    static Frame next(BlockingQueue<Frame> sent) throws InterruptedException {
        Frame f = sent.poll(2, TimeUnit.SECONDS);
        if (f == null) throw new AssertionError("no frame sent");
        return f;
    }

    @Test
    void readinessLookupsErrorsAndFlowControlledFindAll() throws Exception {
        WebSocketBridgeServer server = new WebSocketBridgeServer(
                new ReferenceDataConfig.Endpoint(null, null, null, 2, 2, null, null), HANDLER);
        server.start();
        BlockingQueue<Frame> sent = new LinkedBlockingQueue<>();
        WebSocketSession s = session(sent);
        server.afterConnectionEstablished(s);
        try {
            send(server, s, new Health(1));
            assertEquals(new Status(1, false), next(sent));
            send(server, s, new FindByKeys(2, "ds", List.of("A")));
            assertEquals(Code.UNAVAILABLE, ((Failure) next(sent)).code());       // still preloading

            server.markServing();
            send(server, s, new Health(3));
            assertEquals(new Status(3, true), next(sent));
            send(server, s, new ListDatasets(4));
            assertEquals(Set.of("ds", "broken"), Set.copyOf(((Datasets) next(sent)).names()));

            send(server, s, new FindByKeys(5, "ds", List.of("A", "Z", "C")));
            Rows r = (Rows) next(sent);
            assertEquals(List.of("A", "C"), List.copyOf(r.entries().keySet()));
            assertTrue(r.last());
            send(server, s, new FindByKeys(6, "nope", List.of("A")));
            assertEquals(Code.NOT_FOUND, ((Failure) next(sent)).code());
            send(server, s, new FindByKeys(7, "broken", List.of("A")));
            assertEquals(Code.UNAVAILABLE, ((Failure) next(sent)).code());
            server.handleMessage(s, new BinaryMessage(new byte[] {42}));
            assertEquals(Code.BAD_REQUEST, ((Failure) next(sent)).code());

            // FindAll: 5 keys, 2 per chunk -> 3 chunks; window 1 means one chunk per credit
            send(server, s, new FindAll(8, "ds", 1));
            Rows c1 = (Rows) next(sent);
            assertEquals(List.of("A", "B"), List.copyOf(c1.entries().keySet()));
            assertFalse(c1.last());
            assertNull(sent.poll(200, TimeUnit.MILLISECONDS));                 // no credit, nothing more
            send(server, s, new Credit(8, 1));
            assertEquals(List.of("C", "D"), List.copyOf(((Rows) next(sent)).entries().keySet()));
            send(server, s, new Credit(8, 1));
            Rows c3 = (Rows) next(sent);
            assertEquals(List.of("E"), List.copyOf(c3.entries().keySet()));
            assertTrue(c3.last());

            // cancel stops a stream
            send(server, s, new FindAll(9, "ds", 1));
            assertEquals(9, next(sent).id());
            send(server, s, new Cancel(9));
            send(server, s, new Credit(9, 5));
            assertNull(sent.poll(200, TimeUnit.MILLISECONDS));
        } finally {
            server.afterConnectionClosed(s, CloseStatus.NORMAL);
            server.stop();
        }
    }
}
