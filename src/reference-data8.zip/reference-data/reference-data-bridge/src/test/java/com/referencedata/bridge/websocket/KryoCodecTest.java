package com.referencedata.bridge.websocket;

import com.referencedata.bridge.websocket.KryoCodec.Code;
import com.referencedata.bridge.websocket.KryoCodec.Credit;
import com.referencedata.bridge.websocket.KryoCodec.Datasets;
import com.referencedata.bridge.websocket.KryoCodec.Failure;
import com.referencedata.bridge.websocket.KryoCodec.FindAll;
import com.referencedata.bridge.websocket.KryoCodec.FindByKeys;
import com.referencedata.bridge.websocket.KryoCodec.Frame;
import com.referencedata.bridge.websocket.KryoCodec.Health;
import com.referencedata.bridge.websocket.KryoCodec.Rows;
import com.referencedata.bridge.websocket.KryoCodec.Status;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

class KryoCodecTest {

    private static final int MAX = 64 * 1024 * 1024;

    private static Frame roundTrip(Frame f) {
        return KryoCodec.decode(KryoCodec.encode(f, MAX));
    }

    @Test
    void controlFramesRoundTrip() {
        for (Frame f : List.<Frame>of(new Health(1), new Status(2, true), new Status(3, false),
                new Datasets(4, List.of("currency", "holiday")), new FindByKeys(5, "holiday", List.of("USNY", "CATO")),
                new FindAll(6, "currency", 4), new Credit(7, 1), new KryoCodec.Cancel(8),
                new Failure(9, Code.NOT_FOUND, "Unknown dataset 'x'"), new Failure(10, Code.UNAVAILABLE, null))) {
            assertEquals(f, roundTrip(f));
        }
    }

    @Test
    void rowsKeepEveryValueTypeOrderAndNesting() {
        Map<String, Object> row = new LinkedHashMap<>();
        row.put("id", 42L);
        row.put("neg", -7L);
        row.put("name", "Yen ¥");
        row.put("rate", new BigDecimal("-1234567890.123456789000"));       // scale kept exactly
        row.put("big", new BigDecimal("1E+30"));
        row.put("ratio", 0.25d);
        row.put("active", true);
        row.put("closed", false);
        row.put("blob", new byte[] {0, -1, 127});
        row.put("none", null);
        row.put("tags", List.of("a", List.of(1L, 2L)));
        row.put("head", Map.of("name", "J. Patel"));
        Map<String, List<Map<String, Object>>> entries = new LinkedHashMap<>();
        entries.put("JPY", List.of(row, Map.of("x", 1L)));
        entries.put("USD", List.of());

        Rows back = (Rows) roundTrip(new Rows(11, entries, true));
        assertEquals(11L, back.id());
        assertTrue(back.last());
        assertEquals(List.of("JPY", "USD"), List.copyOf(back.entries().keySet()));
        Map<String, Object> r = back.entries().get("JPY").get(0);
        assertEquals(List.copyOf(row.keySet()), List.copyOf(r.keySet()));
        for (String k : row.keySet()) {
            if (k.equals("blob")) assertTrue(Arrays.equals((byte[]) row.get(k), (byte[]) r.get(k)));
            else assertEquals(row.get(k), r.get(k), k);
        }
        assertEquals(new BigDecimal("-1234567890.123456789000").scale(), ((BigDecimal) r.get("rate")).scale());
        assertThrows(UnsupportedOperationException.class, () -> ((Map<String, Object>) r.get("head")).put("x", 1));
    }

    @Test
    void findAllChunksRespectKeyLimitAndFinishWithLast() {
        Map<String, List<Map<String, Object>>> all = new LinkedHashMap<>();
        for (int i = 0; i < 7; i++) all.put("k" + i, List.of(Map.of("v", (long) i)));
        Iterator<Map.Entry<String, List<Map<String, Object>>>> it = all.entrySet().iterator();
        List<Rows> chunks = new ArrayList<>();
        do {
            chunks.add((Rows) KryoCodec.decode(KryoCodec.encodeChunk(99, it, 3, KryoCodec.MAX_CHUNK_BYTES, MAX)));
        } while (!chunks.get(chunks.size() - 1).last());
        assertEquals(3, chunks.size());
        assertEquals(List.of(3, 3, 1), chunks.stream().map(c -> c.entries().size()).toList());
        assertFalse(chunks.get(0).last());
        Map<String, List<Map<String, Object>>> merged = new LinkedHashMap<>();
        chunks.forEach(c -> merged.putAll(c.entries()));
        assertEquals(all, merged);
        assertTrue(chunks.stream().allMatch(c -> c.id() == 99));
    }

    @Test
    void byteLimitCutsChunksAndOversizedMessagesFail() {
        Map<String, List<Map<String, Object>>> all = new LinkedHashMap<>();
        String big = "x".repeat(600);
        for (int i = 0; i < 10; i++) all.put("k" + i, List.of(Map.of("v", big)));
        Iterator<Map.Entry<String, List<Map<String, Object>>>> it = all.entrySet().iterator();
        Rows first = (Rows) KryoCodec.decode(KryoCodec.encodeChunk(1, it, 500, 1500, MAX));
        assertEquals(3, first.entries().size());                    // cut once ~1.5 KB is written

        assertThrows(IllegalStateException.class, () -> KryoCodec.encode(new Rows(1, all, true), 1024));
        assertThrows(IllegalArgumentException.class, () -> KryoCodec.decode(new byte[] {9, 1, 2}));   // wrong version
    }
}
