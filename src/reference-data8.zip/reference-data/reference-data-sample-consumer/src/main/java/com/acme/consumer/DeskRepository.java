package com.acme.consumer;

import com.referencedata.core.ReferenceRepository;

import java.util.List;

/**
 * This app's own reference data, same behaviour as the pre-built DAOs: extend ReferenceRepository.
 * Rows may be nested: {@code head} is a JSON-like object and {@code books} a list, mapped by Jackson.
 */
public class DeskRepository extends ReferenceRepository<DeskRepository.Desk, String> {

    public record Desk(String deskId, String name, String region, Person head, List<String> books) {}

    public record Person(String name, String email) {}

    public DeskRepository() {
        super("desk", Desk.class);
    }
}
