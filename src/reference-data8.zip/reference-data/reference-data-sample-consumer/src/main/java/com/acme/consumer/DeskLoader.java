package com.acme.consumer;

import com.referencedata.core.ReferenceLoader;
import com.referencedata.core.RowValues;
import lombok.extern.slf4j.Slf4j;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * This app's own source: implement ReferenceLoader (here a fixed list; normally a DB, REST or gRPC call).
 * Rows go through {@link RowValues#normalize} so nested values (maps, lists) have the same shape as over the bridge.
 */
@Slf4j
public class DeskLoader implements ReferenceLoader {

    private static final Map<String, List<Map<String, Object>>> DESKS = new LinkedHashMap<>();
    static {
        put(Map.of("desk_id", "FX-TOR", "name", "FX Toronto", "region", "AMER",
                "head", Map.of("name", "A. Martin", "email", "a.martin@example.com"),
                "books", List.of("FXSPOT-TOR", "FXFWD-TOR")));
        put(Map.of("desk_id", "RATES-LDN", "name", "Rates London", "region", "EMEA",
                "head", Map.of("name", "J. Patel", "email", "j.patel@example.com"),
                "books", List.of("GILTS", "SWAPS-GBP", "SWAPS-EUR")));
    }

    private static void put(Map<String, Object> raw) {
        Map<String, Object> row = RowValues.normalize(raw);
        DESKS.put((String) row.get("desk_id"), List.of(row));
    }

    @Override
    public Map<String, List<Map<String, Object>>> loadAll() {
        log.debug("loadAll: {} desks", DESKS.size());
        return DESKS;
    }

    @Override
    public List<Map<String, Object>> loadByKey(String key) {
        log.debug("loadByKey({})", key);
        return DESKS.getOrDefault(key, List.of());
    }
}
