package com.acme.consumer;

import com.referencedata.client.spring.ReferenceDataClientConfiguration;
import com.referencedata.core.ReferenceLoader;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;

/**
 * Plain Spring, no Boot. One @Import wires the client; the pre-built DAOs named in reference-data-client.json
 * become beans automatically. Our own DAO and loader are ordinary beans the config refers to by name.
 */
@Configuration
@ComponentScan
@Import(ReferenceDataClientConfiguration.class)
public class AppConfig {

    @Bean
    DeskRepository deskRepository() {
        return new DeskRepository();
    }

    @Bean
    ReferenceLoader deskLoader() {
        return new DeskLoader();
    }
}
