package com.acme.consumer;

import com.referencedata.client.datasets.CountryRepository;
import com.referencedata.client.datasets.CurrencyRepository;
import com.referencedata.client.datasets.HolidayRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;

@Slf4j
@Service
@RequiredArgsConstructor
public class PricingService {

    private final CurrencyRepository currencies;
    private final HolidayRepository holidays;
    private final CountryRepository countries;
    private final DeskRepository desks;

    public void demo() {
        log.info("All currencies:  {}", currencies.findAll());
        log.info("JPY decimals:    {}", currencies.decimals("JPY"));
        holidays.findAllByKeys(List.of("USNY", "CATO", "XXXX")).forEach((k, v) -> log.info("Holidays {}:   {}", k, v));
        log.info("CATO 2026-12-28: {}", holidays.isHoliday("CATO", LocalDate.of(2026, 12, 28)));
        log.info("Country CA:      {}", countries.findByKey("CA"));
        log.info("Desk FX-TOR:     {}", desks.findByKey("FX-TOR"));   // nested head + books
    }
}
