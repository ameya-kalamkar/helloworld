package com.acme.consumer;

import com.referencedata.client.ReferenceDataClient;
import com.referencedata.client.datasets.CurrencyRepository;
import com.referencedata.client.datasets.HolidayRepository;
import lombok.extern.slf4j.Slf4j;

import java.util.List;
import java.util.Map;

/**
 * No Spring, as in Flink RichFunction.open() or Spark mapPartitions: same JSON, same DAOs. init() is once per JVM,
 * so every task slot shares one client. Our own DAO and loader are passed by the names the config uses.
 */
@Slf4j
public class PlainJavaExample {

    public static void main(String[] args) {
        try (ReferenceDataClient client = ReferenceDataClient.init(null,
                Map.of("deskRepository", new DeskRepository(), "deskLoader", new DeskLoader()))) {
            CurrencyRepository currencies = client.repository(CurrencyRepository.class);
            HolidayRepository holidays = client.repository(HolidayRepository.class);
            log.info("USD:      {}", currencies.findByKey("USD"));
            log.info("Holidays: {}", holidays.findAllByKeys(List.of("USNY", "CATO")));
            log.info("Desk:     {}", client.repository(DeskRepository.class).findByKey("RATES-LDN"));
        }
    }
}
