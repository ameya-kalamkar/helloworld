package com.acme.consumer;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

/** Start reference-data-server first; it must be SERVING. REFDATA_SERVER points elsewhere. */
public class ConsumerApp {

    public static void main(String[] args) {
        try (AnnotationConfigApplicationContext ctx = new AnnotationConfigApplicationContext(AppConfig.class)) {
            ctx.getBean(PricingService.class).demo();
        }
    }
}
