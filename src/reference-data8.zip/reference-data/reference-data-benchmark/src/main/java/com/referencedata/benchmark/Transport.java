package com.referencedata.benchmark;

import com.referencedata.benchmark.Codecs.Codec;

import java.util.concurrent.ExecutorService;
import java.util.function.Consumer;

/** A client/server pair on localhost carrying one codec's messages. */
public interface Transport extends AutoCloseable {

    String name();

    /** Starts the server, answering from {@code codec}; request work runs on {@code workers}. */
    void start(Codec codec, ExecutorService workers) throws Exception;

    Client connect() throws Exception;

    /** One connection; thread-safe, calls multiplexed. */
    interface Client extends AutoCloseable {

        /** Items [from, from + count) as one message. */
        byte[] lookup(int from, int count) throws Exception;

        /** Items [from, from + total) streamed in messages of {@code chunk} items, with flow control; returns bytes received. */
        long stream(int from, int total, int chunk, Consumer<byte[]> each) throws Exception;
    }
}
