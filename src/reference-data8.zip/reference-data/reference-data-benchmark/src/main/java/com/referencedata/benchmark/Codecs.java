package com.referencedata.benchmark;

import com.esotericsoftware.kryo.Kryo;
import com.esotericsoftware.kryo.io.Input;
import com.esotericsoftware.kryo.io.Output;
import com.esotericsoftware.kryo.util.Pool;
import com.google.protobuf.ByteString;
import com.google.protobuf.InvalidProtocolBufferException;
import com.referencedata.benchmark.Model.Instrument;
import com.referencedata.benchmark.Model.Issuer;
import com.referencedata.benchmark.proto.Decimal;
import com.referencedata.benchmark.proto.InstrumentBatch;
import com.referencedata.benchmark.proto.InstrumentMsg;
import com.referencedata.benchmark.proto.IssuerMsg;
import com.referencedata.bridge.grpc.RowCodecAccess;
import com.referencedata.bridge.grpc.v1.KeyRows;
import com.referencedata.bridge.grpc.v1.KeyRowsChunk;
import com.referencedata.bridge.websocket.KryoCodecAccess;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;

/**
 * The four ways of putting a batch of {@link Instrument}s on the wire.
 * <ul>
 *   <li>{@code protobuf}: typed messages generated from {@code benchmark.proto}; records converted to/from messages.</li>
 *   <li>{@code kryo}: Kryo 5 serializing the records themselves (registered classes, RecordSerializer).</li>
 *   <li>{@code protobuf-rows}: the gRPC bridge today: generic rows ({@code RowCodec}), then rows mapped to records
 *       with Jackson on the client.</li>
 *   <li>{@code kryo-rows}: the WebSocket bridge today: generic rows ({@code KryoCodec}), then Jackson mapping.</li>
 * </ul>
 * The server side holds what it would really hold: records for the typed codecs, normalised rows for the row codecs.
 */
public final class Codecs {

    private Codecs() {}

    public static final int MAX_MESSAGE = 64 * 1024 * 1024;

    /** One serialization strategy: server state + encode a slice; client decode back to records. */
    public abstract static class Codec {
        public abstract String name();

        /** Server: build whatever this codec serves from (once, outside timing). */
        public abstract void load(List<Instrument> all);

        /** Server: items [from, to) as one message. */
        public abstract byte[] encode(int from, int to);

        /** Client: one message back to application objects. */
        public abstract List<Instrument> decode(byte[] bytes);

        @Override
        public String toString() {
            return name();
        }
    }

    public static List<Codec> all() {
        return List.of(new ProtobufTyped(), new KryoTyped(), new ProtobufRows(), new KryoRows());
    }

    // ------------------------------------------------------------------ protobuf, typed

    public static final class ProtobufTyped extends Codec {
        private List<Instrument> items;

        public String name() { return "protobuf"; }

        public void load(List<Instrument> all) { items = all; }

        public byte[] encode(int from, int to) {
            InstrumentBatch.Builder b = InstrumentBatch.newBuilder();
            for (int i = from; i < to; i++) b.addItems(toMsg(items.get(i)));
            return b.build().toByteArray();
        }

        public List<Instrument> decode(byte[] bytes) {
            try {
                InstrumentBatch batch = InstrumentBatch.parseFrom(bytes);
                List<Instrument> out = new ArrayList<>(batch.getItemsCount());
                for (InstrumentMsg m : batch.getItemsList()) out.add(fromMsg(m));
                return out;
            } catch (InvalidProtocolBufferException e) {
                throw new IllegalStateException(e);
            }
        }

        static InstrumentMsg toMsg(Instrument x) {
            Issuer s = x.issuer();
            return InstrumentMsg.newBuilder()
                    .setInstrumentId(x.instrumentId()).setSymbol(x.symbol()).setIsin(x.isin())
                    .setCurrency(x.currency()).setExchange(x.exchange())
                    .setTickSize(decimal(x.tickSize())).setNotional(decimal(x.notional()))
                    .setLotSize(x.lotSize()).setMaturityEpochDay(x.maturity().toEpochDay())
                    .setActive(x.active()).setRating(x.rating()).addAllTags(x.tags())
                    .setIssuer(IssuerMsg.newBuilder().setIssuerId(s.issuerId()).setName(s.name()).setCountry(s.country()))
                    .build();
        }

        static Instrument fromMsg(InstrumentMsg m) {
            IssuerMsg s = m.getIssuer();
            return new Instrument(m.getInstrumentId(), m.getSymbol(), m.getIsin(), m.getCurrency(), m.getExchange(),
                    decimal(m.getTickSize()), decimal(m.getNotional()), m.getLotSize(),
                    LocalDate.ofEpochDay(m.getMaturityEpochDay()), m.getActive(), m.getRating(),
                    new ArrayList<>(m.getTagsList()), new Issuer(s.getIssuerId(), s.getName(), s.getCountry()));
        }

        static Decimal decimal(BigDecimal d) {
            return Decimal.newBuilder().setUnscaled(ByteString.copyFrom(d.unscaledValue().toByteArray())).setScale(d.scale()).build();
        }

        static BigDecimal decimal(Decimal d) {
            return new BigDecimal(new BigInteger(d.getUnscaled().toByteArray()), d.getScale());
        }
    }

    // ------------------------------------------------------------------ Kryo, typed

    public static final class KryoTyped extends Codec {
        private static final Pool<Kryo> KRYO = new Pool<>(true, false, 64) {
            @Override
            protected Kryo create() {
                Kryo k = new Kryo();
                k.setRegistrationRequired(true);
                k.setReferences(false);
                k.register(ArrayList.class, 10);
                k.register(Instrument.class, 11);
                k.register(Issuer.class, 12);
                k.register(BigDecimal.class, 13);
                k.register(LocalDate.class, 14);
                return k;
            }
        };

        private List<Instrument> items;

        public String name() { return "kryo"; }

        public void load(List<Instrument> all) { items = all; }

        public byte[] encode(int from, int to) {
            ArrayList<Instrument> batch = new ArrayList<>(items.subList(from, to));
            Kryo k = KRYO.obtain();
            try (Output out = new Output(8192, MAX_MESSAGE)) {
                k.writeObject(out, batch);
                return out.toBytes();
            } finally {
                KRYO.free(k);
            }
        }

        @SuppressWarnings("unchecked")
        public List<Instrument> decode(byte[] bytes) {
            Kryo k = KRYO.obtain();
            try (Input in = new Input(bytes)) {
                return k.readObject(in, ArrayList.class);
            } finally {
                KRYO.free(k);
            }
        }
    }

    // ------------------------------------------------------------------ generic rows (the bridge today)

    /** Rows keyed like the bridge (key = instrument id), mapped to records by Jackson on the client. */
    abstract static class Rows extends Codec {
        protected List<String> keys;
        protected Map<String, List<Map<String, Object>>> rows;
        private final Function<Map<String, Object>, Instrument> mapper = JacksonRows.mapper(Instrument.class);

        public void load(List<Instrument> all) {
            keys = new ArrayList<>(all.size());
            rows = new LinkedHashMap<>();
            for (Instrument x : all) {
                String k = Long.toString(x.instrumentId());
                keys.add(k);
                rows.put(k, List.of(Model.row(x)));
            }
        }

        protected List<Instrument> toRecords(Map<String, List<Map<String, Object>>> entries) {
            List<Instrument> out = new ArrayList<>(entries.size());
            for (List<Map<String, Object>> rs : entries.values()) for (Map<String, Object> r : rs) out.add(mapper.apply(r));
            return out;
        }
    }

    public static final class ProtobufRows extends Rows {
        public String name() { return "protobuf-rows"; }

        public byte[] encode(int from, int to) {
            KeyRowsChunk.Builder b = RowCodecAccess.chunk();
            for (int i = from; i < to; i++) b.addEntries(RowCodecAccess.toProto(keys.get(i), rows.get(keys.get(i))));
            return b.build().toByteArray();
        }

        public List<Instrument> decode(byte[] bytes) {
            try {
                KeyRowsChunk c = KeyRowsChunk.parseFrom(bytes);
                Map<String, List<Map<String, Object>>> entries = new LinkedHashMap<>();
                for (KeyRows kr : c.getEntriesList()) entries.put(kr.getKey(), RowCodecAccess.fromProto(kr));
                return toRecords(entries);
            } catch (InvalidProtocolBufferException e) {
                throw new IllegalStateException(e);
            }
        }
    }

    public static final class KryoRows extends Rows {
        public String name() { return "kryo-rows"; }

        public byte[] encode(int from, int to) {
            Map<String, List<Map<String, Object>>> slice = new LinkedHashMap<>();
            for (int i = from; i < to; i++) slice.put(keys.get(i), rows.get(keys.get(i)));
            return KryoCodecAccess.encodeRows(slice, MAX_MESSAGE);
        }

        public List<Instrument> decode(byte[] bytes) {
            return toRecords(KryoCodecAccess.decodeRows(bytes));
        }
    }
}
