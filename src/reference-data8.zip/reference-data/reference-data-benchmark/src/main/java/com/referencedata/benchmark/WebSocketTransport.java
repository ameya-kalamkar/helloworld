package com.referencedata.benchmark;

import com.referencedata.benchmark.Codecs.Codec;
import io.netty.bootstrap.ServerBootstrap;
import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;
import io.netty.channel.Channel;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.ChannelInitializer;
import io.netty.channel.ChannelOption;
import io.netty.channel.EventLoopGroup;
import io.netty.channel.SimpleChannelInboundHandler;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.socket.SocketChannel;
import io.netty.channel.socket.nio.NioServerSocketChannel;
import io.netty.handler.codec.http.HttpObjectAggregator;
import io.netty.handler.codec.http.HttpServerCodec;
import io.netty.handler.codec.http.websocketx.BinaryWebSocketFrame;
import io.netty.handler.codec.http.websocketx.WebSocketFrameAggregator;
import io.netty.handler.codec.http.websocketx.WebSocketServerProtocolHandler;

import java.io.ByteArrayOutputStream;
import java.net.InetSocketAddress;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.WebSocket;
import java.nio.ByteBuffer;
import java.util.Map;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionStage;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicLong;
import java.util.function.Consumer;

/**
 * WebSocket the way the bridge's websocket transport works: binary messages multiplexed by request id, bulk pulls
 * flow-controlled by credits (window 4), the client on the JDK's {@code java.net.http.WebSocket}. The server here is
 * Netty (the same I/O stack gRPC uses) so the comparison is protocol against protocol, not Tomcat against Netty.
 */
public final class WebSocketTransport implements Transport {

    private static final byte LOOKUP = 1, STREAM = 2, CREDIT = 3;
    private static final int WINDOW = 4;

    private EventLoopGroup boss;
    private EventLoopGroup io;
    private Channel serverChannel;
    private int port;

    @Override
    public String name() {
        return "WebSocket";
    }

    // ------------------------------------------------------------------ server (Netty)

    @Override
    @SuppressWarnings("deprecation")
    public void start(Codec codec, ExecutorService workers) throws InterruptedException {
        boss = new NioEventLoopGroup(1);
        io = new NioEventLoopGroup();
        serverChannel = new ServerBootstrap().group(boss, io).channel(NioServerSocketChannel.class)
                .childOption(ChannelOption.TCP_NODELAY, true)
                .childHandler(new ChannelInitializer<SocketChannel>() {
                    @Override
                    protected void initChannel(SocketChannel ch) {
                        ch.pipeline().addLast(new HttpServerCodec(), new HttpObjectAggregator(65_536),
                                new WebSocketServerProtocolHandler("/bench", null, false, Codecs.MAX_MESSAGE),
                                new WebSocketFrameAggregator(Codecs.MAX_MESSAGE),
                                new ServerHandler(codec, workers));
                    }
                })
                .bind(0).sync().channel();
        port = ((InetSocketAddress) serverChannel.localAddress()).getPort();
    }

    private static final class ServerHandler extends SimpleChannelInboundHandler<BinaryWebSocketFrame> {
        private final Codec codec;
        private final ExecutorService workers;
        private final Map<Long, Stream> streams = new ConcurrentHashMap<>();

        ServerHandler(Codec codec, ExecutorService workers) {
            this.codec = codec;
            this.workers = workers;
        }

        @Override
        protected void channelRead0(ChannelHandlerContext ctx, BinaryWebSocketFrame frame) {
            ByteBuf b = frame.content();
            byte type = b.readByte();
            long id = b.readLong();
            if (type == LOOKUP) {
                int from = b.readInt(), count = b.readInt();
                workers.execute(() -> send(ctx, id, true, codec.encode(from, from + count)));
            } else if (type == STREAM) {
                Stream s = new Stream(ctx, id, b.readInt(), b.readInt(), b.readInt(), b.readInt());
                streams.put(id, s);
                workers.execute(s::pump);
            } else if (type == CREDIT) {
                Stream s = streams.get(id);
                if (s != null) {
                    s.credit(b.readInt());
                    workers.execute(s::pump);
                }
            }
        }

        private static void send(ChannelHandlerContext ctx, long id, boolean last, byte[] payload) {
            ByteBuf header = Unpooled.buffer(9).writeLong(id).writeByte(last ? 1 : 0);
            ctx.writeAndFlush(new BinaryWebSocketFrame(Unpooled.wrappedBuffer(header, Unpooled.wrappedBuffer(payload))));
        }

        private final class Stream {
            private final ChannelHandlerContext ctx;
            private final long id;
            private final int end, chunk;
            private int next, credit;

            Stream(ChannelHandlerContext ctx, long id, int from, int total, int chunk, int window) {
                this.ctx = ctx;
                this.id = id;
                this.next = from;
                this.end = from + total;
                this.chunk = chunk;
                this.credit = window;
            }

            synchronized void credit(int n) {
                credit += n;
            }

            synchronized void pump() {
                while (credit > 0 && next < end) {
                    int to = Math.min(end, next + chunk);
                    send(ctx, id, to == end, codec.encode(next, to));
                    next = to;
                    credit--;
                }
                if (next >= end) streams.remove(id);
            }
        }
    }

    // ------------------------------------------------------------------ client (JDK WebSocket)

    @Override
    public Client connect() throws Exception {
        JdkClient c = new JdkClient();
        c.ws = HttpClient.newHttpClient().newWebSocketBuilder()
                .buildAsync(URI.create("ws://localhost:" + port + "/bench"), c).get(10, TimeUnit.SECONDS);
        return c;
    }

    private record Msg(boolean last, byte[] payload) {}

    private static final class JdkClient implements Client, WebSocket.Listener {
        private final Map<Long, BlockingQueue<Msg>> pending = new ConcurrentHashMap<>();
        private final AtomicLong ids = new AtomicLong();
        private volatile WebSocket ws;
        private CompletableFuture<?> sends = CompletableFuture.completedFuture(null);
        private ByteArrayOutputStream partial;

        @Override
        public byte[] lookup(int from, int count) throws Exception {
            long id = ids.incrementAndGet();
            BlockingQueue<Msg> q = new LinkedBlockingQueue<>();
            pending.put(id, q);
            try {
                send(ByteBuffer.allocate(17).put(LOOKUP).putLong(id).putInt(from).putInt(count).flip());
                return take(q).payload();
            } finally {
                pending.remove(id);
            }
        }

        @Override
        public long stream(int from, int total, int chunk, Consumer<byte[]> each) throws Exception {
            long id = ids.incrementAndGet();
            BlockingQueue<Msg> q = new LinkedBlockingQueue<>();
            pending.put(id, q);
            long bytes = 0;
            try {
                send(ByteBuffer.allocate(25).put(STREAM).putLong(id).putInt(from).putInt(total).putInt(chunk).putInt(WINDOW).flip());
                while (true) {
                    Msg m = take(q);
                    bytes += m.payload().length;
                    each.accept(m.payload());
                    if (m.last()) return bytes;
                    send(ByteBuffer.allocate(13).put(CREDIT).putLong(id).putInt(1).flip());
                }
            } finally {
                pending.remove(id);
            }
        }

        private static Msg take(BlockingQueue<Msg> q) throws InterruptedException {
            Msg m = q.poll(60, TimeUnit.SECONDS);
            if (m == null) throw new IllegalStateException("timeout");
            return m;
        }

        /** The JDK WebSocket allows one outstanding send: chain them, wait for ours. */
        private void send(ByteBuffer b) throws Exception {
            CompletableFuture<?> done;
            synchronized (this) {
                sends = sends.thenCompose(x -> ws.sendBinary(b, true));
                done = sends;
            }
            done.get(10, TimeUnit.SECONDS);
        }

        @Override
        public void onOpen(WebSocket w) {
            w.request(1);
        }

        @Override
        public CompletionStage<?> onBinary(WebSocket w, ByteBuffer data, boolean last) {
            if (partial == null) partial = new ByteArrayOutputStream(Math.max(1024, data.remaining()));
            byte[] chunk = new byte[data.remaining()];
            data.get(chunk);
            partial.write(chunk, 0, chunk.length);
            if (last) {
                ByteBuffer m = ByteBuffer.wrap(partial.toByteArray());
                partial = null;
                long id = m.getLong();
                boolean lastMsg = m.get() == 1;
                byte[] payload = new byte[m.remaining()];
                m.get(payload);
                BlockingQueue<Msg> q = pending.get(id);
                if (q != null) q.add(new Msg(lastMsg, payload));
            }
            w.request(1);
            return null;
        }

        @Override
        public void close() throws Exception {
            ws.sendClose(WebSocket.NORMAL_CLOSURE, "done").get(5, TimeUnit.SECONDS);
        }
    }

    @Override
    public void close() throws InterruptedException {
        if (serverChannel != null) serverChannel.close().sync();
        if (boss != null) boss.shutdownGracefully(0, 1, TimeUnit.SECONDS).sync();
        if (io != null) io.shutdownGracefully(0, 1, TimeUnit.SECONDS).sync();
    }
}
