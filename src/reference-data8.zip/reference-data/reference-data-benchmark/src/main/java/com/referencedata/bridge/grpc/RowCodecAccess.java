package com.referencedata.bridge.grpc;

import com.referencedata.bridge.grpc.v1.KeyRows;
import com.referencedata.bridge.grpc.v1.KeyRowsChunk;

import java.util.List;
import java.util.Map;

/** Benchmark access to the gRPC bridge's generic-row codec (package-private in the bridge). */
public final class RowCodecAccess {

    private RowCodecAccess() {}

    public static KeyRows toProto(String key, List<Map<String, Object>> rows) {
        return RowCodec.toProto(key, rows);
    }

    public static List<Map<String, Object>> fromProto(KeyRows kr) {
        return RowCodec.fromProto(kr);
    }

    public static KeyRowsChunk.Builder chunk() {
        return KeyRowsChunk.newBuilder();
    }
}
