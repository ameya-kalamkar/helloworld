package com.referencedata.benchmark;

import com.referencedata.benchmark.Codecs.Codec;
import io.grpc.CallOptions;
import io.grpc.Drainable;
import io.grpc.KnownLength;
import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;
import io.grpc.MethodDescriptor;
import io.grpc.Server;
import io.grpc.ServerBuilder;
import io.grpc.ServerServiceDefinition;
import io.grpc.stub.ClientCalls;
import io.grpc.stub.ServerCallStreamObserver;
import io.grpc.stub.ServerCalls;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.UncheckedIOException;
import java.nio.ByteBuffer;
import java.util.Iterator;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.function.Consumer;

/**
 * gRPC over HTTP/2 (Netty), as the bridge uses it: a unary lookup and a server-streaming bulk pull with flow control
 * ({@code isReady} / on-ready handler). Messages are the codec's bytes, so any codec can ride on gRPC; the marshaller
 * hands them to gRPC without copying ({@link Drainable}, {@link KnownLength}).
 */
public final class GrpcTransport implements Transport {

    private static final MethodDescriptor.Marshaller<byte[]> BYTES = new MethodDescriptor.Marshaller<>() {
        @Override
        public InputStream stream(byte[] value) {
            return new BytesStream(value);
        }

        @Override
        public byte[] parse(InputStream in) {
            try {
                return in.readAllBytes();
            } catch (IOException e) {
                throw new UncheckedIOException(e);
            }
        }
    };

    static final MethodDescriptor<byte[], byte[]> LOOKUP = MethodDescriptor.<byte[], byte[]>newBuilder()
            .setType(MethodDescriptor.MethodType.UNARY).setFullMethodName("bench.Bench/Lookup")
            .setRequestMarshaller(BYTES).setResponseMarshaller(BYTES).build();

    static final MethodDescriptor<byte[], byte[]> STREAM = MethodDescriptor.<byte[], byte[]>newBuilder()
            .setType(MethodDescriptor.MethodType.SERVER_STREAMING).setFullMethodName("bench.Bench/Stream")
            .setRequestMarshaller(BYTES).setResponseMarshaller(BYTES).build();

    private Server server;

    @Override
    public String name() {
        return "gRPC";
    }

    @Override
    public void start(Codec codec, ExecutorService workers) throws IOException {
        ServerServiceDefinition service = ServerServiceDefinition.builder("bench.Bench")
                .addMethod(LOOKUP, ServerCalls.asyncUnaryCall((req, out) -> {
                    ByteBuffer b = ByteBuffer.wrap(req);
                    int from = b.getInt(), count = b.getInt();
                    out.onNext(codec.encode(from, from + count));
                    out.onCompleted();
                }))
                .addMethod(STREAM, ServerCalls.asyncServerStreamingCall((req, out) -> {
                    ByteBuffer b = ByteBuffer.wrap(req);
                    int from = b.getInt(), total = b.getInt(), chunk = b.getInt();
                    ServerCallStreamObserver<byte[]> call = (ServerCallStreamObserver<byte[]>) out;
                    Runnable pump = new Runnable() {
                        private int next = from;
                        private boolean done;

                        @Override
                        public synchronized void run() {
                            while (!done && call.isReady()) {
                                if (next >= from + total) {
                                    done = true;
                                    call.onCompleted();
                                    return;
                                }
                                int to = Math.min(from + total, next + chunk);
                                call.onNext(codec.encode(next, to));
                                next = to;
                            }
                        }
                    };
                    call.setOnReadyHandler(pump);
                    pump.run();
                }))
                .build();
        server = ServerBuilder.forPort(0).executor(workers).addService(service)
                .maxInboundMessageSize(Codecs.MAX_MESSAGE).build().start();
    }

    @Override
    public Client connect() {
        ManagedChannel channel = ManagedChannelBuilder.forAddress("localhost", server.getPort())
                .usePlaintext().maxInboundMessageSize(Codecs.MAX_MESSAGE).build();
        return new Client() {
            @Override
            public byte[] lookup(int from, int count) {
                return ClientCalls.blockingUnaryCall(channel, LOOKUP, CallOptions.DEFAULT,
                        ByteBuffer.allocate(8).putInt(from).putInt(count).array());
            }

            @Override
            public long stream(int from, int total, int chunk, Consumer<byte[]> each) {
                long bytes = 0;
                Iterator<byte[]> it = ClientCalls.blockingServerStreamingCall(channel, STREAM, CallOptions.DEFAULT,
                        ByteBuffer.allocate(12).putInt(from).putInt(total).putInt(chunk).array());
                while (it.hasNext()) {
                    byte[] b = it.next();
                    bytes += b.length;
                    each.accept(b);
                }
                return bytes;
            }

            @Override
            public void close() throws InterruptedException {
                channel.shutdown().awaitTermination(5, TimeUnit.SECONDS);
            }
        };
    }

    @Override
    public void close() throws InterruptedException {
        if (server != null) server.shutdown().awaitTermination(5, TimeUnit.SECONDS);
    }

    /** Lets gRPC write the bytes straight to the transport and know the length up front. */
    private static final class BytesStream extends ByteArrayInputStream implements Drainable, KnownLength {
        BytesStream(byte[] b) {
            super(b);
        }

        @Override
        public int drainTo(OutputStream target) throws IOException {
            int n = count - pos;
            target.write(buf, pos, n);
            pos = count;
            return n;
        }
    }
}
