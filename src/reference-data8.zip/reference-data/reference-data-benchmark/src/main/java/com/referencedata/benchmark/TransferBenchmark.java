package com.referencedata.benchmark;

import com.referencedata.benchmark.Codecs.Codec;
import com.referencedata.benchmark.Model.Instrument;
import com.referencedata.benchmark.Transport.Client;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicLong;
import java.util.function.Supplier;

/**
 * Java-to-Java object transfer: Kryo vs protobuf, gRPC vs WebSocket.
 * <ol>
 *   <li><b>Serialization</b> (no network): encode on the server side, decode to application records on the client
 *       side, per object, for small (10) and large (1,000) messages; bytes per object.</li>
 *   <li><b>Transport</b> (localhost, real sockets), every transport x codec:
 *     <ul>
 *       <li>latency: one thread, lookups of 10 objects, mean / p50 / p99</li>
 *       <li>throughput: {@code --threads} threads, lookups of 100 objects</li>
 *       <li>bulk: the whole data set pulled as a flow-controlled stream of 500-object messages (preload)</li>
 *     </ul>
 *   Every timing includes decoding into {@link Instrument} records: what the application receives.</li>
 * </ol>
 * Arguments: {@code --objects 200000 --threads 4 --quick}. Client and server share the machine, so absolute numbers
 * are pessimistic; compare rows with each other.
 */
public final class TransferBenchmark {

    private static volatile long sink;

    public static void main(String[] args) throws Exception {
        int objects = intArg(args, "--objects", 200_000);
        int threads = intArg(args, "--threads", 4);
        boolean quick = Arrays.asList(args).contains("--quick");
        long warmMs = quick ? 500 : 2_000, runMs = quick ? 1_000 : 3_000;

        System.out.printf("Java %s, %d cores, %d objects, %d client threads%s%n%n", System.getProperty("java.version"),
                Runtime.getRuntime().availableProcessors(), objects, threads, quick ? " (quick)" : "");
        List<Instrument> data = Model.instruments(objects);
        List<Codec> codecs = Codecs.all();
        for (Codec c : codecs) {
            c.load(data);
            List<Instrument> back = c.decode(c.encode(0, 1_000));
            if (!back.equals(data.subList(0, 1_000))) throw new IllegalStateException(c + " does not round-trip: " + back.get(0) + " vs " + data.get(0));
        }
        System.out.println("All codecs round-trip the same records.\n");

        // ---------------------------------------------------------------- serialization only
        System.out.println("## Serialization (no network), per object\n");
        System.out.println("| codec | batch | bytes/obj | encode ns/obj | decode ns/obj | encode+decode ns/obj |");
        System.out.println("|---|---:|---:|---:|---:|---:|");
        for (int batch : new int[] {10, 1_000}) {
            for (Codec c : codecs) {
                int slots = Math.max(1, Math.min(256, objects / batch));
                byte[][] msgs = new byte[slots][];
                long bytes = 0;
                for (int i = 0; i < slots; i++) {
                    msgs[i] = c.encode(i * batch, i * batch + batch);
                    bytes += msgs[i].length;
                }
                AtomicLong k = new AtomicLong();
                double enc = perOp(warmMs, runMs, () -> {
                    int i = (int) (k.getAndIncrement() % slots);
                    return (long) c.encode(i * batch, i * batch + batch).length;
                }) / batch;
                double dec = perOp(warmMs, runMs, () -> {
                    int i = (int) (k.getAndIncrement() % slots);
                    return (long) c.decode(msgs[i]).size();
                }) / batch;
                System.out.printf(Locale.ROOT, "| %s | %d | %.0f | %.0f | %.0f | %.0f |%n", c, batch,
                        (double) bytes / slots / batch, enc, dec, enc + dec);
            }
        }

        // ---------------------------------------------------------------- transports
        List<Supplier<Transport>> transports = List.of(GrpcTransport::new, WebSocketTransport::new);
        List<String[]> lat = new ArrayList<>(), thr = new ArrayList<>(), bulk = new ArrayList<>();
        for (Supplier<Transport> t : transports) {
            for (Codec c : codecs) {
                ExecutorService workers = Executors.newFixedThreadPool(4);
                try (Transport tr = t.get()) {
                    tr.start(c, workers);
                    try (Client client = tr.connect()) {
                        String label = tr.name() + " + " + c;
                        System.err.println("running " + label);
                        lat.add(latency(label, client, c, objects, quick));
                        thr.add(throughput(label, client, c, objects, threads, warmMs, runMs));
                        bulk.add(bulk(label, client, c, objects, quick));
                    }
                } finally {
                    workers.shutdownNow();
                }
            }
        }
        table("## Latency: lookup of 10 objects, 1 thread (microseconds)", "| transport + codec | mean | p50 | p99 |", lat);
        table("## Throughput: lookups of 100 objects, " + threads + " threads",
                "| transport + codec | calls/s | objects/s |", thr);
        table("## Bulk: " + objects + " objects streamed in messages of 500 (preload)",
                "| transport + codec | ms | objects/s | MB/s on the wire | MB total |", bulk);
    }

    // ------------------------------------------------------------------ scenarios

    private static String[] latency(String label, Client client, Codec c, int objects, boolean quick) throws Exception {
        int warm = quick ? 1_000 : 5_000, n = quick ? 3_000 : 20_000;
        long[] t = new long[n];
        for (int i = 0; i < warm + n; i++) {
            int from = (i * 10) % (objects - 10);
            long t0 = System.nanoTime();
            sink += c.decode(client.lookup(from, 10)).size();
            if (i >= warm) t[i - warm] = System.nanoTime() - t0;
        }
        Arrays.sort(t);
        double mean = Arrays.stream(t).average().orElse(0) / 1_000;
        return row(label, f1(mean), f1(t[n / 2] / 1_000.0), f1(t[(int) (n * 0.99)] / 1_000.0));
    }

    private static String[] throughput(String label, Client client, Codec c, int objects, int threads, long warmMs,
                                       long runMs) throws Exception {
        AtomicBoolean measuring = new AtomicBoolean(), stop = new AtomicBoolean();
        AtomicLong calls = new AtomicLong();
        ExecutorService pool = Executors.newFixedThreadPool(threads);
        List<Future<?>> fs = new ArrayList<>();
        for (int th = 0; th < threads; th++) {
            int seed = th;
            fs.add(pool.submit(() -> {
                int i = seed * 997;
                while (!stop.get()) {
                    int from = (i++ * 100) % (objects - 100);
                    sink += c.decode(client.lookup(from, 100)).size();
                    if (measuring.get()) calls.incrementAndGet();
                }
                return null;
            }));
        }
        Thread.sleep(warmMs);
        measuring.set(true);
        long t0 = System.nanoTime();
        Thread.sleep(runMs);
        long n = calls.get();
        double secs = (System.nanoTime() - t0) / 1e9;
        stop.set(true);
        for (Future<?> f : fs) f.get();
        pool.shutdown();
        return row(label, f0(n / secs), f0(n * 100 / secs));
    }

    private static String[] bulk(String label, Client client, Codec c, int objects, boolean quick) throws Exception {
        int runs = quick ? 2 : 4;
        long[] ms = new long[runs];
        long bytes = 0;
        for (int r = 0; r < runs; r++) {                       // first run is warm-up
            long[] count = {0};
            long t0 = System.nanoTime();
            bytes = client.stream(0, objects, 500, b -> count[0] += c.decode(b).size());
            ms[r] = (System.nanoTime() - t0) / 1_000_000;
            if (count[0] != objects) throw new IllegalStateException(label + ": received " + count[0]);
        }
        long[] measured = Arrays.copyOfRange(ms, 1, runs);
        Arrays.sort(measured);
        long median = measured[measured.length / 2];
        return row(label, Long.toString(median), f0(objects * 1000.0 / median),
                f0(bytes / 1e6 * 1000.0 / median), f1(bytes / 1e6));
    }

    // ------------------------------------------------------------------ helpers

    /** Mean nanoseconds per call of {@code op} after a warm-up. */
    private static double perOp(long warmMs, long runMs, Supplier<Long> op) {
        long end = System.nanoTime() + warmMs * 1_000_000;
        while (System.nanoTime() < end) sink += op.get();
        long n = 0, t0 = System.nanoTime();
        end = t0 + runMs * 1_000_000;
        long now;
        do {
            for (int i = 0; i < 16; i++) sink += op.get();
            n += 16;
            now = System.nanoTime();
        } while (now < end);
        return (double) (now - t0) / n;
    }

    private static void table(String title, String header, List<String[]> rows) {
        System.out.println("\n" + title + "\n");
        System.out.println(header);
        System.out.println(header.replaceAll("[^|]+", "---").replaceFirst("\\|---\\|", "|---|"));
        for (String[] r : rows) System.out.println("| " + String.join(" | ", r) + " |");
    }

    private static String[] row(String... cells) {
        return cells;
    }

    private static String f0(double v) {
        return String.format(Locale.ROOT, "%,.0f", v);
    }

    private static String f1(double v) {
        return String.format(Locale.ROOT, "%.1f", v);
    }

    private static int intArg(String[] args, String name, int fallback) {
        for (int i = 0; i < args.length - 1; i++) if (args[i].equals(name)) return Integer.parseInt(args[i + 1]);
        return fallback;
    }
}
