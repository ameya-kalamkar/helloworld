package com.referencedata.bridge.websocket;

import java.util.List;
import java.util.Map;

/** Benchmark access to the WebSocket bridge's Kryo frame codec (package-private in the bridge). */
public final class KryoCodecAccess {

    private KryoCodecAccess() {}

    public static byte[] encodeRows(Map<String, List<Map<String, Object>>> entries, int maxBytes) {
        return KryoCodec.encode(new KryoCodec.Rows(0, entries, true), maxBytes);
    }

    public static Map<String, List<Map<String, Object>>> decodeRows(byte[] bytes) {
        return ((KryoCodec.Rows) KryoCodec.decode(bytes)).entries();
    }
}
