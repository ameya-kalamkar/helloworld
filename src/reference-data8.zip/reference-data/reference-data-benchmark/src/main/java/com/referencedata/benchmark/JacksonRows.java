package com.referencedata.benchmark;

import tools.jackson.databind.DeserializationFeature;
import tools.jackson.databind.ObjectMapper;
import tools.jackson.databind.PropertyNamingStrategies;
import tools.jackson.databind.json.JsonMapper;

import java.util.Map;
import java.util.function.Function;

/** Rows to records exactly as the client does it (same Jackson 3 settings as the core's row mapper). */
final class JacksonRows {

    private static final ObjectMapper ROWS = JsonMapper.builder()
            .propertyNamingStrategy(PropertyNamingStrategies.SNAKE_CASE)
            .disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES)
            .disable(DeserializationFeature.FAIL_ON_NULL_FOR_PRIMITIVES)
            .enable(DeserializationFeature.USE_BIG_DECIMAL_FOR_FLOATS)
            .build();

    private JacksonRows() {}

    static <T> Function<Map<String, Object>, T> mapper(Class<T> type) {
        return row -> ROWS.convertValue(row, type);
    }
}
