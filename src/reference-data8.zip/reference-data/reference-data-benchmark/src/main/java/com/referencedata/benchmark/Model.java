package com.referencedata.benchmark;

import com.referencedata.core.RowValues;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

/** The application objects transferred, and a deterministic data set of them. */
public final class Model {

    private Model() {}

    /** A typical reference data object: ids, codes, exact decimals, a date, a list and a nested object. */
    public record Instrument(long instrumentId, String symbol, String isin, String currency, String exchange,
                             BigDecimal tickSize, BigDecimal notional, int lotSize, LocalDate maturity, boolean active,
                             double rating, List<String> tags, Issuer issuer) {}

    public record Issuer(String issuerId, String name, String country) {}

    private static final String[] CCY = {"USD", "EUR", "GBP", "JPY", "CAD", "CHF", "AUD"};
    private static final String[] EXCH = {"XNYS", "XNAS", "XLON", "XTSE", "XETR", "XTKS"};
    private static final String[] TAGS = {"g10", "liquid", "index-member", "esg", "callable", "restricted"};

    /** {@code n} instruments, always the same for the same {@code n}. Decimals carry no trailing zeros. */
    public static List<Instrument> instruments(int n) {
        Random r = new Random(42);
        List<Issuer> issuers = new ArrayList<>();
        for (int i = 0; i < 500; i++) {
            issuers.add(new Issuer("ISS" + (100_000 + i), "Issuer Holdings " + i + " Ltd", CCY[i % CCY.length].substring(0, 2)));
        }
        List<Instrument> out = new ArrayList<>(n);
        for (int i = 0; i < n; i++) {
            List<String> tags = new ArrayList<>();
            for (int t = r.nextInt(4); t > 0; t--) tags.add(TAGS[r.nextInt(TAGS.length)]);
            out.add(new Instrument(
                    10_000_000L + i,
                    "SYM" + Integer.toString(i, 36).toUpperCase(),
                    String.format("US%09dX%d", i, i % 10),
                    CCY[r.nextInt(CCY.length)],
                    EXCH[r.nextInt(EXCH.length)],
                    decimal(BigDecimal.valueOf(1 + r.nextInt(99), 2 + r.nextInt(3))),
                    decimal(BigDecimal.valueOf(r.nextLong(1, 10_000_000_000L), 2)),
                    1 + r.nextInt(1000),
                    LocalDate.of(2027, 1, 1).plusDays(r.nextInt(10_000)),
                    r.nextInt(10) > 0,
                    Math.round(r.nextDouble() * 1000) / 100.0,
                    tags,
                    issuers.get(r.nextInt(issuers.size()))));
        }
        return out;
    }

    /** Canonical form (no trailing zeros, scale >= 0), so generic rows, which normalise decimals, round-trip exactly. */
    private static BigDecimal decimal(BigDecimal d) {
        BigDecimal s = d.stripTrailingZeros();
        return s.scale() < 0 ? s.setScale(0) : s;
    }

    /** The same object as a normalised row, exactly as a loader produces it for the bridge (generic rows). */
    public static Map<String, Object> row(Instrument x) {
        Map<String, Object> issuer = new LinkedHashMap<>();
        issuer.put("issuer_id", x.issuer().issuerId());
        issuer.put("name", x.issuer().name());
        issuer.put("country", x.issuer().country());
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("instrument_id", x.instrumentId());
        m.put("symbol", x.symbol());
        m.put("isin", x.isin());
        m.put("currency", x.currency());
        m.put("exchange", x.exchange());
        m.put("tick_size", x.tickSize());
        m.put("notional", x.notional());
        m.put("lot_size", x.lotSize());
        m.put("maturity", x.maturity());
        m.put("active", x.active());
        m.put("rating", x.rating());
        m.put("tags", x.tags());
        m.put("issuer", issuer);
        return RowValues.normalize(m);
    }
}
