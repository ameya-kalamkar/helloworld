# Benchmark results: Kryo vs protobuf, gRPC vs WebSocket

Java-to-Java transfer of `Instrument` records (13 fields: longs, strings, two exact `BigDecimal`s, a `LocalDate`,
a list, a nested record). Every timing ends with application records on the client.

Codecs:
* `protobuf`: typed messages from `benchmark.proto`, records converted to/from messages
* `kryo`: Kryo 5.6.2 serializing the records directly (registered classes, `RecordSerializer`)
* `protobuf-rows`: today's gRPC bridge: generic rows (`RowCodec`) + Jackson mapping rows to records on the client
* `kryo-rows`: today's WebSocket bridge: generic rows (`KryoCodec`) + Jackson mapping

Environment of the run below: 2 vCPU cloud sandbox, client and server on the same machine (they compete for CPU),
Java 21, gRPC 1.76 / Netty 4.2.13, protobuf-java 4.35.1, Kryo 5.6.2, Jackson 2.21 for row mapping (Jackson 3 jars were
not available there), WebSocket server on Netty with the JDK WebSocket client. Plain timed loops with warm-up, not JMH;
two full runs agreed within about 10-15%. Re-run on your hardware:

    ./gradlew :reference-data-benchmark:run --args='--objects 1000000 --threads 16'

All codecs round-trip the same records.

## Serialization (no network), per object

| codec | batch | bytes/obj | encode ns/obj | decode ns/obj | encode+decode ns/obj |
|---|---:|---:|---:|---:|---:|
| protobuf | 10 | 131 | 802 | 884 | 1685 |
| kryo | 10 | 106 | 1017 | 673 | 1690 |
| protobuf-rows | 10 | 367 | 3282 | 5169 | 8451 |
| kryo-rows | 10 | 244 | 1220 | 3045 | 4265 |
| protobuf | 1000 | 133 | 855 | 962 | 1817 |
| kryo | 1000 | 107 | 1021 | 708 | 1730 |
| protobuf-rows | 1000 | 368 | 5274 | 7570 | 12844 |
| kryo-rows | 1000 | 245 | 1689 | 3777 | 5467 |

## Latency: lookup of 10 objects, 1 thread (microseconds)

| transport + codec | mean | p50 | p99 |
|---|---|---|---|
| gRPC + protobuf | 363.4 | 283.0 | 2643.7 |
| gRPC + kryo | 280.2 | 268.2 | 631.6 |
| gRPC + protobuf-rows | 428.6 | 395.5 | 909.1 |
| gRPC + kryo-rows | 357.8 | 330.6 | 755.8 |
| WebSocket + protobuf | 174.0 | 166.8 | 443.6 |
| WebSocket + kryo | 159.4 | 154.3 | 392.8 |
| WebSocket + protobuf-rows | 304.5 | 280.0 | 801.2 |
| WebSocket + kryo-rows | 238.3 | 217.4 | 503.0 |

## Throughput: lookups of 100 objects, 4 threads

| transport + codec | calls/s | objects/s |
|---|---|---|
| gRPC + protobuf | 2,699 | 269,905 |
| gRPC + kryo | 4,367 | 436,718 |
| gRPC + protobuf-rows | 1,028 | 102,796 |
| gRPC + kryo-rows | 1,735 | 173,540 |
| WebSocket + protobuf | 4,223 | 422,270 |
| WebSocket + kryo | 5,351 | 535,079 |
| WebSocket + protobuf-rows | 1,156 | 115,560 |
| WebSocket + kryo-rows | 1,977 | 197,687 |

## Bulk: 200000 objects streamed in messages of 500 (preload)

| transport + codec | ms | objects/s | MB/s on the wire | MB total |
|---|---|---|---|---|
| gRPC + protobuf | 513 | 389,864 | 52 | 26.6 |
| gRPC + kryo | 325 | 615,385 | 66 | 21.4 |
| gRPC + protobuf-rows | 1617 | 123,686 | 46 | 73.7 |
| gRPC + kryo-rows | 790 | 253,165 | 62 | 49.0 |
| WebSocket + protobuf | 447 | 447,427 | 60 | 26.6 |
| WebSocket + kryo | 347 | 576,369 | 62 | 21.4 |
| WebSocket + protobuf-rows | 1721 | 116,212 | 43 | 73.7 |
| WebSocket + kryo-rows | 880 | 227,273 | 56 | 49.0 |
