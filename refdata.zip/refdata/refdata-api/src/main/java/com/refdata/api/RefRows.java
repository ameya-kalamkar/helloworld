package com.refdata.api;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.time.temporal.TemporalAccessor;
import java.util.Base64;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;

/**
 * Normalizes source rows to a small set of JSON-stable types so a row read from the ref server
 * (JSON) equals the same row read directly from the source:
 * <ul>
 *   <li>column names lower-cased (Oracle returns upper case)</li>
 *   <li>integral numbers to {@link Long}; other numbers to {@link BigDecimal} (trailing zeros stripped)</li>
 *   <li>dates and times to ISO-8601 strings; {@code byte[]} to Base64; everything else {@link String}</li>
 * </ul>
 */
public final class RefRows {

    private RefRows() {}

    public static Map<String, Object> normalize(Map<String, ?> raw) {
        Map<String, Object> out = new LinkedHashMap<>(Math.max(4, raw.size() * 2));
        raw.forEach((k, v) -> out.put(k.toLowerCase(Locale.ROOT), normalizeValue(v)));
        return out;
    }

    public static Object normalizeValue(Object v) {
        if (v == null || v instanceof String || v instanceof Boolean || v instanceof Long) return v;
        if (v instanceof Integer || v instanceof Short || v instanceof Byte) return ((Number) v).longValue();
        if (v instanceof BigInteger bi) return bi.bitLength() < 64 ? (Object) bi.longValue() : new BigDecimal(bi);
        if (v instanceof BigDecimal bd) return normalizeDecimal(bd);
        if (v instanceof Double || v instanceof Float) return normalizeDecimal(BigDecimal.valueOf(((Number) v).doubleValue()));
        if (v instanceof java.sql.Timestamp ts) return ts.toLocalDateTime().toString();
        if (v instanceof java.sql.Date d) return d.toLocalDate().toString();
        if (v instanceof java.sql.Time t) return t.toLocalTime().toString();
        if (v instanceof TemporalAccessor) return v.toString();
        if (v instanceof java.util.Date d) return d.toInstant().toString();
        if (v instanceof byte[] b) return Base64.getEncoder().encodeToString(b);
        return v.toString();
    }

    private static Object normalizeDecimal(BigDecimal bd) {
        BigDecimal s = bd.signum() == 0 ? BigDecimal.ZERO : bd.stripTrailingZeros();
        if (s.scale() <= 0 && s.precision() - s.scale() < 19) return s.longValueExact();
        return s;
    }
}
