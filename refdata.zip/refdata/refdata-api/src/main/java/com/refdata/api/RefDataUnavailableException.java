package com.refdata.api;

import java.util.List;
import java.util.Set;

/**
 * Thrown when keys could not be resolved because every allowed provider failed, timed out,
 * was circuit-open or was skipped. The executor decides whether to retry, skip or fail the job.
 * Keys that are merely absent at the source are reported in {@link LookupResult#notFound()} instead.
 */
public class RefDataUnavailableException extends RuntimeException {

    private final String dataset;
    private final Set<String> unresolvedKeys;
    private final List<String> reasons;

    public RefDataUnavailableException(String dataset, Set<String> unresolvedKeys, List<String> reasons, Throwable cause) {
        super("Ref data unavailable for dataset '" + dataset + "' (" + unresolvedKeys.size()
                + " keys unresolved): " + String.join("; ", reasons), cause);
        this.dataset = dataset;
        this.unresolvedKeys = Set.copyOf(unresolvedKeys);
        this.reasons = List.copyOf(reasons);
    }

    public String dataset() { return dataset; }
    public Set<String> unresolvedKeys() { return unresolvedKeys; }
    public List<String> reasons() { return reasons; }
}
