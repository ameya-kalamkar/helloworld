package com.refdata.api;

import java.time.LocalDate;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Optional;

/** What executors call. Implemented by the routing client; executors never see Ignite or sources. */
public interface RefDataClient extends AutoCloseable {

    /**
     * Batch lookup, the preferred call from executors.
     *
     * @param businessDate null means the ref server's current business date
     * @throws RefDataUnavailableException if some keys could not be resolved by any allowed provider
     */
    LookupResult getAll(String dataset, LocalDate businessDate, Collection<String> keys);

    default LookupResult getAll(String dataset, Collection<String> keys) {
        return getAll(dataset, null, keys);
    }

    default Optional<Map<String, Object>> get(String dataset, String key) {
        return Optional.ofNullable(getAll(dataset, null, List.of(key)).found().get(key));
    }

    /** Current business date as seen by this client. */
    LocalDate currentBusinessDate();

    /** Drops the client-side cache, e.g. after a server-side reload. */
    void invalidateLocal();

    @Override
    void close();
}
