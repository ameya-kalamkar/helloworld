package com.refdata.api;

import java.time.LocalDate;
import java.util.Collection;
import java.util.Map;
import java.util.function.BiConsumer;

/**
 * Loads one reference dataset from its original source (JDBC, REST, file...).
 * <p>
 * The same implementation is used by the ref server (day-start warm + read-through on miss)
 * and by the client's DIRECT mode, so both paths return identically shaped rows.
 * Rows should be passed through {@link RefRows#normalize(Map)} before they are returned.
 */
public interface RefSourceDao {

    /** Streams every row for the business date. Used for the day-start bulk load. */
    void streamAll(LocalDate businessDate, BiConsumer<String, Map<String, Object>> sink);

    /** Loads only the given keys. Keys that do not exist are simply absent from the result. */
    Map<String, Map<String, Object>> loadByKeys(LocalDate businessDate, Collection<String> keys);
}
