package com.refdata.api;

import java.util.List;

/** Where a client goes for a dataset, in order. Anything with DIRECT is opt-in per dataset. */
public enum Route {
    REF_SERVER,
    DIRECT,
    REF_SERVER_THEN_DIRECT,
    DIRECT_THEN_REF_SERVER;

    public static final String REF_SERVER_PROVIDER = "ref-server";

    /** Provider names in call order; {@code direct} is the dataset's configured direct provider. */
    public List<String> chain(String direct) {
        return switch (this) {
            case REF_SERVER -> List.of(REF_SERVER_PROVIDER);
            case DIRECT -> List.of(direct);
            case REF_SERVER_THEN_DIRECT -> List.of(REF_SERVER_PROVIDER, direct);
            case DIRECT_THEN_REF_SERVER -> List.of(direct, REF_SERVER_PROVIDER);
        };
    }

    public boolean usesDirect() {
        return this != REF_SERVER;
    }
}
