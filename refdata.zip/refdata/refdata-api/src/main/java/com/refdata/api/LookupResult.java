package com.refdata.api;

import java.time.LocalDate;
import java.util.Map;
import java.util.Set;

/**
 * Result of a batch lookup. Also the JSON wire format of the ref server's lookup endpoint.
 *
 * @param businessDate the business date the rows belong to
 * @param found        key to row
 * @param notFound     keys confirmed absent at the source
 */
public record LookupResult(LocalDate businessDate,
                           Map<String, Map<String, Object>> found,
                           Set<String> notFound) {

    public LookupResult {
        found = found == null ? Map.of() : Map.copyOf(found);
        notFound = notFound == null ? Set.of() : Set.copyOf(notFound);
    }
}
