package com.refdata.server;

import java.time.LocalDate;

/** Business date used by the day-start warm. Override the bean to plug in a holiday/roll calendar. */
@FunctionalInterface
public interface BusinessDateProvider {
    LocalDate today();
}
