package com.refdata.server;

import com.refdata.server.RefCacheService.WarmReport;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.time.LocalDate;

/**
 * Startup and day-start warm.
 * <p>
 * Spring Boot only reports readiness (ACCEPTING_TRAFFIC) after application runners finish, so
 * running the startup warm here keeps {@code /actuator/health/readiness} DOWN until data is in.
 * A node joining a cluster that is already warm returns immediately. If another node is warming,
 * this node waits for that warm to publish (up to {@code startup-wait-timeout}).
 */
@Component
class DayStartWarmer implements ApplicationRunner {

    private static final Logger log = LoggerFactory.getLogger(DayStartWarmer.class);

    private final RefCacheService service;
    private final RefServerProperties props;
    private final BusinessDateProvider businessDate;

    DayStartWarmer(RefCacheService service, RefServerProperties props, BusinessDateProvider businessDate) {
        this.service = service;
        this.props = props;
        this.businessDate = businessDate;
    }

    @Override
    public void run(ApplicationArguments args) throws InterruptedException {
        if (service.currentBusinessDate().isPresent()) {
            log.info("Cluster already serving business date {}", service.currentBusinessDate().get());
            return;
        }
        if (!props.warmOnStartup()) {
            log.warn("No business date published and warm-on-startup is off; lookups return 503 until POST /admin/refdata/warm");
            return;
        }
        WarmReport report = service.warm(businessDate.today(), false);
        switch (report.status()) {
            case "PUBLISHED", "ALREADY_WARM" -> log.info("Startup warm done: {}", report.status());
            case "BUSY" -> awaitOtherNode();
            default -> throw new IllegalStateException("Startup warm failed; required datasets did not load: " + report.loads());
        }
    }

    /** Every node fires the schedule; the cluster lock plus the ALREADY_WARM check make it run once. */
    @Scheduled(cron = "${refserver.warm-cron:0 45 5 * * MON-FRI}", zone = "${refserver.zone:America/Toronto}")
    void dayStart() {
        LocalDate date = businessDate.today();
        WarmReport report = service.warm(date, false);
        log.info("Day-start warm for {}: {}", date, report.status());
    }

    private void awaitOtherNode() throws InterruptedException {
        long deadline = System.nanoTime() + props.startupWaitTimeout().toNanos();
        while (service.currentBusinessDate().isEmpty()) {
            if (System.nanoTime() > deadline) {
                throw new IllegalStateException("Timed out waiting for another node to finish the startup warm");
            }
            Thread.sleep(2_000);
        }
        log.info("Another node published business date {}", service.currentBusinessDate().get());
    }
}
