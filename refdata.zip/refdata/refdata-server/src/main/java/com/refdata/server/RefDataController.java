package com.refdata.server;

import com.refdata.api.LookupResult;
import com.refdata.server.RefCacheService.DatasetLoad;
import com.refdata.server.RefCacheService.WarmReport;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.format.annotation.DateTimeFormat.ISO;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.time.LocalDate;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Language-neutral JSON API used by the Java client and by Python callers.
 * <p>
 * Secure the {@code /admin} endpoints (Spring Security, network policy) before production.
 */
@RestController
class RefDataController {

    private final RefCacheService service;

    RefDataController(RefCacheService service) {
        this.service = service;
    }

    public record LookupRequest(LocalDate businessDate, List<String> keys) {}

    /** Batch lookup. Body: {@code {"businessDate": "2026-10-08" (optional), "keys": ["USDCAD", ...]}} */
    @PostMapping("/refdata/{dataset}/lookup")
    LookupResult lookup(@PathVariable String dataset, @RequestBody LookupRequest request) {
        if (request.keys() == null) throw new IllegalArgumentException("keys is required");
        return service.lookup(dataset, request.businessDate(), request.keys());
    }

    @GetMapping("/refdata/{dataset}/keys/{key}")
    ResponseEntity<Map<String, Object>> get(@PathVariable String dataset, @PathVariable String key,
                                            @RequestParam(required = false) @DateTimeFormat(iso = ISO.DATE) LocalDate businessDate) {
        Map<String, Object> row = service.lookup(dataset, businessDate, List.of(key)).found().get(key);
        return row == null ? ResponseEntity.notFound().build() : ResponseEntity.ok(row);
    }

    @GetMapping("/refdata/business-date")
    Map<String, Object> businessDate() {
        LocalDate current = service.currentBusinessDate().orElseThrow(RefCacheService.NotReadyException::new);
        Map<String, Object> out = new LinkedHashMap<>();
        out.put("businessDate", current);
        out.put("publishedDates", service.publishedDates());
        return out;
    }

    @GetMapping("/refdata/datasets")
    Object datasets() {
        return service.datasets();
    }

    // ------------------------------------------------------------------ admin

    @PostMapping("/admin/refdata/warm")
    WarmReport warm(@RequestParam @DateTimeFormat(iso = ISO.DATE) LocalDate businessDate,
                    @RequestParam(defaultValue = "false") boolean force) {
        return service.warm(businessDate, force);
    }

    @PostMapping("/admin/refdata/{dataset}/reload")
    DatasetLoad reload(@PathVariable String dataset,
                       @RequestParam(required = false) @DateTimeFormat(iso = ISO.DATE) LocalDate businessDate,
                       @RequestParam(defaultValue = "false") boolean clearFirst) {
        return service.reload(dataset, businessDate, clearFirst);
    }

    @PostMapping("/admin/refdata/destroy")
    Map<String, Object> destroy() {
        return Map.of("destroyedCaches", service.destroyAll());
    }

    @GetMapping("/admin/refdata/status")
    Map<String, Object> status() {
        return service.status();
    }
}
