package com.refdata.server;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.ConfigurationPropertiesScan;
import org.springframework.context.annotation.Bean;
import org.springframework.scheduling.annotation.EnableScheduling;

import java.time.LocalDate;

@SpringBootApplication
@ConfigurationPropertiesScan
@EnableScheduling
public class RefServerApplication {

    public static void main(String[] args) {
        SpringApplication.run(RefServerApplication.class, args);
    }

    /** Default business date = today in the configured zone. Replace with your bank calendar bean. */
    @Bean
    BusinessDateProvider businessDateProvider(RefServerProperties props) {
        return () -> LocalDate.now(props.zone());
    }
}
