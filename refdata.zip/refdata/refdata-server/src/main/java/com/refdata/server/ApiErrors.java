package com.refdata.server;

import org.springframework.http.HttpStatus;
import org.springframework.http.ProblemDetail;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import javax.cache.CacheException;

@RestControllerAdvice
class ApiErrors {

    @ExceptionHandler(RefCacheService.UnknownDatasetException.class)
    ProblemDetail unknown(RuntimeException e) {
        return ProblemDetail.forStatusAndDetail(HttpStatus.NOT_FOUND, e.getMessage());
    }

    /** 503 lets clients treat "warming" like an outage: retry or opt-in fallback. */
    @ExceptionHandler(RefCacheService.NotReadyException.class)
    ProblemDetail notReady(RuntimeException e) {
        return ProblemDetail.forStatusAndDetail(HttpStatus.SERVICE_UNAVAILABLE, e.getMessage());
    }

    @ExceptionHandler(IllegalArgumentException.class)
    ProblemDetail badRequest(RuntimeException e) {
        return ProblemDetail.forStatusAndDetail(HttpStatus.BAD_REQUEST, e.getMessage());
    }

    /** Read-through to the original source failed (javax.cache CacheLoaderException and friends). */
    @ExceptionHandler(CacheException.class)
    ProblemDetail sourceFailure(RuntimeException e) {
        return ProblemDetail.forStatusAndDetail(HttpStatus.BAD_GATEWAY, "Source load failed: " + e.getMessage());
    }
}
