package com.refdata.server;

import com.refdata.api.RefSourceDao;
import com.refdata.sources.JdbcRefSourceDao;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Component;

import javax.sql.DataSource;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Resolves each dataset's {@link RefSourceDao} at startup.
 * <p>
 * Ignite creates cache stores through a serializable factory on every server node, so the store
 * cannot receive Spring beans directly. This registry is populated before Ignite starts (the Ignite
 * bean depends on it) and the factory looks the DAO up here. All server nodes run this same app,
 * so every node has the same registry. This avoids the ignite-spring module and its Spring
 * version coupling.
 */
@Component
public class SourceRegistry {

    private static final Map<String, RefSourceDao> SOURCES = new ConcurrentHashMap<>();

    public SourceRegistry(RefServerProperties props, ApplicationContext ctx, ObjectProvider<DataSource> dataSource) {
        props.datasets().forEach((name, d) -> {
            if ((d.source() == null) == (d.jdbc() == null)) {
                throw new IllegalStateException("Dataset '" + name + "' must set exactly one of 'source' or 'jdbc'");
            }
            RefSourceDao dao = d.source() != null
                    ? ctx.getBean(d.source(), RefSourceDao.class)
                    : new JdbcRefSourceDao(dataSource.getObject(), d.jdbc());
            SOURCES.put(name, dao);
        });
    }

    static RefSourceDao get(String dataset) {
        RefSourceDao dao = SOURCES.get(dataset);
        if (dao == null) throw new IllegalStateException("No source registered for dataset '" + dataset + "' on this node");
        return dao;
    }
}
