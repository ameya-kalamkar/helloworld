package com.refdata.server;

import org.apache.ignite.Ignite;
import org.apache.ignite.Ignition;
import org.apache.ignite.cluster.ClusterState;
import org.apache.ignite.configuration.DataRegionConfiguration;
import org.apache.ignite.configuration.DataStorageConfiguration;
import org.apache.ignite.configuration.IgniteConfiguration;
import org.apache.ignite.logger.slf4j.Slf4jLogger;
import org.apache.ignite.spi.discovery.tcp.TcpDiscoverySpi;
import org.apache.ignite.spi.discovery.tcp.ipfinder.vm.TcpDiscoveryVmIpFinder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration(proxyBeanMethods = false)
class IgniteConfig {

    /** Taking SourceRegistry as a parameter guarantees DAOs are registered before any cache store is created. */
    @Bean(destroyMethod = "close")
    Ignite ignite(RefServerProperties props, SourceRegistry sourcesReadyFirst) {
        TcpDiscoveryVmIpFinder ipFinder = new TcpDiscoveryVmIpFinder();
        ipFinder.setAddresses(props.discoveryAddresses());

        DataRegionConfiguration region = new DataRegionConfiguration()
                .setName("default")
                .setMaxSize(props.dataRegionMaxSize().toBytes())
                .setPersistenceEnabled(props.persistence());

        DataStorageConfiguration storage = new DataStorageConfiguration().setDefaultDataRegionConfiguration(region);
        if (props.persistence() && props.storagePath() != null) storage.setStoragePath(props.storagePath());

        IgniteConfiguration cfg = new IgniteConfiguration()
                .setIgniteInstanceName(props.clusterName())
                .setDiscoverySpi(new TcpDiscoverySpi().setIpFinder(ipFinder))
                .setDataStorageConfiguration(storage)
                .setPeerClassLoadingEnabled(false)
                .setMetricsLogFrequency(0)
                .setGridLogger(new Slf4jLogger());

        Ignite ignite = Ignition.start(cfg);
        if (props.persistence()) {
            // With persistence the cluster starts inactive; activate once the baseline nodes are up.
            ignite.cluster().state(ClusterState.ACTIVE);
        }
        return ignite;
    }
}
