package com.refdata.server;

import com.github.benmanes.caffeine.cache.Cache;
import com.github.benmanes.caffeine.cache.Caffeine;
import com.refdata.api.LookupResult;
import com.refdata.api.RefSourceDao;
import com.refdata.server.RefServerProperties.Dataset;
import jakarta.annotation.PreDestroy;
import org.apache.ignite.Ignite;
import org.apache.ignite.IgniteCache;
import org.apache.ignite.IgniteDataStreamer;
import org.apache.ignite.IgniteLock;
import org.apache.ignite.cache.CacheAtomicityMode;
import org.apache.ignite.cache.CacheMode;
import org.apache.ignite.cache.CachePeekMode;
import org.apache.ignite.configuration.CacheConfiguration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.TreeSet;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;
import java.util.stream.Collectors;

/**
 * Owns the Ignite caches: one cache per dataset per business date ({@code ref_fx-rates_20261008}).
 * <ul>
 *   <li><b>Day-start warm</b>: bulk-load preload datasets with a data streamer, then publish the date.</li>
 *   <li><b>Read-through</b>: misses go to {@link RefCacheStore}; keys absent at the source are remembered
 *       for {@code negative-ttl} so bad keys do not hammer the source.</li>
 *   <li><b>Rollover</b>: the current-date pointer moves only after every required dataset is warm, so a
 *       client never sees a mix of two days. Old dates beyond {@code retain-dates} are destroyed.</li>
 * </ul>
 * Cluster state (current date, retained dates) lives in a small replicated meta cache; only one
 * node runs a warm at a time thanks to a cluster-wide lock.
 */
@Service
public class RefCacheService {

    private static final Logger log = LoggerFactory.getLogger(RefCacheService.class);
    private static final DateTimeFormatter SUFFIX = DateTimeFormatter.BASIC_ISO_DATE;
    private static final String META_CURRENT = "currentBusinessDate";
    private static final String META_DATES = "publishedDates";
    private static final String NEGATIVE_INVALIDATE_TOPIC = "refserver.negative.invalidate";

    private final Ignite ignite;
    private final RefServerProperties props;
    private final IgniteCache<String, String> meta;
    private final Cache<String, Boolean> negative;
    private final Map<String, IgniteCache<String, Map<String, Object>>> handles = new ConcurrentHashMap<>();
    private final Map<String, DatasetLoad> lastLoads = new ConcurrentHashMap<>();
    private final ExecutorService warmPool;

    public RefCacheService(Ignite ignite, RefServerProperties props) {
        this.ignite = ignite;
        this.props = props;
        this.meta = ignite.getOrCreateCache(new CacheConfiguration<String, String>(props.cachePrefix() + "__meta")
                .setCacheMode(CacheMode.REPLICATED)
                .setAtomicityMode(CacheAtomicityMode.ATOMIC));
        this.negative = Caffeine.newBuilder()
                .maximumSize(props.negativeMaxSize())
                .expireAfterWrite(props.negativeTtl())
                .build();
        AtomicInteger n = new AtomicInteger();
        this.warmPool = Executors.newFixedThreadPool(props.warmParallelism(), r -> {
            Thread t = new Thread(r, "refdata-warm-" + n.incrementAndGet());
            t.setDaemon(true);
            return t;
        });
        // Reloads on any node clear "absent" markers on every node.
        ignite.message().localListen(NEGATIVE_INVALIDATE_TOPIC, (nodeId, prefix) -> {
            dropNegatives((String) prefix);
            return true;
        });
    }

    // ------------------------------------------------------------------ lookups

    public LookupResult lookup(String dataset, LocalDate requestedDate, Collection<String> keys) {
        Dataset d = dataset(dataset);
        LocalDate date = resolveDate(requestedDate);
        if (keys.size() > props.maxKeysPerRequest()) {
            throw new IllegalArgumentException("Too many keys: " + keys.size() + " > " + props.maxKeysPerRequest());
        }

        Set<String> notFound = new LinkedHashSet<>();
        Set<String> toFetch = new LinkedHashSet<>();
        for (String k : new LinkedHashSet<>(keys)) {
            if (negative.getIfPresent(negKey(dataset, date, k)) != null) notFound.add(k); else toFetch.add(k);
        }

        Map<String, Map<String, Object>> found = toFetch.isEmpty() ? Map.of() : cache(dataset, d, date).getAll(toFetch);
        for (String k : toFetch) {
            if (!found.containsKey(k)) {
                notFound.add(k);
                if (d.readThrough()) negative.put(negKey(dataset, date, k), Boolean.TRUE);
            }
        }
        return new LookupResult(date, found, notFound);
    }

    public Optional<LocalDate> currentBusinessDate() {
        return Optional.ofNullable(meta.get(META_CURRENT)).map(LocalDate::parse);
    }

    public List<LocalDate> publishedDates() {
        String s = meta.get(META_DATES);
        if (s == null || s.isBlank()) return List.of();
        return java.util.Arrays.stream(s.split(",")).map(LocalDate::parse).sorted().toList();
    }

    public Set<String> datasets() {
        return props.datasets().keySet();
    }

    // ------------------------------------------------------------------ warm / reload / destroy

    /** Bulk-loads every preload dataset for the date, then publishes it if all required datasets succeeded. */
    public WarmReport warm(LocalDate date, boolean force) {
        if (!force && publishedDates().contains(date)) {
            return new WarmReport(date, "ALREADY_WARM", true, List.of());
        }
        IgniteLock lock = warmLock();
        if (!lock.tryLock()) {
            return new WarmReport(date, "BUSY", false, List.of());
        }
        try {
            log.info("Warming ref data for {}", date);
            List<Future<DatasetLoad>> futures = new ArrayList<>();
            List<String> names = new ArrayList<>();
            props.datasets().forEach((name, d) -> {
                if (d.preload()) {
                    names.add(name);
                    futures.add(warmPool.submit(() -> load(name, d, date, force)));
                }
            });

            List<DatasetLoad> loads = new ArrayList<>();
            for (int i = 0; i < futures.size(); i++) {
                try {
                    loads.add(futures.get(i).get());
                } catch (ExecutionException e) {
                    loads.add(DatasetLoad.failed(names.get(i), e.getCause()));
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    loads.add(DatasetLoad.failed(names.get(i), e));
                }
            }
            loads.forEach(l -> lastLoads.put(l.dataset(), l));

            boolean requiredOk = loads.stream()
                    .filter(l -> props.datasets().get(l.dataset()).required())
                    .allMatch(DatasetLoad::ok);
            if (requiredOk) {
                publish(date);
                log.info("Published business date {} ({} datasets)", date, loads.size());
            } else {
                log.error("Not publishing {}: required datasets failed {}", date,
                        loads.stream().filter(l -> !l.ok()).map(DatasetLoad::dataset).toList());
            }
            return new WarmReport(date, requiredOk ? "PUBLISHED" : "FAILED", requiredOk, loads);
        } finally {
            lock.unlock();
        }
    }

    /** Re-streams one dataset into an already published date (rows overwritten). */
    public DatasetLoad reload(String dataset, LocalDate requestedDate, boolean clearFirst) {
        Dataset d = dataset(dataset);
        LocalDate date = resolveDate(requestedDate);
        IgniteLock lock = warmLock();
        // IgniteLock.tryLock(timeout) throws the unchecked IgniteInterruptedException, not InterruptedException.
        if (!lock.tryLock(props.startupWaitTimeout().toMillis(), TimeUnit.MILLISECONDS)) {
            throw new IllegalStateException("Another warm/reload is running");
        }
        try {
            if (clearFirst) cache(dataset, d, date).clear(); // misses read-through until the stream completes
            DatasetLoad l = load(dataset, d, date, true);
            lastLoads.put(dataset, l);
            return l;
        } finally {
            lock.unlock();
        }
    }

    /** Destroys every data cache and clears the published dates. Readiness drops to 503 until the next warm. */
    public int destroyAll() {
        IgniteLock lock = warmLock();
        lock.lock();
        try {
            List<String> names = ignite.cacheNames().stream().filter(this::isDataCache).toList();
            names.forEach(ignite::destroyCache);
            handles.clear();
            meta.clear();
            lastLoads.clear();
            ignite.message(ignite.cluster().forServers()).send(NEGATIVE_INVALIDATE_TOPIC, "");
            log.warn("Destroyed {} ref data caches", names.size());
            return names.size();
        } finally {
            lock.unlock();
        }
    }

    public Map<String, Object> status() {
        Map<String, Object> out = new LinkedHashMap<>();
        out.put("currentBusinessDate", currentBusinessDate().orElse(null));
        out.put("publishedDates", publishedDates());
        Map<String, Object> ds = new LinkedHashMap<>();
        currentBusinessDate().ifPresent(date -> props.datasets().forEach((name, d) -> {
            Map<String, Object> s = new LinkedHashMap<>();
            IgniteCache<String, Map<String, Object>> c = ignite.cache(cacheName(name, date));
            s.put("rows", c == null ? 0 : c.sizeLong(CachePeekMode.PRIMARY));
            s.put("mode", d.cacheMode());
            s.put("preload", d.preload());
            s.put("lastLoadOnThisNode", lastLoads.get(name));
            ds.put(name, s);
        }));
        out.put("datasets", ds);
        out.put("negativeKeysOnThisNode", negative.estimatedSize());
        return out;
    }

    // ------------------------------------------------------------------ internals

    private DatasetLoad load(String name, Dataset d, LocalDate date, boolean overwrite) {
        long t0 = System.nanoTime();
        IgniteCache<String, Map<String, Object>> cache = cache(name, d, date);
        RefSourceDao dao = SourceRegistry.get(name);
        AtomicLong rows = new AtomicLong();
        try (IgniteDataStreamer<String, Map<String, Object>> streamer = ignite.dataStreamer(cache.getName())) {
            streamer.allowOverwrite(overwrite);
            dao.streamAll(date, (k, v) -> {
                streamer.addData(k, v);
                rows.incrementAndGet();
            });
        }
        ignite.message(ignite.cluster().forServers()).send(NEGATIVE_INVALIDATE_TOPIC, name + "|" + date + "|");
        long ms = TimeUnit.NANOSECONDS.toMillis(System.nanoTime() - t0);
        log.info("Loaded {} rows into {} in {} ms", rows.get(), cache.getName(), ms);
        return new DatasetLoad(name, true, rows.get(), ms, null);
    }

    private void publish(LocalDate date) {
        TreeSet<LocalDate> dates = new TreeSet<>(publishedDates());
        dates.add(date);
        while (dates.size() > props.retainDates()) {
            LocalDate old = dates.pollFirst();
            destroyDate(old);
        }
        meta.put(META_DATES, dates.stream().map(LocalDate::toString).collect(Collectors.joining(",")));
        meta.put(META_CURRENT, dates.last().toString()); // never moves backwards
    }

    private void destroyDate(LocalDate date) {
        String suffix = "_" + date.format(SUFFIX);
        ignite.cacheNames().stream()
                .filter(n -> isDataCache(n) && n.endsWith(suffix))
                .toList()
                .forEach(n -> {
                    ignite.destroyCache(n);
                    handles.remove(n);
                    log.info("Destroyed expired cache {}", n);
                });
    }

    private IgniteCache<String, Map<String, Object>> cache(String dataset, Dataset d, LocalDate date) {
        return handles.computeIfAbsent(cacheName(dataset, date), name -> {
            CacheConfiguration<String, Map<String, Object>> cc = new CacheConfiguration<String, Map<String, Object>>(name)
                    .setCacheMode(d.cacheMode())
                    .setAtomicityMode(CacheAtomicityMode.ATOMIC)
                    .setReadThrough(d.readThrough())
                    .setWriteThrough(false)
                    .setStatisticsEnabled(true);
            if (d.cacheMode() == CacheMode.PARTITIONED) cc.setBackups(d.backups());
            if (d.readThrough()) cc.setCacheStoreFactory(new RefCacheStore.Factory(dataset, date));
            return ignite.getOrCreateCache(cc);
        });
    }

    private LocalDate resolveDate(LocalDate requested) {
        LocalDate current = currentBusinessDate().orElseThrow(NotReadyException::new);
        if (requested == null || requested.equals(current)) return current;
        if (!publishedDates().contains(requested)) {
            throw new IllegalArgumentException("Business date " + requested + " is not published; available " + publishedDates());
        }
        return requested;
    }

    private Dataset dataset(String name) {
        Dataset d = props.datasets().get(name);
        if (d == null) throw new UnknownDatasetException(name);
        return d;
    }

    private IgniteLock warmLock() {
        return ignite.reentrantLock(props.cachePrefix() + "__warm", true, false, true);
    }

    private String cacheName(String dataset, LocalDate date) {
        return props.cachePrefix() + "_" + dataset + "_" + date.format(SUFFIX);
    }

    private boolean isDataCache(String name) {
        return name.startsWith(props.cachePrefix() + "_") && !name.startsWith(props.cachePrefix() + "__");
    }

    private static String negKey(String dataset, LocalDate date, String key) {
        return dataset + "|" + date + "|" + key;
    }

    private void dropNegatives(String prefix) {
        if (prefix.isEmpty()) negative.invalidateAll();
        else negative.asMap().keySet().removeIf(k -> k.startsWith(prefix));
    }

    @PreDestroy
    void shutdown() {
        warmPool.shutdownNow();
    }

    // ------------------------------------------------------------------ types

    public record DatasetLoad(String dataset, boolean ok, long rows, long millis, String error) {
        static DatasetLoad failed(String dataset, Throwable t) {
            log.error("Warm failed for {}", dataset, t);
            return new DatasetLoad(dataset, false, 0, 0, String.valueOf(t));
        }
    }

    /** status: PUBLISHED, FAILED, BUSY (another node is warming) or ALREADY_WARM. */
    public record WarmReport(LocalDate businessDate, String status, boolean published, List<DatasetLoad> loads) {}

    public static class UnknownDatasetException extends RuntimeException {
        UnknownDatasetException(String name) { super("Unknown dataset '" + name + "'"); }
    }

    public static class NotReadyException extends RuntimeException {
        NotReadyException() { super("No business date published yet; ref server is warming"); }
    }
}
