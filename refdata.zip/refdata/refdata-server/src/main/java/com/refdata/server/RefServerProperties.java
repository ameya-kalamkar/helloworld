package com.refdata.server;

import com.refdata.sources.JdbcSourceSpec;
import org.apache.ignite.cache.CacheMode;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.bind.DefaultValue;
import org.springframework.util.unit.DataSize;

import java.time.Duration;
import java.time.ZoneId;
import java.util.List;
import java.util.Map;

/**
 * @param clusterName        Ignite instance name
 * @param discoveryAddresses static IP finder addresses, e.g. {@code host1:47500..47509}
 * @param dataRegionMaxSize  off-heap size of the default data region
 * @param persistence        Ignite native persistence; lets a restart skip the full reload
 * @param storagePath        persistence directory (only used when persistence is on)
 * @param cachePrefix        data caches are named {@code <prefix>_<dataset>_<yyyyMMdd>}
 * @param zone               zone for the warm schedule and default business date
 * @param retainDates        how many warmed business dates to keep queryable
 * @param warmOnStartup      warm today's data if the cluster has no current date yet
 * @param warmCron           day-start warm schedule (Spring cron); only one node runs it
 * @param warmParallelism    datasets loaded concurrently during a warm
 * @param startupWaitTimeout how long a joining node waits for another node's warm to finish
 * @param negativeTtl        how long a key absent at the source is remembered as absent
 * @param negativeMaxSize    max remembered absent keys per node
 * @param maxKeysPerRequest  cap on keys in one lookup call
 */
@ConfigurationProperties("refserver")
public record RefServerProperties(
        @DefaultValue("refdata") String clusterName,
        @DefaultValue("127.0.0.1:47500..47509") List<String> discoveryAddresses,
        @DefaultValue("4GB") DataSize dataRegionMaxSize,
        @DefaultValue("false") boolean persistence,
        String storagePath,
        @DefaultValue("ref") String cachePrefix,
        @DefaultValue("America/Toronto") ZoneId zone,
        @DefaultValue("3") int retainDates,
        @DefaultValue("true") boolean warmOnStartup,
        @DefaultValue("0 45 5 * * MON-FRI") String warmCron,
        @DefaultValue("4") int warmParallelism,
        @DefaultValue("10m") Duration startupWaitTimeout,
        @DefaultValue("5m") Duration negativeTtl,
        @DefaultValue("1000000") long negativeMaxSize,
        @DefaultValue("10000") int maxKeysPerRequest,
        Map<String, Dataset> datasets) {

    public RefServerProperties {
        datasets = datasets == null ? Map.of() : Map.copyOf(datasets);
        if (retainDates < 1) throw new IllegalArgumentException("refserver.retain-dates must be >= 1");
    }

    /**
     * @param cacheMode   REPLICATED for small hot tables, PARTITIONED for large ones
     * @param backups     backups for PARTITIONED caches; 1 means a node loss does not hit the sources
     * @param preload     bulk-load at day start; false means filled only by read-through
     * @param required    the day's date is published only if every required dataset warmed successfully
     * @param readThrough load misses from the source; false means preloaded rows are the full truth
     * @param source      bean name of a {@code RefSourceDao}
     * @param jdbc        or an inline JDBC definition using the primary DataSource
     */
    public record Dataset(
            @DefaultValue("PARTITIONED") CacheMode cacheMode,
            @DefaultValue("1") int backups,
            @DefaultValue("true") boolean preload,
            @DefaultValue("true") boolean required,
            @DefaultValue("true") boolean readThrough,
            String source,
            JdbcSourceSpec jdbc) {
    }
}
