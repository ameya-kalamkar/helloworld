package com.refdata.server;

import com.refdata.api.RefSourceDao;
import org.apache.ignite.cache.store.CacheStoreAdapter;

import javax.cache.Cache;
import javax.cache.integration.CacheLoaderException;
import java.io.Serial;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionException;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Read-through store for one dataset and one business date: on a cache miss Ignite calls
 * {@link #loadAll} on the key's primary node, which loads from the original source.
 * <p>
 * Ignite does not guarantee a single source call when many requests miss the same key at once,
 * so concurrent loads of the same key on this node share one DAO call (single-flight). Because a
 * key always maps to one primary node, this effectively de-duplicates cluster-wide.
 * Write-through is off: the ref server never writes back to sources.
 */
public class RefCacheStore extends CacheStoreAdapter<String, Map<String, Object>> {

    private final String dataset;
    private final LocalDate businessDate;
    private final RefSourceDao dao;
    private final ConcurrentHashMap<String, CompletableFuture<Optional<Map<String, Object>>>> inflight = new ConcurrentHashMap<>();

    RefCacheStore(String dataset, LocalDate businessDate, RefSourceDao dao) {
        this.dataset = dataset;
        this.businessDate = businessDate;
        this.dao = dao;
    }

    @Override
    public Map<String, Object> load(String key) {
        return loadAll(java.util.List.of(key)).get(key);
    }

    @Override
    public Map<String, Map<String, Object>> loadAll(Iterable<? extends String> keys) {
        Map<String, CompletableFuture<Optional<Map<String, Object>>>> mine = new HashMap<>();
        Map<String, CompletableFuture<Optional<Map<String, Object>>>> others = new HashMap<>();
        for (String k : keys) {
            CompletableFuture<Optional<Map<String, Object>>> f = new CompletableFuture<>();
            CompletableFuture<Optional<Map<String, Object>>> existing = inflight.putIfAbsent(k, f);
            if (existing == null) mine.put(k, f); else others.put(k, existing);
        }

        Map<String, Map<String, Object>> out = new HashMap<>();
        if (!mine.isEmpty()) {
            try {
                Map<String, Map<String, Object>> loaded = dao.loadByKeys(businessDate, mine.keySet());
                mine.forEach((k, f) -> {
                    Map<String, Object> row = loaded.get(k);
                    if (row != null) out.put(k, row);
                    f.complete(Optional.ofNullable(row));
                });
            } catch (RuntimeException e) {
                mine.values().forEach(f -> f.completeExceptionally(e));
                throw new CacheLoaderException("Read-through failed for dataset '" + dataset + "' " + businessDate, e);
            } finally {
                mine.forEach(inflight::remove);
            }
        }

        others.forEach((k, f) -> {
            try {
                f.join().ifPresent(row -> out.put(k, row));
            } catch (CompletionException e) {
                throw new CacheLoaderException("Read-through failed for dataset '" + dataset + "' " + businessDate, e.getCause());
            }
        });
        return out;
    }

    @Override
    public void write(Cache.Entry<? extends String, ? extends Map<String, Object>> entry) {
        throw new UnsupportedOperationException("Ref server is read-only towards sources");
    }

    @Override
    public void delete(Object key) {
        throw new UnsupportedOperationException("Ref server is read-only towards sources");
    }

    /** Serializable factory shipped with the cache configuration to every server node. */
    static final class Factory implements javax.cache.configuration.Factory<RefCacheStore> {
        @Serial private static final long serialVersionUID = 1L;
        private final String dataset;
        private final String businessDate;

        Factory(String dataset, LocalDate businessDate) {
            this.dataset = dataset;
            this.businessDate = businessDate.toString();
        }

        @Override
        public RefCacheStore create() {
            return new RefCacheStore(dataset, LocalDate.parse(businessDate), SourceRegistry.get(dataset));
        }
    }
}
