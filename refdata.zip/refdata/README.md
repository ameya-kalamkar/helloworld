# refdata: central ref server + routing client

```
executor JVM (Flink / Spark / Java)                 ref server cluster (Spring Boot + Ignite 2.18)
┌───────────────────────────────┐   HTTP/JSON     ┌───────────────────────────────────────────┐
│ RefData (singleton facade)    │ ─────────────▶  │ /refdata/{dataset}/lookup                  │
│  └ RoutingRefClient           │                 │  ├ negative cache (absent keys, 5m)        │
│     ├ local Caffeine cache    │                 │  └ Ignite cache ref_<dataset>_<yyyyMMdd>   │
│     ├ ref-server provider ────┘                 │       ├ day-start warm (DataStreamer)      │
│     └ direct provider (opt-in)── JDBC/REST ─┐   │       └ miss → RefCacheStore read-through ─┐
└───────────────────────────────┘             │   └───────────────────────────────────────────┘ │
                                              └──────────▶ original sources ◀──────────────────┘
                                                 (same RefSourceDao classes on both paths)
```

| Module | Depends on | Purpose |
|---|---|---|
| `refdata-api` | JDK only | `RefSourceDao`, `LookupResult`, `Route`, `RefDataClient`, `RefRows` |
| `refdata-sources` | spring-jdbc | `JdbcRefSourceDao` (JdbcClient, no JPA) |
| `refdata-server` | Boot, Ignite core | Ignite caches, warm, read-through, rollover, REST |
| `refdata-client` | Jackson, Caffeine | routing, opt-in fallback, breaker, bulkhead; no Ignite |

## Server

* **Day start**: `warm-cron` (and startup if the cluster has no current date) bulk-loads every
  `preload` dataset. The business date is published only if every `required` dataset loaded, so
  clients never see two days mixed. Only one node warms (cluster lock); joining nodes reuse it.
* **Miss**: read-through to the source via the dataset's DAO, single-flight per key; keys absent at
  the source are remembered for `negative-ttl`.
* **Readiness**: `/actuator/health/readiness` stays DOWN until the startup warm publishes.
* **Rollover**: keeps `retain-dates` business dates; older caches are destroyed.
* Run with the `--add-opens` flags in `refdata-server/build.gradle` (Ignite 2.x on JDK 17).

| Endpoint | |
|---|---|
| `POST /refdata/{dataset}/lookup` `{"businessDate"?, "keys":[...]}` | batch lookup (Java + Python) |
| `GET /refdata/{dataset}/keys/{key}` | single key |
| `GET /refdata/business-date` | current and published dates |
| `POST /admin/refdata/warm?businessDate=&force=` | warm a date |
| `POST /admin/refdata/{dataset}/reload?clearFirst=` | re-stream one dataset |
| `POST /admin/refdata/destroy` · `GET /admin/refdata/status` | clean everything · status |

Secure `/admin/**` before production.

## Client routes (per dataset, fallback opt-in)

| Route | Behaviour |
|---|---|
| `REF_SERVER` (default) | server only; failure → `RefDataUnavailableException` |
| `DIRECT` | named direct provider only |
| `REF_SERVER_THEN_DIRECT` | server within timeout, then direct for missing keys (one batch, capped) |
| `DIRECT_THEN_REF_SERVER` | source first, server as backup |

Rules: default route must be `REF_SERVER`; any DIRECT route needs a registered `direct` provider
(checked at build/startup); a "not found" answer from a provider stands even if a later fallback fails;
results from direct calls stay in the local cache and are never written to the server.

### Spring executor

```yaml
refdata:
  client:
    server-url: http://ref-server-lb:8080
    defaults: { timeout: 50ms }
    breaker: { failure-threshold: 5, open-for: 30s }
    local-cache: { max-size: 200000, expire-after-write: 10m }
    direct-sources:
      fxJdbc: fxRatesDao             # RefSourceDao bean
    datasets:
      fx-rates: { route: REF_SERVER_THEN_DIRECT, direct: fxJdbc, fallback-max-keys: 5000 }
```

### Flink / Spark / plain Java

```java
// RichFunction.open() or mapPartitions: one client per JVM, shared by all slots
RefData.initIfAbsent(() -> RoutingRefClient.builder()
        .provider(RefServerProvider.create("http://ref-server-lb:8080"))
        .provider(new DirectSourceProvider("fxJdbc", fxDao), 2, 16)   // small bulkhead for a fragile source
        .route("fx-rates", DatasetRoute.refServerThenDirect("fxJdbc").withTimeout(Duration.ofMillis(50)))
        .localCache(new CaffeineLocalCache(200_000, Duration.ofMinutes(10)))
        .build());

LookupResult r = RefData.getAll("fx-rates", pairs);   // batch, never per record
```

Shade/relocate Jackson and Caffeine in the Flink job jar if they clash with the cluster's versions.

## Metrics (Micrometer, if present)

`refdata.client.rows{dataset,source}`, `refdata.fallback{dataset,provider}` (alert when non-zero for
minutes), `refdata.client.failures{dataset,provider,error}`, `refdata.client.skipped{dataset,provider}`.
