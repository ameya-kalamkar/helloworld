package com.refdata.client;

import com.refdata.api.LookupResult;
import com.refdata.api.RefDataUnavailableException;
import com.refdata.api.RefRows;
import com.refdata.api.Route;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.time.Duration;
import java.time.LocalDate;
import java.util.Collection;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.atomic.AtomicInteger;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

class RoutingRefClientTest {

    static final LocalDate D = LocalDate.of(2026, 10, 8);

    /** Provider whose behaviour is a lambda; records calls. */
    static final class Fake implements RefDataProvider {
        interface Impl { LookupResult apply(LocalDate d, Collection<String> keys) throws Exception; }
        final String name; final Impl impl;
        final AtomicInteger calls = new AtomicInteger();
        volatile Collection<String> lastKeys; volatile LocalDate lastDate;
        Fake(String name, Impl impl) { this.name = name; this.impl = impl; }
        public String name() { return name; }
        public LookupResult lookup(String ds, LocalDate d, Collection<String> keys, Duration t) throws Exception {
            calls.incrementAndGet(); lastKeys = keys; lastDate = d;
            return impl.apply(d, keys);
        }
    }

    static Fake serving(String name, Map<String, Map<String, Object>> data) {
        return new Fake(name, (d, keys) -> {
            Map<String, Map<String, Object>> f = new HashMap<>();
            Set<String> nf = new LinkedHashSet<>();
            for (String k : keys) { if (data.containsKey(k)) f.put(k, data.get(k)); else nf.add(k); }
            return new LookupResult(d, f, nf);
        });
    }

    static Fake failing(String name) {
        return new Fake(name, (d, k) -> { throw new java.io.IOException("connection refused"); });
    }

    static Fake slow(String name) {
        return new Fake(name, (d, k) -> { Thread.sleep(2_000); return new LookupResult(d, Map.of(), Set.of()); });
    }

    static Map<String, Object> row(String v) { return Map.of("v", v); }

    static RoutingRefClient.Builder base() {
        return RoutingRefClient.builder().businessDate(() -> D).defaultTimeout(Duration.ofMillis(200));
    }

    @Test
    void refServerOnlyServesAndPassesBusinessDate() {
        Fake server = serving(Route.REF_SERVER_PROVIDER, Map.of("A", row("a")));
        try (RoutingRefClient c = base().provider(server).build()) {
            LookupResult r = c.getAll("fx", List.of("A", "B"));
            assertEquals(Map.of("A", row("a")), r.found());
            assertEquals(Set.of("B"), r.notFound());
            assertEquals(D, server.lastDate);
        }
    }

    @Test
    void localCacheHitSkipsProviders() {
        Fake server = serving(Route.REF_SERVER_PROVIDER, Map.of("A", row("a")));
        try (RoutingRefClient c = base().provider(server).localCache(new MapCache()).build()) {
            c.getAll("fx", List.of("A"));
            c.getAll("fx", List.of("A"));
            assertEquals(1, server.calls.get());
        }
    }

    @Test
    void nonOptedDatasetNeverFallsBack() {
        Fake server = failing(Route.REF_SERVER_PROVIDER);
        Fake direct = serving("fxJdbc", Map.of("A", row("a")));
        try (RoutingRefClient c = base().provider(server).provider(direct).build()) {
            RefDataUnavailableException e = assertThrows(RefDataUnavailableException.class, () -> c.getAll("fx", List.of("A")));
            assertEquals(Set.of("A"), e.unresolvedKeys());
            assertEquals(0, direct.calls.get());
        }
    }

    @Test
    void optedDatasetFallsBackOnTimeout() {
        Fake server = slow(Route.REF_SERVER_PROVIDER);
        Fake direct = serving("fxJdbc", Map.of("A", row("a")));
        try (RoutingRefClient c = base().provider(server).provider(direct)
                .route("fx", DatasetRoute.refServerThenDirect("fxJdbc").withTimeout(Duration.ofMillis(100))).build()) {
            long t0 = System.nanoTime();
            LookupResult r = c.getAll("fx", List.of("A"));
            long ms = (System.nanoTime() - t0) / 1_000_000;
            assertEquals(row("a"), r.found().get("A"));
            assertTrue(ms < 1_000, "fallback must not wait for the slow server, took " + ms + " ms");
        }
    }

    @Test
    void notFoundKeysGoToDirectInOneBatch() {
        Fake server = serving(Route.REF_SERVER_PROVIDER, Map.of("A", row("a")));
        Fake direct = serving("fxJdbc", Map.of("B", row("b")));
        try (RoutingRefClient c = base().provider(server).provider(direct)
                .route("fx", DatasetRoute.refServerThenDirect("fxJdbc")).build()) {
            LookupResult r = c.getAll("fx", List.of("A", "B", "C"));
            assertEquals(Set.of("A", "B"), r.found().keySet());
            assertEquals(Set.of("C"), r.notFound());
            assertEquals(1, direct.calls.get());
            assertEquals(Set.of("B", "C"), Set.copyOf(direct.lastKeys));
        }
    }

    @Test
    void fallbackCapProtectsSource() {
        Fake server = failing(Route.REF_SERVER_PROVIDER);
        Fake direct = serving("fxJdbc", Map.of());
        try (RoutingRefClient c = base().provider(server).provider(direct)
                .route("fx", DatasetRoute.refServerThenDirect("fxJdbc").withFallbackMaxKeys(2)).build()) {
            assertThrows(RefDataUnavailableException.class, () -> c.getAll("fx", List.of("A", "B", "C")));
            assertEquals(0, direct.calls.get());
        }
    }

    @Test
    void definitiveNotFoundSurvivesFailedFallback() {
        Fake server = serving(Route.REF_SERVER_PROVIDER, Map.of());
        Fake direct = failing("fxJdbc");
        try (RoutingRefClient c = base().provider(server).provider(direct)
                .route("fx", DatasetRoute.refServerThenDirect("fxJdbc")).build()) {
            LookupResult r = c.getAll("fx", List.of("X"));
            assertEquals(Set.of("X"), r.notFound());
        }
    }

    @Test
    void breakerOpensAndRoutesStraightToDirect() {
        Fake server = failing(Route.REF_SERVER_PROVIDER);
        Fake direct = serving("fxJdbc", Map.of("A", row("a")));
        try (RoutingRefClient c = base().provider(server).provider(direct).breaker(3, Duration.ofMinutes(1))
                .route("fx", DatasetRoute.refServerThenDirect("fxJdbc")).build()) {
            for (int i = 0; i < 10; i++) c.getAll("fx", List.of("A"));
            assertEquals(3, server.calls.get());
            assertEquals(10, direct.calls.get());
            assertEquals(CircuitBreaker.State.OPEN, c.breakerStates().get(Route.REF_SERVER_PROVIDER));
        }
    }

    @Test
    void directOnlyRouteSkipsServer() {
        Fake server = serving(Route.REF_SERVER_PROVIDER, Map.of());
        Fake file = serving("instrumentFile", Map.of("I1", row("i")));
        try (RoutingRefClient c = base().provider(server).provider(file)
                .route("big-scan", DatasetRoute.direct("instrumentFile")).build()) {
            assertEquals(row("i"), c.get("big-scan", "I1").orElseThrow());
            assertEquals(0, server.calls.get());
        }
    }

    @Test
    void configIsValidatedAtBuild() {
        Fake server = serving(Route.REF_SERVER_PROVIDER, Map.of());
        assertThrows(IllegalStateException.class,
                () -> base().provider(server).defaultRoute(DatasetRoute.refServerThenDirect("x")).build());
        assertThrows(IllegalStateException.class,
                () -> base().provider(server).route("fx", DatasetRoute.refServerThenDirect("missing")).build());
        assertThrows(IllegalArgumentException.class,
                () -> new DatasetRoute(Route.REF_SERVER_THEN_DIRECT, null, null, 10, true));
        assertThrows(IllegalStateException.class, () -> base().build()); // REF_SERVER default but no server provider
    }

    @Test
    void breakerHalfOpenTrial() throws Exception {
        CircuitBreaker b = new CircuitBreaker(1, Duration.ofMillis(50));
        b.onFailure();
        assertEquals(CircuitBreaker.State.OPEN, b.state());
        assertTrue(!b.allowRequest());
        Thread.sleep(80);
        assertTrue(b.allowRequest());          // trial
        assertTrue(!b.allowRequest());         // only one trial
        b.onSuccess();
        assertEquals(CircuitBreaker.State.CLOSED, b.state());
    }

    @Test
    void businessDateResolverKeepsLastKnownOnFailure() {
        AtomicInteger n = new AtomicInteger();
        CachingBusinessDateResolver r = new CachingBusinessDateResolver(() -> {
            if (n.incrementAndGet() > 1) throw new IllegalStateException("down");
            return D;
        }, Duration.ZERO, () -> LocalDate.of(2000, 1, 1));
        assertEquals(D, r.get());
        assertEquals(D, r.get());
    }

    @Test
    void rowsNormaliseToJsonStableTypes() {
        Map<String, Object> raw = new HashMap<>();
        raw.put("CCY_PAIR", "USDCAD");
        raw.put("BID", new BigDecimal("1.37500"));
        raw.put("LOT", new BigDecimal("1000.00"));
        raw.put("N", 7);
        raw.put("AS_OF", java.sql.Timestamp.valueOf("2026-10-08 05:45:00"));
        raw.put("NOTE", null);
        Map<String, Object> r = RefRows.normalize(raw);
        assertEquals("USDCAD", r.get("ccy_pair"));
        assertEquals(new BigDecimal("1.375"), r.get("bid"));
        assertEquals(1000L, r.get("lot"));
        assertEquals(7L, r.get("n"));
        assertEquals("2026-10-08T05:45", r.get("as_of"));
        assertTrue(r.containsKey("note") && r.get("note") == null);
    }

    static final class MapCache implements LocalCache {
        final Map<String, Map<String, Object>> m = new HashMap<>();
        public Map<String, Map<String, Object>> getAllPresent(String ds, LocalDate d, Collection<String> keys) {
            Map<String, Map<String, Object>> out = new HashMap<>();
            for (String k : keys) { Map<String, Object> v = m.get(ds + d + k); if (v != null) out.put(k, v); }
            return out;
        }
        public void putAll(String ds, LocalDate d, Map<String, Map<String, Object>> rows) { rows.forEach((k, v) -> m.put(ds + d + k, v)); }
        public void invalidateAll() { m.clear(); }
    }
}
