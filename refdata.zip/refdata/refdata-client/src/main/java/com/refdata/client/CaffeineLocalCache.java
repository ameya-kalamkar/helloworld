package com.refdata.client;

import com.github.benmanes.caffeine.cache.Cache;
import com.github.benmanes.caffeine.cache.Caffeine;

import java.time.Duration;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** Bounded in-process cache. Including the business date in the key means a date roll never serves stale rows. */
public final class CaffeineLocalCache implements LocalCache {

    private record Key(String dataset, LocalDate date, String key) {}

    private final Cache<Key, Map<String, Object>> cache;

    public CaffeineLocalCache(long maxSize, Duration expireAfterWrite) {
        this.cache = Caffeine.newBuilder().maximumSize(maxSize).expireAfterWrite(expireAfterWrite).build();
    }

    @Override
    public Map<String, Map<String, Object>> getAllPresent(String dataset, LocalDate date, Collection<String> keys) {
        List<Key> ks = new ArrayList<>(keys.size());
        for (String k : keys) ks.add(new Key(dataset, date, k));
        Map<Key, Map<String, Object>> hits = cache.getAllPresent(ks);
        Map<String, Map<String, Object>> out = new HashMap<>(hits.size() * 2);
        hits.forEach((k, v) -> out.put(k.key(), v));
        return out;
    }

    @Override
    public void putAll(String dataset, LocalDate date, Map<String, Map<String, Object>> rows) {
        Map<Key, Map<String, Object>> m = new HashMap<>(rows.size() * 2);
        rows.forEach((k, v) -> m.put(new Key(dataset, date, k), v));
        cache.putAll(m);
    }

    @Override
    public void invalidateAll() {
        cache.invalidateAll();
    }
}
