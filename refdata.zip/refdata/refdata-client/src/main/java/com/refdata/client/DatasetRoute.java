package com.refdata.client;

import com.refdata.api.Route;

import java.time.Duration;
import java.util.List;

/**
 * Per-dataset routing policy.
 *
 * @param route              provider order; anything with DIRECT is an explicit opt-in
 * @param timeout            SLA budget per provider call; null inherits the client default
 * @param direct             name of the direct provider, required when the route uses DIRECT
 * @param fallbackMaxKeys    max keys one fallback call may send to a direct source, so an outage cannot flood it
 * @param fallbackOnNotFound also ask the next provider for keys the previous one reported as not found
 */
public record DatasetRoute(Route route, Duration timeout, String direct, int fallbackMaxKeys, boolean fallbackOnNotFound) {

    public static final int DEFAULT_FALLBACK_MAX_KEYS = 5_000;

    public DatasetRoute {
        if (route == null) route = Route.REF_SERVER;
        if (timeout != null && (timeout.isNegative() || timeout.isZero())) {
            throw new IllegalArgumentException("timeout must be > 0");
        }
        if (route.usesDirect() && (direct == null || direct.isBlank())) {
            throw new IllegalArgumentException("route " + route + " requires a 'direct' provider");
        }
        if (Route.REF_SERVER_PROVIDER.equals(direct)) {
            throw new IllegalArgumentException("'direct' cannot be the ref server");
        }
        if (fallbackMaxKeys <= 0) throw new IllegalArgumentException("fallbackMaxKeys must be > 0");
    }

    public static DatasetRoute refServer() {
        return new DatasetRoute(Route.REF_SERVER, null, null, DEFAULT_FALLBACK_MAX_KEYS, false);
    }

    public static DatasetRoute direct(String provider) {
        return new DatasetRoute(Route.DIRECT, null, provider, DEFAULT_FALLBACK_MAX_KEYS, false);
    }

    /** REF_SERVER_THEN_DIRECT: the usual SLA safety net. */
    public static DatasetRoute refServerThenDirect(String provider) {
        return new DatasetRoute(Route.REF_SERVER_THEN_DIRECT, null, provider, DEFAULT_FALLBACK_MAX_KEYS, true);
    }

    public DatasetRoute withTimeout(Duration t) {
        return new DatasetRoute(route, t, direct, fallbackMaxKeys, fallbackOnNotFound);
    }

    public DatasetRoute withFallbackMaxKeys(int n) {
        return new DatasetRoute(route, timeout, direct, n, fallbackOnNotFound);
    }

    public DatasetRoute withFallbackOnNotFound(boolean b) {
        return new DatasetRoute(route, timeout, direct, fallbackMaxKeys, b);
    }

    public List<String> chain() {
        return route.chain(direct);
    }
}
