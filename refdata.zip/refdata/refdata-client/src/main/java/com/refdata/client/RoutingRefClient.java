package com.refdata.client;

import com.refdata.api.LookupResult;
import com.refdata.api.RefDataClient;
import com.refdata.api.RefDataUnavailableException;
import com.refdata.api.Route;

import java.time.Duration;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Supplier;

/**
 * The executor-side client. For each dataset it follows the configured {@link DatasetRoute}:
 * <ol>
 *   <li>serve what it can from the local cache;</li>
 *   <li>call providers in route order for the remaining keys, each call bounded by the dataset's
 *       timeout, the provider's bulkhead and circuit breaker;</li>
 *   <li>pass keys that are still missing to the next provider in one batch (fallback), capped by
 *       {@code fallbackMaxKeys}; datasets without a DIRECT route never fall back (opt-in).</li>
 * </ol>
 * If no provider gave an answer for some keys (all failed, timed out, were circuit-open or skipped)
 * a {@link RefDataUnavailableException} is thrown. If a provider answered "not found", those keys
 * are returned in {@link LookupResult#notFound()}, even if a later fallback attempt failed.
 * <p>
 * Thread-safe; create one per JVM and share it (see {@link RefData}).
 */
public final class RoutingRefClient implements RefDataClient {

    private static final System.Logger log = System.getLogger(RoutingRefClient.class.getName());

    private final Map<String, Guarded> providers;
    private final Map<String, DatasetRoute> routes;
    private final DatasetRoute defaultRoute;
    private final LocalCache localCache;
    private final Supplier<LocalDate> businessDate;
    private final RoutingListener listener;

    private RoutingRefClient(Builder b, Map<String, Guarded> providers, Supplier<LocalDate> businessDate) {
        this.providers = providers;
        this.defaultRoute = b.defaultRoute.withTimeout(b.defaultTimeout);
        Map<String, DatasetRoute> r = new HashMap<>();
        b.routes.forEach((ds, route) -> r.put(ds, route.timeout() == null ? route.withTimeout(b.defaultTimeout) : route));
        this.routes = Map.copyOf(r);
        this.localCache = b.localCache;
        this.businessDate = businessDate;
        this.listener = b.listener;
    }

    public static Builder builder() {
        return new Builder();
    }

    @Override
    public LookupResult getAll(String dataset, LocalDate requestedDate, Collection<String> keys) {
        Objects.requireNonNull(dataset, "dataset");
        Objects.requireNonNull(keys, "keys");
        DatasetRoute route = routes.getOrDefault(dataset, defaultRoute);
        LocalDate date = requestedDate != null ? requestedDate : businessDate.get();

        Set<String> remaining = new LinkedHashSet<>(keys);
        Map<String, Map<String, Object>> found = new HashMap<>(localCache.getAllPresent(dataset, date, remaining));
        remaining.removeAll(found.keySet());
        if (!found.isEmpty()) listener.onLocalHit(dataset, found.size());
        if (remaining.isEmpty()) return new LookupResult(date, found, Set.of());

        List<String> chain = route.chain();
        List<String> reasons = new ArrayList<>();
        Throwable lastError = null;
        boolean answered = false; // some provider gave a definitive answer for the keys still remaining

        for (int i = 0; i < chain.size() && !remaining.isEmpty(); i++) {
            String name = chain.get(i);
            boolean fallback = i > 0;
            if (fallback && answered && !route.fallbackOnNotFound()) break;
            if (fallback && remaining.size() > route.fallbackMaxKeys()) {
                skip(dataset, name, remaining.size() + " keys exceed fallbackMaxKeys " + route.fallbackMaxKeys(), reasons);
                continue;
            }

            Guarded p = providers.get(name);
            if (!p.breaker.allowRequest()) {
                skip(dataset, name, "circuit open", reasons);
                continue;
            }
            try {
                LookupResult result = p.call(dataset, date, List.copyOf(remaining), route.timeout());
                p.breaker.onSuccess();
                Map<String, Map<String, Object>> got = new HashMap<>();
                for (String k : remaining) {
                    Map<String, Object> row = result.found().get(k);
                    if (row != null) got.put(k, Collections.unmodifiableMap(new LinkedHashMap<>(row)));
                }
                found.putAll(got);
                localCache.putAll(dataset, date, got);
                remaining.removeAll(got.keySet());
                answered = true;
                listener.onProviderHit(dataset, name, got.size(), fallback);
            } catch (BulkheadFullException e) {
                skip(dataset, name, e.getMessage(), reasons);  // overload, not a provider fault: breaker untouched
                lastError = e;
            } catch (Exception e) {
                if (e instanceof InterruptedException) Thread.currentThread().interrupt();
                p.breaker.onFailure();
                lastError = e;
                String reason = name + ": " + describe(e, route.timeout());
                reasons.add(reason);
                listener.onFailure(dataset, name, e);
                log.log(System.Logger.Level.WARNING, "Ref data provider failed for dataset {0}: {1}", dataset, reason);
            }
        }

        if (!remaining.isEmpty() && !answered) {
            throw new RefDataUnavailableException(dataset, remaining, reasons, lastError);
        }
        return new LookupResult(date, found, remaining);
    }

    @Override
    public LocalDate currentBusinessDate() {
        return businessDate.get();
    }

    @Override
    public void invalidateLocal() {
        localCache.invalidateAll();
    }

    /** Breaker state per provider, for health checks. */
    public Map<String, CircuitBreaker.State> breakerStates() {
        Map<String, CircuitBreaker.State> m = new LinkedHashMap<>();
        providers.forEach((n, g) -> m.put(n, g.breaker.state()));
        return m;
    }

    @Override
    public void close() {
        RefData.release(this);
        providers.values().forEach(g -> {
            g.pool.shutdownNow();
            if (g.provider instanceof AutoCloseable c) {
                try { c.close(); } catch (Exception ignored) { }
            }
        });
    }

    private void skip(String dataset, String provider, String why, List<String> reasons) {
        reasons.add(provider + ": " + why);
        listener.onSkipped(dataset, provider, why);
    }

    private static String describe(Exception e, Duration timeout) {
        if (e instanceof TimeoutException) return "timed out after " + timeout.toMillis() + " ms";
        return e.getClass().getSimpleName() + (e.getMessage() == null ? "" : " " + e.getMessage());
    }

    // ------------------------------------------------------------------ provider guard

    static final class BulkheadFullException extends Exception {
        BulkheadFullException(String provider) { super("bulkhead full for " + provider); }
    }

    private static final class Guarded {
        final RefDataProvider provider;
        final CircuitBreaker breaker;
        final ThreadPoolExecutor pool;

        Guarded(RefDataProvider provider, CircuitBreaker breaker, int threads, int queue) {
            this.provider = provider;
            this.breaker = breaker;
            AtomicInteger n = new AtomicInteger();
            this.pool = new ThreadPoolExecutor(threads, threads, 60, TimeUnit.SECONDS, new ArrayBlockingQueue<>(queue), r -> {
                Thread t = new Thread(r, "refdata-" + provider.name() + "-" + n.incrementAndGet());
                t.setDaemon(true);
                return t;
            }, new ThreadPoolExecutor.AbortPolicy());
            this.pool.allowCoreThreadTimeOut(true);
        }

        LookupResult call(String dataset, LocalDate date, List<String> keys, Duration timeout) throws Exception {
            Future<LookupResult> f;
            try {
                f = pool.submit(() -> provider.lookup(dataset, date, keys, timeout));
            } catch (RejectedExecutionException e) {
                throw new BulkheadFullException(provider.name());
            }
            try {
                return f.get(timeout.toNanos(), TimeUnit.NANOSECONDS);
            } catch (TimeoutException e) {
                f.cancel(true);
                throw e;
            } catch (ExecutionException e) {
                Throwable c = e.getCause();
                if (c instanceof Exception ex) throw ex;
                throw e;
            }
        }
    }

    // ------------------------------------------------------------------ builder

    public static final class Builder {
        private final Map<String, RefDataProvider> providerList = new LinkedHashMap<>();
        private final Map<String, int[]> bulkheads = new HashMap<>();
        private final Map<String, DatasetRoute> routes = new LinkedHashMap<>();
        private DatasetRoute defaultRoute = DatasetRoute.refServer();
        private Duration defaultTimeout = Duration.ofMillis(50);
        private int breakerThreshold = 5;
        private Duration breakerOpenFor = Duration.ofSeconds(30);
        private int bulkheadThreads = 8;
        private int bulkheadQueue = 64;
        private LocalCache localCache = LocalCache.none();
        private RoutingListener listener = RoutingListener.NOOP;
        private Supplier<LocalDate> businessDate;
        private Duration businessDateRefresh = Duration.ofSeconds(30);
        private ZoneId zone = ZoneId.systemDefault();

        public Builder provider(RefDataProvider p) {
            if (providerList.putIfAbsent(p.name(), p) != null) throw new IllegalArgumentException("Duplicate provider " + p.name());
            return this;
        }

        /** Provider with its own bulkhead size, e.g. a small pool for a fragile source. */
        public Builder provider(RefDataProvider p, int threads, int queue) {
            provider(p);
            bulkheads.put(p.name(), new int[]{threads, queue});
            return this;
        }

        public Builder route(String dataset, DatasetRoute route) { routes.put(dataset, route); return this; }
        public Builder defaultRoute(DatasetRoute route) { this.defaultRoute = route; return this; }
        public Builder defaultTimeout(Duration t) { this.defaultTimeout = t; return this; }
        public Builder breaker(int threshold, Duration openFor) { this.breakerThreshold = threshold; this.breakerOpenFor = openFor; return this; }
        public Builder bulkhead(int threads, int queue) { this.bulkheadThreads = threads; this.bulkheadQueue = queue; return this; }
        public Builder localCache(LocalCache c) { this.localCache = c; return this; }
        public Builder listener(RoutingListener l) { this.listener = l; return this; }
        /** Explicit business date source; by default the ref server's date, cached for {@link #businessDateRefresh}. */
        public Builder businessDate(Supplier<LocalDate> s) { this.businessDate = s; return this; }
        public Builder businessDateRefresh(Duration d) { this.businessDateRefresh = d; return this; }
        /** Zone for the last-resort "today" when the ref server has never been reachable. */
        public Builder zone(ZoneId z) { this.zone = z; return this; }

        public RoutingRefClient build() {
            validate();
            Map<String, Guarded> guarded = new LinkedHashMap<>();
            providerList.forEach((name, p) -> {
                int[] bh = bulkheads.getOrDefault(name, new int[]{bulkheadThreads, bulkheadQueue});
                guarded.put(name, new Guarded(p, new CircuitBreaker(breakerThreshold, breakerOpenFor), bh[0], bh[1]));
            });
            Supplier<LocalDate> date = businessDate;
            if (date == null) {
                RefDataProvider server = providerList.get(Route.REF_SERVER_PROVIDER);
                Supplier<LocalDate> today = () -> LocalDate.now(zone);
                date = server instanceof RefDataProvider.BusinessDateSource src
                        ? new CachingBusinessDateResolver(src::currentBusinessDate, businessDateRefresh, today)
                        : today;
            }
            return new RoutingRefClient(this, Map.copyOf(guarded), date);
        }

        private void validate() {
            if (defaultRoute.route() != Route.REF_SERVER) {
                throw new IllegalStateException("Default route must be REF_SERVER; direct fallback is opt-in per dataset");
            }
            List<String> errors = new ArrayList<>();
            Map<String, DatasetRoute> all = new LinkedHashMap<>(routes);
            all.put("<default>", defaultRoute);
            all.forEach((ds, r) -> {
                for (String p : r.chain()) {
                    if (!providerList.containsKey(p)) errors.add("dataset '" + ds + "' routes to unknown provider '" + p + "'");
                }
                if (r.route() == Route.REF_SERVER && r.direct() != null) {
                    log.log(System.Logger.Level.WARNING,
                            "Dataset {0} names direct provider {1} but its route is REF_SERVER; it will never be used", ds, r.direct());
                }
            });
            if (!errors.isEmpty()) throw new IllegalStateException("Invalid ref data client config: " + String.join("; ", errors));
        }
    }
}
