package com.refdata.client.spring;

import com.refdata.api.RefDataClient;
import com.refdata.api.RefSourceDao;
import com.refdata.api.Route;
import com.refdata.client.CaffeineLocalCache;
import com.refdata.client.DatasetRoute;
import com.refdata.client.DirectSourceProvider;
import com.refdata.client.RefData;
import com.refdata.client.RefServerProvider;
import com.refdata.client.RoutingListener;
import com.refdata.client.RoutingRefClient;
import io.micrometer.core.instrument.MeterRegistry;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * Builds the {@link RefDataClient} from {@code refdata.client.*}, validates routes at startup
 * (fail fast) and registers it with the {@link RefData} singleton facade.
 */
@AutoConfiguration(afterName = "org.springframework.boot.actuate.autoconfigure.metrics.CompositeMeterRegistryAutoConfiguration")
@EnableConfigurationProperties(RefClientProperties.class)
public class RefClientAutoConfiguration {

    @Bean(destroyMethod = "close")
    @ConditionalOnMissingBean(RefDataClient.class)
    public RefDataClient refDataClient(RefClientProperties p, ApplicationContext ctx, ObjectProvider<RoutingListener> listener) {
        RoutingRefClient.Builder b = RoutingRefClient.builder()
                .defaultRoute(new DatasetRoute(p.defaults().route(), null, null, DatasetRoute.DEFAULT_FALLBACK_MAX_KEYS, false))
                .defaultTimeout(p.defaults().timeout())
                .breaker(p.breaker().failureThreshold(), p.breaker().openFor())
                .bulkhead(p.bulkhead().threads(), p.bulkhead().queue())
                .businessDateRefresh(p.businessDateRefresh())
                .zone(p.zone());

        if (p.serverUrl() != null) {
            b.provider(new RefServerProvider(p.serverUrl(), p.connectTimeout()));
        }
        p.directSources().forEach((name, bean) -> {
            if (Route.REF_SERVER_PROVIDER.equals(name)) {
                throw new IllegalStateException("'" + name + "' is reserved for the ref server");
            }
            b.provider(new DirectSourceProvider(name, ctx.getBean(bean, RefSourceDao.class)));
        });
        p.datasets().forEach((ds, d) -> b.route(ds, d.toRoute()));
        if (p.localCache().enabled()) {
            b.localCache(new CaffeineLocalCache(p.localCache().maxSize(), p.localCache().expireAfterWrite()));
        }
        listener.ifAvailable(b::listener);

        RoutingRefClient client = b.build(); // throws on invalid routes: startup fails fast
        RefData.initIfAbsent(() -> client);
        return client;
    }

    @Configuration(proxyBeanMethods = false)
    @ConditionalOnClass(name = "io.micrometer.core.instrument.MeterRegistry")
    static class Metrics {
        @Bean
        @ConditionalOnBean(MeterRegistry.class)
        @ConditionalOnMissingBean(RoutingListener.class)
        RoutingListener micrometerRoutingListener(MeterRegistry registry) {
            return new MicrometerRoutingListener(registry);
        }
    }
}
