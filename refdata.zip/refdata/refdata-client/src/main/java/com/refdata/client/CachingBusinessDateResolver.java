package com.refdata.client;

import java.time.Duration;
import java.time.LocalDate;
import java.util.function.Supplier;

/**
 * Caches the ref server's current business date for {@code refresh}. If the server is unreachable it
 * keeps serving the last known date (retrying every few seconds), and only before the first
 * successful call does it fall back to {@code fallback} (today in the configured zone).
 * Every lookup carries an explicit date, so a client a few seconds behind a roll still gets
 * a consistent, still-published day.
 */
public final class CachingBusinessDateResolver implements Supplier<LocalDate> {

    private record Snapshot(LocalDate date, long at) {}

    private static final long RETRY_NANOS = Duration.ofSeconds(5).toNanos();

    private final Supplier<LocalDate> source;
    private final Supplier<LocalDate> fallback;
    private final long refreshNanos;
    private volatile Snapshot snapshot;

    public CachingBusinessDateResolver(Supplier<LocalDate> source, Duration refresh, Supplier<LocalDate> fallback) {
        this.source = source;
        this.fallback = fallback;
        this.refreshNanos = refresh.toNanos();
    }

    @Override
    public LocalDate get() {
        Snapshot s = snapshot;
        if (s != null && System.nanoTime() - s.at() < refreshNanos) return s.date();
        synchronized (this) {
            s = snapshot;
            long now = System.nanoTime();
            if (s != null && now - s.at() < refreshNanos) return s.date();
            try {
                LocalDate d = source.get();
                snapshot = new Snapshot(d, now);
                return d;
            } catch (RuntimeException e) {
                if (s != null) {
                    snapshot = new Snapshot(s.date(), now - refreshNanos + Math.min(refreshNanos, RETRY_NANOS));
                    return s.date();
                }
                return fallback.get();
            }
        }
    }
}
