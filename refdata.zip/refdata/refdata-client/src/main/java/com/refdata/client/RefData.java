package com.refdata.client;

import com.refdata.api.LookupResult;
import com.refdata.api.RefDataClient;

import java.util.Collection;
import java.util.Map;
import java.util.Optional;
import java.util.function.Supplier;

/**
 * JVM-wide singleton facade, so every task slot in a Flink TaskManager or Spark executor shares one
 * client, one local cache and one set of connections.
 *
 * <pre>{@code
 * // Flink RichFunction.open() / Spark mapPartitions:
 * RefData.initIfAbsent(() -> RoutingRefClient.builder()
 *         .provider(RefServerProvider.create("http://ref-server:8080"))
 *         .localCache(new CaffeineLocalCache(200_000, Duration.ofMinutes(10)))
 *         .build());
 * LookupResult fx = RefData.getAll("fx-rates", pairs);
 * }</pre>
 * Flink loads user code in a per-job classloader, so this is one instance per job per TaskManager.
 * In a Spring app the auto-configuration registers its client here automatically.
 */
public final class RefData {

    private static volatile RefDataClient client;

    private RefData() {}

    public static RefDataClient initIfAbsent(Supplier<? extends RefDataClient> factory) {
        RefDataClient c = client;
        if (c != null) return c;
        synchronized (RefData.class) {
            if (client == null) client = factory.get();
            return client;
        }
    }

    public static RefDataClient client() {
        RefDataClient c = client;
        if (c == null) throw new IllegalStateException("RefData not initialised; call RefData.initIfAbsent(...) first");
        return c;
    }

    public static LookupResult getAll(String dataset, Collection<String> keys) {
        return client().getAll(dataset, keys);
    }

    public static Optional<Map<String, Object>> get(String dataset, String key) {
        return client().get(dataset, key);
    }

    public static synchronized void shutdown() {
        RefDataClient c = client;
        client = null;
        if (c != null) c.close();
    }

    /** Called by a client being closed elsewhere, so the facade never hands out a closed client. */
    static synchronized void release(RefDataClient c) {
        if (client == c) client = null;
    }
}
