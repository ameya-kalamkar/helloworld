package com.refdata.client;

import java.time.Duration;

/**
 * Minimal consecutive-failure circuit breaker (no Resilience4j dependency).
 * CLOSED → OPEN after {@code failureThreshold} consecutive failures; after {@code openFor} one trial
 * call is let through (HALF_OPEN); success closes, failure re-opens. A trial that never reports back
 * is replaced by a new one after another {@code openFor}.
 */
public final class CircuitBreaker {

    public enum State { CLOSED, OPEN, HALF_OPEN }

    private final int failureThreshold;
    private final long openNanos;

    private State state = State.CLOSED;
    private int consecutiveFailures;
    private long stateSince;

    public CircuitBreaker(int failureThreshold, Duration openFor) {
        if (failureThreshold < 1) throw new IllegalArgumentException("failureThreshold must be >= 1");
        this.failureThreshold = failureThreshold;
        this.openNanos = openFor.toNanos();
    }

    public synchronized boolean allowRequest() {
        long now = System.nanoTime();
        switch (state) {
            case CLOSED:
                return true;
            case OPEN:
                if (now - stateSince < openNanos) return false;
                state = State.HALF_OPEN;
                stateSince = now;
                return true;
            default: // HALF_OPEN: one trial in flight; replace it if it went silent
                if (now - stateSince < openNanos) return false;
                stateSince = now;
                return true;
        }
    }

    public synchronized void onSuccess() {
        consecutiveFailures = 0;
        state = State.CLOSED;
    }

    public synchronized void onFailure() {
        if (state == State.HALF_OPEN || ++consecutiveFailures >= failureThreshold) {
            state = State.OPEN;
            stateSince = System.nanoTime();
            consecutiveFailures = 0;
        }
    }

    public synchronized State state() {
        return state;
    }
}
