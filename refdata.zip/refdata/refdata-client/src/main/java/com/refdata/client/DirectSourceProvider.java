package com.refdata.client;

import com.refdata.api.LookupResult;
import com.refdata.api.RefSourceDao;

import java.time.Duration;
import java.time.LocalDate;
import java.util.Collection;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;

/**
 * Calls an original source directly from the executor, using the same {@link RefSourceDao}
 * the ref server uses for read-through, so rows have the same shape on both paths.
 * Set a JDBC query timeout on the DAO too; the router's timeout only stops the wait.
 */
public final class DirectSourceProvider implements RefDataProvider {

    private final String name;
    private final RefSourceDao dao;

    public DirectSourceProvider(String name, RefSourceDao dao) {
        this.name = name;
        this.dao = dao;
    }

    @Override
    public String name() {
        return name;
    }

    @Override
    public LookupResult lookup(String dataset, LocalDate businessDate, Collection<String> keys, Duration timeout) {
        Map<String, Map<String, Object>> found = dao.loadByKeys(businessDate, keys);
        Set<String> notFound = new LinkedHashSet<>(keys);
        notFound.removeAll(found.keySet());
        return new LookupResult(businessDate, found, notFound);
    }
}
