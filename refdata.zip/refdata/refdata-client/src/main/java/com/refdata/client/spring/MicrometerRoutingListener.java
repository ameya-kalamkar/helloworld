package com.refdata.client.spring;

import com.refdata.client.RoutingListener;
import io.micrometer.core.instrument.Counter;
import io.micrometer.core.instrument.MeterRegistry;

/**
 * Metrics:
 * <ul>
 *   <li>{@code refdata.client.rows{dataset,source}}: rows served from local cache or each provider</li>
 *   <li>{@code refdata.fallback{dataset,provider}}: rows served by a fallback provider; alert if non-zero for minutes</li>
 *   <li>{@code refdata.client.failures{dataset,provider,error}} and {@code refdata.client.skipped{dataset,provider}}</li>
 * </ul>
 */
class MicrometerRoutingListener implements RoutingListener {

    private final MeterRegistry registry;

    MicrometerRoutingListener(MeterRegistry registry) {
        this.registry = registry;
    }

    @Override
    public void onLocalHit(String dataset, int rows) {
        counter("refdata.client.rows", "dataset", dataset, "source", "local").increment(rows);
    }

    @Override
    public void onProviderHit(String dataset, String provider, int rows, boolean fallback) {
        counter("refdata.client.rows", "dataset", dataset, "source", provider).increment(rows);
        if (fallback) counter("refdata.fallback", "dataset", dataset, "provider", provider).increment(rows);
    }

    @Override
    public void onFailure(String dataset, String provider, Throwable error) {
        counter("refdata.client.failures", "dataset", dataset, "provider", provider,
                "error", error.getClass().getSimpleName()).increment();
    }

    @Override
    public void onSkipped(String dataset, String provider, String reason) {
        counter("refdata.client.skipped", "dataset", dataset, "provider", provider).increment();
    }

    private Counter counter(String name, String... tags) {
        return Counter.builder(name).tags(tags).register(registry);
    }
}
