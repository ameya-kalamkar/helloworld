package com.refdata.client;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.refdata.api.LookupResult;
import com.refdata.api.Route;

import java.io.IOException;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.time.LocalDate;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Talks to the ref server's JSON API with the JDK HttpClient (no Spring or Ignite in the executor).
 * Point it at a load balancer in front of the server nodes; every node can answer any lookup.
 * <p>
 * Numbers are read as Long / BigDecimal so rows equal those from {@link DirectSourceProvider}
 * (both sides are normalised by {@code RefRows}).
 */
public final class RefServerProvider implements RefDataProvider, RefDataProvider.BusinessDateSource {

    private final URI base;
    private final HttpClient http;
    private final ObjectMapper mapper;
    private final Duration dateTimeout;

    public RefServerProvider(URI baseUrl, Duration connectTimeout) {
        String s = baseUrl.toString();
        this.base = URI.create(s.endsWith("/") ? s : s + "/");
        this.http = HttpClient.newBuilder()
                .connectTimeout(connectTimeout)
                .version(HttpClient.Version.HTTP_1_1)
                .build();
        this.mapper = new ObjectMapper()
                .registerModule(new JavaTimeModule())
                .disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS)
                .disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES)
                .enable(DeserializationFeature.USE_BIG_DECIMAL_FOR_FLOATS)
                .enable(DeserializationFeature.USE_LONG_FOR_INTS);
        this.dateTimeout = connectTimeout.plusSeconds(2);
    }

    public static RefServerProvider create(String baseUrl) {
        return new RefServerProvider(URI.create(baseUrl), Duration.ofSeconds(2));
    }

    @Override
    public String name() {
        return Route.REF_SERVER_PROVIDER;
    }

    @Override
    public LookupResult lookup(String dataset, LocalDate businessDate, Collection<String> keys, Duration timeout)
            throws IOException, InterruptedException {
        Map<String, Object> body = new LinkedHashMap<>();
        body.put("businessDate", businessDate);
        body.put("keys", List.copyOf(keys));
        HttpRequest req = HttpRequest.newBuilder(base.resolve("refdata/" + segment(dataset) + "/lookup"))
                .timeout(timeout)
                .header("Content-Type", "application/json")
                .header("Accept", "application/json")
                .POST(HttpRequest.BodyPublishers.ofByteArray(mapper.writeValueAsBytes(body)))
                .build();
        HttpResponse<byte[]> resp = http.send(req, HttpResponse.BodyHandlers.ofByteArray());
        check(resp);
        return mapper.readValue(resp.body(), LookupResult.class);
    }

    @Override
    public LocalDate currentBusinessDate() {
        try {
            HttpRequest req = HttpRequest.newBuilder(base.resolve("refdata/business-date"))
                    .timeout(dateTimeout)
                    .header("Accept", "application/json")
                    .GET()
                    .build();
            HttpResponse<byte[]> resp = http.send(req, HttpResponse.BodyHandlers.ofByteArray());
            check(resp);
            JsonNode node = mapper.readTree(resp.body());
            return LocalDate.parse(node.get("businessDate").asText());
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new IllegalStateException(e);
        } catch (IOException e) {
            throw new IllegalStateException("Cannot read business date from ref server: " + e.getMessage(), e);
        }
    }

    private static void check(HttpResponse<byte[]> resp) {
        int sc = resp.statusCode();
        if (sc == 200) return;
        String detail = new String(resp.body(), StandardCharsets.UTF_8);
        if (detail.length() > 300) detail = detail.substring(0, 300);
        throw new RefServerException(sc, detail);
    }

    private static String segment(String s) {
        return URLEncoder.encode(s, StandardCharsets.UTF_8).replace("+", "%20");
    }

    /** Non-200 from the ref server: 503 = warming / not ready, 502 = its read-through failed, 404 = unknown dataset. */
    public static final class RefServerException extends RuntimeException {
        private final int status;

        RefServerException(int status, String detail) {
            super("ref server HTTP " + status + ": " + detail);
            this.status = status;
        }

        public int status() { return status; }
    }
}
