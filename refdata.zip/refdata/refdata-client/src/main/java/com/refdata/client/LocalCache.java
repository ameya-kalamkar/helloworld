package com.refdata.client;

import java.time.LocalDate;
import java.util.Collection;
import java.util.Map;

/** Client-side cache in front of the providers. Keyed by dataset + business date + key. */
public interface LocalCache {

    Map<String, Map<String, Object>> getAllPresent(String dataset, LocalDate businessDate, Collection<String> keys);

    void putAll(String dataset, LocalDate businessDate, Map<String, Map<String, Object>> rows);

    void invalidateAll();

    static LocalCache none() {
        return new LocalCache() {
            @Override public Map<String, Map<String, Object>> getAllPresent(String d, LocalDate b, Collection<String> k) { return Map.of(); }
            @Override public void putAll(String d, LocalDate b, Map<String, Map<String, Object>> rows) { }
            @Override public void invalidateAll() { }
        };
    }
}
