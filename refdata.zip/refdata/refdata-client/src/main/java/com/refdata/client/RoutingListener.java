package com.refdata.client;

/** Hooks for metrics. {@code fallback=true} means the hit came from a provider after the first one in the route. */
public interface RoutingListener {

    default void onLocalHit(String dataset, int rows) {}

    default void onProviderHit(String dataset, String provider, int rows, boolean fallback) {}

    default void onFailure(String dataset, String provider, Throwable error) {}

    default void onSkipped(String dataset, String provider, String reason) {}

    RoutingListener NOOP = new RoutingListener() {};
}
