package com.refdata.client.spring;

import com.refdata.api.Route;
import com.refdata.client.DatasetRoute;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.bind.DefaultValue;

import java.net.URI;
import java.time.Duration;
import java.time.ZoneId;
import java.util.Map;

/**
 * <pre>
 * refdata:
 *   client:
 *     server-url: http://ref-server:8080
 *     defaults: { route: REF_SERVER, timeout: 50ms }
 *     direct-sources:
 *       fxJdbc: fxRatesDao            # provider name -> RefSourceDao bean
 *     datasets:
 *       fx-rates: { route: REF_SERVER_THEN_DIRECT, direct: fxJdbc, timeout: 50ms, fallback-max-keys: 5000 }
 * </pre>
 *
 * @param directSources provider name to the bean name of a {@code RefSourceDao}
 */
@ConfigurationProperties("refdata.client")
public record RefClientProperties(
        URI serverUrl,
        @DefaultValue("2s") Duration connectTimeout,
        @DefaultValue("America/Toronto") ZoneId zone,
        @DefaultValue("30s") Duration businessDateRefresh,
        @DefaultValue LocalCacheProps localCache,
        @DefaultValue Defaults defaults,
        @DefaultValue Breaker breaker,
        @DefaultValue Bulkhead bulkhead,
        Map<String, String> directSources,
        Map<String, DatasetProps> datasets) {

    public RefClientProperties {
        directSources = directSources == null ? Map.of() : Map.copyOf(directSources);
        datasets = datasets == null ? Map.of() : Map.copyOf(datasets);
    }

    public record LocalCacheProps(@DefaultValue("true") boolean enabled,
                                  @DefaultValue("200000") long maxSize,
                                  @DefaultValue("10m") Duration expireAfterWrite) {}

    /** Only REF_SERVER is accepted as the default route: fallback is opt-in per dataset. */
    public record Defaults(@DefaultValue("REF_SERVER") Route route,
                           @DefaultValue("50ms") Duration timeout) {}

    public record Breaker(@DefaultValue("5") int failureThreshold,
                          @DefaultValue("30s") Duration openFor) {}

    public record Bulkhead(@DefaultValue("8") int threads,
                           @DefaultValue("64") int queue) {}

    public record DatasetProps(@DefaultValue("REF_SERVER") Route route,
                               Duration timeout,
                               String direct,
                               @DefaultValue("5000") int fallbackMaxKeys,
                               @DefaultValue("true") boolean fallbackOnNotFound) {

        DatasetRoute toRoute() {
            return new DatasetRoute(route, timeout, direct, fallbackMaxKeys, fallbackOnNotFound);
        }
    }
}
