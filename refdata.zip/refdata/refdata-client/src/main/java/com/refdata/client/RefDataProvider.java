package com.refdata.client;

import com.refdata.api.LookupResult;

import java.time.Duration;
import java.time.LocalDate;
import java.util.Collection;

/**
 * One place a client can fetch rows from: the ref server, or a source called directly.
 * The router wraps each provider with a timeout, a bulkhead and a circuit breaker.
 */
public interface RefDataProvider {

    /** Name used in routes; the ref server is always {@link com.refdata.api.Route#REF_SERVER_PROVIDER}. */
    String name();

    /**
     * @param timeout the SLA budget for this call; implementations should honour it natively where they can
     *                (HTTP request timeout, JDBC query timeout). The router enforces it regardless.
     */
    LookupResult lookup(String dataset, LocalDate businessDate, Collection<String> keys, Duration timeout) throws Exception;

    /** Implemented by providers that know the current business date (the ref server). */
    interface BusinessDateSource {
        LocalDate currentBusinessDate();
    }
}
