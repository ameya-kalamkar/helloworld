package com.refdata.sources;

import com.refdata.api.RefRows;
import com.refdata.api.RefSourceDao;
import org.springframework.jdbc.core.ColumnMapRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.simple.JdbcClient;

import javax.sql.DataSource;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.StringJoiner;
import java.util.function.BiConsumer;
import java.util.stream.Stream;

/** {@link RefSourceDao} over plain SQL with Spring {@link JdbcClient}. No JPA. */
public class JdbcRefSourceDao implements RefSourceDao {

    private final JdbcClient bulk;   // large fetch size for the day-start stream
    private final JdbcClient point;  // default fetch size for small point loads
    private final JdbcSourceSpec spec;
    private final List<String> keyCols;
    private final ColumnMapRowMapper mapper = new ColumnMapRowMapper();

    public JdbcRefSourceDao(DataSource dataSource, JdbcSourceSpec spec) {
        this.spec = spec;
        this.keyCols = spec.keyColumns().stream().map(c -> c.toLowerCase(Locale.ROOT)).toList();

        JdbcTemplate bulkTemplate = new JdbcTemplate(dataSource);
        bulkTemplate.setFetchSize(spec.fetchSize());
        bulkTemplate.setQueryTimeout(spec.queryTimeoutSec());
        this.bulk = JdbcClient.create(bulkTemplate);

        JdbcTemplate pointTemplate = new JdbcTemplate(dataSource);
        pointTemplate.setQueryTimeout(spec.queryTimeoutSec());
        this.point = JdbcClient.create(pointTemplate);
    }

    @Override
    public void streamAll(LocalDate businessDate, BiConsumer<String, Map<String, Object>> sink) {
        try (Stream<Map<String, Object>> rows = bulk.sql(spec.sqlAll())
                .param("businessDate", businessDate)
                .query(mapper)
                .stream()) {
            rows.forEach(raw -> {
                Map<String, Object> row = RefRows.normalize(raw);
                sink.accept(keyOf(row), row);
            });
        }
    }

    @Override
    public Map<String, Map<String, Object>> loadByKeys(LocalDate businessDate, Collection<String> keys) {
        if (spec.sqlByKeys() == null) {
            throw new UnsupportedOperationException("No jdbc.sql-by-keys configured; dataset must be fully preloaded");
        }
        Map<String, Map<String, Object>> out = new HashMap<>();
        List<String> all = new ArrayList<>(keys);
        for (int i = 0; i < all.size(); i += spec.keyBatchSize()) {
            List<String> chunk = all.subList(i, Math.min(all.size(), i + spec.keyBatchSize()));
            point.sql(spec.sqlByKeys())
                    .param("businessDate", businessDate)
                    .param("keys", chunk)
                    .query(mapper)
                    .list()
                    .forEach(raw -> {
                        Map<String, Object> row = RefRows.normalize(raw);
                        out.put(keyOf(row), row);
                    });
        }
        return out;
    }

    private String keyOf(Map<String, Object> row) {
        if (keyCols.size() == 1) return String.valueOf(row.get(keyCols.get(0)));
        StringJoiner j = new StringJoiner(spec.keySeparator());
        keyCols.forEach(c -> j.add(String.valueOf(row.get(c))));
        return j.toString();
    }
}
