package com.refdata.sources;

import java.util.List;

/**
 * YAML-bindable definition of a JDBC-backed dataset.
 *
 * <pre>
 * jdbc:
 *   key-columns: [ccy_pair]
 *   sql-all: select * from fx_rates where biz_date = :businessDate
 *   sql-by-keys: select * from fx_rates where biz_date = :businessDate and ccy_pair in (:keys)
 * </pre>
 *
 * @param keyColumns      one or more columns; composite keys are joined with {@code keySeparator}
 * @param sqlAll          full load for a business date, must use {@code :businessDate}
 * @param sqlByKeys       point load, must use {@code :businessDate} and {@code :keys} (single key column only)
 * @param keySeparator    separator for composite keys, default {@code |}
 * @param keyBatchSize    max keys per IN list, default 900 (stays under Oracle's 1000 limit)
 * @param fetchSize       JDBC fetch size for the full load, default 5000
 * @param queryTimeoutSec statement timeout, default 30
 */
public record JdbcSourceSpec(List<String> keyColumns,
                             String sqlAll,
                             String sqlByKeys,
                             String keySeparator,
                             Integer keyBatchSize,
                             Integer fetchSize,
                             Integer queryTimeoutSec) {

    public JdbcSourceSpec {
        if (keyColumns == null || keyColumns.isEmpty()) throw new IllegalArgumentException("jdbc.key-columns is required");
        if (sqlAll == null || sqlAll.isBlank()) throw new IllegalArgumentException("jdbc.sql-all is required");
        keyColumns = List.copyOf(keyColumns);
        keySeparator = keySeparator == null ? "|" : keySeparator;
        keyBatchSize = keyBatchSize == null ? 900 : keyBatchSize;
        fetchSize = fetchSize == null ? 5000 : fetchSize;
        queryTimeoutSec = queryTimeoutSec == null ? 30 : queryTimeoutSec;
        if (sqlByKeys != null && keyColumns.size() > 1) {
            throw new IllegalArgumentException("jdbc.sql-by-keys supports a single key column; implement RefSourceDao for composite point loads");
        }
    }
}
