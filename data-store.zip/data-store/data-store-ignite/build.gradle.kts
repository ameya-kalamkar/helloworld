dependencies {
    api(project(":data-store-core"))
    implementation(libs.ignite.core)

    testImplementation(testFixtures(project(":data-store-core")))
    testImplementation(platform(libs.junit.bom))
    testImplementation(libs.junit.jupiter)
    testRuntimeOnly(libs.junit.launcher)
    testRuntimeOnly(libs.logback.classic)
}

// Ignite contract tests need a running Ignite 2 cluster:
//   ./gradlew :data-store-ignite:test -Dignite.addresses=localhost:10800
tasks.withType<Test>().configureEach {
    systemProperty("ignite.addresses", System.getProperty("ignite.addresses", ""))
}
