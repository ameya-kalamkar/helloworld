package com.acme.datastore.ignite;

import com.acme.datastore.DataStoreException;
import com.acme.datastore.spi.DatasetSpec;
import com.acme.datastore.spi.KeyCodec;
import com.acme.datastore.spi.Store;
import com.acme.datastore.spi.StoreMap;
import org.apache.ignite.Ignition;
import org.apache.ignite.binary.BinaryObject;
import org.apache.ignite.binary.BinaryObjectBuilder;
import org.apache.ignite.cache.CacheAtomicityMode;
import org.apache.ignite.cache.CacheKeyConfiguration;
import org.apache.ignite.cache.CacheMode;
import org.apache.ignite.cache.CacheRebalanceMode;
import org.apache.ignite.cache.CacheWriteSynchronizationMode;
import org.apache.ignite.cache.PartitionLossPolicy;
import org.apache.ignite.cache.query.QueryCursor;
import org.apache.ignite.cache.query.ScanQuery;
import org.apache.ignite.client.ClientCache;
import org.apache.ignite.client.ClientCacheConfiguration;
import org.apache.ignite.client.IgniteClient;
import org.apache.ignite.configuration.ClientConfiguration;

import javax.cache.Cache;
import java.math.BigInteger;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.AbstractMap;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeSet;
import java.util.stream.IntStream;
import java.util.stream.Stream;

/**
 * {@code store-type: ignite} — Ignite 2 caches through the thin client, for pipelines whose jobs run on several
 * hosts. One {@code PARTITIONED}, {@code ATOMIC} cache per dataset per partition, named
 * {@code <namespace>__<dataset>__<partition>}. Values are the encoded bytes; keys are simple values or,
 * for composite keys, {@code BinaryObject}s with one field per key component (so equality and
 * distribution follow the fields, identically in every JVM).
 *
 * <pre>
 * datastore:
 *   store-type: ignite
 *   ignite:                           # connection only
 *     addresses: ["node1:10800", "node2:10800"]
 *     partition-awareness: true
 *   dataset-defaults:
 *     splits: 16                      # parallel scans; each groups some of Ignite's partitions
 *     ignite: { backups: 1, data-region: batch_region }
 *   datasets:
 *     region:   { ignite: { cache-mode: REPLICATED } }
 *     position: { ignite: { affinity-field: customerId } }   # colocate by a component of a composite key
 * </pre>
 *
 * No distributed partition lock (the thin client cannot take one): coordinate destroyPartition through
 * the scheduler.
 */
public final class IgniteStore implements Store {

    /** {@code ignite:} at store level: the connection (one thin client per JVM). */
    public static final class Settings {
        private List<String> addresses = new ArrayList<>();
        private boolean partitionAwareness = true;
        private int timeoutMillis;

        public List<String> getAddresses() {
            return addresses;
        }

        public void setAddresses(List<String> addresses) {
            this.addresses = addresses == null ? new ArrayList<>() : new ArrayList<>(addresses);
        }

        public boolean isPartitionAwareness() {
            return partitionAwareness;
        }

        public void setPartitionAwareness(boolean partitionAwareness) {
            this.partitionAwareness = partitionAwareness;
        }

        public int getTimeoutMillis() {
            return timeoutMillis;
        }

        public void setTimeoutMillis(int timeoutMillis) {
            this.timeoutMillis = timeoutMillis;
        }
    }

    /**
     * {@code ignite:} inside a dataset or {@code dataset-defaults}: the cache. Mirrors the thin client's
     * {@code ClientCacheConfiguration}; unset fields keep Ignite's defaults (except those noted).
     */
    public static final class DatasetSettings {
        private String cacheMode = "PARTITIONED";
        private String atomicityMode = "ATOMIC";
        private Integer backups = 1;
        private String dataRegion;
        private String groupName;
        private Boolean readFromBackup;
        private String writeSynchronizationMode;
        private String partitionLossPolicy;
        private String rebalanceMode;
        private Integer rebalanceBatchSize;
        private Boolean copyOnRead;
        private Boolean statisticsEnabled;
        private String affinityField;
        private int igniteCachePartitions = 1024;

        /** PARTITIONED (default) | REPLICATED. */
        public String getCacheMode() {
            return cacheMode;
        }

        public void setCacheMode(String cacheMode) {
            this.cacheMode = cacheMode;
        }

        /** ATOMIC (default) | TRANSACTIONAL. */
        public String getAtomicityMode() {
            return atomicityMode;
        }

        public void setAtomicityMode(String atomicityMode) {
            this.atomicityMode = atomicityMode;
        }

        /** Default 1 (ignored for REPLICATED). */
        public Integer getBackups() {
            return backups;
        }

        public void setBackups(Integer backups) {
            this.backups = backups;
        }

        public String getDataRegion() {
            return dataRegion;
        }

        public void setDataRegion(String dataRegion) {
            this.dataRegion = dataRegion;
        }

        public String getGroupName() {
            return groupName;
        }

        public void setGroupName(String groupName) {
            this.groupName = groupName;
        }

        public Boolean getReadFromBackup() {
            return readFromBackup;
        }

        public void setReadFromBackup(Boolean readFromBackup) {
            this.readFromBackup = readFromBackup;
        }

        /** FULL_SYNC | FULL_ASYNC | PRIMARY_SYNC. */
        public String getWriteSynchronizationMode() {
            return writeSynchronizationMode;
        }

        public void setWriteSynchronizationMode(String writeSynchronizationMode) {
            this.writeSynchronizationMode = writeSynchronizationMode;
        }

        /** READ_ONLY_SAFE | READ_WRITE_SAFE | IGNORE. */
        public String getPartitionLossPolicy() {
            return partitionLossPolicy;
        }

        public void setPartitionLossPolicy(String partitionLossPolicy) {
            this.partitionLossPolicy = partitionLossPolicy;
        }

        /** SYNC | ASYNC | NONE. */
        public String getRebalanceMode() {
            return rebalanceMode;
        }

        public void setRebalanceMode(String rebalanceMode) {
            this.rebalanceMode = rebalanceMode;
        }

        public Integer getRebalanceBatchSize() {
            return rebalanceBatchSize;
        }

        public void setRebalanceBatchSize(Integer rebalanceBatchSize) {
            this.rebalanceBatchSize = rebalanceBatchSize;
        }

        public Boolean getCopyOnRead() {
            return copyOnRead;
        }

        public void setCopyOnRead(Boolean copyOnRead) {
            this.copyOnRead = copyOnRead;
        }

        public Boolean getStatisticsEnabled() {
            return statisticsEnabled;
        }

        public void setStatisticsEnabled(Boolean statisticsEnabled) {
            this.statisticsEnabled = statisticsEnabled;
        }

        /** A component of the dataset's composite key: entries with equal values land on the same node. */
        public String getAffinityField() {
            return affinityField;
        }

        public void setAffinityField(String affinityField) {
            this.affinityField = affinityField;
        }

        /** Ignite partitions of the cache, used to build scan splits; must match the cluster's affinity (default 1024). */
        public int getIgniteCachePartitions() {
            return igniteCachePartitions;
        }

        public void setIgniteCachePartitions(int igniteCachePartitions) {
            this.igniteCachePartitions = igniteCachePartitions;
        }
    }

    private static final int DEFAULT_SPLITS = 16;

    private Settings settings;
    private String prefix;
    private volatile IgniteClient client;

    @Override
    public String name() {
        return "ignite";
    }

    @Override
    public Class<?> settingsType() {
        return Settings.class;
    }

    @Override
    public Class<?> datasetSettingsType() {
        return DatasetSettings.class;
    }

    @Override
    public void init(String namespace, Object s, Collection<DatasetSpec<?>> datasets) {
        this.settings = (Settings) s;
        List<String> problems = new ArrayList<>();
        if (settings.getAddresses().isEmpty()) {
            problems.add("ignite.addresses is required");
        }
        for (DatasetSpec<?> d : datasets) {
            DatasetSettings ds = d.settings(DatasetSettings.class);
            if (ds == null) {
                continue;
            }
            String p = "datasets." + d.name() + ".ignite.";
            check(problems, p + "cache-mode", ds.getCacheMode(), CacheMode.class);
            check(problems, p + "atomicity-mode", ds.getAtomicityMode(), CacheAtomicityMode.class);
            check(problems, p + "write-synchronization-mode", ds.getWriteSynchronizationMode(),
                    CacheWriteSynchronizationMode.class);
            check(problems, p + "partition-loss-policy", ds.getPartitionLossPolicy(), PartitionLossPolicy.class);
            check(problems, p + "rebalance-mode", ds.getRebalanceMode(), CacheRebalanceMode.class);
            if (ds.getIgniteCachePartitions() < 1) {
                problems.add(p + "ignite-cache-partitions must be >= 1");
            }
            if (ds.getAffinityField() != null) {
                KeyCodec<?> k = d.keyCodec();
                if (k.simple() || !k.componentNames().contains(ds.getAffinityField())) {
                    problems.add("datasets." + d.name() + ".ignite.affinity-field '" + ds.getAffinityField()
                            + "' must be a component of the composite key " + d.keyType().getSimpleName()
                            + " " + k.componentNames());
                }
            }
        }
        if (!problems.isEmpty()) {
            throw new DataStoreException("Invalid Ignite configuration: " + problems);
        }
        this.prefix = namespace + "__";
    }

    private static <E extends Enum<E>> void check(List<String> problems, String path, String value, Class<E> type) {
        if (value != null) {
            try {
                Enum.valueOf(type, value);
            } catch (IllegalArgumentException e) {
                problems.add(path + " '" + value + "' is not one of " + java.util.Arrays.toString(type.getEnumConstants()));
            }
        }
    }

    /** Connects lazily: a misconfigured job fails on first use with a clear message. */
    private IgniteClient client() {
        IgniteClient c = client;
        if (c == null) {
            synchronized (this) {
                c = client;
                if (c == null) {
                    ClientConfiguration cfg = new ClientConfiguration()
                            .setAddresses(settings.getAddresses().toArray(String[]::new))
                            .setPartitionAwarenessEnabled(settings.isPartitionAwareness());
                    if (settings.getTimeoutMillis() > 0) {
                        cfg.setTimeout(settings.getTimeoutMillis());
                    }
                    try {
                        c = Ignition.startClient(cfg);
                    } catch (RuntimeException e) {
                        throw new DataStoreException("Cannot connect to Ignite at " + settings.getAddresses(), e);
                    }
                    client = c;
                }
            }
        }
        return c;
    }

    @Override
    public <K> StoreMap<K> open(DatasetSpec<K> d, String partition, boolean create) {
        String cacheName = prefix + d.name() + "__" + partition;
        KeyCodec<K> keys = d.keyCodec();
        String keyType = "datastore." + d.keyType().getSimpleName() + "_" + keys.fingerprint();
        DatasetSettings ds = d.settings(DatasetSettings.class);
        if (ds == null) {
            ds = new DatasetSettings();      // internal manifest
        }
        if (create) {
            ClientCacheConfiguration cfg = new ClientCacheConfiguration()
                    .setName(cacheName)
                    .setCacheMode(CacheMode.valueOf(ds.getCacheMode()))
                    .setAtomicityMode(CacheAtomicityMode.valueOf(ds.getAtomicityMode()));
            if (ds.getBackups() != null) {
                cfg.setBackups(ds.getBackups());
            }
            if (ds.getDataRegion() != null) {
                cfg.setDataRegionName(ds.getDataRegion());
            }
            if (ds.getGroupName() != null) {
                cfg.setGroupName(ds.getGroupName());
            }
            if (ds.getReadFromBackup() != null) {
                cfg.setReadFromBackup(ds.getReadFromBackup());
            }
            if (ds.getWriteSynchronizationMode() != null) {
                cfg.setWriteSynchronizationMode(CacheWriteSynchronizationMode.valueOf(ds.getWriteSynchronizationMode()));
            }
            if (ds.getPartitionLossPolicy() != null) {
                cfg.setPartitionLossPolicy(PartitionLossPolicy.valueOf(ds.getPartitionLossPolicy()));
            }
            if (ds.getRebalanceMode() != null) {
                cfg.setRebalanceMode(CacheRebalanceMode.valueOf(ds.getRebalanceMode()));
            }
            if (ds.getRebalanceBatchSize() != null) {
                cfg.setRebalanceBatchSize(ds.getRebalanceBatchSize());
            }
            if (ds.getCopyOnRead() != null) {
                cfg.setCopyOnRead(ds.getCopyOnRead());
            }
            if (ds.getStatisticsEnabled() != null) {
                cfg.setStatisticsEnabled(ds.getStatisticsEnabled());
            }
            if (ds.getAffinityField() != null) {
                cfg.setKeyConfiguration(new CacheKeyConfiguration(keyType, ds.getAffinityField()));
            }
            client().getOrCreateCache(cfg);
        } else if (!client().cacheNames().contains(cacheName)) {
            throw new DataStoreException("Dataset '" + d.name() + "' does not exist in partition " + partition
                    + " (cache " + cacheName + "; run createAll() first)");
        }
        int partitions = ds.getIgniteCachePartitions();
        int splits = Math.min(partitions, d.internal() ? 1 : d.splits() > 0 ? d.splits() : DEFAULT_SPLITS);
        ClientCache<Object, byte[]> cache = client().<Object, byte[]>cache(cacheName).withKeepBinary();
        return new IgniteStoreMap<>(cache, keys, keyType, splits, partitions);
    }

    @Override
    public List<String> partitions() {
        TreeSet<String> out = new TreeSet<>();
        for (String n : client().cacheNames()) {
            if (n.startsWith(prefix)) {
                out.add(n.substring(n.lastIndexOf("__") + 2));
            }
        }
        return List.copyOf(out);
    }

    @Override
    public void destroy(String partition) {
        for (String n : new ArrayList<>(client().cacheNames())) {
            if (n.startsWith(prefix) && n.endsWith("__" + partition)) {
                client().destroyCache(n);
            }
        }
    }

    @Override
    public synchronized void close() {
        IgniteClient c = client;
        client = null;
        if (c != null) {
            try {
                c.close();
            } catch (Exception e) {
                throw new DataStoreException("Error closing Ignite client", e);
            }
        }
    }

    // ================================================================== one dataset

    private final class IgniteStoreMap<K> implements StoreMap<K> {
        private final ClientCache<Object, byte[]> cache;
        private final KeyCodec<K> keys;
        private final String keyType;
        private final int splits;
        private final int partitions;

        IgniteStoreMap(ClientCache<Object, byte[]> cache, KeyCodec<K> keys, String keyType, int splits, int partitions) {
            this.cache = cache;
            this.keys = keys;
            this.keyType = keyType;
            this.splits = splits;
            this.partitions = partitions;
        }

        /** Key as stored: a portable simple value, or a BinaryObject with one field per component. */
        private Object toIgnite(K key) {
            Object[] values = keys.values(key);
            if (keys.simple()) {
                return portable(values[0]);
            }
            BinaryObjectBuilder b = client().binary().builder(keyType);
            for (int i = 0; i < values.length; i++) {
                if (values[i] == null) {
                    throw new DataStoreException("Key " + keys.type().getSimpleName() + "." + keys.componentNames().get(i)
                            + " is null");
                }
                b.setField(keys.componentNames().get(i), portable(values[i]));
            }
            return b.build();
        }

        private K fromIgnite(Object stored) {
            if (keys.simple()) {
                return keys.construct(unportable(stored, keys.type()));
            }
            BinaryObject bo = (BinaryObject) stored;
            Object[] values = new Object[keys.componentNames().size()];
            for (int i = 0; i < values.length; i++) {
                values[i] = unportable(bo.field(keys.componentNames().get(i)), keys.componentTypes().get(i));
            }
            return keys.construct(values);
        }

        @Override
        public byte[] get(K key) {
            return cache.get(toIgnite(key));
        }

        @Override
        public Map<K, byte[]> getAll(Collection<K> ks) {
            Map<Object, K> byIgnite = new LinkedHashMap<>(ks.size() * 2);
            for (K k : ks) {
                byIgnite.put(toIgnite(k), k);
            }
            Map<Object, byte[]> raw = cache.getAll(byIgnite.keySet());          // one request per owning node
            Map<K, byte[]> out = new HashMap<>(raw.size() * 2);
            raw.forEach((ik, v) -> {
                if (v != null) {
                    out.put(byIgnite.get(ik), v);
                }
            });
            return out;
        }

        @Override
        public void put(K key, byte[] value) {
            cache.put(toIgnite(key), value);
        }

        @Override
        public void putAll(Map<K, byte[]> entries) {
            Map<Object, byte[]> raw = new HashMap<>(entries.size() * 2);
            entries.forEach((k, v) -> raw.put(toIgnite(k), v));
            cache.putAll(raw);
        }

        @Override
        public boolean remove(K key) {
            return cache.remove(toIgnite(key));
        }

        @Override
        public long size() {
            return cache.size();
        }

        @Override
        public int splits() {
            return splits;
        }

        /** Split s = Ignite partitions p with p % splits == s, scanned one partition at a time. */
        @Override
        public Stream<Map.Entry<K, byte[]>> scan(int split) {
            if (split < 0 || split >= splits) {
                throw new IndexOutOfBoundsException("split " + split + " of " + splits);
            }
            return IntStream.range(0, partitions)
                    .filter(p -> p % splits == split)
                    .boxed()
                    .flatMap(p -> {
                        List<Cache.Entry<Object, byte[]>> rows;
                        try (QueryCursor<Cache.Entry<Object, byte[]>> cur =
                                     cache.query(new ScanQuery<Object, byte[]>().setPartition(p))) {
                            rows = cur.getAll();
                        }
                        return rows.stream().map(e -> new AbstractMap.SimpleImmutableEntry<>(fromIgnite(e.getKey()),
                                e.getValue()));
                    });
        }

        @Override
        public void clear() {
            cache.clear();
        }

        @Override
        public void close() {
            // the client is owned by the store
        }
    }

    // ================================================================== key components ↔ Ignite binary types

    /** Types Ignite's binary format stores natively are kept; others become long/String deterministically. */
    static Object portable(Object v) {
        if (v instanceof Enum<?> e) {
            return e.name();
        }
        if (v instanceof LocalDate d) {
            return d.toEpochDay();
        }
        if (v instanceof LocalTime t) {
            return t.toNanoOfDay();
        }
        if (v instanceof LocalDateTime t) {
            return t.toString();
        }
        if (v instanceof Instant t) {
            return t.toString();
        }
        if (v instanceof BigInteger b) {
            return b.toString();
        }
        return v;
    }

    @SuppressWarnings({"unchecked", "rawtypes"})
    static Object unportable(Object v, Class<?> type) {
        Class<?> t = type.isPrimitive() ? box(type) : type;
        if (t.isEnum()) {
            return Enum.valueOf((Class) t, (String) v);
        }
        if (t == LocalDate.class) {
            return LocalDate.ofEpochDay(((Number) v).longValue());
        }
        if (t == LocalTime.class) {
            return LocalTime.ofNanoOfDay(((Number) v).longValue());
        }
        if (t == LocalDateTime.class) {
            return LocalDateTime.parse((String) v);
        }
        if (t == Instant.class) {
            return Instant.parse((String) v);
        }
        if (t == BigInteger.class) {
            return new BigInteger((String) v);
        }
        return v;
    }

    private static Class<?> box(Class<?> c) {
        if (c == long.class) return Long.class;
        if (c == int.class) return Integer.class;
        if (c == short.class) return Short.class;
        if (c == byte.class) return Byte.class;
        if (c == boolean.class) return Boolean.class;
        if (c == char.class) return Character.class;
        if (c == double.class) return Double.class;
        if (c == float.class) return Float.class;
        return c;
    }
}
