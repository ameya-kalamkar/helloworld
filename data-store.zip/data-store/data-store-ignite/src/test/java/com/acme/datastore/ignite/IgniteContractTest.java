package com.acme.datastore.ignite;

import com.acme.datastore.testing.DataStoreContractTest;
import org.junit.jupiter.api.condition.EnabledIfSystemProperty;

import java.nio.file.Path;

/** Needs a running Ignite 2 cluster: {@code ./gradlew :data-store-ignite:test -Dignite.addresses=localhost:10800}. */
@EnabledIfSystemProperty(named = "ignite.addresses", matches = ".+")
class IgniteContractTest extends DataStoreContractTest {

    @Override
    protected String store() {
        return "ignite";
    }

    @Override
    protected String storeBlock(Path tempDir) {
        return "ignite:\n  addresses: [\"" + System.getProperty("ignite.addresses") + "\"]\n";
    }

    @Override
    protected String datasetBlock() {
        return "ignite: { backups: 0, write-synchronization-mode: FULL_SYNC }";
    }
}
