// A team's existing domain library. It needs data-store-core only at compile time for the
// optional @Id / @Lookup annotations; apps that never use the data store are unaffected.
// (A domain lib configured purely through YAML needs no dependency at all.)
dependencies {
    compileOnly(project(":data-store-core"))
}
