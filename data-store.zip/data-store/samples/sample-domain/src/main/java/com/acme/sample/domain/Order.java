package com.acme.sample.domain;

import com.acme.datastore.annotation.Id;
import com.acme.datastore.annotation.Lookup;
import com.acme.datastore.annotation.Resolve;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/**
 * Primary data built from flat CSV rows. In REFERENCE mode only customerId and the lines' skus are stored;
 * customer (EAGER) is filled on every read, lines.product (LAZY) when asked for.
 */
public class Order {
    @Id
    private long orderId;
    private LocalDate tradeDate;
    @Lookup(dataset = "customer", into = "customer", resolvePolicy = Resolve.EAGER)
    private long customerId;
    private Customer customer;
    private List<OrderLine> lines = new ArrayList<>();

    public Order() {
    }

    public Order(long orderId, LocalDate tradeDate, long customerId, List<OrderLine> lines) {
        this.orderId = orderId;
        this.tradeDate = tradeDate;
        this.customerId = customerId;
        this.lines = new ArrayList<>(lines);
    }

    public long getOrderId() {
        return orderId;
    }

    public LocalDate getTradeDate() {
        return tradeDate;
    }

    public long getCustomerId() {
        return customerId;
    }

    public Customer getCustomer() {
        return customer;
    }

    public List<OrderLine> getLines() {
        return lines;
    }
}
