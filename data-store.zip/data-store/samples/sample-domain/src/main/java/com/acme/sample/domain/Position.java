package com.acme.sample.domain;

import com.acme.datastore.annotation.Id;

import java.math.BigDecimal;

/** Output of the enrichment job, keyed by a composite key. */
public class Position {
    @Id
    private PositionKey key;
    private long quantity;
    private BigDecimal notional;

    public Position() {
    }

    public Position(PositionKey key, long quantity, BigDecimal notional) {
        this.key = key;
        this.quantity = quantity;
        this.notional = notional;
    }

    public PositionKey getKey() {
        return key;
    }

    public long getQuantity() {
        return quantity;
    }

    public BigDecimal getNotional() {
        return notional;
    }

    public Position plus(long qty, BigDecimal amount) {
        return new Position(key, quantity + qty, notional.add(amount));
    }
}
