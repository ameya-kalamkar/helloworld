package com.acme.sample.domain;

import com.acme.datastore.annotation.Id;

public class Region {
    @Id
    private String code;
    private String name;

    public Region() {
    }

    public Region(String code, String name) {
        this.code = code;
        this.name = name;
    }

    public String getCode() {
        return code;
    }

    public String getName() {
        return name;
    }
}
