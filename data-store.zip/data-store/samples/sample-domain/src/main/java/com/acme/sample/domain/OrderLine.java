package com.acme.sample.domain;

import com.acme.datastore.annotation.Lookup;

/** Nested inside Order, not a dataset of its own. */
public class OrderLine {
    @Lookup(dataset = "product", into = "product")
    private String sku;
    private Product product;
    private int quantity;

    public OrderLine() {
    }

    public OrderLine(String sku, int quantity) {
        this.sku = sku;
        this.quantity = quantity;
    }

    public String getSku() {
        return sku;
    }

    public Product getProduct() {
        return product;
    }

    public int getQuantity() {
        return quantity;
    }
}
