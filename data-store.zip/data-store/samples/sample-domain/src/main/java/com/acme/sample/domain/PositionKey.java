package com.acme.sample.domain;

/** Composite key: one position per customer and product. */
public record PositionKey(long customerId, String sku) {
}
