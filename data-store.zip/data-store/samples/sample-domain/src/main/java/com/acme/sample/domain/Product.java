package com.acme.sample.domain;

import com.acme.datastore.annotation.Id;

import java.math.BigDecimal;

public class Product {
    @Id
    private String sku;
    private String name;
    private BigDecimal unitPrice;

    public Product() {
    }

    public Product(String sku, String name, BigDecimal unitPrice) {
        this.sku = sku;
        this.name = name;
        this.unitPrice = unitPrice;
    }

    public String getSku() {
        return sku;
    }

    public String getName() {
        return name;
    }

    public BigDecimal getUnitPrice() {
        return unitPrice;
    }
}
