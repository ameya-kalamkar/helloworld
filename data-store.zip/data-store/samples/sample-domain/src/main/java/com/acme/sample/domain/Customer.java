package com.acme.sample.domain;

/**
 * No data-store annotations: id and the regionCode -> region lookup are configured in YAML
 * (the way to handle classes you cannot or do not want to edit).
 */
public class Customer {
    private long customerId;
    private String name;
    private String regionCode;
    private Region region;          // full object, used by older apps

    public Customer() {
    }

    public Customer(long customerId, String name, String regionCode) {
        this.customerId = customerId;
        this.name = name;
        this.regionCode = regionCode;
    }

    public long getCustomerId() {
        return customerId;
    }

    public String getName() {
        return name;
    }

    public String getRegionCode() {
        return regionCode;
    }

    public Region getRegion() {
        return region;
    }

    public void setRegion(Region region) {
        this.region = region;
    }
}
