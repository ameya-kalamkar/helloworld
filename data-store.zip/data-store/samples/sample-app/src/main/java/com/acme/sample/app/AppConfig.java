package com.acme.sample.app;

import com.acme.datastore.spring.DataStoreConfiguration;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.context.annotation.PropertySource;

/** Plain Spring 7 (no Boot): the data store comes from one @Import. */
@Configuration
@Import(DataStoreConfiguration.class)
@PropertySource("classpath:app.properties")
@ComponentScan("com.acme.sample.app")
public class AppConfig {
}
