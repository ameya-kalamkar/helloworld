package com.acme.sample.app;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import java.util.Arrays;
import java.util.List;

/**
 * Runs pipeline steps by name: {@code create reference orders enrich export}, or {@code all}.
 * Partition from REGION / RUN_DATE, store from DATASTORE_STORE (default chronicle). Each step could run
 * as its own JVM with the same YAML: steps share data only through the store.
 */
public final class SampleApp {

    private SampleApp() {
    }

    public static void main(String[] args) {
        List<String> steps = args.length == 0 || (args.length == 1 && args[0].equals("all"))
                ? Pipeline.ALL : Arrays.asList(args);
        try (AnnotationConfigApplicationContext ctx = new AnnotationConfigApplicationContext(AppConfig.class)) {
            ctx.getBean(Pipeline.class).run(steps);
        }
    }
}
