package com.acme.sample.app;

import com.acme.datastore.Dao;
import com.acme.datastore.DataStore;
import com.acme.datastore.Manifest;
import com.acme.datastore.annotation.Resolve;
import com.acme.sample.domain.Customer;
import com.acme.sample.domain.Order;
import com.acme.sample.domain.OrderLine;
import com.acme.sample.domain.Position;
import com.acme.sample.domain.PositionKey;
import com.acme.sample.domain.Product;
import com.acme.sample.domain.Region;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UncheckedIOException;
import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Function;
import java.util.stream.IntStream;
import java.util.stream.Stream;

/**
 * The daily pipeline, one method per atomic job:
 * <ol>
 *   <li>{@code create}: create the partition's datasets</li>
 *   <li>{@code reference}: load regions, customers, products</li>
 *   <li>{@code orders}: flat CSV rows → nested Order objects (only ids stored: REFERENCE mode)</li>
 *   <li>{@code enrich}: read orders fully resolved, write full snapshots (EMBEDDED) and positions (composite key)</li>
 *   <li>{@code export}: flatten snapshots and positions back to CSV for downstream</li>
 * </ol>
 */
@Component
public class Pipeline {

    static final List<String> ALL = List.of("create", "reference", "orders", "enrich", "export");
    private static final Logger LOG = LoggerFactory.getLogger(Pipeline.class);

    private final DataStore ds;
    private final String inputDir;
    private final Path outputDir;

    public Pipeline(DataStore ds, @Value("${sample.input-dir}") String inputDir,
                    @Value("${sample.output-dir}") String outputDir) {
        this.ds = ds;
        this.inputDir = inputDir;
        this.outputDir = Path.of(outputDir);
    }

    public void run(List<String> steps) {
        LOG.info("store={} namespace={} partition={} steps={}", ds.storeName(), ds.namespace(), ds.partition(), steps);
        for (String step : steps) {
            long t0 = System.nanoTime();
            switch (step) {
                case "create" -> ds.createAll();
                case "reference" -> reference();
                case "orders" -> orders();
                case "enrich" -> enrich();
                case "export" -> export();
                default -> throw new IllegalArgumentException("Unknown step '" + step + "'; steps: " + ALL);
            }
            LOG.info("step {} done in {} ms", step, (System.nanoTime() - t0) / 1_000_000);
        }
        ds.manifest().all().forEach(e -> LOG.info("manifest {}", e));
    }

    // ------------------------------------------------------------------ jobs

    void reference() {
        load(Region.class, "regions.csv", r -> new Region(r[0], r[1]));
        load(Customer.class, "customers.csv", r -> new Customer(Long.parseLong(r[0]), r[1], r[2]));
        load(Product.class, "products.csv", r -> new Product(r[0], r[1], new BigDecimal(r[2])));
    }

    void orders() {
        Manifest m = ds.manifest();
        m.loading("order");                       // Order backs two datasets, so use names, not the class
        Map<Long, List<String[]>> byOrder = new LinkedHashMap<>();       // order_id,trade_date,customer_id,sku,qty
        for (String[] r : csv("orders.csv")) {
            byOrder.computeIfAbsent(Long.parseLong(r[0]), k -> new ArrayList<>()).add(r);
        }
        List<Order> orders = byOrder.entrySet().stream().map(e -> {
            String[] first = e.getValue().get(0);
            List<OrderLine> lines = e.getValue().stream().map(r -> new OrderLine(r[3], Integer.parseInt(r[4]))).toList();
            return new Order(e.getKey(), LocalDate.parse(first[1]), Long.parseLong(first[2]), lines);
        }).toList();
        ds.<Order, Long>dao("order").saveAll(orders);
        m.complete("order");
    }

    void enrich() {
        Manifest m = ds.manifest();
        m.requireComplete("order", "customer", "region", "product");
        Dao<Order, Long> orders = ds.dao("order");
        Dao<Order, Long> snapshots = ds.dao("order-snapshot");
        m.loading("order-snapshot");
        m.loading("position");
        Map<PositionKey, Position> positions = new ConcurrentHashMap<>();
        IntStream.range(0, orders.splits()).parallel().forEach(split -> {
            // Resolve.EAGER: customer -> region and lines -> product, one bulk call per dataset per level and page
            try (Stream<List<Order>> pages = orders.pages(split, 1_000, Resolve.EAGER)) {
                pages.forEach(page -> {
                    snapshots.saveAll(page);                              // EMBEDDED: the whole graph is stored
                    for (Order o : page) {
                        for (OrderLine l : o.getLines()) {
                            BigDecimal amount = l.getProduct().getUnitPrice().multiply(BigDecimal.valueOf(l.getQuantity()));
                            PositionKey key = new PositionKey(o.getCustomerId(), l.getSku());
                            positions.merge(key, new Position(key, l.getQuantity(), amount),
                                    (a, b) -> a.plus(b.getQuantity(), b.getNotional()));
                        }
                    }
                });
            }
        });
        ds.dao(Position.class).saveAll(positions.values());
        m.complete("order-snapshot");
        m.complete("position");
    }

    void export() {
        ds.manifest().requireComplete("order-snapshot", "position");
        Dao<Order, Long> snapshots = ds.dao("order-snapshot");
        List<String> rows = new ArrayList<>();
        try (Stream<Order> all = snapshots.streamAll()) {               // members are embedded: no lookups
            all.sorted(Comparator.comparingLong(Order::getOrderId)).forEach(o -> {
                int lineNo = 0;
                for (OrderLine l : o.getLines()) {
                    Product p = l.getProduct();
                    rows.add(String.join(",", Long.toString(o.getOrderId()), o.getTradeDate().toString(),
                            Long.toString(o.getCustomerId()), esc(o.getCustomer().getName()),
                            esc(o.getCustomer().getRegion().getName()), Integer.toString(++lineNo), p.getSku(),
                            esc(p.getName()), p.getUnitPrice().toPlainString(), Integer.toString(l.getQuantity()),
                            p.getUnitPrice().multiply(BigDecimal.valueOf(l.getQuantity())).toPlainString()));
                }
            });
        }
        write("orders_" + ds.partition() + ".csv",
                "order_id,trade_date,customer_id,customer_name,region,line_no,sku,product_name,unit_price,quantity,amount",
                rows);

        Dao<Position, PositionKey> positions = ds.dao(Position.class);
        List<String> prow = new ArrayList<>();
        try (Stream<Position> all = positions.streamAll()) {
            all.sorted(Comparator.comparingLong((Position p) -> p.getKey().customerId()).thenComparing(p -> p.getKey().sku()))
                    .forEach(p -> prow.add(p.getKey().customerId() + "," + p.getKey().sku() + "," + p.getQuantity() + ","
                            + p.getNotional().toPlainString()));
        }
        write("positions_" + ds.partition() + ".csv", "customer_id,sku,quantity,notional", prow);
    }

    // ------------------------------------------------------------------ helpers

    private <T> void load(Class<T> type, String file, Function<String[], T> mapper) {
        ds.manifest().loading(type);
        ds.dao(type).saveAll(csv(file).stream().map(mapper).toList());
        ds.manifest().complete(type);
    }

    private List<String[]> csv(String file) {
        String path = inputDir + file;
        try (InputStream in = Thread.currentThread().getContextClassLoader().getResourceAsStream(path)) {
            if (in == null) {
                throw new IllegalStateException("Missing input " + path);
            }
            BufferedReader r = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8));
            List<String[]> rows = new ArrayList<>();
            r.readLine(); // header
            for (String line; (line = r.readLine()) != null; ) {
                if (!line.isBlank()) {
                    String[] cols = line.split(",", -1);
                    for (int i = 0; i < cols.length; i++) {
                        cols[i] = cols[i].trim();
                    }
                    rows.add(cols);
                }
            }
            return rows;
        } catch (IOException e) {
            throw new UncheckedIOException(e);
        }
    }

    private void write(String name, String header, List<String> rows) {
        Path file = outputDir.resolve(name);
        try {
            Files.createDirectories(outputDir);
            List<String> lines = new ArrayList<>();
            lines.add(header);
            lines.addAll(rows);
            Files.write(file, lines, StandardCharsets.UTF_8);
        } catch (IOException e) {
            throw new UncheckedIOException("Cannot write " + file, e);
        }
        LOG.info("Exported {} rows to {}", rows.size(), file.toAbsolutePath());
    }

    private static String esc(String s) {
        return s.contains(",") || s.contains("\"") ? "\"" + s.replace("\"", "\"\"") + "\"" : s;
    }
}
