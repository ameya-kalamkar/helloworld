package com.acme.sample.app;

import com.acme.datastore.DataStore;
import com.acme.datastore.annotation.Resolve;
import com.acme.sample.domain.Order;
import com.acme.sample.domain.Position;
import com.acme.sample.domain.PositionKey;
import org.junit.jupiter.api.Test;

import java.io.InputStream;
import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

/** The production YAML, run on the in-memory store: no Chronicle files, no Ignite cluster, no Spring context. */
class PipelineTest {

    @Test
    void wholePipelineOnTheMemoryStore() throws Exception {
        String yaml;
        try (InputStream in = getClass().getClassLoader().getResourceAsStream("datastore.yml")) {
            yaml = new String(in.readAllBytes(), StandardCharsets.UTF_8);
        }
        Path out = Files.createTempDirectory("pipeline-test");
        try (DataStore ds = DataStore.builder().configText(yaml, "datastore.yml")
                .storeType("memory").partition("TEST_20261018").build()) {

            new Pipeline(ds, "data/", out.toString()).run(Pipeline.ALL);

            // REFERENCE mode: the stored order holds ids only; a plain read fills the EAGER customer (full depth)
            Order o = ds.<Order, Long>dao("order").findById(5003L).orElseThrow();
            assertEquals("Harbour Asset Mgmt", o.getCustomer().getName());
            assertEquals("Asia Pacific", o.getCustomer().getRegion().getName());
            assertNull(o.getLines().get(0).getProduct(), "lines.product is LAZY");
            assertNull(ds.<Order, Long>dao("order").findById(5003L, Resolve.LAZY).orElseThrow().getCustomer());

            // composite key
            Position p = ds.<Position, PositionKey>dao(Position.class)
                    .findById(new PositionKey(1001, "BND-CAN-10Y")).orElseThrow();
            assertEquals(150, p.getQuantity());
            assertEquals(0, new BigDecimal("14812.50").compareTo(p.getNotional()));

            List<String> csv = Files.readAllLines(out.resolve("orders_TEST_20261018.csv"));
            assertEquals(13, csv.size());                    // header + 12 order lines
            assertTrue(csv.get(1).startsWith("5001,2026-10-18,1001,Maple Capital,North America,1,BND-CAN-10Y"));
            assertEquals(12, Files.readAllLines(out.resolve("positions_TEST_20261018.csv")).size()); // header + 11
        }
    }
}
