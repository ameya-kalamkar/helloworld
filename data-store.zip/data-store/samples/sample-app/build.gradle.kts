plugins {
    application
}

dependencies {
    implementation(project(":data-store-core"))
    implementation(project(":samples:sample-domain"))

    // A real consumer adds ONE store module. The sample has both so `store:` can be switched in YAML
    // (or with DATASTORE_STORE=memory|chronicle|ignite) without rebuilding.
    runtimeOnly(project(":data-store-chronicle"))
    runtimeOnly(project(":data-store-ignite"))
    runtimeOnly(libs.logback.classic)

    testImplementation(platform(libs.junit.bom))
    testImplementation(libs.junit.jupiter)
    testRuntimeOnly(libs.junit.launcher)
}

application {
    mainClass.set("com.acme.sample.app.SampleApp")
    @Suppress("UNCHECKED_CAST")
    applicationDefaultJvmArgs = rootProject.extra["storeJvmArgs"] as List<String>
}

tasks.named<JavaExec>("run") {
    workingDir = projectDir
    // ./gradlew :samples:sample-app:run --args="all"
    environment("RUN_DATE", System.getenv("RUN_DATE") ?: "20261018")
}
