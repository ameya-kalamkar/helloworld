package com.acme.datastore;

import com.acme.datastore.spi.DatasetSpec;
import com.acme.datastore.store.MemoryStore;
import com.acme.datastore.spi.Store;
import com.acme.datastore.spi.StoreMap;

import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Stream;

/**
 * A custom store, selected by class name ({@code store-type: com.acme.datastore.CountingStore}) with no
 * registration file. Wraps the memory store and counts read calls per dataset, to prove lookups are
 * resolved with one bulk call per dataset per level. Also shows a custom store-level settings block.
 */
public final class CountingStore implements Store {

    static final Map<String, AtomicInteger> GET_ALL = new ConcurrentHashMap<>();
    static final Map<String, AtomicInteger> GET = new ConcurrentHashMap<>();

    /** {@code counting: { label: ... }} */
    public static final class Settings {
        private String label = "default";

        public String getLabel() {
            return label;
        }

        public void setLabel(String label) {
            this.label = label;
        }
    }

    private final MemoryStore delegate = new MemoryStore();
    String label;

    @Override
    public String name() {
        return "counting";
    }

    @Override
    public Class<?> settingsType() {
        return Settings.class;
    }

    @Override
    public void init(String namespace, Object settings, Collection<DatasetSpec<?>> datasets) {
        this.label = ((Settings) settings).getLabel();
        delegate.init(namespace, null, datasets);
    }

    @Override
    public <K> StoreMap<K> open(DatasetSpec<K> dataset, String partition, boolean create) {
        StoreMap<K> m = delegate.open(dataset, partition, create);
        String ds = dataset.name();
        return new StoreMap<>() {
            public byte[] get(K key) {
                GET.computeIfAbsent(ds, k -> new AtomicInteger()).incrementAndGet();
                return m.get(key);
            }

            public Map<K, byte[]> getAll(Collection<K> keys) {
                GET_ALL.computeIfAbsent(ds, k -> new AtomicInteger()).incrementAndGet();
                return m.getAll(keys);
            }

            public void put(K key, byte[] value) {
                m.put(key, value);
            }

            public void putAll(Map<K, byte[]> entries) {
                m.putAll(entries);
            }

            public boolean remove(K key) {
                return m.remove(key);
            }

            public long size() {
                return m.size();
            }

            public int splits() {
                return m.splits();
            }

            public Stream<Map.Entry<K, byte[]>> scan(int split) {
                return m.scan(split);
            }

            public void clear() {
                m.clear();
            }

            public void close() {
                m.close();
            }
        };
    }

    @Override
    public List<String> partitions() {
        return delegate.partitions();
    }

    @Override
    public void destroy(String partition) {
        delegate.destroy(partition);
    }

    @Override
    public void close() {
        delegate.close();
    }
}
