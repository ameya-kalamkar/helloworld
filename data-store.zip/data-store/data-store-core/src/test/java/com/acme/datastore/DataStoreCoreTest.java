package com.acme.datastore;

import com.acme.datastore.annotation.Id;
import com.acme.datastore.annotation.Lookup;
import com.acme.datastore.annotation.Resolve;
import com.acme.datastore.config.DataStoreConfig;
import com.acme.datastore.testing.domain.TCountry;
import com.acme.datastore.testing.domain.TCustomer;
import com.acme.datastore.testing.domain.TLine;
import com.acme.datastore.testing.domain.TOrder;
import com.acme.datastore.testing.domain.TProduct;
import com.acme.datastore.testing.domain.TRegion;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.function.Consumer;
import java.util.stream.IntStream;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

/** Core behaviour not tied to a store: bulk call counts, programmatic config, startup validation. */
class DataStoreCoreTest {

    private static String ns() {
        return "t" + UUID.randomUUID().toString().replace("-", "").substring(0, 10);
    }

    /** Programmatic setup, as a unit test of a job would do it (memory store is the default). */
    private static DataStore.Builder graph(String store) {
        return DataStore.builder().storeType(store).namespace(ns()).partition("P1")
                .dataset("country", TCountry.class)
                .dataset("region", TRegion.class)
                .dataset("customer", TCustomer.class, d -> d.lookup("regionCode", "region", "region", Resolve.DEFAULT))
                .dataset("product", TProduct.class)
                .dataset("order", TOrder.class);
    }

    @Test
    void eagerPageIsOneBulkCallPerDatasetPerLevel() {
        try (DataStore ds = graph(CountingStore.class.getName()).build()) {
            ds.createAll();
            ds.dao(TCountry.class).saveAll(List.of(new TCountry("CA", "Canada"), new TCountry("US", "USA")));
            ds.dao(TRegion.class).saveAll(List.of(new TRegion("ON", "Ontario", "CA"), new TRegion("NY", "NY", "US")));
            ds.dao(TCustomer.class).saveAll(List.of(new TCustomer(1, "A", "ON", "O-0"), new TCustomer(2, "B", "NY", null),
                    new TCustomer(3, "C", "ON", null)));
            ds.dao(TProduct.class).saveAll(List.of(new TProduct(10, "P10", BigDecimal.ONE),
                    new TProduct(20, "P20", BigDecimal.ONE), new TProduct(30, "P30", BigDecimal.ONE)));
            List<TOrder> orders = new ArrayList<>();
            IntStream.range(0, 50).forEach(i -> orders.add(new TOrder("O-" + i, 1 + i % 3,
                    List.of(new TLine(10, 1), new TLine(20 + (i % 2) * 10, 1)), List.of(30))));
            ds.dao(TOrder.class).saveAll(orders);
            CountingStore.GET_ALL.clear();
            CountingStore.GET.clear();

            var page = ds.<TOrder, String>dao(TOrder.class)
                    .findAllById(orders.stream().map(TOrder::getId).toList(), Resolve.EAGER);

            assertEquals(50, page.size());
            assertEquals("Canada", page.get("O-0").getCustomer().getRegion().getCountry().getName());
            assertEquals("P30", page.get("O-1").getLines().get(1).getProduct().getName());
            for (String ds2 : List.of("order", "customer", "region", "country", "product")) {
                assertEquals(1, CountingStore.GET_ALL.get(ds2).get(), ds2 + ": one bulk call for the whole page");
            }
            assertTrue(CountingStore.GET.isEmpty(), "no single-key reads");
        }
    }

    @Test
    void customStoreReceivesItsSettings() {
        DataStoreConfig cfg = DataStoreConfig.parse("""
                datastore:
                  store-type: com.acme.datastore.CountingStore
                  namespace: x
                  partition: { parts: { d: "1" } }
                  counting: { label: hello }
                  datasets:
                    country: { value: com.acme.datastore.testing.domain.TCountry }
                """, "test");
        try (DataStore ds = DataStore.builder().config(cfg).build()) {
            assertEquals("counting", ds.storeName());
            assertEquals("1", ds.partition());
        }
    }

    @Test
    void jsonConfigWorksToo() {
        String json = """
                {"datastore": {"namespace": "%s", "partition": {"parts": {"day": "20261018", "region": "NA"}},
                  "datasets": {"country": {"value": "com.acme.datastore.testing.domain.TCountry"}}}}
                """.formatted(ns());
        try (DataStore ds = DataStore.builder().configText(json, "test.json").build()) {
            assertEquals("memory", ds.storeName());
            assertEquals("20261018_NA", ds.partition());
        }
    }

    // ------------------------------------------------------------------ startup validation

    private static void fails(String expectedFragment, Consumer<DataStore.Builder> setup) {
        DataStore.Builder b = DataStore.builder().namespace(ns()).partition("P1");
        setup.accept(b);
        DataStoreException e = assertThrows(DataStoreException.class, b::build);
        assertTrue(e.getMessage().contains(expectedFragment), "message was: " + e.getMessage());
    }

    @Test
    void validationErrors() {
        fails("not on the classpath", b -> b.storeType("redis").dataset("country", TCountry.class));
        fails("takes no settings", b -> b.dataset("country", TCountry.class, d -> d.store("memory", java.util.Map.of())));
        // a block for a store that is not installed is a typo (blocks of installed, inactive stores are ignored)
        fails("Unknown setting 'datasets.country.redis'",
                b -> b.dataset("country", TCountry.class, d -> d.store("redis", java.util.Map.of("entries", 1))));
        fails("unknown target dataset", b -> b.dataset("customer", TCustomer.class));
        fails("does not match key", b -> b.dataset("country", TCountry.class).dataset("bad", BadLookup.class));
        fails("EAGER needs an 'into'", b -> b.dataset("country", TCountry.class).dataset("bad", EagerNoInto.class));
        fails("no id", b -> b.dataset("noid", NoId.class));
        fails("must override equals", b -> b.dataset("badkey", BadKeyHolder.class));
        fails("several datasets", b -> b.dataset("country", TCountry.class).dataset("country2", TCountry.class)
                .dataset("bad", ByClass.class));
    }

    @Test
    void datasetDefaultsAreValidated() {
        String base = """
                datastore:
                  namespace: x
                  partition: { parts: { d: "1" } }
                  dataset-defaults: { %s }
                  datasets:
                    country: { value: com.acme.datastore.testing.domain.TCountry }
                """;
        DataStoreException e = assertThrows(DataStoreException.class, () -> DataStore.builder()
                .configText(base.formatted("value: com.acme.X"), "t").build());
        assertTrue(e.getMessage().contains("dataset-defaults cannot set value"), e.getMessage());
        e = assertThrows(DataStoreException.class, () -> DataStore.builder()
                .configText(base.formatted("redis: { a: 1 }"), "t").build());
        assertTrue(e.getMessage().contains("Unknown setting 'dataset-defaults.redis'"), e.getMessage());
        try (DataStore ds = DataStore.builder().configText(base.formatted("local-cache: true, splits: 3"), "t")
                .namespace(ns()).build()) {
            ds.createAll();
            assertEquals(3, ds.dao(TCountry.class).splits(), "inherited from dataset-defaults");
        }
    }

    @Test
    void ambiguousClassNeedsDatasetName() {
        try (DataStore ds = DataStore.builder().namespace(ns()).partition("P1")
                .dataset("a", TCountry.class).dataset("b", TCountry.class).build()) {
            assertThrows(DataStoreException.class, () -> ds.dao(TCountry.class));
            ds.createAll();
            ds.dao("b").save(new TCountry("CA", "Canada"));
            assertEquals(0, ds.dao("a").count());
        }
    }

    @Test
    void typoInYamlIsRejectedAtStartup() {
        DataStoreException e = assertThrows(DataStoreException.class, () -> DataStore.builder().configText("""
                datastore:
                  namespace: x
                  partition: { parts: { d: "1" } }
                  datasets:
                    country: { value: com.acme.datastore.testing.domain.TCountry, splitz: 3 }
                """, "typo.yml").build());
        assertTrue(e.getMessage().contains("Unknown setting 'datasets.country.splitz'"), e.getMessage());
    }

    // ---- invalid domain classes

    static class BadLookup {
        @Id
        String id;
        @Lookup(dataset = "country")
        long countryId;               // country keys are String
    }

    static class EagerNoInto {
        @Id
        String id;
        @Lookup(dataset = "country", resolvePolicy = Resolve.EAGER)
        String countryIso;
    }

    static class NoId {
        String name;
    }

    static final class MutableKey {
        final String a;

        MutableKey(String a) {
            this.a = a;
        }
    }

    static class BadKeyHolder {
        @Id
        MutableKey key;
    }

    static class ByClass {
        @Id
        String id;
        @Lookup(target = TCountry.class)
        String countryIso;
    }
}
