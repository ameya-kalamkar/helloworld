package com.acme.datastore;

import com.acme.datastore.testing.DataStoreContractTest;

import java.nio.file.Path;

/** The built-in memory store (default). */
class MemoryContractTest extends DataStoreContractTest {

    @Override
    protected String store() {
        return "memory";
    }

    @Override
    protected String storeBlock(Path tempDir) {
        return "";
    }

    @Override
    protected String datasetBlock() {
        return "";
    }
}
