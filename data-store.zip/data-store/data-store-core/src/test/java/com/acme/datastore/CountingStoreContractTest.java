package com.acme.datastore;

import com.acme.datastore.testing.DataStoreContractTest;

import java.nio.file.Path;

/** A custom store selected by class name passes the same contract as the built-in ones. */
class CountingStoreContractTest extends DataStoreContractTest {

    @Override
    protected String store() {
        return CountingStore.class.getName();
    }

    @Override
    protected String storeBlock(Path tempDir) {
        return "counting:\n  label: contract\n";
    }

    @Override
    protected String datasetBlock() {
        return "";
    }
}
