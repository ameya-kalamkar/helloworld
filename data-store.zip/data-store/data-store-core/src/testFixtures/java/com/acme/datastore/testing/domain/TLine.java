package com.acme.datastore.testing.domain;

import com.acme.datastore.annotation.Lookup;

/** Nested inside TOrder (not a dataset): lookup path lines.productId. */
public class TLine {
    @Lookup(target = TProduct.class, into = "product")
    private int productId;
    private TProduct product;
    private int qty;

    public TLine() {
    }

    public TLine(int productId, int qty) {
        this.productId = productId;
        this.qty = qty;
    }

    public int getProductId() {
        return productId;
    }

    public TProduct getProduct() {
        return product;
    }

    public int getQty() {
        return qty;
    }
}
