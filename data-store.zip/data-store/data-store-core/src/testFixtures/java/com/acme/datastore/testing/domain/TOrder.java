package com.acme.datastore.testing.domain;

import com.acme.datastore.annotation.Id;
import com.acme.datastore.annotation.Lookup;
import com.acme.datastore.annotation.Resolve;

import java.util.ArrayList;
import java.util.List;

/**
 * An "existing" domain class: full-object fields (customer, favourites) kept for older apps, plus the
 * annotated id fields the data store stores in REFERENCE mode.
 */
public class TOrder {
    @Id
    private String id;
    @Lookup(dataset = "customer", into = "customer", resolvePolicy = Resolve.EAGER)
    private long customerId;
    private TCustomer customer;
    private List<TLine> lines = new ArrayList<>();
    @Lookup(target = TProduct.class, into = "favourites")
    private List<Integer> favouriteIds = new ArrayList<>();
    private List<TProduct> favourites;

    public TOrder() {
    }

    public TOrder(String id, long customerId, List<TLine> lines, List<Integer> favouriteIds) {
        this.id = id;
        this.customerId = customerId;
        this.lines = new ArrayList<>(lines);
        this.favouriteIds = new ArrayList<>(favouriteIds);
    }

    /** Built the old way: full objects only, ids not set. */
    public static TOrder withObjects(String id, TCustomer customer, List<TLine> lines) {
        TOrder o = new TOrder();
        o.id = id;
        o.customer = customer;
        o.lines = new ArrayList<>(lines);
        return o;
    }

    public String getId() {
        return id;
    }

    public long getCustomerId() {
        return customerId;
    }

    public TCustomer getCustomer() {
        return customer;
    }

    public void setCustomer(TCustomer customer) {
        this.customer = customer;
    }

    public List<TLine> getLines() {
        return lines;
    }

    public List<Integer> getFavouriteIds() {
        return favouriteIds;
    }

    public List<TProduct> getFavourites() {
        return favourites;
    }
}
