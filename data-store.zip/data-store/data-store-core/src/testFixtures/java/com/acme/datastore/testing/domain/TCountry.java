package com.acme.datastore.testing.domain;

import com.acme.datastore.annotation.Id;

public class TCountry {
    @Id
    private String iso;
    private String name;

    public TCountry() {
    }

    public TCountry(String iso, String name) {
        this.iso = iso;
        this.name = name;
    }

    public String getIso() {
        return iso;
    }

    public String getName() {
        return name;
    }
}
