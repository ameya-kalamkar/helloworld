package com.acme.datastore.testing.domain;

import com.acme.datastore.annotation.Id;

public class TPosition {
    @Id
    private TPositionKey key;
    private long qty;

    public TPosition() {
    }

    public TPosition(TPositionKey key, long qty) {
        this.key = key;
        this.qty = qty;
    }

    public TPositionKey getKey() {
        return key;
    }

    public long getQty() {
        return qty;
    }
}
