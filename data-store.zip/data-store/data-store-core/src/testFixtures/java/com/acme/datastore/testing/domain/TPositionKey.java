package com.acme.datastore.testing.domain;

/** Composite key as a record (with an enum component). */
public record TPositionKey(long customerId, String sku, TSide side) {
}
