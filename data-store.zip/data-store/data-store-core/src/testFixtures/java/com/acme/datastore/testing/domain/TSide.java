package com.acme.datastore.testing.domain;

public enum TSide { BUY, SELL }
