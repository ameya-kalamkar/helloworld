package com.acme.datastore.testing;

import com.acme.datastore.Dao;
import com.acme.datastore.DataStore;
import com.acme.datastore.DataStoreException;
import com.acme.datastore.lookup.LookupResult;
import com.acme.datastore.Manifest;
import com.acme.datastore.annotation.Resolve;
import com.acme.datastore.testing.domain.TCountry;
import com.acme.datastore.testing.domain.TCustomer;
import com.acme.datastore.testing.domain.TLeg;
import com.acme.datastore.testing.domain.TLegKey;
import com.acme.datastore.testing.domain.TLine;
import com.acme.datastore.testing.domain.TOrder;
import com.acme.datastore.testing.domain.TPosition;
import com.acme.datastore.testing.domain.TPositionKey;
import com.acme.datastore.testing.domain.TProduct;
import com.acme.datastore.testing.domain.TRegion;
import com.acme.datastore.testing.domain.TSide;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.io.IOException;
import java.math.BigDecimal;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Behaviour every store must have. Store modules, and authors of custom stores, extend this:
 *
 * <pre>{@code
 * class MyStoreContractTest extends DataStoreContractTest {
 *     protected String store() { return "com.acme.MyStore"; }       // or its name
 *     protected String storeBlock(Path dir) { return "my:\n  url: x\n"; }   // "" if none
 *     protected String datasetBlock() { return ""; }                 // dataset-level settings, "" if none
 * }
 * }</pre>
 */
public abstract class DataStoreContractTest {

    protected static final String DAY = "NA_20261018";

    protected Path tempDir;
    protected String namespace;
    private final List<DataStore> started = new ArrayList<>();

    /** Value of {@code store:}. */
    protected abstract String store();

    /** Store-level block, unindented (e.g. {@code "chronicle:\n  base-dir: /x\n"}), or "". */
    protected abstract String storeBlock(Path tempDir);

    /** Dataset-level store block put in dataset-defaults, one line (e.g. {@code "chronicle: { entries: 1000 }"}), or "". */
    protected abstract String datasetBlock();

    @BeforeEach
    void setUpStore() throws IOException {
        tempDir = Files.createTempDirectory("datastore-contract");
        namespace = "t" + UUID.randomUUID().toString().replace("-", "").substring(0, 12);
    }

    @AfterEach
    void tearDownStore() throws IOException {
        for (DataStore s : started) {
            s.close();
        }
        started.clear();
        if (tempDir != null && Files.exists(tempDir)) {
            try (Stream<Path> paths = Files.walk(tempDir)) {
                for (Path p : paths.sorted(Comparator.reverseOrder()).toList()) {
                    Files.deleteIfExists(p);
                }
            }
        }
    }

    /** Store-specific settings go once into dataset-defaults; datasets override field by field. */
    protected String yaml(String missing) {
        String block = indent(storeBlock(tempDir), "  ");
        String ds = datasetBlock().isBlank() ? "" : "\n    " + datasetBlock();
        return """
                datastore:
                  store-type: %s
                  namespace: %s
                  partition:
                    parts: { region: NA, business-date: "20261018" }
                  lookup-resolver: { parallelism: 3, single-read-warn: 0 }
                %s
                  dataset-defaults:
                    storage-mode: REFERENCE
                    lookup-resolve-policy: LAZY
                    on-missing-target: %s%s
                  datasets:
                    country:
                      value: com.acme.datastore.testing.domain.TCountry
                      on-missing-target: NULL                # overrides dataset-defaults
                    region:
                      value: com.acme.datastore.testing.domain.TRegion
                      local-cache: true
                    customer:
                      value: com.acme.datastore.testing.domain.TCustomer
                      lookups:
                        - { field: regionCode, target: region, into: region }
                    product:
                      value: com.acme.datastore.testing.domain.TProduct
                    order:
                      value: com.acme.datastore.testing.domain.TOrder
                      splits: 4
                    order-snapshot:
                      value: com.acme.datastore.testing.domain.TOrder
                      storage-mode: EMBEDDED
                    position:
                      value: com.acme.datastore.testing.domain.TPosition
                      splits: 3
                    leg:
                      value: com.acme.datastore.testing.domain.TLeg
                      key: com.acme.datastore.testing.domain.TLegKey
                      id: [tradeId, legNo]
                """.formatted(store(), namespace, block, missing, ds);
    }

    private static String indent(String text, String by) {
        return text.lines().map(l -> by + l).collect(Collectors.joining("\n"));
    }

    protected DataStore start(String partition, String missing, boolean create) {
        DataStore ds = DataStore.builder().configText(yaml(missing), "contract-test").partition(partition).build();
        started.add(ds);
        if (create) {
            ds.createAll();
        }
        return ds;
    }

    protected DataStore start() {
        return start(DAY, "FAIL", true);
    }

    protected void stop(DataStore ds) {
        started.remove(ds);
        ds.close();
    }

    protected static void loadReference(DataStore ds) {
        ds.dao(TCountry.class).saveAll(List.of(new TCountry("CA", "Canada"), new TCountry("US", "United States")));
        ds.dao(TRegion.class).saveAll(List.of(new TRegion("ON", "Ontario", "CA"), new TRegion("NY", "New York", "US")));
        ds.dao(TCustomer.class).saveAll(List.of(new TCustomer(1, "Alice", "ON", "O-1"),
                new TCustomer(2, "Bob", "NY", null), new TCustomer(3, "Chen", "ON", null)));
        ds.dao(TProduct.class).saveAll(List.of(new TProduct(10, "Bond", new BigDecimal("99.50")),
                new TProduct(20, "Swap", new BigDecimal("12.00")), new TProduct(30, "Fx", BigDecimal.ONE)));
    }

    protected static Dao<TOrder, String> orders(DataStore ds) {
        return ds.dao("order");
    }

    protected static List<TOrder> sampleOrders() {
        return List.of(
                new TOrder("O-1", 1, List.of(new TLine(10, 1), new TLine(20, 2)), List.of(30)),
                new TOrder("O-2", 1, List.of(new TLine(10, 3)), List.of()),
                new TOrder("O-3", 2, List.of(), List.of(10, 20)));
    }

    // ------------------------------------------------------------------ basics

    @Test
    void roundTripAndMissingKey() {
        DataStore ds = start();
        Dao<TCountry, String> countries = ds.dao(TCountry.class);
        countries.save(new TCountry("CA", "Canada"));
        assertEquals("Canada", countries.findById("CA").orElseThrow().getName());
        assertTrue(countries.findById("XX").isEmpty());
        assertEquals(1, countries.count());
    }

    @Test
    void bulkReadReturnsOnlyFoundKeys() {
        DataStore ds = start();
        loadReference(ds);
        Map<Long, TCustomer> found = ds.<TCustomer, Long>dao(TCustomer.class).findAllById(List.of(1L, 3L, 42L), Resolve.LAZY);
        assertEquals(Set.of(1L, 3L), found.keySet());
        assertEquals("Chen", found.get(3L).getName());
    }

    @Test
    void readsAreCopies() {
        DataStore ds = start();
        loadReference(ds);
        Dao<TCountry, String> c = ds.dao(TCountry.class);
        assertFalse(c.findById("CA").orElseThrow() == c.findById("CA").orElseThrow());
    }

    @Test
    void overwriteDeleteAndReset() {
        DataStore ds = start();
        Dao<TProduct, Integer> products = ds.dao(TProduct.class);
        products.save(new TProduct(10, "Bond", BigDecimal.ONE));
        products.save(new TProduct(10, "Bond v2", BigDecimal.TEN));
        assertEquals(1, products.count());
        assertEquals("Bond v2", products.findById(10).orElseThrow().getName());
        assertTrue(products.deleteById(10));
        assertFalse(products.deleteById(10));
        products.save(new TProduct(11, "X", BigDecimal.ONE));
        ds.reset("product");
        assertEquals(0, products.count());
        assertEquals(Manifest.Status.CREATED, ds.manifest().status("product"));
    }

    @Test
    void splitsCoverTheDatasetExactlyOnce() {
        DataStore ds = start();
        loadReference(ds);
        Dao<TOrder, String> orders = orders(ds);
        orders.saveAll(IntStream.range(0, 300).mapToObj(i -> new TOrder("O-" + i, 1 + i % 3, List.of(new TLine(10, i)),
                List.of())).toList());
        Set<String> seen = new HashSet<>();
        int total = 0;
        for (int s = 0; s < orders.splits(); s++) {
            try (Stream<TOrder> split = orders.streamSplit(s, Resolve.LAZY)) {
                for (TOrder o : split.toList()) {
                    total++;
                    seen.add(o.getId());
                }
            }
        }
        assertEquals(300, total, "splits must not overlap");
        assertEquals(300, seen.size());
    }

    // ------------------------------------------------------------------ keys

    @Test
    void compositeRecordKeyWithEnum() {
        DataStore ds = start();
        Dao<TPosition, TPositionKey> positions = ds.dao(TPosition.class);
        positions.saveAll(List.of(new TPosition(new TPositionKey(1, "BND", TSide.BUY), 100),
                new TPosition(new TPositionKey(1, "BND", TSide.SELL), 40),
                new TPosition(new TPositionKey(2, "BND", TSide.BUY), 7)));
        assertEquals(40, positions.findById(new TPositionKey(1, "BND", TSide.SELL)).orElseThrow().getQty());
        assertEquals(3, positions.count());
        Set<TPositionKey> scanned = new HashSet<>();
        for (int s = 0; s < positions.splits(); s++) {
            try (Stream<TPosition> split = positions.streamSplit(s)) {
                split.forEach(p -> scanned.add(p.getKey()));
            }
        }
        assertEquals(3, scanned.size());
        assertTrue(scanned.contains(new TPositionKey(2, "BND", TSide.BUY)));
    }

    @Test
    void keyBuiltFromSeveralFields() {
        DataStore ds = start();
        Dao<TLeg, TLegKey> legs = ds.dao(TLeg.class);
        legs.saveAll(List.of(new TLeg("T1", 1, BigDecimal.ONE), new TLeg("T1", 2, BigDecimal.TEN)));
        assertEquals(BigDecimal.TEN, legs.findById(new TLegKey("T1", 2)).orElseThrow().getNotional());
        assertEquals(new TLegKey("T1", 1), legs.idOf(new TLeg("T1", 1, null)));
    }

    // ------------------------------------------------------------------ storage modes

    @Test
    void referenceModeStoresOnlyIdsAndLeavesCallerObjectsAlone() {
        DataStore ds = start();
        loadReference(ds);
        TCustomer alice = ds.<TCustomer, Long>dao(TCustomer.class).findById(1L, Resolve.LAZY).orElseThrow();
        TOrder legacy = TOrder.withObjects("O-9", alice, List.of(new TLine(10, 1)));   // id field not set
        orders(ds).save(legacy);

        assertSame(alice, legacy.getCustomer(), "caller's object must not be modified");
        assertEquals(0, legacy.getCustomerId());
        TOrder stored = orders(ds).findById("O-9", Resolve.LAZY).orElseThrow();
        assertEquals(1, stored.getCustomerId(), "id filled from the into object");
        assertNull(stored.getCustomer(), "full object not stored in REFERENCE mode");
    }

    @Test
    void referenceModeRejectsIdThatDisagreesWithObject() {
        DataStore ds = start();
        loadReference(ds);
        TOrder o = new TOrder("O-8", 2, List.of(), List.of());
        o.setCustomer(ds.<TCustomer, Long>dao(TCustomer.class).findById(1L, Resolve.LAZY).orElseThrow());
        assertThrows(DataStoreException.class, () -> orders(ds).save(o));
    }

    @Test
    void embeddedModeStoresTheWholeGraph() {
        DataStore ds = start();
        loadReference(ds);
        orders(ds).save(sampleOrders().get(0));
        TOrder full = orders(ds).findById("O-1", Resolve.EAGER).orElseThrow();   // fully hydrated
        ds.<TOrder, String>dao("order-snapshot").save(full);
        ds.reset("customer");                                   // the snapshot must not need it
        TOrder snap = ds.<TOrder, String>dao("order-snapshot").findById("O-1").orElseThrow();
        assertEquals("Alice", snap.getCustomer().getName());
        assertEquals("Canada", snap.getCustomer().getRegion().getCountry().getName());
        assertEquals("Swap", snap.getLines().get(1).getProduct().getName());
    }

    // ------------------------------------------------------------------ lookups

    @Test
    void eagerReadResolvesTheFullGraph() {
        DataStore ds = start();
        loadReference(ds);
        orders(ds).saveAll(sampleOrders());
        TOrder o = orders(ds).findById("O-1").orElseThrow();
        // customer is EAGER; region (YAML, LAZY) and country (annotation, LAZY) come with it: full depth
        assertEquals("Alice", o.getCustomer().getName());
        assertEquals("Ontario", o.getCustomer().getRegion().getName());
        assertEquals("Canada", o.getCustomer().getRegion().getCountry().getName());
        // lines.product and favourites are LAZY at the order level: not resolved by a plain read
        assertNull(o.getLines().get(0).getProduct());
        assertNull(o.getFavourites());
    }

    @Test
    void cyclesTerminateAndReusePageObjects() {
        DataStore ds = start();
        loadReference(ds);
        orders(ds).saveAll(sampleOrders());
        TOrder o1 = orders(ds).findById("O-1").orElseThrow();
        // O-1 -> Alice -> primaryOrder O-1: resolved to the same object instead of looping
        assertSame(o1, o1.getCustomer().getPrimaryOrder());
    }

    @Test
    void perCallOverrides() {
        DataStore ds = start();
        loadReference(ds);
        orders(ds).saveAll(sampleOrders());
        assertNull(orders(ds).findById("O-1", Resolve.LAZY).orElseThrow().getCustomer());
        TOrder all = orders(ds).findById("O-1", Resolve.EAGER).orElseThrow();
        assertEquals("Swap", all.getLines().get(1).getProduct().getName());
        assertEquals("Fx", all.getFavourites().get(0).getName());
    }

    @Test
    void resolverOnDemandAndScope() {
        DataStore ds = start();
        loadReference(ds);
        orders(ds).saveAll(sampleOrders());
        List<TOrder> page = new ArrayList<>(orders(ds).findAllById(List.of("O-1", "O-2", "O-3"), Resolve.LAZY).values());
        assertNull(page.get(0).getCustomer());

        LookupResult<TOrder> scope = ds.lookups().scope("order", page);
        TCustomer c = scope.get(page.get(0), "customer");         // loads customer for the whole page
        assertEquals("Alice", c.getName());
        assertSame(c, scope.get(page.get(1), "customer"), "same id -> one shared instance in the page");
        assertEquals("New York", page.get(2).getCustomer().getRegion().getName(), "into fields hydrated, full depth");
        assertNull(page.get(0).getLines().get(0).getProduct(), "not asked for yet");

        ds.lookups().resolve("order", page, "lines.product");
        assertEquals("Bond", page.get(1).getLines().get(0).getProduct().getName());
        List<TProduct> favs = scope.get(page.get(2), "favourites");
        assertEquals(List.of("Bond", "Swap"), favs.stream().map(TProduct::getName).toList());
    }

    @Test
    void streamingResolvesEagerLookupsPerPage() {
        DataStore ds = start();
        loadReference(ds);
        orders(ds).saveAll(sampleOrders());
        int withCustomer = 0;
        for (int s = 0; s < orders(ds).splits(); s++) {
            try (Stream<List<TOrder>> pages = orders(ds).pages(s, 2)) {
                for (List<TOrder> page : pages.toList()) {
                    for (TOrder o : page) {
                        assertNotNull(o.getCustomer().getRegion());
                        withCustomer++;
                    }
                }
            }
        }
        assertEquals(3, withCustomer);
    }

    @Test
    void missingTargetFailsByDefault() {
        DataStore ds = start();
        loadReference(ds);
        orders(ds).save(new TOrder("O-7", 77, List.of(), List.of()));
        assertThrows(DataStoreException.class, () -> orders(ds).findById("O-7"));
    }

    @Test
    void missingTargetIsNullWhenConfigured() {
        DataStore ds = start(DAY, "NULL", true);
        loadReference(ds);
        orders(ds).save(new TOrder("O-7", 77, List.of(), List.of()));
        assertNull(orders(ds).findById("O-7").orElseThrow().getCustomer());
    }

    @Test
    void datasetOverridesDatasetDefaults() {
        DataStore ds = start();                                   // defaults: on-missing-target FAIL
        loadReference(ds);
        ds.dao(TRegion.class).save(new TRegion("QC", "Quebec", "XX"));   // country XX does not exist
        ds.dao(TCustomer.class).save(new TCustomer(4, "Dana", "QC", null));
        orders(ds).save(new TOrder("O-5", 4, List.of(), List.of()));
        TOrder o = orders(ds).findById("O-5").orElseThrow();       // country says NULL: tolerated
        assertEquals("Quebec", o.getCustomer().getRegion().getName());
        assertNull(o.getCustomer().getRegion().getCountry());
        orders(ds).save(new TOrder("O-6", 99, List.of(), List.of()));
        assertThrows(DataStoreException.class, () -> orders(ds).findById("O-6"));   // customer: FAIL
    }

    // ------------------------------------------------------------------ lifecycle

    @Test
    void manifestTracksCompletion() {
        DataStore ds = start();
        assertEquals(Manifest.Status.CREATED, ds.manifest().status("customer"));
        assertThrows(DataStoreException.class, () -> ds.manifest().requireComplete("customer", "region"));
        loadReference(ds);
        ds.manifest().complete(TCustomer.class);
        ds.manifest().complete("region");
        ds.manifest().requireComplete("customer", "region");
        assertEquals(3, ds.manifest().get("customer").orElseThrow().recordCount());
    }

    @Test
    void openingBeforeCreateFails() {
        DataStore ds = start(DAY, "FAIL", false);
        assertThrows(DataStoreException.class, () -> ds.dao(TCustomer.class).count());
    }

    @Test
    void partitionsAreIsolatedAndKeptUntilDestroyed() {
        DataStore old = start("NA_20261017", "FAIL", true);
        old.dao(TCountry.class).save(new TCountry("CA", "Canada (yesterday)"));
        stop(old);
        DataStore other = start("EU_20261018", "FAIL", true);
        stop(other);
        DataStore today = start();
        assertEquals(0, today.dao(TCountry.class).count(), "today must not see other partitions");
        assertEquals(List.of("EU_20261018", "NA_20261017", "NA_20261018"), today.partitions());

        DataStore yesterday = start("NA_20261017", "FAIL", false);
        assertEquals("Canada (yesterday)", yesterday.<TCountry, String>dao(TCountry.class).findById("CA")
                .orElseThrow().getName(), "older partitions stay until someone deletes them");
        stop(yesterday);

        assertTrue(today.destroyPartition("EU_20261018"));
        assertEquals(List.of("NA_20261017", "NA_20261018"), today.partitions());
        assertThrows(DataStoreException.class, () -> today.destroyPartition(DAY));
    }

    @Test
    void secondStoreInSameJvmSeesTheSameData() {
        DataStore writer = start();
        loadReference(writer);
        DataStore reader = start(DAY, "FAIL", false);
        assertEquals(3, reader.dao(TCustomer.class).count());
    }
}
