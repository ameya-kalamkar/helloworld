package com.acme.datastore.testing.domain;

import java.util.Objects;

/** Composite key as a final class with final fields. */
public final class TLegKey {
    private final String tradeId;
    private final int legNo;

    public TLegKey(String tradeId, int legNo) {
        this.tradeId = tradeId;
        this.legNo = legNo;
    }

    public String tradeId() {
        return tradeId;
    }

    public int legNo() {
        return legNo;
    }

    @Override
    public boolean equals(Object o) {
        return o instanceof TLegKey k && legNo == k.legNo && tradeId.equals(k.tradeId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(tradeId, legNo);
    }
}
