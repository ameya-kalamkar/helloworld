package com.acme.datastore.testing.domain;

import java.math.BigDecimal;

/** No annotations at all: the key is built from two fields via YAML (id: [tradeId, legNo]). */
public class TLeg {
    private String tradeId;
    private int legNo;
    private BigDecimal notional;

    public TLeg() {
    }

    public TLeg(String tradeId, int legNo, BigDecimal notional) {
        this.tradeId = tradeId;
        this.legNo = legNo;
        this.notional = notional;
    }

    public String getTradeId() {
        return tradeId;
    }

    public int getLegNo() {
        return legNo;
    }

    public BigDecimal getNotional() {
        return notional;
    }
}
