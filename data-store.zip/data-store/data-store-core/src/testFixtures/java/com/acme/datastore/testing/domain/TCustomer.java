package com.acme.datastore.testing.domain;

import com.acme.datastore.annotation.Id;
import com.acme.datastore.annotation.Lookup;

/**
 * regionCode -> region is configured in YAML (no annotation). primaryOrderId points back to the order
 * dataset, so resolving orders forms a cycle that must terminate.
 */
public class TCustomer {
    @Id
    private long id;
    private String name;
    private String regionCode;
    private TRegion region;
    @Lookup(dataset = "order", into = "primaryOrder")
    private String primaryOrderId;
    private TOrder primaryOrder;

    public TCustomer() {
    }

    public TCustomer(long id, String name, String regionCode, String primaryOrderId) {
        this.id = id;
        this.name = name;
        this.regionCode = regionCode;
        this.primaryOrderId = primaryOrderId;
    }

    public long getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getRegionCode() {
        return regionCode;
    }

    public TRegion getRegion() {
        return region;
    }

    public void setRegion(TRegion region) {
        this.region = region;
    }

    public TOrder getPrimaryOrder() {
        return primaryOrder;
    }
}
