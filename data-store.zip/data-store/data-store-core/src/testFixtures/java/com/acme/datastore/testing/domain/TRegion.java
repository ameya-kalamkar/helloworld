package com.acme.datastore.testing.domain;

import com.acme.datastore.annotation.Id;
import com.acme.datastore.annotation.Lookup;

/** Lookup by annotation, LAZY (default): only resolved when something above it is resolved. */
public class TRegion {
    @Id
    private String code;
    private String name;
    @Lookup(dataset = "country", into = "country")
    private String countryIso;
    private TCountry country;

    public TRegion() {
    }

    public TRegion(String code, String name, String countryIso) {
        this.code = code;
        this.name = name;
        this.countryIso = countryIso;
    }

    public String getCode() {
        return code;
    }

    public String getName() {
        return name;
    }

    public String getCountryIso() {
        return countryIso;
    }

    public TCountry getCountry() {
        return country;
    }
}
