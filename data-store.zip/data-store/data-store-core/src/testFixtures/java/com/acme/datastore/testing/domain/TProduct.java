package com.acme.datastore.testing.domain;

import com.acme.datastore.annotation.Id;

import java.math.BigDecimal;

public class TProduct {
    @Id
    private int id;
    private String name;
    private BigDecimal price;

    public TProduct() {
    }

    public TProduct(int id, String name, BigDecimal price) {
        this.id = id;
        this.name = name;
        this.price = price;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public BigDecimal getPrice() {
        return price;
    }
}
