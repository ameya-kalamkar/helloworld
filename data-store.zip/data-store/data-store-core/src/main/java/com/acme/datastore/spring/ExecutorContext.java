package com.acme.datastore.spring;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

/**
 * One Spring context per executor JVM for Flink / Spark jobs, shared by every task in that JVM (so they
 * share one DataStore, one set of open maps and one local-cache).
 *
 * <pre>{@code
 * // Flink RichFunction#open
 * DataStore ds = ExecutorContext.bean(DataStore.class, JobConfig.class);
 * getRuntimeContext().registerUserCodeClassLoaderReleaseHookIfAbsent("datastore", ExecutorContext::close);
 *
 * // Spark mapPartitions / foreachPartition: call lazily; the shutdown hook closes it on executor exit
 * DataStore ds = ExecutorContext.bean(DataStore.class, JobConfig.class);
 * }</pre>
 */
public final class ExecutorContext {

    private static volatile AnnotationConfigApplicationContext context;

    private ExecutorContext() {
    }

    public static <T> T bean(Class<T> type, Class<?>... configClasses) {
        return context(configClasses).getBean(type);
    }

    public static AnnotationConfigApplicationContext context(Class<?>... configClasses) {
        AnnotationConfigApplicationContext ctx = context;
        if (ctx == null) {
            synchronized (ExecutorContext.class) {
                ctx = context;
                if (ctx == null) {
                    ClassLoader previous = Thread.currentThread().getContextClassLoader();
                    ClassLoader jobLoader = configClasses.length > 0
                            ? configClasses[0].getClassLoader() : ExecutorContext.class.getClassLoader();
                    Thread.currentThread().setContextClassLoader(jobLoader);
                    try {
                        ctx = new AnnotationConfigApplicationContext(configClasses);
                        ctx.registerShutdownHook();
                        context = ctx;
                    } finally {
                        Thread.currentThread().setContextClassLoader(previous);
                    }
                }
            }
        }
        return ctx;
    }

    public static synchronized void close() {
        AnnotationConfigApplicationContext ctx = context;
        context = null;
        if (ctx != null) {
            ctx.close();
        }
    }
}
