package com.acme.datastore.internal;

import com.acme.datastore.DataStoreException;
import com.acme.datastore.annotation.Lookup;
import com.acme.datastore.annotation.Resolve;
import com.acme.datastore.config.DataStoreConfig.OnMissingTarget;
import com.acme.datastore.config.DataStoreConfig.StorageMode;
import com.acme.datastore.spi.KeyCodec;
import org.apache.fory.ThreadSafeFory;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.GenericArrayType;
import java.lang.reflect.Modifier;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.SortedSet;
import java.util.TreeSet;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Consumer;
import java.util.function.Function;

/**
 * <b>Internal, not API</b> (public only so the library's packages can share it): what the library knows
 * about each dataset's domain classes, built once at startup. Nothing here runs reflection per record.
 */
public final class Model {

    private static final Map<Class<?>, List<Field>> FIELDS = new ConcurrentHashMap<>();

    private Model() {
    }

    // ================================================================= per dataset

    /** One dataset: value class, key, id accessor, lookups, storage mode and codec. */
    public static final class Meta {
        public final String name;
        public final Class<?> valueType;
        public final KeyCodec<?> keys;
        public final StorageMode mode;
        public final Function<Object, Object> idReader;
        public final String idSource;
        public final boolean internal;
        public final List<Link> links = new ArrayList<>();
        public final List<Link> eager = new ArrayList<>();
        public final Map<String, Link> byName = new LinkedHashMap<>();
        /** Effective settings (dataset over dataset-defaults over built-in). */
        public OnMissingTarget onMissingTarget = OnMissingTarget.FAIL;
        public boolean requireComplete;
        public boolean localCache;
        public Resolve defaultPolicy = Resolve.LAZY;
        public ThreadSafeFory fory;
        private StripNode strip;

        public Meta(String name, Class<?> valueType, KeyCodec<?> keys, StorageMode mode, Function<Object, Object> idReader,
                    String idSource, boolean internal) {
            this.name = name;
            this.valueType = valueType;
            this.keys = keys;
            this.mode = mode;
            this.idReader = idReader;
            this.idSource = idSource;
            this.internal = internal;
        }

        public Object id(Object value) {
            Object id = idReader.apply(value);
            if (id == null) {
                throw new DataStoreException("Null id on " + valueType.getName() + " (dataset '" + name + "')");
            }
            return id;
        }

        /** Called once all links are final: precomputes the eager list and the strip plan. */
        public void seal() {
            for (Link l : links) {
                if (l.resolve == Resolve.EAGER) {
                    eager.add(l);
                }
            }
            if (mode == StorageMode.REFERENCE) {
                StripNode root = new StripNode();
                for (Link l : links) {
                    if (l.into != null) {
                        StripNode n = root;
                        for (Field step : l.path) {
                            n = n.children.computeIfAbsent(step, k -> new StripNode());
                        }
                        n.links.add(l);
                    }
                }
                strip = root.isEmpty() ? null : root;
            }
        }

        public byte[] encode(Object value) {
            if (!valueType.isInstance(value)) {
                throw new DataStoreException("Dataset '" + name + "' stores " + valueType.getName() + ", got "
                        + (value == null ? "null" : value.getClass().getName()));
            }
            return fory.serialize(strip == null ? value : copy(value, strip));
        }

        public Object decode(byte[] bytes) {
            return valueType.cast(fory.deserialize(bytes));
        }

        @Override
        public String toString() {
            return name;
        }
    }

    // ================================================================= lookups

    /** One relation: an id field (or id collection) somewhere inside a dataset's value. */
    public static final class Link {
        public final Meta owner;
        public final String name;
        public final List<Field> path;       // from the dataset value to the object holding the id field
        public final Field idField;
        public final Field into;             // may be null
        public final boolean many;
        public final String targetName;
        public final Class<?> targetType;    // annotation target = X.class (resolved to a dataset later)
        public final String source;
        public Resolve resolve;
        public Meta target;

        public Link(Meta owner, String name, List<Field> path, Field idField, Field into, String targetName,
             Class<?> targetType, Resolve resolve, String source) {
            this.owner = owner;
            this.name = name;
            this.path = List.copyOf(path);
            this.idField = idField;
            this.into = into;
            this.many = isCollection(idField.getGenericType());
            this.targetName = targetName;
            this.targetType = targetType;
            this.resolve = resolve;
            this.source = source;
        }

        public String fieldPath() {
            return pathString(path, idField.getName());
        }

        public String intoPath() {
            return into == null ? null : pathString(path, into.getName());
        }

        /** Every object holding this link's id field, reached from a dataset value. */
        public void owners(Object root, Consumer<Object> sink) {
            walk(root, 0, sink);
        }

        private void walk(Object obj, int i, Consumer<Object> sink) {
            if (obj == null) {
                return;
            }
            if (i == path.size()) {
                sink.accept(obj);
                return;
            }
            Object v = get(path.get(i), obj);
            if (v instanceof Collection<?> c) {
                for (Object e : c) {
                    walk(e, i + 1, sink);
                }
            } else if (v instanceof Map<?, ?> m) {
                for (Object e : m.values()) {
                    walk(e, i + 1, sink);
                }
            } else {
                walk(v, i + 1, sink);
            }
        }

        /** Feeds the non-null ids held by {@code holder}. */
        public void ids(Object holder, Consumer<Object> sink) {
            Object v = get(idField, holder);
            if (v == null) {
                return;
            }
            if (many) {
                for (Object id : (Collection<?>) v) {
                    if (id != null) {
                        sink.accept(id);
                    }
                }
            } else {
                sink.accept(v);
            }
        }

        /** Sets the into field of {@code holder} from resolved targets. */
        public void hydrate(Object holder, Map<Object, Object> byId) {
            if (into == null) {
                return;
            }
            Object v = get(idField, holder);
            if (v == null) {
                set(into, holder, null);
                return;
            }
            if (many) {
                Collection<Object> out = newCollection(into.getType(), null);
                for (Object id : (Collection<?>) v) {
                    Object t = present(byId.get(id));
                    if (t != null) {
                        out.add(t);
                    }
                }
                set(into, holder, out);
            } else {
                set(into, holder, present(byId.get(v)));
            }
        }

        /** Value of this lookup for one holder: the target, or a List of targets. */
        public Object valueFor(Object holder, Map<Object, Object> byId) {
            Object v = get(idField, holder);
            if (v == null) {
                return null;
            }
            if (!many) {
                return present(byId.get(v));
            }
            List<Object> out = new ArrayList<>();
            for (Object id : (Collection<?>) v) {
                Object t = present(byId.get(id));
                if (t != null) {
                    out.add(t);
                }
            }
            return out;
        }

        /** On save (REFERENCE): fill an empty id from the into object(s); fail if both are set and differ. */
        public void fillIdFromInto(Object copy) {
            Object targetObj = get(into, copy);
            if (targetObj == null) {
                return;
            }
            Object current = get(idField, copy);
            if (many) {
                List<Object> ids = new ArrayList<>();
                for (Object t : (Collection<?>) targetObj) {
                    if (t != null) {
                        ids.add(target.id(t));
                    }
                }
                if (current == null || ((Collection<?>) current).isEmpty()) {
                    Collection<Object> c = newCollection(idField.getType(), null);
                    c.addAll(ids);
                    set(idField, copy, c);
                } else if (!new ArrayList<>((Collection<?>) current).equals(ids)) {
                    throw mismatch(current, ids);
                }
            } else {
                Object id = target.id(targetObj);
                if (current == null || (idField.getType().isPrimitive() && isDefault(current))) {
                    set(idField, copy, id);
                } else if (!current.equals(id)) {
                    throw mismatch(current, id);
                }
            }
        }

        private DataStoreException mismatch(Object id, Object fromInto) {
            return new DataStoreException("Dataset '" + owner.name + "': " + fieldPath() + " = " + id + " but "
                    + intoPath() + " has id " + fromInto);
        }

        @Override
        public String toString() {
            return owner.name + "." + fieldPath() + " -> " + (target == null ? targetName : target.name)
                    + (into == null ? "" : " (into " + intoPath() + ")") + " " + resolve + " [" + source + "]";
        }
    }

    /** Marks an id that was asked for but not found (MissingPolicy.NULL). */
    public static final Object MISSING = new Object();

    public static Object present(Object o) {
        return o == MISSING ? null : o;
    }

    // ================================================================= strip copy (REFERENCE writes)

    private static final class StripNode {
        final Map<Field, StripNode> children = new LinkedHashMap<>();
        final List<Link> links = new ArrayList<>();

        boolean isEmpty() {
            return links.isEmpty() && children.values().stream().allMatch(StripNode::isEmpty);
        }
    }

    /** Copies along the paths that hold into fields, leaving them out; the caller's object is untouched. */
    private static Object copy(Object obj, StripNode node) {
        Object c = shallowCopy(obj);
        for (Link l : node.links) {
            l.fillIdFromInto(c);
            set(l.into, c, null);
        }
        for (Map.Entry<Field, StripNode> e : node.children.entrySet()) {
            Object v = get(e.getKey(), c);
            if (v != null) {
                set(e.getKey(), c, copyContainer(v, e.getValue(), e.getKey().getType()));
            }
        }
        return c;
    }

    @SuppressWarnings("unchecked")
    private static Object copyContainer(Object v, StripNode node, Class<?> declared) {
        if (v instanceof Collection<?> col) {
            Collection<Object> out = newCollection(declared, col);
            for (Object e : col) {
                out.add(e == null ? null : copy(e, node));
            }
            return out;
        }
        if (v instanceof Map<?, ?> map) {
            Map<Object, Object> out = newMap(map);
            for (Map.Entry<?, ?> e : map.entrySet()) {
                out.put(e.getKey(), e.getValue() == null ? null : copy(e.getValue(), node));
            }
            return out;
        }
        return copy(v, node);
    }

    private static Object shallowCopy(Object obj) {
        try {
            Constructor<?> ctor = noArgConstructor(obj.getClass());
            Object c = ctor.newInstance();
            for (Field f : fields(obj.getClass())) {
                f.set(c, f.get(obj));
            }
            return c;
        } catch (ReflectiveOperationException e) {
            throw new DataStoreException("Cannot copy " + obj.getClass().getName(), e);
        }
    }

    // ================================================================= reflection helpers

    /** Instance fields incl. superclasses (transient included: they are copied, never stored by Fory). */
    public static List<Field> fields(Class<?> type) {
        return FIELDS.computeIfAbsent(type, t -> {
            List<Field> out = new ArrayList<>();
            for (Class<?> c = t; c != null && c != Object.class; c = c.getSuperclass()) {
                for (Field f : c.getDeclaredFields()) {
                    if (!Modifier.isStatic(f.getModifiers()) && !f.isSynthetic()) {
                        f.setAccessible(true);
                        out.add(f);
                    }
                }
            }
            return List.copyOf(out);
        });
    }

    public static Field field(Class<?> type, String name) {
        for (Field f : fields(type)) {
            if (f.getName().equals(name)) {
                return f;
            }
        }
        return null;
    }

    public static Field requireField(Class<?> type, String name, String where) {
        Field f = field(type, name);
        if (f == null) {
            throw new DataStoreException(where + ": " + type.getSimpleName() + " has no field '" + name + "' (fields: "
                    + fields(type).stream().map(Field::getName).toList() + ")");
        }
        return f;
    }

    public static Object get(Field f, Object o) {
        try {
            return f.get(o);
        } catch (IllegalAccessException e) {
            throw new DataStoreException("Cannot read " + f, e);
        }
    }

    public static void set(Field f, Object o, Object v) {
        try {
            f.set(o, v);
        } catch (IllegalAccessException e) {
            throw new DataStoreException("Cannot write " + f, e);
        }
    }

    public static Constructor<?> noArgConstructor(Class<?> c) throws NoSuchMethodException {
        Constructor<?> ctor = c.getDeclaredConstructor();
        ctor.setAccessible(true);
        return ctor;
    }

    public static boolean hasNoArgConstructor(Class<?> c) {
        try {
            noArgConstructor(c);
            return true;
        } catch (NoSuchMethodException | RuntimeException e) {
            return false;
        }
    }

    public static boolean isDomainClass(Class<?> c) {
        if (c == null || c.isPrimitive() || c.isArray()) {
            return false;
        }
        String n = c.getName();
        return !(n.startsWith("java.") || n.startsWith("javax.") || n.startsWith("jdk.") || n.startsWith("sun."));
    }

    public static boolean isCollection(Type t) {
        Class<?> raw = raw(t);
        return raw != null && Collection.class.isAssignableFrom(raw);
    }

    public static Class<?> raw(Type t) {
        if (t instanceof Class<?> c) {
            return c;
        }
        if (t instanceof ParameterizedType p) {
            return raw(p.getRawType());
        }
        if (t instanceof GenericArrayType g) {
            Class<?> comp = raw(g.getGenericComponentType());
            return comp == null ? null : comp.arrayType();
        }
        return null;
    }

    /** Element class for Collection&lt;E&gt;, value class for Map&lt;K,V&gt;, else the raw class. */
    public static Class<?> elementType(Type t) {
        Class<?> raw = raw(t);
        if (raw == null) {
            return null;
        }
        if (Collection.class.isAssignableFrom(raw)) {
            return t instanceof ParameterizedType p ? raw(p.getActualTypeArguments()[0]) : null;
        }
        if (Map.class.isAssignableFrom(raw)) {
            return t instanceof ParameterizedType p ? raw(p.getActualTypeArguments()[1]) : null;
        }
        return raw;
    }

    public static Class<?> box(Class<?> c) {
        if (!c.isPrimitive()) return c;
        if (c == long.class) return Long.class;
        if (c == int.class) return Integer.class;
        if (c == short.class) return Short.class;
        if (c == byte.class) return Byte.class;
        if (c == boolean.class) return Boolean.class;
        if (c == char.class) return Character.class;
        if (c == double.class) return Double.class;
        if (c == float.class) return Float.class;
        return c;
    }

    public static boolean isDefault(Object v) {
        return (v instanceof Number n && n.longValue() == 0 && n.doubleValue() == 0)
                || Boolean.FALSE.equals(v) || Character.valueOf('\0').equals(v);
    }

    @SuppressWarnings("unchecked")
    public static Collection<Object> newCollection(Class<?> declared, Collection<?> like) {
        if (like != null) {
            try {
                return (Collection<Object>) noArgConstructor(like.getClass()).newInstance();
            } catch (ReflectiveOperationException | RuntimeException ignored) {
                // immutable / unusual collection: fall back by declared type
            }
        }
        if (!declared.isInterface() && Collection.class.isAssignableFrom(declared)) {
            try {
                return (Collection<Object>) noArgConstructor(declared).newInstance();
            } catch (ReflectiveOperationException | RuntimeException ignored) {
                // fall through
            }
        }
        if (SortedSet.class.isAssignableFrom(declared)) {
            return new TreeSet<>();
        }
        if (Set.class.isAssignableFrom(declared)) {
            return new LinkedHashSet<>();
        }
        return new ArrayList<>();
    }

    @SuppressWarnings("unchecked")
    private static Map<Object, Object> newMap(Map<?, ?> like) {
        try {
            return (Map<Object, Object>) noArgConstructor(like.getClass()).newInstance();
        } catch (ReflectiveOperationException | RuntimeException e) {
            return new LinkedHashMap<>();
        }
    }

    public static String pathString(List<Field> path, String last) {
        StringBuilder b = new StringBuilder();
        for (Field f : path) {
            b.append(f.getName()).append('.');
        }
        return b.append(last).toString();
    }

    /** Every domain class reachable from {@code roots} (fields, collections, maps, arrays). For codec registration. */
    public static Set<Class<?>> reachable(Collection<Class<?>> roots) {
        Set<Class<?>> seen = new LinkedHashSet<>();
        for (Class<?> r : roots) {
            collect(r, seen);
        }
        return seen;
    }

    private static void collect(Type t, Set<Class<?>> seen) {
        if (t instanceof ParameterizedType p) {
            for (Type a : p.getActualTypeArguments()) {
                collect(a, seen);
            }
            collect(p.getRawType(), seen);
            return;
        }
        if (t instanceof GenericArrayType g) {
            collect(g.getGenericComponentType(), seen);
            return;
        }
        if (!(t instanceof Class<?> c)) {
            return;
        }
        if (c.isArray()) {
            collect(c.getComponentType(), seen);
            return;
        }
        if (!isDomainClass(c) || !seen.add(c) || c.isEnum()) {
            return;
        }
        for (Field f : fields(c)) {
            if (!Modifier.isTransient(f.getModifiers())) {
                collect(f.getGenericType(), seen);
            }
        }
    }

    /** Fields annotated with {@link Lookup} anywhere inside {@code root}, with their paths. */
    public static void annotatedLookups(Class<?> root, Consumer<AnnotatedLookup> sink) {
        scan(root, new ArrayList<>(), new HashSet<>(), sink);
    }

    public record AnnotatedLookup(List<Field> path, Field idField, Lookup annotation) {
    }

    private static void scan(Class<?> c, List<Field> path, Set<Class<?>> visiting, Consumer<AnnotatedLookup> sink) {
        if (!visiting.add(c)) {
            return;
        }
        Set<String> intoNames = new HashSet<>();
        for (Field f : fields(c)) {
            Lookup l = f.getAnnotation(Lookup.class);
            if (l != null) {
                sink.accept(new AnnotatedLookup(path, f, l));
                if (!l.into().isEmpty()) {
                    intoNames.add(l.into());
                }
            }
        }
        for (Field f : fields(c)) {
            if (f.isAnnotationPresent(Lookup.class) || intoNames.contains(f.getName())
                    || Modifier.isTransient(f.getModifiers())) {
                continue;
            }
            Class<?> e = elementType(f.getGenericType());
            if (e != null && isDomainClass(e) && !e.isEnum() && !e.isInterface()) {
                List<Field> next = new ArrayList<>(path);
                next.add(f);
                scan(e, next, visiting, sink);
            }
        }
        visiting.remove(c);
    }
}
