package com.acme.datastore;

import com.acme.datastore.annotation.Id;
import com.acme.datastore.annotation.Resolve;

import java.lang.management.ManagementFactory;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.stream.Stream;

/**
 * Status of each dataset in the current partition. A job marks its output {@code COMPLETE} as its last
 * step; downstream jobs call {@link #requireComplete} before reading. This is the commit point between jobs.
 */
public final class Manifest {

    /** Internal dataset holding the manifest. */
    public static final String DATASET = "_manifest";
    private static final String WRITER = ManagementFactory.getRuntimeMXBean().getName();

    public enum Status { CREATED, LOADING, COMPLETE, FAILED }

    /** One dataset's status. */
    public static final class Entry {
        @Id
        private String dataset;
        private Status status;
        private long recordCount;
        private long updatedAtMillis;
        private String updatedBy;

        @SuppressWarnings("unused")
        private Entry() {
        }

        Entry(String dataset, Status status, long recordCount) {
            this.dataset = dataset;
            this.status = status;
            this.recordCount = recordCount;
            this.updatedAtMillis = System.currentTimeMillis();
            this.updatedBy = WRITER;
        }

        public String dataset() {
            return dataset;
        }

        public Status status() {
            return status;
        }

        public long recordCount() {
            return recordCount;
        }

        public Instant updatedAt() {
            return Instant.ofEpochMilli(updatedAtMillis);
        }

        public String updatedBy() {
            return updatedBy;
        }

        @Override
        public String toString() {
            return dataset + "=" + status + " (" + recordCount + " records, " + updatedAt() + ", " + updatedBy + ")";
        }
    }

    private final DataStore store;

    Manifest(DataStore store) {
        this.store = store;
    }

    private Dao<Entry, String> entries() {
        return store.dao(DATASET);
    }

    public Optional<Entry> get(String dataset) {
        return entries().findById(dataset, Resolve.LAZY);
    }

    /** Null if the dataset was never created in this partition. */
    public Status status(String dataset) {
        return get(dataset).map(Entry::status).orElse(null);
    }

    public boolean isComplete(String dataset) {
        return status(dataset) == Status.COMPLETE;
    }

    public void mark(String dataset, Status status) {
        store.meta(dataset);
        long count = status == Status.COMPLETE ? store.dao(dataset).count() : 0L;
        entries().save(new Entry(dataset, status, count));
    }

    public void loading(String dataset) {
        mark(dataset, Status.LOADING);
    }

    /** COMPLETE, with the dataset's current record count. */
    public void complete(String dataset) {
        mark(dataset, Status.COMPLETE);
    }

    public void failed(String dataset) {
        mark(dataset, Status.FAILED);
    }

    public void loading(Class<?> type) {
        loading(store.datasetOf(type));
    }

    public void complete(Class<?> type) {
        complete(store.datasetOf(type));
    }

    public void failed(Class<?> type) {
        failed(store.datasetOf(type));
    }

    /** @throws DataStoreException listing every dataset that is not COMPLETE */
    public void requireComplete(String... datasets) {
        List<String> notReady = new ArrayList<>();
        for (String ds : datasets) {
            Status s = status(ds);
            if (s != Status.COMPLETE) {
                notReady.add(ds + "=" + (s == null ? "NOT_CREATED" : s));
            }
        }
        if (!notReady.isEmpty()) {
            throw new DataStoreException("Inputs not ready in partition " + store.partition() + ": " + notReady);
        }
    }

    public void requireComplete(Class<?>... types) {
        requireComplete(Stream.of(types).map(store::datasetOf).toArray(String[]::new));
    }

    public List<Entry> all() {
        try (Stream<Entry> s = entries().streamAll(Resolve.LAZY)) {
            return s.sorted(Comparator.comparing(Entry::dataset)).toList();
        }
    }
}
