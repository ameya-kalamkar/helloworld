package com.acme.datastore.spring;

import com.acme.datastore.DataStore;
import com.acme.datastore.DataStoreException;
import com.acme.datastore.lookup.LookupResolver;
import com.acme.datastore.Manifest;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;

/**
 * Plain Spring wiring (no Spring Boot):
 *
 * <pre>{@code
 * @Configuration
 * @Import(DataStoreConfiguration.class)
 * @PropertySource("classpath:app.properties")    // datastore.config=classpath:datastore.yml (or .json)
 * class AppConfig { }
 * }</pre>
 *
 * {@code ${...}} placeholders in the file resolve through the Spring {@link Environment}. Optional
 * properties {@code datastore.store-type} and {@code datastore.partition} override the file (handy in tests).
 */
@Configuration(proxyBeanMethods = false)
public class DataStoreConfiguration {

    public static final String CONFIG_PROPERTY = "datastore.config";
    public static final String DEFAULT_LOCATION = "classpath:datastore.yml";

    @Bean(destroyMethod = "close")
    public DataStore dataStore(Environment environment, ResourceLoader resourceLoader) {
        String location = environment.resolveRequiredPlaceholders(
                environment.getProperty(CONFIG_PROPERTY, DEFAULT_LOCATION));
        Resource resource = resourceLoader.getResource(location);
        String text;
        try (InputStream in = resource.getInputStream()) {
            text = new String(in.readAllBytes(), StandardCharsets.UTF_8);
        } catch (IOException e) {
            throw new DataStoreException("Cannot read data-store config " + location
                    + " (set the '" + CONFIG_PROPERTY + "' property)", e);
        }
        DataStore.Builder b = DataStore.builder()
                .configText(text, location)
                .placeholders(environment::resolveRequiredPlaceholders)
                .classLoader(resourceLoader.getClassLoader());
        String storeType = environment.getProperty("datastore.store-type", (String) null);
        if (storeType != null) {
            b.storeType(storeType);
        }
        String partition = environment.getProperty("datastore.partition", (String) null);
        if (partition != null) {
            b.partition(partition);
        }
        return b.build();
    }

    @Bean
    public LookupResolver lookupResolver(DataStore dataStore) {
        return dataStore.lookups();
    }

    @Bean
    public Manifest manifest(DataStore dataStore) {
        return dataStore.manifest();
    }
}
