package com.acme.datastore.config;

import com.acme.datastore.DataStoreException;
import com.acme.datastore.annotation.Resolve;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import tools.jackson.core.JacksonException;
import tools.jackson.databind.DeserializationFeature;
import tools.jackson.databind.JsonNode;
import tools.jackson.databind.PropertyNamingStrategies;
import tools.jackson.dataformat.yaml.YAMLMapper;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * The {@code datastore:} block, from YAML or JSON (same structure; JSON is read by the YAML parser).
 * Keys are kebab-case.
 *
 * <pre>
 * datastore:
 *   store-type: chronicle            # memory (default) | chronicle | ignite | com.acme.MyStore   (whole store)
 *   namespace: risk-eod              #                                                              (whole store)
 *   partition:                       # parts joined with "_" → NA_20261018                         (whole store)
 *     parts: { region: "${REGION}", business-date: "${RUN_DATE}" }
 *   lookup-resolver: { parallelism: 4, page-size: 1000, max-depth: 0 }                           (whole store)
 *   chronicle: { base-dir: /dev/shm/grid }                       # store-level settings of the active store
 *
 *   dataset-defaults:                # anything a dataset can set; each dataset overrides field by field
 *     storage-mode: REFERENCE
 *     lookup-resolve-policy: LAZY
 *     on-missing-target: FAIL
 *     require-complete: true
 *     splits: 8
 *     local-cache: false
 *     chronicle: { entries: 1000000, avg-value-bytes: 256 }   # nested store blocks merge per field
 *
 *   datasets:
 *     order:
 *       value: com.acme.Order
 *       id: orderId                  # or [tradeId, legNo] with key:, or @Id on a field
 *       lookups:
 *         - { field: customerId, target: customer, into: customer, lookup-resolve-policy: EAGER }
 * </pre>
 *
 * Store blocks: only the active store's blocks are validated (strictly); blocks of other installed stores
 * are ignored, so switching {@code store-type} is a one-line change. The same classes double as a
 * programmatic builder for tests: {@code DataStore.builder().namespace("t").partition("P1").dataset(...)}.
 */
public final class DataStoreConfig {

    public enum StorageMode {
        /** Store lookup ids only; {@code into} fields are left out on write and filled on resolve. */
        REFERENCE,
        /** Store the complete object graph as given. */
        EMBEDDED
    }

    public enum OnMissingTarget {
        /** A lookup id without a target object fails the read (usually an upstream job did not finish). */
        FAIL,
        /** Missing targets resolve to null. */
        NULL
    }

    private String storeType = "memory";
    private String namespace;
    private PartitionConfig partition = new PartitionConfig();
    private LookupResolverConfig lookupResolver = new LookupResolverConfig();
    private List<String> extraClasses = new ArrayList<>();
    private DatasetConfig datasetDefaults = new DatasetConfig();
    private Map<String, DatasetConfig> datasets = new LinkedHashMap<>();
    private final Map<String, Object> storeBlocks = new LinkedHashMap<>();

    @JsonAnySetter
    public void setStoreBlock(String name, Object value) {
        storeBlocks.put(name, value);
    }

    /** Store-level blocks, by store name. */
    public Map<String, Object> getStoreBlocks() {
        return storeBlocks;
    }

    public String getStoreType() {
        return storeType;
    }

    public void setStoreType(String storeType) {
        this.storeType = storeType;
    }

    public String getNamespace() {
        return namespace;
    }

    public void setNamespace(String namespace) {
        this.namespace = namespace;
    }

    public PartitionConfig getPartition() {
        return partition;
    }

    public void setPartition(PartitionConfig partition) {
        this.partition = partition == null ? new PartitionConfig() : partition;
    }

    public LookupResolverConfig getLookupResolver() {
        return lookupResolver;
    }

    public void setLookupResolver(LookupResolverConfig lookupResolver) {
        this.lookupResolver = lookupResolver == null ? new LookupResolverConfig() : lookupResolver;
    }

    /** Classes the codec must know that are not reachable from dataset value classes (e.g. subclasses). */
    public List<String> getExtraClasses() {
        return extraClasses;
    }

    public void setExtraClasses(List<String> extraClasses) {
        this.extraClasses = extraClasses == null ? new ArrayList<>() : new ArrayList<>(extraClasses);
    }

    public DatasetConfig getDatasetDefaults() {
        return datasetDefaults;
    }

    public void setDatasetDefaults(DatasetConfig datasetDefaults) {
        this.datasetDefaults = datasetDefaults == null ? new DatasetConfig() : datasetDefaults;
    }

    public Map<String, DatasetConfig> getDatasets() {
        return datasets;
    }

    public void setDatasets(Map<String, DatasetConfig> datasets) {
        this.datasets = datasets == null ? new LinkedHashMap<>() : new LinkedHashMap<>(datasets);
    }

    /** {@code partition:} — named parts joined with {@code _} in declaration order. */
    public static final class PartitionConfig {
        private Map<String, String> parts = new LinkedHashMap<>();

        public Map<String, String> getParts() {
            return parts;
        }

        public void setParts(Map<String, String> parts) {
            this.parts = parts == null ? new LinkedHashMap<>() : new LinkedHashMap<>(parts);
        }
    }

    /** {@code lookup-resolver:} — the resolver engine, one per store. */
    public static final class LookupResolverConfig {
        private int parallelism = 4;
        private int pageSize = 1000;
        private int maxDepth;
        private int singleReadWarn = 10_000;

        /** Target datasets fetched in parallel per level. */
        public int getParallelism() {
            return parallelism;
        }

        public void setParallelism(int parallelism) {
            this.parallelism = parallelism;
        }

        /** Page size used when streaming with EAGER lookups. */
        public int getPageSize() {
            return pageSize;
        }

        public void setPageSize(int pageSize) {
            this.pageSize = pageSize;
        }

        /** 0 = unlimited (full graph). */
        public int getMaxDepth() {
            return maxDepth;
        }

        public void setMaxDepth(int maxDepth) {
            this.maxDepth = maxDepth;
        }

        /** Warn once per dataset after this many single findById calls that resolve EAGER lookups (0 = off). */
        public int getSingleReadWarn() {
            return singleReadWarn;
        }

        public void setSingleReadWarn(int singleReadWarn) {
            this.singleReadWarn = singleReadWarn;
        }
    }

    /**
     * One entry under {@code datasets:}, and also {@code dataset-defaults:}. Unset fields (null) inherit
     * from {@code dataset-defaults}, then from the built-in default. {@code value}, {@code key}, {@code id}
     * and {@code lookups} belong to one dataset and cannot be set in the defaults.
     */
    public static final class DatasetConfig {
        private String key;
        private String value;
        private Object id;
        private StorageMode storageMode;
        private Resolve lookupResolvePolicy;
        private OnMissingTarget onMissingTarget;
        private Boolean requireComplete;
        private Integer splits;
        private Boolean localCache;
        private List<LookupConfig> lookups = new ArrayList<>();
        private final Map<String, Object> storeBlocks = new LinkedHashMap<>();

        @JsonAnySetter
        public void setStoreBlock(String name, Object value) {
            storeBlocks.put(name, value);
        }

        public Map<String, Object> getStoreBlocks() {
            return storeBlocks;
        }

        /** Key class; optional when the id is a single field (inferred from its type). */
        public String getKey() {
            return key;
        }

        public void setKey(String key) {
            this.key = key;
        }

        public String getValue() {
            return value;
        }

        public void setValue(String value) {
            this.value = value;
        }

        /** {@code "field"} or {@code ["f1", "f2"]} (composite key built from fields); null = use {@code @Id}. */
        public Object getId() {
            return id;
        }

        public void setId(Object id) {
            this.id = id;
        }

        /** Built-in default REFERENCE. */
        public StorageMode getStorageMode() {
            return storageMode;
        }

        public void setStorageMode(StorageMode storageMode) {
            this.storageMode = storageMode;
        }

        /** Default policy for this dataset's lookups; built-in default LAZY. */
        public Resolve getLookupResolvePolicy() {
            return lookupResolvePolicy;
        }

        public void setLookupResolvePolicy(Resolve lookupResolvePolicy) {
            this.lookupResolvePolicy = lookupResolvePolicy;
        }

        /** Applies when this dataset is the <b>target</b> of a lookup; built-in default FAIL. */
        public OnMissingTarget getOnMissingTarget() {
            return onMissingTarget;
        }

        public void setOnMissingTarget(OnMissingTarget onMissingTarget) {
            this.onMissingTarget = onMissingTarget;
        }

        /** Refuse to resolve lookups into this dataset unless its manifest says COMPLETE; built-in default false. */
        public Boolean getRequireComplete() {
            return requireComplete;
        }

        public void setRequireComplete(Boolean requireComplete) {
            this.requireComplete = requireComplete;
        }

        /** Parallel scan splits; unset = the store's default. */
        public Integer getSplits() {
            return splits;
        }

        public void setSplits(Integer splits) {
            this.splits = splits;
        }

        /** Per-JVM cache (unbounded ConcurrentHashMap) of encoded values; built-in default false. */
        public Boolean getLocalCache() {
            return localCache;
        }

        public void setLocalCache(Boolean localCache) {
            this.localCache = localCache;
        }

        public List<LookupConfig> getLookups() {
            return lookups;
        }

        public void setLookups(List<LookupConfig> lookups) {
            this.lookups = lookups == null ? new ArrayList<>() : new ArrayList<>(lookups);
        }

        /** This dataset's settings with every unset field taken from {@code defaults} (store blocks merged per field). */
        public DatasetConfig over(DatasetConfig defaults) {
            DatasetConfig e = new DatasetConfig();
            e.key = key;
            e.value = value;
            e.id = id;
            e.lookups = lookups;
            e.storageMode = storageMode != null ? storageMode : defaults.storageMode;
            e.lookupResolvePolicy = lookupResolvePolicy != null ? lookupResolvePolicy : defaults.lookupResolvePolicy;
            e.onMissingTarget = onMissingTarget != null ? onMissingTarget : defaults.onMissingTarget;
            e.requireComplete = requireComplete != null ? requireComplete : defaults.requireComplete;
            e.splits = splits != null ? splits : defaults.splits;
            e.localCache = localCache != null ? localCache : defaults.localCache;
            e.storeBlocks.putAll(defaults.storeBlocks);
            storeBlocks.forEach((store, block) -> e.storeBlocks.merge(store, block, DataStoreConfig::mergeBlocks));
            return e;
        }

        // ---- fluent helpers for programmatic configuration (tests) ----

        public DatasetConfig key(Class<?> keyClass) {
            this.key = keyClass.getName();
            return this;
        }

        public DatasetConfig id(String... fields) {
            this.id = fields.length == 1 ? fields[0] : List.of(fields);
            return this;
        }

        public DatasetConfig storageMode(StorageMode mode) {
            this.storageMode = mode;
            return this;
        }

        public DatasetConfig onMissingTarget(OnMissingTarget policy) {
            this.onMissingTarget = policy;
            return this;
        }

        public DatasetConfig splits(int splits) {
            this.splits = splits;
            return this;
        }

        public DatasetConfig localCache() {
            this.localCache = true;
            return this;
        }

        public DatasetConfig lookup(String field, String target, String into, Resolve policy) {
            LookupConfig l = new LookupConfig();
            l.setField(field);
            l.setTarget(target);
            l.setInto(into);
            l.setLookupResolvePolicy(policy);
            lookups.add(l);
            return this;
        }

        /** Store-specific dataset settings, e.g. {@code store("chronicle", Map.of("entries", 1000, ...))}. */
        public DatasetConfig store(String storeName, Map<String, ?> settings) {
            storeBlocks.put(storeName, new LinkedHashMap<>(settings));
            return this;
        }
    }

    /** One entry of a dataset's {@code lookups:}. */
    public static final class LookupConfig {
        private String field;
        private String target;
        private String into;
        private String name;
        private Resolve lookupResolvePolicy = Resolve.DEFAULT;

        /** Path to the id field from the dataset's value, e.g. {@code customerId} or {@code lines.sku}. */
        public String getField() {
            return field;
        }

        public void setField(String field) {
            this.field = field;
        }

        /** Target dataset name. */
        public String getTarget() {
            return target;
        }

        public void setTarget(String target) {
            this.target = target;
        }

        /** Sibling field receiving the resolved object(s): {@code customer} or full path {@code lines.product}. */
        public String getInto() {
            return into;
        }

        public void setInto(String into) {
            this.into = into;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public Resolve getLookupResolvePolicy() {
            return lookupResolvePolicy;
        }

        public void setLookupResolvePolicy(Resolve lookupResolvePolicy) {
            this.lookupResolvePolicy = lookupResolvePolicy == null ? Resolve.DEFAULT : lookupResolvePolicy;
        }
    }

    // ---------------------------------------------------------------- parsing

    private static final YAMLMapper MAPPER = YAMLMapper.builder()
            .propertyNamingStrategy(PropertyNamingStrategies.KEBAB_CASE)
            .enable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES)
            .build();

    /** Parses YAML or JSON text (placeholders already resolved) and binds its {@code datastore} block. */
    public static DataStoreConfig parse(String text, String source) {
        try {
            JsonNode root = MAPPER.readTree(text);
            JsonNode block = root == null ? null : root.get("datastore");
            if (block == null || block.isNull()) {
                throw new DataStoreException("No 'datastore' block in " + source);
            }
            return MAPPER.treeToValue(block, DataStoreConfig.class);
        } catch (JacksonException e) {
            throw new DataStoreException("Invalid data-store config in " + source + ": " + e.getOriginalMessage(), e);
        }
    }

    /** Binds a store-specific block (already parsed into maps/lists) to that store's settings class. */
    public static <T> T bind(Object raw, Class<T> type, String path) {
        try {
            return MAPPER.convertValue(raw == null ? Map.of() : raw, type);
        } catch (JacksonException e) {
            throw new DataStoreException("Invalid '" + path + "': " + e.getOriginalMessage(), e);
        }
    }

    /** Field-by-field merge of two store blocks (maps merge recursively; the dataset's value wins). */
    @SuppressWarnings("unchecked")
    static Object mergeBlocks(Object defaults, Object overrides) {
        if (defaults instanceof Map<?, ?> d && overrides instanceof Map<?, ?> o) {
            Map<String, Object> out = new LinkedHashMap<>((Map<String, Object>) d);
            ((Map<String, Object>) o).forEach((k, v) -> out.merge(k, v, DataStoreConfig::mergeBlocks));
            return out;
        }
        return overrides;
    }
}
