package com.acme.datastore.store;

import com.acme.datastore.DataStoreException;
import com.acme.datastore.spi.DatasetSpec;
import com.acme.datastore.spi.KeyCodec;
import com.acme.datastore.spi.Store;
import com.acme.datastore.spi.StoreMap;

import java.util.AbstractMap;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeSet;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Stream;

/**
 * {@code store-type: memory} (the default) — one {@link ConcurrentHashMap} per dataset per partition, shared by
 * everything in this JVM. For unit tests, local runs and single-JVM pipelines; it cannot share data
 * between JVMs. Values are the encoded bytes, so every read decodes a fresh copy, like the real stores.
 *
 * <p>Also the reference implementation to read when writing a custom {@link Store}.
 */
public final class MemoryStore implements Store {

    /** namespace/partition/dataset → map; JVM-wide so several DataStore instances share data. */
    private static final Map<String, ConcurrentHashMap<Object, byte[]>> DATA = new ConcurrentHashMap<>();

    private String namespace;

    @Override
    public String name() {
        return "memory";
    }

    @Override
    public void init(String namespace, Object settings, Collection<DatasetSpec<?>> datasets) {
        this.namespace = namespace;
    }

    @Override
    @SuppressWarnings("unchecked")
    public <K> StoreMap<K> open(DatasetSpec<K> dataset, String partition, boolean create) {
        String key = namespace + "/" + partition + "/" + dataset.name();
        ConcurrentHashMap<Object, byte[]> map = create
                ? DATA.computeIfAbsent(key, k -> new ConcurrentHashMap<>())
                : DATA.get(key);
        if (map == null) {
            throw new DataStoreException("Dataset '" + dataset.name() + "' does not exist in partition " + partition
                    + " (run createAll() first)");
        }
        int splits = dataset.splits() > 0 ? dataset.splits() : 1;
        return new MemoryMap<>((ConcurrentHashMap<K, byte[]>) (ConcurrentHashMap<?, ?>) map, dataset.keyCodec(), splits);
    }

    @Override
    public List<String> partitions() {
        TreeSet<String> out = new TreeSet<>();
        String prefix = namespace + "/";
        for (String k : DATA.keySet()) {
            if (k.startsWith(prefix)) {
                out.add(k.substring(prefix.length(), k.indexOf('/', prefix.length())));
            }
        }
        return List.copyOf(out);
    }

    @Override
    public void destroy(String partition) {
        String prefix = namespace + "/" + partition + "/";
        DATA.keySet().removeIf(k -> k.startsWith(prefix));
    }

    @Override
    public void close() {
        // data stays for other DataStore instances in this JVM
    }

    private static final class MemoryMap<K> implements StoreMap<K> {
        private final ConcurrentHashMap<K, byte[]> map;
        private final KeyCodec<K> keys;
        private final int splits;

        MemoryMap(ConcurrentHashMap<K, byte[]> map, KeyCodec<K> keys, int splits) {
            this.map = map;
            this.keys = keys;
            this.splits = splits;
        }

        @Override
        public byte[] get(K key) {
            return map.get(key);
        }

        @Override
        public Map<K, byte[]> getAll(Collection<K> ks) {
            Map<K, byte[]> out = new HashMap<>(ks.size() * 2);
            for (K k : ks) {
                byte[] v = map.get(k);
                if (v != null) {
                    out.put(k, v);
                }
            }
            return out;
        }

        @Override
        public void put(K key, byte[] value) {
            map.put(key, value);
        }

        @Override
        public void putAll(Map<K, byte[]> entries) {
            map.putAll(entries);
        }

        @Override
        public boolean remove(K key) {
            return map.remove(key) != null;
        }

        @Override
        public long size() {
            return map.size();
        }

        @Override
        public int splits() {
            return splits;
        }

        @Override
        public Stream<Map.Entry<K, byte[]>> scan(int split) {
            if (split < 0 || split >= splits) {
                throw new IndexOutOfBoundsException("split " + split + " of " + splits);
            }
            return map.entrySet().stream()
                    .filter(e -> keys.split(e.getKey(), splits) == split)
                    .map(e -> new AbstractMap.SimpleImmutableEntry<>(e.getKey(), e.getValue()));
        }

        @Override
        public void clear() {
            map.clear();
        }

        @Override
        public void close() {
            // nothing held
        }
    }
}
