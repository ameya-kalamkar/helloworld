package com.acme.datastore.spi;

import com.acme.datastore.DataStoreException;

import java.io.IOException;
import java.nio.channels.FileChannel;
import java.nio.channels.FileLock;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.HashMap;
import java.util.Map;

/**
 * Cross-process partition locks from OS file locks, for stores whose data lives on one host
 * (see {@link Store#lock}). Shared locks are reference-counted per JVM, because the JDK refuses
 * overlapping {@link FileLock}s from the same process.
 */
public final class FileLocks {

    private static final Map<Path, Held> HELD = new HashMap<>();

    private FileLocks() {
    }

    /** Shared locks wait; an exclusive lock never waits and returns null when the file is in use. */
    public static synchronized AutoCloseable acquire(Path lockFile, boolean exclusive) {
        Path key = lockFile.toAbsolutePath().normalize();
        Held held = HELD.get(key);
        if (held != null) {
            if (exclusive || held.exclusive) {
                return null;
            }
            held.count++;
            return () -> release(key);
        }
        try {
            Files.createDirectories(key.getParent());
            FileChannel channel = FileChannel.open(key, StandardOpenOption.CREATE, StandardOpenOption.READ,
                    StandardOpenOption.WRITE);
            FileLock lock = exclusive ? channel.tryLock(0, Long.MAX_VALUE, false)
                    : channel.lock(0, Long.MAX_VALUE, true);
            if (lock == null) {
                channel.close();
                return null;
            }
            HELD.put(key, new Held(channel, lock, exclusive));
            return () -> release(key);
        } catch (IOException e) {
            throw new DataStoreException("Cannot lock " + key, e);
        }
    }

    private static synchronized void release(Path key) {
        Held held = HELD.get(key);
        if (held == null || --held.count > 0) {
            return;
        }
        HELD.remove(key);
        try {
            held.lock.release();
            held.channel.close();
        } catch (IOException ignored) {
            // the OS releases the lock when the process exits anyway
        }
    }

    private static final class Held {
        final FileChannel channel;
        final FileLock lock;
        final boolean exclusive;
        int count = 1;

        Held(FileChannel channel, FileLock lock, boolean exclusive) {
            this.channel = channel;
            this.lock = lock;
            this.exclusive = exclusive;
        }
    }
}
