package com.acme.datastore.spi;

import com.acme.datastore.DataStoreException;

import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.lang.reflect.RecordComponent;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Deterministic encoding of keys: equal keys give identical bytes in every JVM.
 *
 * <p>A key is either a <b>simple</b> value (String, boxed primitive, BigDecimal, BigInteger, LocalDate,
 * LocalDateTime, LocalTime, Instant, UUID, enum) or a <b>composite</b>: a record, or a final class with
 * final fields, overriding equals/hashCode, whose fields are all simple. Component order (record
 * components / declared field order) is part of the storage format: changing a key class needs a new
 * namespace or partition. Null components are rejected.
 */
public final class KeyCodec<K> {

    private static final Map<Class<?>, KeyCodec<?>> CACHE = new ConcurrentHashMap<>();
    private static final Set<Class<?>> SIMPLE = Set.of(String.class, Long.class, Integer.class, Short.class,
            Byte.class, Boolean.class, Character.class, Double.class, Float.class, BigDecimal.class,
            BigInteger.class, LocalDate.class, LocalDateTime.class, LocalTime.class, Instant.class, UUID.class);

    private final Class<K> type;
    private final boolean simple;
    private final List<String> names;
    private final List<Class<?>> types;
    private final List<Field> fields;          // composite non-record
    private final List<Method> accessors;      // composite record
    private final Constructor<K> constructor;  // canonical / matching ctor, or null
    private final int fixedSize;
    private final String fingerprint;

    @SuppressWarnings("unchecked")
    public static <K> KeyCodec<K> of(Class<K> type) {
        return (KeyCodec<K>) CACHE.computeIfAbsent(box(type), KeyCodec::new);
    }

    /** True if {@code type} can be a key or a key component. */
    public static boolean isSimple(Class<?> type) {
        Class<?> t = box(type);
        return SIMPLE.contains(t) || t.isEnum();
    }

    @SuppressWarnings("unchecked")
    private KeyCodec(Class<?> raw) {
        this.type = (Class<K>) raw;
        List<String> n = new ArrayList<>();
        List<Class<?>> t = new ArrayList<>();
        List<Field> f = new ArrayList<>();
        List<Method> a = new ArrayList<>();
        Constructor<K> ctor = null;
        if (isSimple(raw)) {
            simple = true;
            n.add("value");
            t.add(raw);
        } else {
            simple = false;
            requireValueSemantics(raw);
            if (raw.isRecord()) {
                RecordComponent[] rc = raw.getRecordComponents();
                Class<?>[] params = new Class<?>[rc.length];
                for (int i = 0; i < rc.length; i++) {
                    n.add(rc[i].getName());
                    t.add(rc[i].getType());
                    params[i] = rc[i].getType();
                    Method m = rc[i].getAccessor();
                    m.setAccessible(true);
                    a.add(m);
                }
                ctor = constructor(raw, params);
            } else {
                if (!Modifier.isFinal(raw.getModifiers())) {
                    throw bad(raw, "must be a record or a final class");
                }
                for (Field field : raw.getDeclaredFields()) {
                    int m = field.getModifiers();
                    if (Modifier.isStatic(m) || field.isSynthetic()) {
                        continue;
                    }
                    if (!Modifier.isFinal(m)) {
                        throw bad(raw, "field '" + field.getName() + "' must be final (keys are immutable)");
                    }
                    field.setAccessible(true);
                    n.add(field.getName());
                    t.add(field.getType());
                    f.add(field);
                }
                ctor = constructor(raw, t.toArray(Class<?>[]::new));
                if (ctor == null) {
                    ctor = constructor(raw);
                }
                if (ctor == null) {
                    throw bad(raw, "needs a constructor taking its fields in declaration order, or a no-arg constructor");
                }
            }
            if (n.isEmpty()) {
                throw bad(raw, "has no fields");
            }
            for (int i = 0; i < t.size(); i++) {
                if (!isSimple(t.get(i))) {
                    throw bad(raw, "component '" + n.get(i) + "' is " + t.get(i).getName()
                            + "; key components must be simple types (String, numbers, dates, UUID, enums)");
                }
            }
        }
        this.names = List.copyOf(n);
        this.types = List.copyOf(t);
        this.fields = List.copyOf(f);
        this.accessors = List.copyOf(a);
        this.constructor = ctor;
        int size = 0;
        for (Class<?> c : types) {
            int s = fixedSize(c);
            if (s < 0) {
                size = -1;
                break;
            }
            size += s;
        }
        this.fixedSize = size;
        StringBuilder fp = new StringBuilder(raw.getName());
        for (int i = 0; i < names.size(); i++) {
            fp.append('|').append(names.get(i)).append(':').append(types.get(i).getName());
        }
        this.fingerprint = Integer.toHexString(fp.toString().hashCode());
    }

    public Class<K> type() {
        return type;
    }

    /** True for a single simple value (Long, String, ...), false for a record/class composite. */
    public boolean simple() {
        return simple;
    }

    public List<String> componentNames() {
        return names;
    }

    public List<Class<?>> componentTypes() {
        return types;
    }

    /** Encoded size when every component is fixed width, else -1. */
    public int fixedSize() {
        return fixedSize;
    }

    /** Short hex id of the key's structure (class + component names/types). */
    public String fingerprint() {
        return fingerprint;
    }

    /** Component values in order. */
    public Object[] values(K key) {
        if (simple) {
            return new Object[]{key};
        }
        Object[] out = new Object[names.size()];
        try {
            for (int i = 0; i < out.length; i++) {
                out[i] = accessors.isEmpty() ? fields.get(i).get(key) : accessors.get(i).invoke(key);
            }
        } catch (ReflectiveOperationException e) {
            throw new DataStoreException("Cannot read key " + key, e);
        }
        return out;
    }

    /** Builds a key from component values (in order). */
    public K construct(Object... values) {
        if (values.length != names.size()) {
            throw new DataStoreException(type.getName() + " has " + names.size() + " components, got " + values.length);
        }
        for (int i = 0; i < values.length; i++) {
            if (values[i] == null) {
                throw new DataStoreException("Key " + type.getSimpleName() + "." + names.get(i) + " is null");
            }
        }
        if (simple) {
            return type.cast(values[0]);
        }
        try {
            if (constructor.getParameterCount() == values.length) {
                return constructor.newInstance(values);
            }
            K k = constructor.newInstance();
            for (int i = 0; i < values.length; i++) {
                fields.get(i).set(k, values[i]);
            }
            return k;
        } catch (ReflectiveOperationException e) {
            throw new DataStoreException("Cannot construct key " + type.getName(), e);
        }
    }

    public byte[] encode(K key) {
        Object[] values = values(key);
        ByteArrayOutputStream buf = new ByteArrayOutputStream(fixedSize > 0 ? fixedSize : 32);
        try (DataOutputStream out = new DataOutputStream(buf)) {
            for (int i = 0; i < values.length; i++) {
                if (values[i] == null) {
                    throw new DataStoreException("Key " + type.getSimpleName() + "." + names.get(i) + " is null");
                }
                write(out, box(types.get(i)), values[i]);
            }
        } catch (IOException e) {
            throw new DataStoreException("Cannot encode key " + key, e);
        }
        return buf.toByteArray();
    }

    public K decode(byte[] bytes) {
        Object[] values = new Object[names.size()];
        try (DataInputStream in = new DataInputStream(new java.io.ByteArrayInputStream(bytes))) {
            for (int i = 0; i < values.length; i++) {
                values[i] = read(in, box(types.get(i)));
            }
        } catch (IOException e) {
            throw new DataStoreException("Cannot decode key of " + type.getName(), e);
        }
        return construct(values);
    }

    /** Stable, well-mixed hash of the encoded key (same in every JVM; unlike enum hashCode). */
    public int hash(K key) {
        return hash(encode(key));
    }

    public static int hash(byte[] encoded) {
        int h = Arrays.hashCode(encoded);
        h ^= (h >>> 16);
        h *= 0x85ebca6b;
        h ^= (h >>> 13);
        return h;
    }

    /** Split (0..splits-1) for a key. */
    public int split(K key, int splits) {
        return splits <= 1 ? 0 : Math.floorMod(hash(key), splits);
    }

    // ------------------------------------------------------------------ helpers

    private static void requireValueSemantics(Class<?> raw) {
        if (raw.isInterface() || Modifier.isAbstract(raw.getModifiers()) || raw.isArray() || raw.isPrimitive()) {
            throw bad(raw, "must be a concrete record or final class");
        }
        try {
            Method eq = raw.getMethod("equals", Object.class);
            Method hc = raw.getMethod("hashCode");
            if (eq.getDeclaringClass() == Object.class || hc.getDeclaringClass() == Object.class) {
                throw bad(raw, "must override equals() and hashCode()");
            }
        } catch (NoSuchMethodException e) {
            throw new IllegalStateException(e);
        }
    }

    @SuppressWarnings("unchecked")
    private static <K> Constructor<K> constructor(Class<?> raw, Class<?>... params) {
        try {
            Constructor<K> c = (Constructor<K>) raw.getDeclaredConstructor(params);
            c.setAccessible(true);
            return c;
        } catch (NoSuchMethodException e) {
            return null;
        }
    }

    private static DataStoreException bad(Class<?> raw, String why) {
        return new DataStoreException("Key class " + raw.getName() + " " + why);
    }

    static Class<?> box(Class<?> c) {
        if (!c.isPrimitive()) {
            return c;
        }
        if (c == long.class) return Long.class;
        if (c == int.class) return Integer.class;
        if (c == short.class) return Short.class;
        if (c == byte.class) return Byte.class;
        if (c == boolean.class) return Boolean.class;
        if (c == char.class) return Character.class;
        if (c == double.class) return Double.class;
        if (c == float.class) return Float.class;
        throw new IllegalArgumentException(c.getName());
    }

    private static int fixedSize(Class<?> raw) {
        Class<?> c = box(raw);
        if (c == Long.class || c == Double.class) return 8;
        if (c == Integer.class || c == Float.class) return 4;
        if (c == Short.class || c == Character.class) return 2;
        if (c == Byte.class || c == Boolean.class) return 1;
        if (c == LocalDate.class || c == LocalTime.class) return 8;
        if (c == LocalDateTime.class || c == UUID.class) return 16;
        if (c == Instant.class) return 12;
        return -1;
    }

    private static void write(DataOutputStream out, Class<?> c, Object v) throws IOException {
        if (c == String.class) {
            byte[] b = ((String) v).getBytes(StandardCharsets.UTF_8);
            out.writeInt(b.length);
            out.write(b);
        } else if (c == Long.class) {
            out.writeLong((Long) v);
        } else if (c == Integer.class) {
            out.writeInt((Integer) v);
        } else if (c == Short.class) {
            out.writeShort((Short) v);
        } else if (c == Byte.class) {
            out.writeByte((Byte) v);
        } else if (c == Boolean.class) {
            out.writeBoolean((Boolean) v);
        } else if (c == Character.class) {
            out.writeChar((Character) v);
        } else if (c == Double.class) {
            out.writeLong(Double.doubleToLongBits((Double) v));
        } else if (c == Float.class) {
            out.writeInt(Float.floatToIntBits((Float) v));
        } else if (c == BigDecimal.class) {
            BigDecimal d = (BigDecimal) v;
            out.writeInt(d.scale());
            byte[] b = d.unscaledValue().toByteArray();
            out.writeInt(b.length);
            out.write(b);
        } else if (c == BigInteger.class) {
            byte[] b = ((BigInteger) v).toByteArray();
            out.writeInt(b.length);
            out.write(b);
        } else if (c == LocalDate.class) {
            out.writeLong(((LocalDate) v).toEpochDay());
        } else if (c == LocalTime.class) {
            out.writeLong(((LocalTime) v).toNanoOfDay());
        } else if (c == LocalDateTime.class) {
            LocalDateTime t = (LocalDateTime) v;
            out.writeLong(t.toLocalDate().toEpochDay());
            out.writeLong(t.toLocalTime().toNanoOfDay());
        } else if (c == Instant.class) {
            Instant t = (Instant) v;
            out.writeLong(t.getEpochSecond());
            out.writeInt(t.getNano());
        } else if (c == UUID.class) {
            UUID u = (UUID) v;
            out.writeLong(u.getMostSignificantBits());
            out.writeLong(u.getLeastSignificantBits());
        } else if (c.isEnum()) {
            write(out, String.class, ((Enum<?>) v).name());   // by name: stable across reordering
        } else {
            throw new IllegalStateException(c.getName());
        }
    }

    @SuppressWarnings({"unchecked", "rawtypes"})
    private static Object read(DataInputStream in, Class<?> c) throws IOException {
        if (c == String.class) {
            byte[] b = new byte[in.readInt()];
            in.readFully(b);
            return new String(b, StandardCharsets.UTF_8);
        }
        if (c == Long.class) return in.readLong();
        if (c == Integer.class) return in.readInt();
        if (c == Short.class) return in.readShort();
        if (c == Byte.class) return in.readByte();
        if (c == Boolean.class) return in.readBoolean();
        if (c == Character.class) return in.readChar();
        if (c == Double.class) return Double.longBitsToDouble(in.readLong());
        if (c == Float.class) return Float.intBitsToFloat(in.readInt());
        if (c == BigDecimal.class) {
            int scale = in.readInt();
            byte[] b = new byte[in.readInt()];
            in.readFully(b);
            return new BigDecimal(new BigInteger(b), scale);
        }
        if (c == BigInteger.class) {
            byte[] b = new byte[in.readInt()];
            in.readFully(b);
            return new BigInteger(b);
        }
        if (c == LocalDate.class) return LocalDate.ofEpochDay(in.readLong());
        if (c == LocalTime.class) return LocalTime.ofNanoOfDay(in.readLong());
        if (c == LocalDateTime.class) {
            return LocalDateTime.of(LocalDate.ofEpochDay(in.readLong()), LocalTime.ofNanoOfDay(in.readLong()));
        }
        if (c == Instant.class) return Instant.ofEpochSecond(in.readLong(), in.readInt());
        if (c == UUID.class) return new UUID(in.readLong(), in.readLong());
        if (c.isEnum()) return Enum.valueOf((Class) c, (String) read(in, String.class));
        throw new IllegalStateException(c.getName());
    }
}
