package com.acme.datastore.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Optional: marks a field holding the id (or a collection of ids) of an object in another dataset.
 * The same relation can be declared in YAML under the dataset's {@code lookups:} instead.
 * Only direct members: fields of the dataset's value or of value objects nested in it.
 *
 * <pre>{@code
 * public class Order {
 *     @Id private long orderId;
 *
 *     @Lookup(dataset = "customer", into = "customer", resolvePolicy = Resolve.EAGER)
 *     private long customerId;
 *
 *     private Customer customer;     // existing full-object field, still used by older apps
 * }
 * }</pre>
 *
 * In {@code REFERENCE} storage mode only {@code customerId} is stored; {@code customer} is left out on
 * write and filled again on read (EAGER) or on request (LAZY).
 */
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.FIELD)
public @interface Lookup {

    /** Target dataset name. Either this or {@link #target()}. */
    String dataset() default "";

    /** Target value class; must be the value of exactly one dataset. Either this or {@link #dataset()}. */
    Class<?> target() default void.class;

    /** Name of the sibling field (same class) that receives the resolved object(s). Optional. */
    String into() default "";

    /** Name used in {@code LookupResolver.resolve(page, "name")}; defaults to the into path, else the field path. */
    String name() default "";

    /** Same as {@code lookup-resolve-policy} in YAML; DEFAULT inherits the dataset / dataset-defaults policy. */
    Resolve resolvePolicy() default Resolve.DEFAULT;
}
