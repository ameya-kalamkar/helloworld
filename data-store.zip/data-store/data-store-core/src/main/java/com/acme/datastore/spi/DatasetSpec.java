package com.acme.datastore.spi;

/** What a {@link Store} knows about one dataset. */
public final class DatasetSpec<K> {

    private final String name;
    private final Class<?> valueType;
    private final KeyCodec<K> keyCodec;
    private final int splits;
    private final Object settings;
    private final boolean internal;

    public DatasetSpec(String name, Class<?> valueType, KeyCodec<K> keyCodec, int splits, Object settings,
                       boolean internal) {
        this.name = name;
        this.valueType = valueType;
        this.keyCodec = keyCodec;
        this.splits = splits;
        this.settings = settings;
        this.internal = internal;
    }

    /** Dataset name: {@code [a-z][a-z0-9-]*}, or {@code _manifest} for the internal manifest. */
    public String name() {
        return name;
    }

    public Class<?> valueType() {
        return valueType;
    }

    public Class<K> keyType() {
        return keyCodec.type();
    }

    public KeyCodec<K> keyCodec() {
        return keyCodec;
    }

    /** Configured splits; 0 = the store's default. */
    public int splits() {
        return splits;
    }

    /** Bound instance of the store's {@code datasetSettingsType()}, or null (Void / internal dataset). */
    public <S> S settings(Class<S> type) {
        return settings == null ? null : type.cast(settings);
    }

    /** True for the library's own manifest dataset: no user sizing, use small defaults. */
    public boolean internal() {
        return internal;
    }

    @Override
    public String toString() {
        return name + "[" + keyType().getSimpleName() + " -> " + valueType.getName() + "]";
    }
}
