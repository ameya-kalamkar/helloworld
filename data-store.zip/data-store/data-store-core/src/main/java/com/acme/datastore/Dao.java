package com.acme.datastore;

import com.acme.datastore.annotation.Resolve;
import com.acme.datastore.internal.Model.Link;
import com.acme.datastore.internal.Model.Meta;
import com.acme.datastore.spi.StoreMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Optional;
import java.util.Spliterator;
import java.util.Spliterators;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;
import java.util.stream.IntStream;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;

/**
 * Data access for one dataset of the current partition. Obtained from {@link DataStore#dao}; jobs never
 * implement it.
 *
 * <p>Reads resolve the dataset's EAGER lookups (full depth) unless overridden per call:
 * {@code Resolve.LAZY} resolves nothing, {@code Resolve.EAGER} resolves every lookup.
 * Bulk reads ({@link #findAllById}, {@link #streamSplit}, {@link #pages}) resolve per page with one bulk
 * call per target dataset per level; prefer them over {@link #findById} in loops.
 *
 * <p>Every read returns fresh copies; objects you save are never modified by the library. With
 * {@code local-cache: true} the encoded values of this dataset are also kept in an unbounded per-JVM map
 * (meant for reference data; safe because a partition's data is written once).
 */
public final class Dao<T, K> {

    private static final Logger LOG = LoggerFactory.getLogger(Dao.class);

    private final DataStore store;
    private final Meta meta;
    private final Class<T> type;
    private final StoreMap<K> map;
    private final ConcurrentHashMap<K, byte[]> cache;   // local-cache: unbounded, encoded values
    private final AtomicLong singleEagerReads = new AtomicLong();

    @SuppressWarnings("unchecked")
    Dao(DataStore store, Meta meta, StoreMap<K> map) {
        this.store = store;
        this.meta = meta;
        this.type = (Class<T>) meta.valueType;
        this.map = map;
        this.cache = meta.localCache ? new ConcurrentHashMap<>() : null;
    }

    public String dataset() {
        return meta.name;
    }

    public Class<T> type() {
        return type;
    }

    @SuppressWarnings("unchecked")
    public Class<K> keyType() {
        return (Class<K>) meta.keys.type();
    }

    @SuppressWarnings("unchecked")
    public K idOf(T value) {
        return (K) meta.id(value);
    }

    // ------------------------------------------------------------------ reads

    public Optional<T> findById(K id) {
        return findById(id, Resolve.DEFAULT);
    }

    public Optional<T> findById(K id, Resolve resolve) {
        byte[] bytes = cached(id);
        if (bytes == null) {
            return Optional.empty();
        }
        T value = type.cast(meta.decode(bytes));
        List<Link> links = links(resolve);
        if (!links.isEmpty()) {
            if (resolve == Resolve.DEFAULT) {
                warnSingleReads();
            }
            store.lookups().apply(meta, List.of(value), links);
        }
        return Optional.of(value);
    }

    /** Bulk read; the result holds only the ids found, in request order. */
    public Map<K, T> findAllById(Collection<K> ids) {
        return findAllById(ids, Resolve.DEFAULT);
    }

    public Map<K, T> findAllById(Collection<K> ids, Resolve resolve) {
        Map<K, T> out = rawGetAll(ids);
        resolve(new ArrayList<>(out.values()), resolve);
        return out;
    }

    public long count() {
        return map.size();
    }

    public int splits() {
        return map.splits();
    }

    /** One split, EAGER lookups resolved page by page. Close the stream (try-with-resources). */
    public Stream<T> streamSplit(int split) {
        return streamSplit(split, Resolve.DEFAULT);
    }

    public Stream<T> streamSplit(int split, Resolve resolve) {
        if (links(resolve).isEmpty()) {
            return decode(map.scan(split));
        }
        return pages(split, store.config().getLookupResolver().getPageSize(), resolve).flatMap(List::stream);
    }

    /** One split as pages of {@code pageSize}, lookups resolved per page: the unit for batch processing. */
    public Stream<List<T>> pages(int split, int pageSize) {
        return pages(split, pageSize, Resolve.DEFAULT);
    }

    public Stream<List<T>> pages(int split, int pageSize, Resolve resolve) {
        if (pageSize <= 0) {
            throw new IllegalArgumentException("pageSize must be > 0");
        }
        Stream<T> source = decode(map.scan(split));
        Iterator<T> it = source.iterator();
        Iterator<List<T>> pages = new Iterator<>() {
            @Override
            public boolean hasNext() {
                return it.hasNext();
            }

            @Override
            public List<T> next() {
                if (!it.hasNext()) {
                    throw new NoSuchElementException();
                }
                List<T> page = new ArrayList<>(pageSize);
                while (it.hasNext() && page.size() < pageSize) {
                    page.add(it.next());
                }
                resolve(page, resolve);
                return page;
            }
        };
        return StreamSupport.stream(Spliterators.spliteratorUnknownSize(pages, Spliterator.ORDERED), false)
                .onClose(source::close);
    }

    /** All splits in sequence. */
    public Stream<T> streamAll() {
        return streamAll(Resolve.DEFAULT);
    }

    public Stream<T> streamAll(Resolve resolve) {
        return IntStream.range(0, splits()).boxed().flatMap(s -> streamSplit(s, resolve));
    }

    // ------------------------------------------------------------------ writes

    public void save(T value) {
        @SuppressWarnings("unchecked")
        K id = (K) meta.id(value);
        byte[] bytes = meta.encode(value);
        map.put(id, bytes);
        if (cache != null) {
            cache.remove(id);
        }
    }

    public void saveAll(Collection<? extends T> values) {
        if (values.isEmpty()) {
            return;
        }
        Map<K, byte[]> batch = new LinkedHashMap<>(values.size() * 2);
        for (T v : values) {
            @SuppressWarnings("unchecked")
            K id = (K) meta.id(v);
            batch.put(id, meta.encode(v));
        }
        map.putAll(batch);
        if (cache != null) {
            batch.keySet().forEach(cache::remove);
        }
    }

    public boolean deleteById(K id) {
        if (cache != null) {
            cache.remove(id);
        }
        return map.remove(id);
    }

    /** Removes every entry (used to re-run the job that owns this dataset). */
    public void clear() {
        if (cache != null) {
            cache.clear();
        }
        map.clear();
    }

    // ------------------------------------------------------------------ internals

    /** Decoded values without lookup resolution (used by the resolver). */
    Map<K, T> rawGetAll(Collection<K> ids) {
        if (ids.isEmpty()) {
            return Map.of();
        }
        Map<K, byte[]> found;
        if (cache == null) {
            found = map.getAll(ids);
        } else {
            found = new HashMap<>(ids.size() * 2);
            List<K> misses = new ArrayList<>();
            for (K id : ids) {
                byte[] b = cache.get(id);
                if (b != null) {
                    found.put(id, b);
                } else {
                    misses.add(id);
                }
            }
            if (!misses.isEmpty()) {
                Map<K, byte[]> loaded = map.getAll(misses);
                found.putAll(loaded);
                loaded.forEach(this::remember);
            }
        }
        Map<K, T> out = new LinkedHashMap<>(found.size() * 2);
        for (K id : ids) {
            byte[] b = found.get(id);
            if (b != null) {
                out.put(id, type.cast(meta.decode(b)));
            }
        }
        return out;
    }

    void close() {
        map.close();
    }

    private byte[] cached(K id) {
        if (cache != null) {
            byte[] b = cache.get(id);
            if (b != null) {
                return b;
            }
        }
        byte[] b = map.get(id);
        if (b != null) {
            remember(id, b);
        }
        return b;
    }

    private void remember(K id, byte[] bytes) {
        if (cache != null) {
            cache.putIfAbsent(id, bytes);
        }
    }

    private void resolve(List<T> values, Resolve resolve) {
        List<Link> links = links(resolve);
        store.lookups().apply(meta, values, links);
    }

    private List<Link> links(Resolve resolve) {
        return switch (resolve) {
            case DEFAULT -> meta.eager;
            case EAGER -> meta.links;
            case LAZY -> List.of();
        };
    }

    private Stream<T> decode(Stream<Map.Entry<K, byte[]>> entries) {
        return entries.map(e -> type.cast(meta.decode(e.getValue())));
    }

    private void warnSingleReads() {
        int limit = store.config().getLookupResolver().getSingleReadWarn();
        if (limit > 0 && singleEagerReads.incrementAndGet() == limit) {
            LOG.warn("Dataset '{}': {} single findById calls resolved EAGER lookups one object at a time. "
                    + "Use findAllById / pages / streamSplit to resolve in bulk, or findById(id, Resolve.LAZY).",
                    meta.name, limit);
        }
    }
}
