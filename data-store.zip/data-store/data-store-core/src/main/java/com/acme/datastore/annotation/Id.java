package com.acme.datastore.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Optional: marks the field holding an object's key. Not needed when the dataset sets {@code id:} in
 * YAML ({@code id: orderId}, or {@code id: [tradeId, legNo]} to build a composite key from several fields).
 */
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.FIELD)
public @interface Id {
}
