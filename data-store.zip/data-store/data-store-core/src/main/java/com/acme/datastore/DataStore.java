package com.acme.datastore;

import com.acme.datastore.annotation.Id;
import com.acme.datastore.annotation.Lookup;
import com.acme.datastore.annotation.Resolve;
import com.acme.datastore.config.DataStoreConfig;
import com.acme.datastore.config.DataStoreConfig.DatasetConfig;
import com.acme.datastore.config.DataStoreConfig.LookupConfig;
import com.acme.datastore.config.DataStoreConfig.LookupResolverConfig;
import com.acme.datastore.config.DataStoreConfig.OnMissingTarget;
import com.acme.datastore.config.DataStoreConfig.StorageMode;
import com.acme.datastore.internal.Model;
import com.acme.datastore.internal.Model.Link;
import com.acme.datastore.internal.Model.Meta;
import com.acme.datastore.lookup.LookupResolver;
import com.acme.datastore.spi.DatasetSpec;
import com.acme.datastore.spi.KeyCodec;
import com.acme.datastore.spi.Store;
import org.apache.fory.Fory;
import org.apache.fory.ThreadSafeFory;
import org.apache.fory.config.Language;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.ServiceLoader;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.UnaryOperator;
import java.util.regex.Pattern;

/**
 * One started data store: the configured store, bound to one namespace and one partition.
 * Create one per JVM (a Spring singleton, or {@code ExecutorContext} in Flink/Spark executors) and close
 * it on shutdown.
 *
 * <pre>{@code
 * // from YAML / JSON
 * DataStore ds = DataStore.builder().config(Path.of("datastore.yml")).build();
 *
 * // programmatic (unit tests; memory store is the default)
 * DataStore ds = DataStore.builder().namespace("test").partition("P1")
 *         .dataset("order", Order.class)
 *         .dataset("customer", Customer.class, d -> d.localCache(10_000))
 *         .build();
 * ds.createAll();
 * Dao<Order, Long> orders = ds.dao(Order.class);
 * }</pre>
 *
 * Start-up validates everything before job code runs: store on the classpath, store blocks, classes,
 * ids, key classes, every lookup's target and types.
 */
public final class DataStore implements AutoCloseable {

    private static final Logger LOG = LoggerFactory.getLogger(DataStore.class);
    private static final Pattern NAMESPACE = Pattern.compile("[A-Za-z][A-Za-z0-9-]{0,62}");
    private static final Pattern DATASET = Pattern.compile("[a-z][a-z0-9-]{0,62}");
    private static final Pattern PART = Pattern.compile("[A-Za-z0-9-]+");
    private static final Pattern PARTITION = Pattern.compile("[A-Za-z0-9-]+(_[A-Za-z0-9-]+)*");

    private final DataStoreConfig config;
    private final String partition;
    private final Store store;
    private final Map<String, Meta> metas;
    private final Map<String, DatasetSpec<?>> specs;
    private final Map<String, Dao<?, ?>> daos = new ConcurrentHashMap<>();
    private final AutoCloseable partitionLock;
    private final ExecutorService executor;
    private final LookupResolver lookups;
    private final Manifest manifest;
    private final AtomicBoolean closed = new AtomicBoolean();

    private DataStore(DataStoreConfig config, String partition, Store store, Map<String, Meta> metas,
                      Map<String, DatasetSpec<?>> specs, AutoCloseable partitionLock, ExecutorService executor) {
        this.config = config;
        this.partition = partition;
        this.store = store;
        this.metas = metas;
        this.specs = specs;
        this.partitionLock = partitionLock;
        this.executor = executor;
        this.manifest = new Manifest(this);
        this.lookups = new LookupResolver(new LookupResolver.Backend() {
            @Override
            public Meta meta(String dataset) {
                return DataStore.this.meta(dataset);
            }

            @Override
            public String datasetOf(Class<?> type) {
                return DataStore.this.datasetOf(type);
            }

            @Override
            @SuppressWarnings({"unchecked", "rawtypes"})
            public Map<Object, Object> fetch(Meta dataset, Set<Object> ids) {
                Dao dao = dao(dataset.name);
                return (Map<Object, Object>) dao.rawGetAll((Collection) ids);
            }

            @Override
            public void requireComplete(String dataset) {
                manifest.requireComplete(dataset);
            }
        }, config.getLookupResolver(), executor);
    }

    public static Builder builder() {
        return new Builder();
    }

    // ------------------------------------------------------------------ API

    public String namespace() {
        return config.getNamespace();
    }

    public String partition() {
        return partition;
    }

    public String storeName() {
        return store.name();
    }

    public DataStoreConfig config() {
        return config;
    }

    /** DAO of the dataset whose value class is {@code type} (must be unique; else use {@link #dao(String)}). */
    public <T, K> Dao<T, K> dao(Class<T> type) {
        return dao(datasetOf(type));
    }

    @SuppressWarnings("unchecked")
    public <T, K> Dao<T, K> dao(String dataset) {
        Dao<?, ?> d = daos.get(dataset);
        if (d == null) {
            d = daos.computeIfAbsent(dataset, n -> newDao(n, false));
        }
        return (Dao<T, K>) d;
    }

    public LookupResolver lookups() {
        return lookups;
    }

    public Manifest manifest() {
        return manifest;
    }

    /** Dataset names from the configuration (the internal manifest excluded). */
    public List<String> datasets() {
        return metas.values().stream().filter(m -> !m.internal).map(m -> m.name).toList();
    }

    /** The one dataset holding {@code type}. */
    public String datasetOf(Class<?> type) {
        List<String> hits = new ArrayList<>();
        for (Meta m : metas.values()) {
            if (m.valueType == type) {
                hits.add(m.name);
            }
        }
        if (hits.size() == 1) {
            return hits.get(0);
        }
        throw new DataStoreException(hits.isEmpty()
                ? "No dataset holds " + type.getName() + "; datasets: " + datasets()
                : type.getName() + " is the value of several datasets " + hits + "; use the dataset name");
    }

    /** First step of a partition: creates every dataset (idempotent; existing data and status are kept). */
    public void createAll() {
        newDaoIfAbsent(Manifest.DATASET);
        for (String name : specs.keySet()) {
            newDaoIfAbsent(name);
        }
        for (String name : datasets()) {
            if (manifest.status(name) == null) {
                manifest.mark(name, Manifest.Status.CREATED);
            }
        }
        LOG.info("Partition {} ready: {}", partition, datasets());
    }

    /** Clears one dataset so the job that owns it can be re-run. */
    public void reset(String dataset) {
        dao(dataset).clear();
        manifest.mark(dataset, Manifest.Status.CREATED);
    }

    /** Partitions with data in this namespace. Nothing is ever deleted automatically. */
    public List<String> partitions() {
        return store.partitions();
    }

    /**
     * Deletes every dataset of another partition. Returns false (nothing deleted) if a job still holds it
     * (on stores that support locks).
     */
    public boolean destroyPartition(String other) {
        if (!PARTITION.matcher(other).matches()) {
            throw new DataStoreException("Invalid partition '" + other + "'");
        }
        if (other.equals(partition)) {
            throw new DataStoreException("Refusing to destroy the partition this process uses (" + other + ")");
        }
        AutoCloseable lock = store.lock(other, true);
        if (lock == null) {
            LOG.warn("Partition {} is in use by another job; not destroyed", other);
            return false;
        }
        try {
            store.destroy(other);
        } finally {
            closeQuietly(lock);
        }
        LOG.info("Partition {} destroyed", other);
        return true;
    }

    @Override
    public void close() {
        if (!closed.compareAndSet(false, true)) {
            return;
        }
        if (executor != null) {
            executor.shutdownNow();
        }
        daos.values().forEach(Dao::close);
        daos.clear();
        closeQuietly(partitionLock);
        store.close();
        LOG.info("DataStore closed ({} / {} / {})", namespace(), store.name(), partition);
    }

    // ------------------------------------------------------------------ internals

    /** Internal. */
    public Meta meta(String dataset) {
        Meta m = metas.get(dataset);
        if (m == null) {
            throw new DataStoreException("Unknown dataset '" + dataset + "'; datasets: " + datasets());
        }
        return m;
    }

    private void newDaoIfAbsent(String name) {
        daos.computeIfAbsent(name, n -> newDao(n, true));
    }

    @SuppressWarnings({"unchecked", "rawtypes"})
    private Dao<?, ?> newDao(String name, boolean create) {
        Meta meta = meta(name);
        DatasetSpec spec = specs.get(name);
        return new Dao(this, meta, store.open(spec, partition, create));
    }

    private static void closeQuietly(AutoCloseable c) {
        try {
            c.close();
        } catch (Exception e) {
            LOG.warn("Error releasing {}", c, e);
        }
    }

    // ================================================================== builder

    /** Builds and starts a {@link DataStore}; validates everything first. */
    public static final class Builder {

        private DataStoreConfig config;
        private String text;
        private String source;
        private UnaryOperator<String> placeholders = Builder::resolvePlaceholders;
        private ClassLoader classLoader;
        private String storeTypeOverride;
        private String namespaceOverride;
        private String partitionOverride;
        private final Map<String, DatasetConfig> extraDatasets = new LinkedHashMap<>();

        private Builder() {
        }

        /** YAML or JSON file. */
        public Builder config(Path path) {
            try {
                return configText(Files.readString(path, StandardCharsets.UTF_8), path.toString());
            } catch (IOException e) {
                throw new DataStoreException("Cannot read " + path, e);
            }
        }

        /** YAML or JSON text with a {@code datastore} block; placeholders are resolved first. */
        public Builder configText(String text, String source) {
            this.text = text;
            this.source = source;
            return this;
        }

        public Builder config(DataStoreConfig config) {
            this.config = config;
            return this;
        }

        /** Resolves {@code ${...}} in the text (default: system properties, then environment, {@code ${X:default}}). */
        public Builder placeholders(UnaryOperator<String> placeholders) {
            this.placeholders = placeholders;
            return this;
        }

        /** Where domain classes and stores are loaded from (default: thread context class loader). */
        public Builder classLoader(ClassLoader classLoader) {
            this.classLoader = classLoader;
            return this;
        }

        /** Overrides {@code store-type} (e.g. "memory" in tests of a pipeline configured for chronicle). */
        public Builder storeType(String storeType) {
            this.storeTypeOverride = storeType;
            return this;
        }

        public Builder namespace(String namespace) {
            this.namespaceOverride = namespace;
            return this;
        }

        /** Overrides {@code partition.parts} with a ready partition value, e.g. {@code NA_20261018}. */
        public Builder partition(String partition) {
            this.partitionOverride = partition;
            return this;
        }

        public Builder dataset(String name, Class<?> valueType) {
            return dataset(name, valueType, d -> { });
        }

        public Builder dataset(String name, Class<?> valueType, Consumer<DatasetConfig> customize) {
            DatasetConfig dc = new DatasetConfig();
            dc.setValue(valueType.getName());
            customize.accept(dc);
            extraDatasets.put(name, dc);
            return this;
        }

        public DataStore build() {
            DataStoreConfig cfg = config;
            if (text != null) {
                cfg = DataStoreConfig.parse(placeholders.apply(text), source);
            }
            if (cfg == null) {
                cfg = new DataStoreConfig();
            }
            if (storeTypeOverride != null) {
                cfg.setStoreType(storeTypeOverride);
            }
            if (namespaceOverride != null) {
                cfg.setNamespace(namespaceOverride);
            }
            cfg.getDatasets().putAll(extraDatasets);
            ClassLoader cl = classLoader != null ? classLoader
                    : Thread.currentThread().getContextClassLoader() != null
                    ? Thread.currentThread().getContextClassLoader() : DataStore.class.getClassLoader();
            return start(cfg, cl);
        }

        private DataStore start(DataStoreConfig cfg, ClassLoader cl) {
            require(cfg.getNamespace() != null && NAMESPACE.matcher(cfg.getNamespace()).matches(),
                    "namespace must match " + NAMESPACE + " (got '" + cfg.getNamespace() + "')");
            String partition = partition(cfg);
            require(!cfg.getDatasets().isEmpty(), "datasets is empty");
            LookupResolverConfig ld = cfg.getLookupResolver();
            require(ld.getParallelism() >= 1, "lookup-resolver.parallelism must be >= 1");
            require(ld.getPageSize() >= 1, "lookup-resolver.page-size must be >= 1");
            require(ld.getMaxDepth() >= 0, "lookup-resolver.max-depth must be >= 0 (0 = unlimited)");
            DatasetConfig defaults = cfg.getDatasetDefaults();
            require(defaults.getValue() == null && defaults.getKey() == null && defaults.getId() == null
                    && defaults.getLookups().isEmpty(), "dataset-defaults cannot set value, key, id or lookups "
                    + "(they belong to one dataset)");

            // ---- store and its blocks
            Map<String, Store> installed = installedStores(cl);
            Store store = selectStore(cfg.getStoreType(), installed, cl);
            Set<String> storeNames = new LinkedHashSet<>(installed.keySet());
            storeNames.add(store.name());
            Object settings = storeBlock(store, cfg.getStoreBlocks(), storeNames, store.settingsType(), "");
            storeBlock(store, defaults.getStoreBlocks(), storeNames, Void.class, "dataset-defaults.", false);

            // ---- datasets
            Map<String, Meta> metas = new LinkedHashMap<>();
            Map<String, DatasetSpec<?>> specs = new LinkedHashMap<>();
            Map<String, DatasetConfig> effective = new LinkedHashMap<>();
            for (Map.Entry<String, DatasetConfig> e : cfg.getDatasets().entrySet()) {
                String name = e.getKey();
                require(DATASET.matcher(name).matches(), "dataset name '" + name + "' must match " + DATASET);
                String where = "datasets." + name;
                storeBlock(store, e.getValue().getStoreBlocks(), storeNames, Void.class, where + ".", false);
                DatasetConfig dc = e.getValue().over(defaults);              // effective settings
                Class<?> value = load(requireText(dc.getValue(), where + ".value"), cl, where + ".value");
                require(Model.isDomainClass(value) && !value.isInterface() && !value.isEnum()
                        && !Modifier.isAbstract(value.getModifiers()), where + ".value must be a concrete domain class");
                int splits = dc.getSplits() == null ? 0 : dc.getSplits();
                require(splits >= 0, where + ".splits must be >= 0");
                Object dsSettings = storeBlock(store, dc.getStoreBlocks(), storeNames, store.datasetSettingsType(),
                        where + ".", true);
                StorageMode mode = dc.getStorageMode() != null ? dc.getStorageMode() : StorageMode.REFERENCE;
                Meta meta = meta(name, value, dc, mode, cl, where);
                meta.onMissingTarget = dc.getOnMissingTarget() != null ? dc.getOnMissingTarget() : OnMissingTarget.FAIL;
                meta.requireComplete = Boolean.TRUE.equals(dc.getRequireComplete());
                meta.localCache = Boolean.TRUE.equals(dc.getLocalCache());
                Resolve policy = dc.getLookupResolvePolicy();
                meta.defaultPolicy = policy == Resolve.EAGER ? Resolve.EAGER : Resolve.LAZY;
                metas.put(name, meta);
                specs.put(name, spec(name, meta, splits, dsSettings, false));
                effective.put(name, dc);
            }
            Meta manifestMeta = new Meta(Manifest.DATASET, Manifest.Entry.class, KeyCodec.of(String.class),
                    StorageMode.EMBEDDED, o -> ((Manifest.Entry) o).dataset(), "@Id", true);
            metas.put(Manifest.DATASET, manifestMeta);
            specs.put(Manifest.DATASET, spec(Manifest.DATASET, manifestMeta, 1, null, true));

            // ---- lookups
            for (Meta m : metas.values()) {
                if (!m.internal) {
                    buildLinks(m, effective.get(m.name), metas);
                }
            }
            metas.values().forEach(Meta::seal);

            // ---- codec
            Set<Class<?>> classes = new LinkedHashSet<>();
            List<Class<?>> roots = new ArrayList<>();
            for (Meta m : metas.values()) {
                roots.add(m.valueType);
                roots.add(m.keys.type());
            }
            classes.addAll(Model.reachable(roots));
            classes.add(Manifest.Entry.class);
            classes.add(Manifest.Status.class);
            for (String extra : cfg.getExtraClasses()) {
                classes.add(load(extra, cl, "extra-classes"));
            }
            List<Class<?>> ordered = classes.stream().distinct().sorted(Comparator.comparing(Class::getName)).toList();
            ThreadSafeFory plain = fory(ordered, false);
            ThreadSafeFory refs = fory(ordered, true);
            for (Meta m : metas.values()) {
                m.fory = m.mode == StorageMode.EMBEDDED ? refs : plain;
            }

            // ---- start the store
            ExecutorService executor = null;
            AutoCloseable lock = null;
            try {
                store.init(cfg.getNamespace(), settings, List.copyOf(specs.values()));
                lock = store.lock(partition, false);
                require(lock != null, "Could not take the shared lock for partition " + partition);
                executor = ld.getParallelism() > 1 ? Executors.newFixedThreadPool(ld.getParallelism(), daemons()) : null;
                DataStore ds = new DataStore(cfg, partition, store, metas, specs, lock, executor);
                LOG.info("DataStore started: store={} namespace={} partition={}", store.name(), cfg.getNamespace(),
                        partition);
                for (Meta m : metas.values()) {
                    if (!m.internal) {
                        DatasetSpec<?> sp = specs.get(m.name);
                        LOG.info("  {} : {} key={} id={} storage-mode={} lookup-resolve-policy={} on-missing-target={} "
                                        + "require-complete={} local-cache={} splits={} {}={}", m.name,
                                m.valueType.getSimpleName(), m.keys.type().getSimpleName(), m.idSource, m.mode,
                                m.defaultPolicy, m.onMissingTarget, m.requireComplete, m.localCache,
                                sp.splits() == 0 ? "store default" : sp.splits(), store.name(),
                                effective.get(m.name).getStoreBlocks().getOrDefault(store.name(), Map.of()));
                        m.links.forEach(l -> LOG.info("    lookup {}", l));
                    }
                }
                return ds;
            } catch (RuntimeException e) {
                if (executor != null) {
                    executor.shutdownNow();
                }
                if (lock != null) {
                    closeQuietly(lock);
                }
                store.close();
                throw e;
            }
        }

        // ---------------------------------------------------------------- partition

        private String partition(DataStoreConfig cfg) {
            if (partitionOverride != null) {
                require(PARTITION.matcher(partitionOverride).matches(),
                        "partition '" + partitionOverride + "' must be parts of [A-Za-z0-9-] joined with _");
                return partitionOverride;
            }
            Map<String, String> parts = cfg.getPartition().getParts();
            require(!parts.isEmpty(), "partition.parts is required (e.g. business-date: ${RUN_DATE})");
            List<String> values = new ArrayList<>();
            parts.forEach((k, v) -> {
                require(v != null && PART.matcher(v).matches(),
                        "partition part '" + k + "' = '" + v + "' must be non-empty [A-Za-z0-9-]");
                values.add(v);
            });
            return String.join("_", values);
        }

        // ---------------------------------------------------------------- stores

        private static Map<String, Store> installedStores(ClassLoader cl) {
            Map<String, Store> out = new LinkedHashMap<>();
            for (Store s : ServiceLoader.load(Store.class, cl)) {
                out.putIfAbsent(s.name(), s);
            }
            return out;
        }

        private static Store selectStore(String name, Map<String, Store> installed, ClassLoader cl) {
            require(name != null && !name.isBlank(), "store is required");
            Store s = installed.get(name);
            if (s != null) {
                return s;
            }
            if (name.contains(".")) {
                try {
                    Object o = Class.forName(name, true, cl).getDeclaredConstructor().newInstance();
                    if (o instanceof Store custom) {
                        return custom;
                    }
                    throw new DataStoreException(name + " does not implement " + Store.class.getName());
                } catch (ReflectiveOperationException e) {
                    throw new DataStoreException("Cannot create store " + name, e);
                }
            }
            throw new DataStoreException("store '" + name + "' is not on the classpath (installed: " + installed.keySet()
                    + "). Add com.acme.datastore:data-store-" + name + ", or give a Store class name.");
        }

        private static Object storeBlock(Store store, Map<String, Object> blocks, Set<String> storeNames,
                                         Class<?> type, String prefix) {
            return storeBlock(store, blocks, storeNames, type, prefix, true);
        }

        /** Validates the store block names at one level and (if {@code bind}) binds the active store's block. */
        private static Object storeBlock(Store store, Map<String, Object> blocks, Set<String> storeNames,
                                         Class<?> type, String prefix, boolean bind) {
            for (String key : blocks.keySet()) {
                require(storeNames.contains(key), "Unknown setting '" + prefix + key + "' (not a field, and no store "
                        + "named '" + key + "' is installed; stores: " + storeNames + ")");
            }
            if (!bind) {
                return null;
            }
            Object raw = blocks.get(store.name());
            if (type == Void.class) {
                require(raw == null, "Store '" + store.name() + "' takes no settings, but '" + prefix + store.name()
                        + "' is set");
                return null;
            }
            return DataStoreConfig.bind(raw, type, prefix + store.name());
        }

        // ---------------------------------------------------------------- datasets

        private static Meta meta(String name, Class<?> value, DatasetConfig dc, StorageMode mode, ClassLoader cl,
                                 String where) {
            Class<?> configuredKey = dc.getKey() == null ? null : load(dc.getKey(), cl, where + ".key");
            Object id = dc.getId();
            if (id instanceof List<?> list) {
                require(!list.isEmpty(), where + ".id is empty");
                require(configuredKey != null, where + ".key is required when id lists several fields");
                KeyCodec<?> keys = KeyCodec.of(configuredKey);
                require(keys.componentNames().size() == list.size(), where + ".id lists " + list.size()
                        + " fields but key " + configuredKey.getSimpleName() + " has " + keys.componentNames().size()
                        + " components " + keys.componentNames());
                List<Field> fields = new ArrayList<>();
                for (int i = 0; i < list.size(); i++) {
                    Field f = Model.requireField(value, String.valueOf(list.get(i)), where + ".id");
                    require(Model.box(f.getType()) == Model.box(keys.componentTypes().get(i)), where + ".id: field '"
                            + f.getName() + "' is " + f.getType().getSimpleName() + " but key component '"
                            + keys.componentNames().get(i) + "' is " + keys.componentTypes().get(i).getSimpleName());
                    fields.add(f);
                }
                Function<Object, Object> reader = o -> {
                    Object[] vals = new Object[fields.size()];
                    for (int i = 0; i < vals.length; i++) {
                        vals[i] = Model.get(fields.get(i), o);
                    }
                    return keys.construct(vals);
                };
                return new Meta(name, value, keys, mode, reader, "yaml " + list, false);
            }
            Field idField;
            String idSource;
            if (id != null) {
                String f = String.valueOf(id);
                require(!f.contains("."), where + ".id must be a field of " + value.getSimpleName() + " (no path)");
                idField = Model.requireField(value, f, where + ".id");
                idSource = "yaml " + f;
            } else {
                List<Field> annotated = Model.fields(value).stream().filter(f -> f.isAnnotationPresent(Id.class)).toList();
                require(annotated.size() == 1, annotated.isEmpty()
                        ? where + ": no id: set 'id:' in the dataset or put @Id on one field of " + value.getName()
                        : where + ": " + value.getName() + " has several @Id fields");
                idField = annotated.get(0);
                idSource = "@Id " + idField.getName();
            }
            Class<?> keyType = configuredKey != null ? configuredKey : Model.box(idField.getType());
            require(Model.box(idField.getType()) == keyType, where + ": id field '" + idField.getName() + "' is "
                    + idField.getType().getSimpleName() + " but key is " + keyType.getSimpleName());
            KeyCodec<?> keys = KeyCodec.of(keyType);
            return new Meta(name, value, keys, mode, o -> Model.get(idField, o), idSource, false);
        }

        private static DatasetSpec<?> spec(String name, Meta m, int splits, Object settings, boolean internal) {
            return new DatasetSpec<>(name, m.valueType, m.keys, splits, settings, internal);
        }

        // ---------------------------------------------------------------- lookups

        private static void buildLinks(Meta m, DatasetConfig dc, Map<String, Meta> metas) {
            String where = "datasets." + m.name + ".lookups";
            Map<String, Link> byField = new LinkedHashMap<>();
            for (LookupConfig lc : dc.getLookups()) {
                String field = requireText(lc.getField(), where + ".field");
                requireText(lc.getTarget(), where + "[" + field + "].target");
                String[] seg = field.split("\\.");
                List<Field> path = new ArrayList<>();
                Class<?> c = m.valueType;
                for (int i = 0; i < seg.length - 1; i++) {
                    Field step = Model.requireField(c, seg[i], where + "[" + field + "]");
                    path.add(step);
                    c = Model.elementType(step.getGenericType());
                    require(Model.isDomainClass(c), where + "[" + field + "]: '" + seg[i] + "' is not a domain object");
                }
                Field idField = Model.requireField(c, seg[seg.length - 1], where + "[" + field + "]");
                Field into = intoField(c, path, lc.getInto(), where + "[" + field + "].into");
                Link l = new Link(m, name(lc.getName(), path, into, idField), path, idField, into, lc.getTarget(),
                        null, lc.getLookupResolvePolicy(), "yaml");
                byField.put(l.fieldPath(), l);
            }
            Model.annotatedLookups(m.valueType, al -> {
                Lookup a = al.annotation();
                Class<?> holder = al.path().isEmpty() ? m.valueType
                        : Model.elementType(al.path().get(al.path().size() - 1).getGenericType());
                String w = "@Lookup on " + al.idField().getDeclaringClass().getSimpleName() + "." + al.idField().getName();
                require(a.dataset().isEmpty() != (a.target() == void.class), w + ": set exactly one of dataset/target");
                Field into = a.into().isEmpty() ? null : Model.requireField(holder, a.into(), w + " into");
                Link l = new Link(m, name(a.name(), al.path(), into, al.idField()), al.path(), al.idField(), into,
                        a.dataset().isEmpty() ? null : a.dataset(), a.target() == void.class ? null : a.target(),
                        a.resolvePolicy(), "annotation");
                Link yaml = byField.get(l.fieldPath());
                if (yaml == null) {
                    byField.put(l.fieldPath(), l);
                } else {
                    String annTarget = l.targetName != null ? l.targetName : datasetFor(l.targetType, metas, w);
                    require(annTarget.equals(yaml.targetName) && java.util.Objects.equals(l.into, yaml.into),
                            m.name + "." + l.fieldPath() + " is configured differently in YAML and @Lookup");
                    if (yaml.resolve == Resolve.DEFAULT) {
                        yaml.resolve = l.resolve;
                    }
                }
            });
            for (Link l : byField.values()) {
                String w = "Lookup " + m.name + "." + l.fieldPath() + " [" + l.source + "]";
                String targetName = l.targetName != null ? l.targetName : datasetFor(l.targetType, metas, w);
                Meta target = metas.get(targetName);
                require(target != null && !target.internal, w + ": unknown target dataset '" + targetName + "'");
                l.target = target;
                Class<?> idType = l.many ? Model.elementType(l.idField.getGenericType()) : Model.box(l.idField.getType());
                require(idType == target.keys.type(), w + ": id type " + (idType == null ? "?" : idType.getSimpleName())
                        + " does not match key " + target.keys.type().getSimpleName() + " of dataset '" + targetName + "'");
                if (l.into != null) {
                    require(!Modifier.isFinal(l.into.getModifiers()), w + ": into field '" + l.into.getName()
                            + "' must not be final");
                    if (l.many) {
                        require(Model.isCollection(l.into.getGenericType())
                                && Model.elementType(l.into.getGenericType()) == target.valueType,
                                w + ": into '" + l.into.getName() + "' must be a collection of " + target.valueType.getSimpleName());
                    } else {
                        require(l.into.getType().isAssignableFrom(target.valueType), w + ": into '" + l.into.getName()
                                + "' is " + l.into.getType().getSimpleName() + ", target is " + target.valueType.getSimpleName());
                    }
                    if (m.mode == StorageMode.REFERENCE) {
                        requireCopyable(m.valueType, w);
                        for (Field step : l.path) {
                            requireCopyable(Model.elementType(step.getGenericType()), w);
                        }
                    }
                }
                if (l.resolve == Resolve.DEFAULT) {
                    l.resolve = m.defaultPolicy;          // dataset, then dataset-defaults, then LAZY
                }
                require(l.resolve != Resolve.EAGER || l.into != null, w + ": EAGER needs an 'into' field to fill");
                require(m.byName.putIfAbsent(l.name, l) == null, w + ": duplicate lookup name '" + l.name + "'");
                m.links.add(l);
            }
        }

        private static Field intoField(Class<?> holder, List<Field> path, String into, String where) {
            if (into == null || into.isBlank()) {
                return null;
            }
            String name = into;
            if (into.contains(".")) {
                String prefix = Model.pathString(path, "");
                require(into.startsWith(prefix) && !into.substring(prefix.length()).contains("."),
                        where + ": '" + into + "' must be a sibling of the id field (" + prefix + "<field>)");
                name = into.substring(prefix.length());
            }
            return Model.requireField(holder, name, where);
        }

        private static String name(String explicit, List<Field> path, Field into, Field idField) {
            if (explicit != null && !explicit.isBlank()) {
                return explicit;
            }
            return Model.pathString(path, into != null ? into.getName() : idField.getName());
        }

        private static String datasetFor(Class<?> type, Map<String, Meta> metas, String where) {
            List<String> hits = new ArrayList<>();
            metas.values().forEach(m -> {
                if (m.valueType == type && !m.internal) {
                    hits.add(m.name);
                }
            });
            require(hits.size() == 1, where + ": target " + type.getSimpleName() + (hits.isEmpty()
                    ? " is not the value of any dataset" : " is the value of several datasets " + hits + "; use dataset="));
            return hits.get(0);
        }

        private static void requireCopyable(Class<?> c, String where) {
            require(c != null && !c.isRecord() && Model.hasNoArgConstructor(c), where + ": "
                    + (c == null ? "?" : c.getSimpleName()) + " needs a no-arg constructor (and must not be a record) so "
                    + "REFERENCE mode can leave into fields out without touching your objects");
        }

        // ---------------------------------------------------------------- misc

        private static ThreadSafeFory fory(Collection<Class<?>> classes, boolean refs) {
            ThreadSafeFory f = Fory.builder()
                    .withLanguage(Language.JAVA)
                    .requireClassRegistration(true)
                    .withRefTracking(refs)
                    .buildThreadSafeFory();
            classes.forEach(f::register);
            return f;
        }

        private static Class<?> load(String name, ClassLoader cl, String where) {
            try {
                return Class.forName(name.trim(), true, cl);
            } catch (ClassNotFoundException e) {
                throw new DataStoreException(where + ": class " + name + " not found", e);
            }
        }

        private static String requireText(String s, String what) {
            require(s != null && !s.isBlank(), what + " is required");
            return s;
        }

        private static void require(boolean ok, String message) {
            if (!ok) {
                throw new DataStoreException(message);
            }
        }

        private static java.util.concurrent.ThreadFactory daemons() {
            AtomicInteger n = new AtomicInteger();
            return r -> {
                Thread t = new Thread(r, "datastore-lookup-" + n.incrementAndGet());
                t.setDaemon(true);
                return t;
            };
        }

        /** {@code ${NAME}} / {@code ${NAME:default}} from system properties, then environment variables. */
        static String resolvePlaceholders(String text) {
            StringBuilder out = new StringBuilder(text.length());
            int i = 0;
            while (i < text.length()) {
                int start = text.indexOf("${", i);
                if (start < 0) {
                    out.append(text, i, text.length());
                    break;
                }
                int end = text.indexOf('}', start);
                require(end > 0, "Unclosed placeholder at offset " + start);
                out.append(text, i, start);
                String expr = text.substring(start + 2, end);
                int colon = expr.indexOf(':');
                String key = colon < 0 ? expr : expr.substring(0, colon);
                String value = System.getProperty(key, System.getenv(key));
                if (value == null && colon >= 0) {
                    value = expr.substring(colon + 1);
                }
                require(value != null, "Unresolved placeholder ${" + key + "}");
                out.append(value);
                i = end + 1;
            }
            return out.toString();
        }
    }
}
