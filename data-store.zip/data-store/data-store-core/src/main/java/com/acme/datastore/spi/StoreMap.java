package com.acme.datastore.spi;

import java.util.Collection;
import java.util.Map;
import java.util.stream.Stream;

/**
 * One dataset of one partition: keys to encoded values. Must be thread-safe.
 * Missing keys return null from {@link #get} and are absent from {@link #getAll}.
 */
public interface StoreMap<K> extends AutoCloseable {

    byte[] get(K key);

    /** Bulk read; must not make one remote call per key. */
    Map<K, byte[]> getAll(Collection<K> keys);

    void put(K key, byte[] value);

    void putAll(Map<K, byte[]> entries);

    boolean remove(K key);

    long size();

    /** Number of disjoint parallel scan splits; {@code scan(0..splits-1)} together cover the dataset once. */
    int splits();

    /** Entries of one split. Callers close the stream. */
    Stream<Map.Entry<K, byte[]>> scan(int split);

    void clear();

    @Override
    void close();
}
