package com.acme.datastore.lookup;

import com.acme.datastore.DataStoreException;
import com.acme.datastore.config.DataStoreConfig.LookupResolverConfig;
import com.acme.datastore.config.DataStoreConfig.OnMissingTarget;
import com.acme.datastore.config.DataStoreConfig.StorageMode;
import com.acme.datastore.internal.Model;
import com.acme.datastore.internal.Model.Link;
import com.acme.datastore.internal.Model.Meta;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionException;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;

/**
 * Resolves lookups for a page of objects, in bulk: one call per target dataset per level, different
 * datasets of a level in parallel. Whatever is resolved is resolved to full depth (each target's own
 * lookups, and theirs, ...), reusing objects already loaded, so cycles terminate. Resolved objects are
 * written into the {@code into} fields of the page's objects.
 *
 * <pre>{@code
 * lookups.resolve(page);                              // every lookup, full depth
 * lookups.resolve(page, "customer", "lines.product"); // named lookups (each still full depth)
 * LookupResult<Order> r = lookups.scope(page);        // nothing yet; r.get(order, "customer") loads that
 *                                                     // lookup for the whole page on first use
 * }</pre>
 *
 * The dataset of a page is found from its element class; when one class backs several datasets, pass the
 * dataset name ({@code resolve("order-snapshot", page)}).
 */
public final class LookupResolver {

    private static final Logger LOG = LoggerFactory.getLogger(LookupResolver.class);

    /** What the resolver needs from the data store. Implemented by {@code DataStore}; not for applications. */
    public interface Backend {
        Meta meta(String dataset);

        String datasetOf(Class<?> type);

        /** Decoded values by id, without resolving their lookups. */
        Map<Object, Object> fetch(Meta dataset, Set<Object> ids);

        /** Throws if the dataset is not COMPLETE in the manifest. */
        void requireComplete(String dataset);
    }

    private final Backend backend;
    private final LookupResolverConfig config;
    private final ExecutorService executor;
    private final Set<String> confirmedComplete = ConcurrentHashMap.newKeySet();

    /** Created by {@code DataStore}. */
    public LookupResolver(Backend backend, LookupResolverConfig config, ExecutorService executor) {
        this.backend = backend;
        this.config = config;
        this.executor = executor;
    }

    /** Resolves {@code lookups} (all if none named) for the page and hydrates their into fields. */
    public <T> LookupResult<T> resolve(Collection<T> page, String... lookups) {
        return resolve(datasetOf(page), page, lookups);
    }

    public <T> LookupResult<T> resolve(String dataset, Collection<T> page, String... lookups) {
        LookupResult<T> r = scope(dataset, page);
        Meta meta = backend.meta(dataset);
        r.ensure(lookups.length == 0 ? meta.links : named(meta, lookups));
        return r;
    }

    /** Single object: same as {@code resolve(List.of(value))}. */
    public <T> T resolve(T value, String... lookups) {
        resolve(List.of(value), lookups);
        return value;
    }

    /** Lazy scope: loads each lookup for the whole page on first {@link LookupResult#get}. */
    public <T> LookupResult<T> scope(Collection<T> page) {
        return scope(datasetOf(page), page);
    }

    public <T> LookupResult<T> scope(String dataset, Collection<T> page) {
        return new LookupResult<>(this, backend.meta(dataset), new ArrayList<>(page));
    }

    /** Internal (used by {@code Dao}): applies {@code links} to freshly read objects of one dataset. */
    public void apply(Meta meta, List<?> objects, Collection<Link> links) {
        if (!links.isEmpty() && !objects.isEmpty()) {
            run(meta, objects, links, new State());
        }
    }

    // ------------------------------------------------------------------ engine

    /** Per call (or per LookupResult) state: everything loaded so far, by dataset and id. */
    static final class State {
        final Map<Meta, Map<Object, Object>> loaded = new HashMap<>();
        final Set<Link> appliedToRoots = new HashSet<>();

        Map<Object, Object> of(Meta m) {
            return loaded.computeIfAbsent(m, k -> new HashMap<>());
        }
    }

    private record Work(Meta meta, List<?> objects, Collection<Link> links) {
    }

    /**
     * Applies {@code links} to {@code roots}; every object fetched on the way gets all of its own links
     * (full depth). Ends when a level brings no new ids.
     */
    void run(Meta rootMeta, List<?> roots, Collection<Link> links, State st) {
        Map<Object, Object> rootsById = st.of(rootMeta);
        for (Object o : roots) {
            rootsById.putIfAbsent(rootMeta.id(o), o);   // a lookup back to a page object reuses it
        }
        List<Work> level = List.of(new Work(rootMeta, roots, links));
        List<Work> done = new ArrayList<>();
        int depth = 0;
        while (!level.isEmpty()) {
            if (config.getMaxDepth() > 0 && depth >= config.getMaxDepth()) {
                LOG.debug("Lookup resolution of '{}' stopped at max-depth {}", rootMeta.name, config.getMaxDepth());
                break;
            }
            Map<Meta, Set<Object>> wanted = new LinkedHashMap<>();
            for (Work w : level) {
                for (Link l : w.links()) {
                    Map<Object, Object> have = st.of(l.target);
                    Set<Object> ids = wanted.computeIfAbsent(l.target, k -> new LinkedHashSet<>());
                    Class<?> keyType = l.target.keys.type();
                    for (Object o : w.objects()) {
                        l.owners(o, holder -> {
                            if (keepsEmbedded(l, holder)) {
                                return;
                            }
                            l.ids(holder, id -> {
                                if (!keyType.isInstance(id)) {
                                    throw new DataStoreException("Lookup " + l + ": id " + id + " ("
                                            + id.getClass().getSimpleName() + ") is not a " + keyType.getSimpleName());
                                }
                                if (!have.containsKey(id)) {
                                    ids.add(id);
                                }
                            });
                        });
                    }
                }
            }
            wanted.values().removeIf(Set::isEmpty);
            done.addAll(level);

            Map<Meta, Map<Object, Object>> fetched = fetch(wanted);
            List<Work> next = new ArrayList<>();
            for (Map.Entry<Meta, Set<Object>> e : wanted.entrySet()) {
                Meta target = e.getKey();
                Map<Object, Object> found = fetched.getOrDefault(target, Map.of());
                checkMissing(target, e.getValue(), found);
                Map<Object, Object> have = st.of(target);
                for (Object id : e.getValue()) {
                    have.put(id, found.containsKey(id) ? found.get(id) : Model.MISSING);
                }
                if (!found.isEmpty() && !target.links.isEmpty()) {
                    next.add(new Work(target, new ArrayList<>(found.values()), target.links));
                }
            }
            level = next;
            depth++;
        }
        for (Work w : done) {
            for (Link l : w.links()) {
                if (l.into != null) {
                    Map<Object, Object> byId = st.of(l.target);
                    for (Object o : w.objects()) {
                        l.owners(o, holder -> {
                            if (!keepsEmbedded(l, holder)) {
                                l.hydrate(holder, byId);
                            }
                        });
                    }
                }
            }
        }
        st.appliedToRoots.addAll(links);
    }

    /** EMBEDDED datasets already carry their members: only empty into fields are resolved. */
    private static boolean keepsEmbedded(Link l, Object holder) {
        return l.owner.mode == StorageMode.EMBEDDED && l.into != null && Model.get(l.into, holder) != null;
    }

    private Map<Meta, Map<Object, Object>> fetch(Map<Meta, Set<Object>> wanted) {
        Map<Meta, Map<Object, Object>> out = new HashMap<>();
        if (wanted.isEmpty()) {
            return out;
        }
        if (wanted.size() == 1 || executor == null) {
            wanted.forEach((m, ids) -> out.put(m, fetchOne(m, ids)));
            return out;
        }
        Map<Meta, CompletableFuture<Map<Object, Object>>> futures = new LinkedHashMap<>();
        wanted.forEach((m, ids) -> futures.put(m, CompletableFuture.supplyAsync(() -> fetchOne(m, ids), executor)));
        try {
            CompletableFuture.allOf(futures.values().toArray(CompletableFuture[]::new)).join();
        } catch (CompletionException e) {
            if (e.getCause() instanceof RuntimeException re) {
                throw re;
            }
            throw e;
        }
        futures.forEach((m, f) -> out.put(m, f.join()));
        return out;
    }

    private Map<Object, Object> fetchOne(Meta m, Set<Object> ids) {
        if (m.requireComplete && confirmedComplete.add(m.name)) {
            try {
                backend.requireComplete(m.name);
            } catch (RuntimeException e) {
                confirmedComplete.remove(m.name);
                throw e;
            }
        }
        return backend.fetch(m, ids);
    }

    /** {@code on-missing-target} of the target dataset decides. */
    private static void checkMissing(Meta target, Set<Object> asked, Map<Object, Object> found) {
        if (target.onMissingTarget != OnMissingTarget.FAIL || found.size() == asked.size()) {
            return;
        }
        List<Object> sample = new ArrayList<>();
        for (Object id : asked) {
            if (!found.containsKey(id) && sample.size() < 10) {
                sample.add(id);
            }
        }
        throw new DataStoreException((asked.size() - found.size()) + " lookup id(s) not found in dataset '"
                + target.name + "', e.g. " + sample
                + " (did the upstream job finish? on-missing-target: NULL tolerates this)");
    }

    // ------------------------------------------------------------------ helpers

    Meta meta(String dataset) {
        return backend.meta(dataset);
    }

    Link link(Meta meta, String name) {
        Link l = meta.byName.get(name);
        if (l == null) {
            throw new DataStoreException("Dataset '" + meta.name + "' has no lookup '" + name + "'; lookups: "
                    + meta.byName.keySet());
        }
        return l;
    }

    private List<Link> named(Meta meta, String... names) {
        List<Link> out = new ArrayList<>();
        for (String n : names) {
            out.add(link(meta, n));
        }
        return out;
    }

    private String datasetOf(Collection<?> page) {
        if (page.isEmpty()) {
            throw new DataStoreException("Empty page: pass the dataset name, e.g. resolve(\"order\", page)");
        }
        return backend.datasetOf(page.iterator().next().getClass());
    }
}
