package com.acme.datastore.annotation;

/**
 * When lookups are resolved.
 *
 * <ul>
 *   <li>In configuration ({@code lookup-resolve-policy:} on a lookup, a dataset or {@code dataset-defaults}):
 *       {@link #EAGER} fills the lookup's {@code into} field on every DAO read; {@link #LAZY} leaves it
 *       until the job asks through {@link com.acme.datastore.lookup.LookupResolver}. {@link #DEFAULT} inherits the next level up.</li>
 *   <li>As a per-call override on DAO reads: {@link #DEFAULT} uses the configured policies,
 *       {@link #EAGER} resolves every lookup, {@link #LAZY} resolves none.</li>
 * </ul>
 *
 * Whenever a lookup is resolved, the whole graph below it is resolved too, to any depth.
 */
public enum Resolve {
    DEFAULT,
    EAGER,
    LAZY
}
