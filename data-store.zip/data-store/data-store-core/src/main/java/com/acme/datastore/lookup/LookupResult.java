package com.acme.datastore.lookup;

import com.acme.datastore.internal.Model;
import com.acme.datastore.internal.Model.Link;
import com.acme.datastore.internal.Model.Meta;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Lookups of one page. Anything not yet resolved is resolved on first use, for the whole page in bulk
 * (and to full depth). Page-scoped and not thread-safe: use it from the thread processing the page.
 */
public final class LookupResult<T> {

    private final LookupResolver resolver;
    private final Meta meta;
    private final List<T> items;
    private final LookupResolver.State state = new LookupResolver.State();

    LookupResult(LookupResolver resolver, Meta meta, List<T> items) {
        this.resolver = resolver;
        this.meta = meta;
        this.items = items;
    }

    public List<T> items() {
        return Collections.unmodifiableList(items);
    }

    /**
     * The resolved value of lookup {@code name} for {@code item}: the target object, a List of targets for
     * an id collection, or null. For lookups inside nested objects ({@code lines.product}) use
     * {@link #target}/{@link #all} or the hydrated into fields.
     */
    @SuppressWarnings("unchecked")
    public <X> X get(T item, String name) {
        Link l = resolver.link(meta, name);
        ensure(List.of(l));
        List<Object> values = new ArrayList<>();
        l.owners(item, holder -> values.add(l.valueFor(holder, state.of(l.target))));
        if (l.path.isEmpty()) {
            return (X) values.get(0);
        }
        return (X) values;
    }

    /** A resolved object of dataset {@code dataset} by id (null if not loaded or missing). */
    @SuppressWarnings("unchecked")
    public <X> X target(String dataset, Object id) {
        Map<Object, Object> byId = state.loaded.get(resolver.meta(dataset));
        return byId == null ? null : (X) Model.present(byId.get(id));
    }

    /** Every resolved object of {@code dataset} in this page, by id. */
    @SuppressWarnings("unchecked")
    public <X> Map<Object, X> all(String dataset) {
        Map<Object, Object> byId = state.loaded.get(resolver.meta(dataset));
        Map<Object, X> out = new LinkedHashMap<>();
        if (byId != null) {
            byId.forEach((k, v) -> {
                if (v != Model.MISSING) {
                    out.put(k, (X) v);
                }
            });
        }
        return out;
    }

    void ensure(Collection<Link> links) {
        List<Link> todo = new ArrayList<>();
        for (Link l : links) {
            if (!state.appliedToRoots.contains(l)) {
                todo.add(l);
            }
        }
        if (!todo.isEmpty() && !items.isEmpty()) {
            resolver.run(meta, items, todo, state);
        }
    }
}
