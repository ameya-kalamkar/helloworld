package com.acme.datastore.spi;

import java.util.Collection;
import java.util.List;

/**
 * A storage backend. Implement this (plus {@link StoreMap}) to add a custom store; nothing else is needed.
 *
 * <p>Selected by {@code datastore.store-type}: either its {@link #name()} (discovered with
 * {@link java.util.ServiceLoader} from {@code META-INF/services/com.acme.datastore.spi.Store}) or the
 * fully-qualified class name (public no-arg constructor, no registration file needed).
 *
 * <p>Stores only ever see <b>encoded values</b> ({@code byte[]}); serialization, storage modes and
 * lookups are handled by the core. Keys arrive as key objects; use {@link DatasetSpec#keyCodec()}
 * for deterministic bytes, field values or a stable hash.
 *
 * <p>Verify an implementation by extending {@code com.acme.datastore.testing.DataStoreContractTest}
 * from the core test fixtures.
 */
public interface Store extends AutoCloseable {

    /** Name used in {@code store-type:} and as the name of this store's config blocks. */
    String name();

    /**
     * Class bound from the store-level block ({@code datastore.<name>:}); unknown keys are rejected.
     * {@code Void.class} = this store takes no settings (a block is then an error).
     */
    default Class<?> settingsType() {
        return Void.class;
    }

    /** Class bound from each dataset's {@code <name>:} block, merged over {@code dataset-defaults.<name>:};
     * {@code Void.class} = none. */
    default Class<?> datasetSettingsType() {
        return Void.class;
    }

    /**
     * Called once, before anything else. Validate here and fail fast.
     *
     * @param settings bound instance of {@link #settingsType()} (default-constructed if the block is absent),
     *                 or null for {@code Void}
     */
    void init(String namespace, Object settings, Collection<DatasetSpec<?>> datasets);

    /**
     * Opens one dataset of one partition.
     *
     * @param create true: create if missing (lifecycle step); false: fail if it was not created
     */
    <K> StoreMap<K> open(DatasetSpec<K> dataset, String partition, boolean create);

    /** Partitions that currently hold data in this namespace, sorted. */
    List<String> partitions();

    /** Deletes every dataset of {@code partition}. The caller holds the exclusive lock. */
    void destroy(String partition);

    /**
     * Guards a partition while jobs use it. Jobs hold a shared lock; destroy takes the exclusive one.
     *
     * @return the held lock, or null if {@code exclusive} was requested and the partition is in use
     */
    default AutoCloseable lock(String partition, boolean exclusive) {
        return () -> { };
    }

    @Override
    void close();
}
