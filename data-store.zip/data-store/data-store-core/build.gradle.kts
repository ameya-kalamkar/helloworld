plugins {
    `java-test-fixtures`
}

dependencies {
    api(libs.spring.context)
    api(platform(libs.jackson.bom))
    implementation(libs.jackson.databind)
    implementation(libs.jackson.yaml)
    implementation(libs.fory.core)
    api(libs.slf4j.api)

    // Contract tests + sample domain, published as test fixtures so every store (built-in or custom) runs them.
    testFixturesApi(platform(libs.junit.bom))
    testFixturesApi(libs.junit.jupiter)

    testImplementation(platform(libs.junit.bom))
    testImplementation(libs.junit.jupiter)
    testRuntimeOnly(libs.junit.launcher)
    testRuntimeOnly(libs.logback.classic)
}
