allprojects {
    group = "com.acme.datastore"
    version = "1.0.0-SNAPSHOT"

    repositories {
        // Replace with your Artifactory virtual repo, e.g.
        // maven { url = uri(providers.gradleProperty("artifactoryUrl").get() + "/maven-virtual") }
        mavenCentral()
    }
}

/** JVM flags Chronicle Map, Ignite 2 and Fory need on Java 17+. Reused by tests and the sample app. */
extra["storeJvmArgs"] = listOf(
    "--add-exports=java.base/jdk.internal.ref=ALL-UNNAMED",
    "--add-exports=java.base/jdk.internal.misc=ALL-UNNAMED",
    "--add-exports=java.base/sun.nio.ch=ALL-UNNAMED",
    "--add-exports=java.management/com.sun.jmx.mbeanserver=ALL-UNNAMED",
    "--add-exports=jdk.internal.jvmstat/sun.jvmstat.monitor=ALL-UNNAMED",
    "--add-exports=java.base/sun.reflect.generics.reflectiveObjects=ALL-UNNAMED",
    "--add-exports=jdk.unsupported/sun.misc=ALL-UNNAMED",
    "--add-exports=jdk.compiler/com.sun.tools.javac.file=ALL-UNNAMED",
    "--add-opens=jdk.compiler/com.sun.tools.javac=ALL-UNNAMED",
    "--add-opens=jdk.management/com.sun.management.internal=ALL-UNNAMED",
    "--add-opens=java.base/java.lang=ALL-UNNAMED",
    "--add-opens=java.base/java.lang.invoke=ALL-UNNAMED",
    "--add-opens=java.base/java.lang.reflect=ALL-UNNAMED",
    "--add-opens=java.base/java.io=ALL-UNNAMED",
    "--add-opens=java.base/java.nio=ALL-UNNAMED",
    "--add-opens=java.base/java.math=ALL-UNNAMED",
    "--add-opens=java.base/java.net=ALL-UNNAMED",
    "--add-opens=java.base/java.text=ALL-UNNAMED",
    "--add-opens=java.base/java.time=ALL-UNNAMED",
    "--add-opens=java.base/java.util=ALL-UNNAMED",
    "--add-opens=java.base/java.util.concurrent=ALL-UNNAMED",
    "--add-opens=java.base/java.util.concurrent.atomic=ALL-UNNAMED",
    "--add-opens=java.base/java.util.concurrent.locks=ALL-UNNAMED",
    "--add-opens=java.base/sun.nio.ch=ALL-UNNAMED",
    "--add-opens=java.sql/java.sql=ALL-UNNAMED",
)

// ':samples' is only a folder; every other subproject is a Java module.
configure(subprojects.filter { it.path != ":samples" }) {
    apply(plugin = "java-library")

    extensions.configure<JavaPluginExtension> {
        // Compile for Java 17 bytecode from any JDK 17+ (no toolchain download needed).
        withSourcesJar()
    }

    tasks.withType<JavaCompile>().configureEach {
        options.release.set(17)
        options.encoding = "UTF-8"
        options.compilerArgs.addAll(listOf("-parameters", "-Xlint:all,-serial,-processing"))
    }

    // Used at startup to refuse mismatched core/backend jars.
    tasks.withType<Jar>().configureEach {
        manifest {
            attributes(
                "Implementation-Title" to project.name,
                "Implementation-Version" to project.version,
            )
        }
    }

    tasks.withType<Test>().configureEach {
        useJUnitPlatform()
        @Suppress("UNCHECKED_CAST")
        jvmArgs(rootProject.extra["storeJvmArgs"] as List<String>)
    }
}

// Publish only the three library modules.
listOf("data-store-core", "data-store-chronicle", "data-store-ignite").forEach { name ->
    project(":$name") {
        apply(plugin = "maven-publish")
        extensions.configure<PublishingExtension> {
            publications {
                create<MavenPublication>("maven") {
                    from(components["java"])
                }
            }
            repositories {
                maven {
                    this.name = "artifactory"
                    this.url = uri(
                        providers.gradleProperty("artifactoryPublishUrl")
                            .orElse("https://artifactory.example.com/artifactory/libs-snapshot-local")
                    )
                    credentials {
                        username = providers.gradleProperty("artifactoryUser").orNull
                        password = providers.gradleProperty("artifactoryPassword").orNull
                    }
                }
            }
        }
    }
}
