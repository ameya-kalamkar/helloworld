dependencies {
    api(project(":data-store-core"))
    implementation(libs.chronicle.map)

    testImplementation(testFixtures(project(":data-store-core")))
    testImplementation(platform(libs.junit.bom))
    testImplementation(libs.junit.jupiter)
    testRuntimeOnly(libs.junit.launcher)
    testRuntimeOnly(libs.logback.classic)
}
