package com.acme.datastore.chronicle;

import com.acme.datastore.testing.DataStoreContractTest;

import java.nio.file.Path;

class ChronicleContractTest extends DataStoreContractTest {

    @Override
    protected String store() {
        return "chronicle";
    }

    @Override
    protected String storeBlock(Path tempDir) {
        return "chronicle:\n  base-dir: " + tempDir.resolve("grid") + "\n  default-splits: 2\n";
    }

    @Override
    protected String datasetBlock() {
        return "chronicle: { entries: 5000, avg-value-bytes: 256, avg-key-bytes: 32 }";
    }
}
