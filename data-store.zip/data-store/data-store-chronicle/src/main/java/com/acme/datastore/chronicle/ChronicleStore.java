package com.acme.datastore.chronicle;

import com.acme.datastore.DataStoreException;
import com.acme.datastore.spi.DatasetSpec;
import com.acme.datastore.spi.FileLocks;
import com.acme.datastore.spi.KeyCodec;
import com.acme.datastore.spi.Store;
import com.acme.datastore.spi.StoreMap;
import net.openhft.chronicle.map.ChronicleMap;
import net.openhft.chronicle.map.ChronicleMapBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.AbstractMap;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.regex.Pattern;
import java.util.stream.Stream;

/**
 * {@code store-type: chronicle} — memory-mapped Chronicle Map files shared by every JVM on one host. No server:
 * each JVM maps the same files. A dataset is {@code splits} map files (keys spread by a stable hash of the
 * encoded key); keys and values are stored as bytes.
 *
 * <pre>
 * datastore:
 *   store-type: chronicle
 *   chronicle:
 *     base-dir: /dev/shm/grid      # tmpfs = RAM speed; survives process crashes, not reboots
 *     default-splits: 16
 *     headroom: 1.2                # capacity per split = entries * headroom / splits
 *   datasets:
 *     order:
 *       splits: 32
 *       chronicle: { entries: 10000000, avg-value-bytes: 512, avg-key-bytes: 16 }
 * </pre>
 *
 * Files: {@code <base-dir>/<namespace>/<partition>/<dataset>/split-0000.cm}. Nothing is deleted
 * automatically; delete a whole partition directory (and its {@code .<partition>.lock}) or call
 * {@code destroyPartition}.
 */
public final class ChronicleStore implements Store {

    private static final Logger LOG = LoggerFactory.getLogger(ChronicleStore.class);
    private static final Pattern PARTITION = Pattern.compile("[A-Za-z0-9-]+(_[A-Za-z0-9-]+)*");
    private static final String META = "_dataset.properties";

    /** {@code chronicle:} at store level. */
    public static final class Settings {
        private String baseDir;
        private int defaultSplits = 16;
        private double headroom = 1.2;
        private int segmentsPerSplit;

        public String getBaseDir() {
            return baseDir;
        }

        public void setBaseDir(String baseDir) {
            this.baseDir = baseDir;
        }

        public int getDefaultSplits() {
            return defaultSplits;
        }

        public void setDefaultSplits(int defaultSplits) {
            this.defaultSplits = defaultSplits;
        }

        public double getHeadroom() {
            return headroom;
        }

        public void setHeadroom(double headroom) {
            this.headroom = headroom;
        }

        /** Chronicle segments per split map; 0 = Chronicle's default for the entry count. */
        public int getSegmentsPerSplit() {
            return segmentsPerSplit;
        }

        public void setSegmentsPerSplit(int segmentsPerSplit) {
            this.segmentsPerSplit = segmentsPerSplit;
        }
    }

    /** {@code chronicle:} inside a dataset. */
    public static final class DatasetSettings {
        private long entries;
        private int avgValueBytes;
        private int avgKeyBytes;

        /** Expected total entries (required). */
        public long getEntries() {
            return entries;
        }

        public void setEntries(long entries) {
            this.entries = entries;
        }

        /** Average encoded value size (required; measure a real day). */
        public int getAvgValueBytes() {
            return avgValueBytes;
        }

        public void setAvgValueBytes(int avgValueBytes) {
            this.avgValueBytes = avgValueBytes;
        }

        /** Average encoded key size; computed for fixed-size keys (numbers, dates), required otherwise. */
        public int getAvgKeyBytes() {
            return avgKeyBytes;
        }

        public void setAvgKeyBytes(int avgKeyBytes) {
            this.avgKeyBytes = avgKeyBytes;
        }
    }

    private Settings settings;
    private Path namespaceDir;
    private final List<ChronicleStoreMap<?>> open = new ArrayList<>();

    @Override
    public String name() {
        return "chronicle";
    }

    @Override
    public Class<?> settingsType() {
        return Settings.class;
    }

    @Override
    public Class<?> datasetSettingsType() {
        return DatasetSettings.class;
    }

    @Override
    public void init(String namespace, Object s, Collection<DatasetSpec<?>> datasets) {
        this.settings = (Settings) s;
        List<String> problems = new ArrayList<>();
        if (settings.getBaseDir() == null || settings.getBaseDir().isBlank()) {
            problems.add("chronicle.base-dir is required");
        }
        if (settings.getDefaultSplits() < 1) {
            problems.add("chronicle.default-splits must be >= 1");
        }
        if (settings.getHeadroom() < 1.0) {
            problems.add("chronicle.headroom must be >= 1.0");
        }
        for (DatasetSpec<?> d : datasets) {
            if (d.internal()) {
                continue;
            }
            DatasetSettings ds = d.settings(DatasetSettings.class);
            String p = "datasets." + d.name() + ".chronicle.";
            if (ds.getEntries() <= 0) {
                problems.add(p + "entries must be > 0");
            }
            if (ds.getAvgValueBytes() <= 0) {
                problems.add(p + "avg-value-bytes must be > 0");
            }
            if (d.keyCodec().fixedSize() < 0 && ds.getAvgKeyBytes() <= 0) {
                problems.add(p + "avg-key-bytes must be > 0 (key " + d.keyType().getSimpleName() + " has variable size)");
            }
        }
        if (!problems.isEmpty()) {
            throw new DataStoreException("Invalid Chronicle configuration: " + problems);
        }
        this.namespaceDir = Path.of(settings.getBaseDir()).toAbsolutePath().resolve(namespace);
    }

    @Override
    public synchronized <K> StoreMap<K> open(DatasetSpec<K> d, String partition, boolean create) {
        Path dir = namespaceDir.resolve(partition).resolve(d.name());
        int splits = splits(d, dir, partition, create);
        DatasetSettings ds = d.internal() ? internal() : d.settings(DatasetSettings.class);
        long perSplit = Math.max(16, (long) Math.ceil(ds.getEntries() * settings.getHeadroom() / splits));
        int fixed = d.keyCodec().fixedSize();
        int keyBytes = fixed > 0 ? fixed : ds.getAvgKeyBytes();
        ChronicleStoreMap<K> map = new ChronicleStoreMap<>(d, dir, splits, perSplit, keyBytes, fixed > 0,
                ds.getAvgValueBytes(), settings.getSegmentsPerSplit());
        open.add(map);
        return map;
    }

    private static DatasetSettings internal() {
        DatasetSettings s = new DatasetSettings();
        s.setEntries(1_000);
        s.setAvgKeyBytes(32);
        s.setAvgValueBytes(256);
        return s;
    }

    /** The split count is fixed when the dataset is created; later JVMs read it back. */
    private int splits(DatasetSpec<?> d, Path dir, String partition, boolean create) {
        Path meta = dir.resolve(META);
        if (Files.exists(meta)) {
            Properties p = new Properties();
            try (InputStream in = Files.newInputStream(meta)) {
                p.load(in);
            } catch (IOException e) {
                throw new DataStoreException("Cannot read " + meta, e);
            }
            int stored = Integer.parseInt(p.getProperty("splits"));
            String fp = p.getProperty("key-fingerprint");
            if (fp != null && !fp.equals(d.keyCodec().fingerprint())) {
                throw new DataStoreException("Dataset '" + d.name() + "' in " + partition + " was written with a different "
                        + "key class layout; use a new partition or namespace after changing " + d.keyType().getName());
            }
            if (d.splits() > 0 && d.splits() != stored && !d.internal()) {
                LOG.warn("Dataset '{}' in {} was created with {} splits; config says {}. Using {}.", d.name(), partition,
                        stored, d.splits(), stored);
            }
            return stored;
        }
        if (!create) {
            throw new DataStoreException("Dataset '" + d.name() + "' does not exist in partition " + partition + " under "
                    + dir + " (run createAll() first)");
        }
        int splits = d.internal() ? 1 : d.splits() > 0 ? d.splits() : settings.getDefaultSplits();
        try {
            Files.createDirectories(dir);
            Properties p = new Properties();
            p.setProperty("splits", Integer.toString(splits));
            p.setProperty("key", d.keyType().getName());
            p.setProperty("key-fingerprint", d.keyCodec().fingerprint());
            p.setProperty("value", d.valueType().getName());
            Path tmp = Files.createTempFile(dir, META, ".tmp");
            try (OutputStream out = Files.newOutputStream(tmp)) {
                p.store(out, "data-store dataset metadata; do not edit");
            }
            try {
                Files.move(tmp, meta, StandardCopyOption.ATOMIC_MOVE);
            } catch (IOException raced) {
                Files.deleteIfExists(tmp);
                if (!Files.exists(meta)) {
                    throw raced;
                }
                return splits(d, dir, partition, false);
            }
        } catch (IOException e) {
            throw new DataStoreException("Cannot create " + dir, e);
        }
        return splits;
    }

    @Override
    public List<String> partitions() {
        if (!Files.isDirectory(namespaceDir)) {
            return List.of();
        }
        try (Stream<Path> dirs = Files.list(namespaceDir)) {
            return dirs.filter(Files::isDirectory)
                    .map(p -> p.getFileName().toString())
                    .filter(n -> PARTITION.matcher(n).matches())
                    .sorted()
                    .toList();
        } catch (IOException e) {
            throw new DataStoreException("Cannot list " + namespaceDir, e);
        }
    }

    @Override
    public synchronized void destroy(String partition) {
        Path dir = namespaceDir.resolve(partition);
        open.removeIf(m -> {
            if (m.dir.startsWith(dir)) {
                m.close();
                return true;
            }
            return false;
        });
        if (Files.exists(dir)) {
            try (Stream<Path> paths = Files.walk(dir)) {
                for (Path p : paths.sorted(Comparator.reverseOrder()).toList()) {
                    Files.deleteIfExists(p);
                }
            } catch (IOException e) {
                throw new DataStoreException("Cannot delete " + dir, e);
            }
        }
        try {
            Files.deleteIfExists(lockFile(partition));
        } catch (IOException ignored) {
            // another process may hold or recreate it
        }
    }

    @Override
    public AutoCloseable lock(String partition, boolean exclusive) {
        return FileLocks.acquire(lockFile(partition), exclusive);
    }

    @Override
    public synchronized void close() {
        open.forEach(ChronicleStoreMap::close);
        open.clear();
    }

    private Path lockFile(String partition) {
        return namespaceDir.resolve("." + partition + ".lock");
    }

    // ================================================================== one dataset

    private static final class ChronicleStoreMap<K> implements StoreMap<K> {
        final Path dir;
        private final KeyCodec<K> keys;
        private final List<ChronicleMap<byte[], byte[]>> maps;
        private final List<Path> files;
        private final AtomicBoolean closed = new AtomicBoolean();

        ChronicleStoreMap(DatasetSpec<K> d, Path dir, int splits, long perSplit, int keyBytes, boolean fixedKey,
                          int valueBytes, int segments) {
            this.dir = dir;
            this.keys = d.keyCodec();
            List<ChronicleMap<byte[], byte[]>> m = new ArrayList<>(splits);
            List<Path> f = new ArrayList<>(splits);
            try {
                for (int i = 0; i < splits; i++) {
                    Path file = dir.resolve(String.format("split-%04d.cm", i));
                    String name = d.name() + "-" + i;
                    m.add(SharedMaps.acquire(file, () -> create(file, name, perSplit, keyBytes, fixedKey, valueBytes, segments)));
                    f.add(file);
                }
            } catch (RuntimeException e) {
                f.forEach(SharedMaps::release);
                throw e;
            }
            this.maps = List.copyOf(m);
            this.files = List.copyOf(f);
        }

        private static ChronicleMap<byte[], byte[]> create(Path file, String name, long entries, int keyBytes,
                                                         boolean fixedKey, int valueBytes, int segments) {
            ChronicleMapBuilder<byte[], byte[]> b = ChronicleMapBuilder.of(byte[].class, byte[].class)
                    .name(name)
                    .entries(entries)
                    .averageValueSize(valueBytes);
            b = fixedKey ? b.constantKeySizeBySample(new byte[keyBytes]) : b.averageKeySize(keyBytes);
            if (segments > 0) {
                b = b.actualSegments(segments);
            }
            try {
                // creates the file, or maps the existing one (every JVM must use the same sizing: shared YAML)
                return b.createPersistedTo(file.toFile());
            } catch (IOException e) {
                throw new DataStoreException("Cannot open Chronicle map " + file, e);
            }
        }

        private ChronicleMap<byte[], byte[]> mapFor(byte[] key) {
            return maps.size() == 1 ? maps.get(0) : maps.get(Math.floorMod(KeyCodec.hash(key), maps.size()));
        }

        @Override
        public byte[] get(K key) {
            byte[] k = keys.encode(key);
            return mapFor(k).get(k);
        }

        @Override
        public Map<K, byte[]> getAll(Collection<K> ks) {
            Map<K, byte[]> out = new HashMap<>(ks.size() * 2);
            for (K key : ks) {                       // local memory reads: nothing to batch
                byte[] k = keys.encode(key);
                byte[] v = mapFor(k).get(k);
                if (v != null) {
                    out.put(key, v);
                }
            }
            return out;
        }

        @Override
        public void put(K key, byte[] value) {
            byte[] k = keys.encode(key);
            mapFor(k).put(k, value);
        }

        @Override
        public void putAll(Map<K, byte[]> entries) {
            entries.forEach(this::put);
        }

        @Override
        public boolean remove(K key) {
            byte[] k = keys.encode(key);
            return mapFor(k).remove(k) != null;
        }

        @Override
        public long size() {
            long n = 0;
            for (ChronicleMap<byte[], byte[]> m : maps) {
                n += m.longSize();
            }
            return n;
        }

        @Override
        public int splits() {
            return maps.size();
        }

        @Override
        public Stream<Map.Entry<K, byte[]>> scan(int split) {
            return maps.get(split).entrySet().stream()
                    .map(e -> new AbstractMap.SimpleImmutableEntry<>(keys.decode(e.getKey()), e.getValue()));
        }

        @Override
        public void clear() {
            maps.forEach(ChronicleMap::clear);
        }

        @Override
        public void close() {
            if (closed.compareAndSet(false, true)) {
                files.forEach(SharedMaps::release);
            }
        }
    }

    // ================================================================== map sharing within a JVM

    /** One ChronicleMap per file per JVM, reference-counted, so several DataStores share a mapping. */
    private static final class SharedMaps {
        private static final Map<Path, Object[]> MAPS = new HashMap<>();   // [map, refCount]

        @SuppressWarnings("unchecked")
        static synchronized ChronicleMap<byte[], byte[]> acquire(Path file,
                java.util.function.Supplier<ChronicleMap<byte[], byte[]>> opener) {
            Path key = file.toAbsolutePath().normalize();
            Object[] e = MAPS.get(key);
            if (e == null || !((ChronicleMap<?, ?>) e[0]).isOpen()) {
                e = new Object[]{opener.get(), 1};
                MAPS.put(key, e);
            } else {
                e[1] = (Integer) e[1] + 1;
            }
            return (ChronicleMap<byte[], byte[]>) e[0];
        }

        static synchronized void release(Path file) {
            Path key = file.toAbsolutePath().normalize();
            Object[] e = MAPS.get(key);
            if (e != null) {
                int refs = (Integer) e[1] - 1;
                if (refs <= 0) {
                    MAPS.remove(key);
                    ((ChronicleMap<?, ?>) e[0]).close();
                } else {
                    e[1] = refs;
                }
            }
        }
    }
}
