# data-store

Shared, partition-scoped storage for multi-job batch pipelines. Jobs in different JVMs hand data to each
other through one store instead of files. One store per pipeline, chosen in YAML; job code is identical
on all of them.

| Store | Module | Use |
|---|---|---|
| `memory` (default) | built into core | unit tests, local runs, single-JVM pipelines |
| `chronicle` | `data-store-chronicle` | one host: memory-mapped Chronicle Map files, no server |
| `ignite` | `data-store-ignite` | many hosts: Ignite 2 thin client |
| your own | implement `Store` | `store-type: com.acme.MyStore` |

Java 17 · Spring 7 (no Boot) · Jackson 3 · Fory · Chronicle Map 3 API · Ignite 2.18

## Modules and packages

```
data-store-core
  com.acme.datastore             DataStore, Dao, Manifest, DataStoreException
  com.acme.datastore.annotation  @Id, @Lookup, Resolve
  com.acme.datastore.config      DataStoreConfig (YAML/JSON model)
  com.acme.datastore.lookup      LookupResolver, LookupResult
  com.acme.datastore.spi         Store, StoreMap, DatasetSpec, KeyCodec, FileLocks   (for store authors)
  com.acme.datastore.store       MemoryStore (built-in default)
  com.acme.datastore.spring      DataStoreConfiguration, ExecutorContext
  com.acme.datastore.internal    Model (public for the library's own packages; not API)
  test fixtures: com.acme.datastore.testing.DataStoreContractTest + its domain
data-store-chronicle             com.acme.datastore.chronicle.ChronicleStore
data-store-ignite                com.acme.datastore.ignite.IgniteStore
samples/sample-domain            an "existing" domain lib (compileOnly on core, annotations only)
samples/sample-app               plain Spring 7 app + JUnit test of the whole pipeline on the memory store
```

19 classes in core and one per store module. A consumer depends on `data-store-core` plus one store
module. Domain libs need core only as `compileOnly` for the annotations, or nothing at all if relations
are configured in YAML.

## Configuration (YAML or JSON)

Every setting is in exactly one place. **Whole-store** settings are identical for every dataset. Anything
a dataset can set can also go in **`dataset-defaults`**, and a dataset overrides it field by field;
nested store blocks merge per field.

```yaml
datastore:
  # ---- whole store
  store-type: ${DATASTORE_STORE:chronicle}   # memory | chronicle | ignite | com.acme.MyStore
  namespace: risk-eod                        # who owns the data (isolates teams sharing a host/cluster)
  partition:                                 # which run: parts joined with "_" → NA_20261018
    parts:
      region: ${REGION:NA}
      business-date: "${RUN_DATE:20261018}"
  lookup-resolver:                           # the resolver engine
    parallelism: 4                           # target datasets fetched in parallel per level
    page-size: 1000                          # page size when streaming with EAGER lookups
    max-depth: 0                             # 0 = full graph
    single-read-warn: 10000                  # warn after N single findById calls resolving EAGER lookups

  chronicle:                                 # store-level settings (only the active store's are validated)
    base-dir: /dev/shm/grid
    default-splits: 16
  ignite:
    addresses: ["node1:10800"]

  # ---- per dataset, with defaults
  dataset-defaults:
    storage-mode: REFERENCE                  # REFERENCE (ids only) | EMBEDDED (whole graph)
    lookup-resolve-policy: LAZY              # default policy of this dataset's lookups: EAGER | LAZY
    on-missing-target: FAIL                  # when this dataset is a lookup TARGET and an id is missing: FAIL | NULL
    require-complete: true                   # refuse lookups into this dataset until it is COMPLETE
    splits: 8                                # parallel scan splits
    local-cache: false                       # per-JVM unbounded ConcurrentHashMap of encoded values
    chronicle: { entries: 1000000, avg-value-bytes: 256, avg-key-bytes: 16 }
    ignite: { backups: 1 }

  datasets:
    region:
      value: com.acme.Region
      local-cache: true                      # overrides dataset-defaults
      on-missing-target: NULL
      chronicle: { entries: 1000 }           # avg-value-bytes / avg-key-bytes inherited
      ignite: { cache-mode: REPLICATED }     # backups inherited
    order:
      value: com.acme.Order
      id: orderId                            # or [tradeId, legNo] with key:, or @Id on a field
      key: java.lang.Long                    # optional for a single-field id (inferred)
      lookups:                               # direct members only; or @Lookup on the field
        - { field: customerId, target: customer, into: customer, lookup-resolve-policy: EAGER }
        - { field: lines.sku, target: product, into: lines.product }
```

**Precedence:**
- Dataset settings: dataset, then `dataset-defaults`, then the built-in default.
- A lookup's policy: the lookup (YAML `lookup-resolve-policy` or `@Lookup(resolvePolicy=...)`), then
  the owning dataset's `lookup-resolve-policy`, then `dataset-defaults`, then LAZY.
- `dataset-defaults` cannot set `value`, `key`, `id` or `lookups`; those belong to one dataset.
- The effective settings of every dataset are logged at startup.

**Store-specific settings:**

| | Store level (whole store) | Dataset level (`datasets.*.<store>`, defaults in `dataset-defaults.<store>`) |
|---|---|---|
| chronicle | `base-dir` (required), `default-splits`, `headroom`, `segments-per-split` | `entries`, `avg-value-bytes` (required), `avg-key-bytes` (required unless the key is fixed size) |
| ignite | `addresses` (required), `partition-awareness`, `timeout-millis` | `cache-mode`, `atomicity-mode`, `backups`, `data-region`, `group-name`, `read-from-backup`, `write-synchronization-mode`, `partition-loss-policy`, `rebalance-mode`, `rebalance-batch-size`, `copy-on-read`, `statistics-enabled`, `affinity-field` (composite keys), `ignite-cache-partitions` |
| memory | none | none |

Unknown keys fail at startup with their full path, e.g. `datasets.order.ignite.bakups`.

`local-cache` is an unbounded `ConcurrentHashMap` per dataset per JVM. Enable it only for datasets that
fit in memory, typically reference data. It needs no invalidation, because a partition's data is written
once.

Placeholders `${NAME}` / `${NAME:default}` resolve from system properties and environment, or from the
Spring `Environment` when wired through Spring.

## Keys

Any immutable value with `equals`/`hashCode`:

- simple types: `String`, boxed primitives, `BigDecimal`, `BigInteger`, `LocalDate`, `LocalDateTime`,
  `LocalTime`, `Instant`, `UUID`, enums;
- composite: a record, or a final class with final fields, whose components are simple types.

`KeyCodec` encodes keys deterministically, so equal keys give the same bytes in every JVM. Chronicle
stores those bytes and splits by their hash. Ignite stores simple keys natively and composite keys as a
`BinaryObject` with one field per component. Component order is part of the format: after changing a key
class, use a new partition or namespace. Chronicle detects the change and refuses to open the dataset.

## Lookups and storage modes

```java
public class Order {                          // an existing domain class
    @Id private long orderId;

    @Lookup(dataset = "customer", into = "customer", resolvePolicy = Resolve.EAGER)
    private long customerId;
    private Customer customer;                // still used by older apps

    private List<OrderLine> lines;            // OrderLine has @Lookup(dataset = "product", into = "product") sku
}
```

**REFERENCE mode.**
- On write, only `customerId` is stored. The `into` field is left out of a copy, so your object is
  never changed.
- If `customerId` is empty, it is filled from `customer`'s id. If both are set and disagree, the save
  fails.
- On read, `customer` comes back null until it is resolved.

**EMBEDDED mode.** The whole graph is stored and read back as written, with reference tracking for
cycles. Only `into` fields that are still empty get resolved.

**Resolution:**
- **EAGER** lookups are filled on every DAO read.
- **LAZY** lookups are filled when asked:
  - `lookups.resolve(page)` (all), or `resolve(page, "lines.product")` (named);
  - `lookups.scope(page)` loads a lookup for the whole page on first `get`.
- **Per-call override:** `dao.findById(id, Resolve.LAZY | Resolve.EAGER)`.
- **Full depth.** Whatever is resolved is resolved completely: the target's own lookups and theirs, to
  any depth, whatever policy they have.
- **Bulk calls.** Each level costs one bulk call per target dataset, and the datasets of a level are
  fetched in parallel.
- **Cycles end.** Objects already loaded are reused, including the page's own objects.
- **Batches.** Use `findAllById`, `pages(split, size)` or `streamSplit` for batches. A warning is logged
  if `findById` is used in a loop with EAGER lookups.

## Using it

```java
@Configuration
@Import(DataStoreConfiguration.class)
@PropertySource("classpath:app.properties")       // datastore.config=classpath:datastore.yml
class AppConfig { }

@Component
class EnrichJob {
    EnrichJob(DataStore ds) { this.ds = ds; }
    void run() {
        ds.manifest().requireComplete("order", "customer");
        Dao<Order, Long> orders = ds.dao("order");
        for (int s = 0; s < orders.splits(); s++) {                 // splits can run in parallel
            try (var pages = orders.pages(s, 1_000, Resolve.EAGER)) {
                pages.forEach(page -> ds.dao("order-snapshot").saveAll(page));
            }
        }
        ds.manifest().complete("order-snapshot");                    // commit point for downstream jobs
    }
}
```

- **Unit tests:**

  ```java
  DataStore.builder().namespace("t").partition("P1").dataset("order", Order.class).build()
  ```

  Or load the production YAML with `.storeType("memory")`; see `samples/sample-app/.../PipelineTest`.
- **Flink and Spark executors:** `ExecutorContext.bean(DataStore.class, JobConfig.class)` gives one
  context per executor JVM.

## Lifecycle

- `ds.createAll()`: first step of a partition; idempotent.
- `ds.reset("dataset")`: clear one dataset to re-run its job.
- **Nothing is deleted automatically.**
  - `ds.destroyPartition("NA_20261017")` deletes another partition.
  - On Chronicle it refuses while a job holds the partition, via a file lock.
  - On Ignite there is no distributed lock; coordinate through the scheduler.
- **Manual Chronicle cleanup:** delete `<base-dir>/<namespace>/<partition>/` and its `.<partition>.lock`,
  only when no job uses that partition.

## Custom store

Implement `Store` and `StoreMap`. Values arrive as bytes, and keys as objects; use
`spec.keyCodec()` for bytes, field values or a stable hash. Declare your config classes through
`settingsType()` and `datasetSettingsType()`. Select the store by name (with a ServiceLoader file) or by
class name. Its dataset blocks are merged over `dataset-defaults.<name>` before binding, like the built-in
stores'. Verify it by extending `DataStoreContractTest` from the core test fixtures.
`core/src/test/.../CountingStore` is a complete example.

## Build

```bash
./gradlew build
./gradlew :data-store-ignite:test -Dignite.addresses=localhost:10800   # needs an Ignite 2 cluster
./gradlew :samples:sample-app:run --args="all"                          # chronicle under samples/sample-app/build/grid
./gradlew publish -PartifactoryPublishUrl=... -PartifactoryUser=... -PartifactoryPassword=...
```

## Verification status

The sandbox this was built in could not reach Maven Central. All modules were compiled with
`javac --release 17` against hand-written stand-ins for Spring, Jackson, Fory, Chronicle Map, Ignite and
JUnit. The stand-ins were made to behave like the real libraries where it matters:
- Fory deep-copies values and rejects cycles without reference tracking;
- Chronicle compares `byte[]` keys by content;
- Ignite rejects non-portable key types.

Results against those stand-ins:
- 96 tests pass: the contract on memory, a custom store, Chronicle and Ignite (22 each); 7 core tests;
  the sample pipeline test.
- The sample pipeline produces identical exports on Chronicle and Ignite.

Not yet verified against the real libraries:
- exact API signatures of Jackson 3, Fory 1.6, Chronicle Map and the Ignite 2 thin client;
- real cross-JVM sharing of Chronicle files;
- a live Ignite cluster.

Run `./gradlew build` once with Artifactory access and fix any signature drift the compiler reports.
