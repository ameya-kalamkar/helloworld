rootProject.name = "data-store"

include(
    "data-store-core",
    "data-store-chronicle",
    "data-store-ignite",
    "samples:sample-domain",
    "samples:sample-app",
)
